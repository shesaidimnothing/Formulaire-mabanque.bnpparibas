document.addEventListener('DOMContentLoaded', function() {
    const selectElement = document.querySelector('select.form-control');
    const showMoreOption = document.getElementById('showMoreOption');
    const optionsFieldset = document.getElementById('options');
    let firstScriptExecuted = false;
  
    // Premier script
    selectElement.addEventListener('change', function() {
      const selectedValue = this.value;
  
      console.log(`Sélectionné: ${selectedValue}`);
  
      if (selectedValue !== '') {
        console.log('valeur non vide');
        document.querySelectorAll('#div-ville, .immobilier-bottom-rows').forEach(element => {
          element.style.display = "block";
        });
      } else {
        console.log('valeur vide');
        document.querySelectorAll('#div-ville, .immobilier-bottom-rows').forEach(element => {
          element.style.display = "none";
        });
      }
  
      // Premier script éxécuté 
      firstScriptExecuted = true;
    });
  
    // Deuxième script
    showMoreOption.addEventListener('click', function() {
      if (!firstScriptExecuted) {
        console.log('Le premier script doit être exécuté avant de montrer plus d\'options.');
        return;
      }
  
      if (optionsFieldset.style.display === 'none' || optionsFieldset.style.display === '') {
        optionsFieldset.style.display = 'block';
      }
    });
  });
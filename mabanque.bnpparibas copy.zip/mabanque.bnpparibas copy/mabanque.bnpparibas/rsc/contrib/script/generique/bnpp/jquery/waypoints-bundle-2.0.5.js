! function(t, n, e, r, i) {
    (function() {
        var n = [].indexOf || function(t) {
                for (var n = 0, e = this.length; e > n; n++)
                    if (n in this && this[n] === t) return n;
                return -1
            },
            e = [].slice;
        ! function(t, n) {
            return "function" == typeof i && i.amd ? i("waypoints", ["jquery"], function(e) {
                return n(e, t)
            }) : n(t.jQuery, t)
        }(t, function(t, r) {
            var i, o, l, s, c, a, u, f, h, d, p, y, v, w, g, m;
            return i = t(r), f = n.call(r, "ontouchstart") >= 0, s = {
                horizontal: {},
                vertical: {}
            }, c = 1, u = {}, a = "waypoints-context-id", p = "resize.waypoints", y = "scroll.waypoints", v = 1, w = "waypoints-waypoint-ids", g = "waypoint", m = "waypoints", o = function() {
                function n(n) {
                    var e = this;
                    this.$element = n, this.element = n[0], this.didResize = !1, this.didScroll = !1, this.id = "context" + c++, this.oldScroll = {
                        x: n.scrollLeft(),
                        y: n.scrollTop()
                    }, this.waypoints = {
                        horizontal: {},
                        vertical: {}
                    }, this.element[a] = this.id, u[this.id] = this, n.bind(y, function() {
                        var n;
                        return e.didScroll || f ? void 0 : (e.didScroll = !0, n = function() {
                            return e.doScroll(), e.didScroll = !1
                        }, r.setTimeout(n, t[m].settings.scrollThrottle))
                    }), n.bind(p, function() {
                        var n;
                        return e.didResize ? void 0 : (e.didResize = !0, n = function() {
                            return t[m]("refresh"), e.didResize = !1
                        }, r.setTimeout(n, t[m].settings.resizeThrottle))
                    })
                }
                return n.prototype.doScroll = function() {
                    var n, e = this;
                    return n = {
                        horizontal: {
                            newScroll: this.$element.scrollLeft(),
                            oldScroll: this.oldScroll.x,
                            forward: "right",
                            backward: "left"
                        },
                        vertical: {
                            newScroll: this.$element.scrollTop(),
                            oldScroll: this.oldScroll.y,
                            forward: "down",
                            backward: "up"
                        }
                    }, !f || n.vertical.oldScroll && n.vertical.newScroll || t[m]("refresh"), t.each(n, function(n, r) {
                        var i, o, l;
                        return l = [], o = r.newScroll > r.oldScroll, i = o ? r.forward : r.backward, t.each(e.waypoints[n], function(t, n) {
                            var e, i;
                            return r.oldScroll < (e = n.offset) && e <= r.newScroll ? l.push(n) : r.newScroll < (i = n.offset) && i <= r.oldScroll ? l.push(n) : void 0
                        }), l.sort(function(t, n) {
                            return t.offset - n.offset
                        }), o || l.reverse(), t.each(l, function(t, n) {
                            return n.options.continuous || t === l.length - 1 ? n.trigger([i]) : void 0
                        })
                    }), this.oldScroll = {
                        x: n.horizontal.newScroll,
                        y: n.vertical.newScroll
                    }
                }, n.prototype.refresh = function() {
                    var n, e, r, i = this;
                    return r = t.isWindow(this.element), e = this.$element.offset(), this.doScroll(), n = {
                        horizontal: {
                            contextOffset: r ? 0 : e.left,
                            contextScroll: r ? 0 : this.oldScroll.x,
                            contextDimension: this.$element.width(),
                            oldScroll: this.oldScroll.x,
                            forward: "right",
                            backward: "left",
                            offsetProp: "left"
                        },
                        vertical: {
                            contextOffset: r ? 0 : e.top,
                            contextScroll: r ? 0 : this.oldScroll.y,
                            contextDimension: r ? t[m]("viewportHeight") : this.$element.height(),
                            oldScroll: this.oldScroll.y,
                            forward: "down",
                            backward: "up",
                            offsetProp: "top"
                        }
                    }, t.each(n, function(n, e) {
                        return t.each(i.waypoints[n], function(n, r) {
                            var i, o, l, s, c;
                            return i = r.options.offset, l = r.offset, o = t.isWindow(r.element) ? 0 : r.$element.offset()[e.offsetProp], t.isFunction(i) ? i = i.apply(r.element) : "string" == typeof i && (i = parseFloat(i), r.options.offset.indexOf("%") > -1 && (i = Math.ceil(e.contextDimension * i / 100))), r.offset = o - e.contextOffset + e.contextScroll - i, r.options.onlyOnScroll && null != l || !r.enabled ? void 0 : null !== l && l < (s = e.oldScroll) && s <= r.offset ? r.trigger([e.backward]) : null !== l && l > (c = e.oldScroll) && c >= r.offset ? r.trigger([e.forward]) : null === l && e.oldScroll >= r.offset ? r.trigger([e.forward]) : void 0
                        })
                    })
                }, n.prototype.checkEmpty = function() {
                    return t.isEmptyObject(this.waypoints.horizontal) && t.isEmptyObject(this.waypoints.vertical) ? (this.$element.unbind([p, y].join(" ")), delete u[this.id]) : void 0
                }, n
            }(), l = function() {
                function n(n, e, r) {
                    var i, o;
                    "bottom-in-view" === r.offset && (r.offset = function() {
                        var n;
                        return n = t[m]("viewportHeight"), t.isWindow(e.element) || (n = e.$element.height()), n - t(this).outerHeight()
                    }), this.$element = n, this.element = n[0], this.axis = r.horizontal ? "horizontal" : "vertical", this.callback = r.handler, this.context = e, this.enabled = r.enabled, this.id = "waypoints" + v++, this.offset = null, this.options = r, e.waypoints[this.axis][this.id] = this, s[this.axis][this.id] = this, i = null != (o = this.element[w]) ? o : [], i.push(this.id), this.element[w] = i
                }
                return n.prototype.trigger = function(t) {
                    return this.enabled ? (null != this.callback && this.callback.apply(this.element, t), this.options.triggerOnce ? this.destroy() : void 0) : void 0
                }, n.prototype.disable = function() {
                    return this.enabled = !1
                }, n.prototype.enable = function() {
                    return this.context.refresh(), this.enabled = !0
                }, n.prototype.destroy = function() {
                    return delete s[this.axis][this.id], delete this.context.waypoints[this.axis][this.id], this.context.checkEmpty()
                }, n.getWaypointsByElement = function(n) {
                    var e, r;
                    return (r = n[w]) ? (e = t.extend({}, s.horizontal, s.vertical), t.map(r, function(t) {
                        return e[t]
                    })) : []
                }, n
            }(), d = {
                init: function(n, e) {
                    var r;
                    return e = t.extend({}, t.fn[g].defaults, e), null == (r = e.handler) && (e.handler = n), this.each(function() {
                        var n, r, i, s;
                        return n = t(this), i = null != (s = e.context) ? s : t.fn[g].defaults.context, t.isWindow(i) || (i = n.closest(i)), i = t(i), r = u[i[0][a]], r || (r = new o(i)), new l(n, r, e)
                    }), t[m]("refresh"), this
                },
                disable: function() {
                    return d._invoke.call(this, "disable")
                },
                enable: function() {
                    return d._invoke.call(this, "enable")
                },
                destroy: function() {
                    return d._invoke.call(this, "destroy")
                },
                prev: function(t, n) {
                    return d._traverse.call(this, t, n, function(t, n, e) {
                        return n > 0 ? t.push(e[n - 1]) : void 0
                    })
                },
                next: function(t, n) {
                    return d._traverse.call(this, t, n, function(t, n, e) {
                        return n < e.length - 1 ? t.push(e[n + 1]) : void 0
                    })
                },
                _traverse: function(n, e, i) {
                    var o, l;
                    return null == n && (n = "vertical"), null == e && (e = r), l = h.aggregate(e), o = [], this.each(function() {
                        var e;
                        return e = t.inArray(this, l[n]), i(o, e, l[n])
                    }), this.pushStack(o)
                },
                _invoke: function(n) {
                    return this.each(function() {
                        var e;
                        return e = l.getWaypointsByElement(this), t.each(e, function(t, e) {
                            return e[n](), !0
                        })
                    }), this
                }
            }, t.fn[g] = function() {
                var n, r;
                return r = arguments[0], n = 2 <= arguments.length ? e.call(arguments, 1) : [], d[r] ? d[r].apply(this, n) : t.isFunction(r) ? d.init.apply(this, arguments) : t.isPlainObject(r) ? d.init.apply(this, [null, r]) : r ? t.error("The " + r + " method does not exist in jQuery Waypoints.") : t.error("jQuery Waypoints needs a callback function or handler option.")
            }, t.fn[g].defaults = {
                context: r,
                continuous: !0,
                enabled: !0,
                horizontal: !1,
                offset: 0,
                triggerOnce: !1
            }, h = {
                refresh: function() {
                    return t.each(u, function(t, n) {
                        return n.refresh()
                    })
                },
                viewportHeight: function() {
                    var t;
                    return null != (t = r.innerHeight) ? t : i.height()
                },
                aggregate: function(n) {
                    var e, r, i;
                    return e = s, n && (e = null != (i = u[t(n)[0][a]]) ? i.waypoints : void 0), e ? (r = {
                        horizontal: [],
                        vertical: []
                    }, t.each(r, function(n, i) {
                        return t.each(e[n], function(t, n) {
                            return i.push(n)
                        }), i.sort(function(t, n) {
                            return t.offset - n.offset
                        }), r[n] = t.map(i, function(t) {
                            return t.element
                        }), r[n] = t.unique(r[n])
                    }), r) : []
                },
                above: function(t) {
                    return null == t && (t = r), h._filter(t, "vertical", function(t, n) {
                        return n.offset <= t.oldScroll.y
                    })
                },
                below: function(t) {
                    return null == t && (t = r), h._filter(t, "vertical", function(t, n) {
                        return n.offset > t.oldScroll.y
                    })
                },
                left: function(t) {
                    return null == t && (t = r), h._filter(t, "horizontal", function(t, n) {
                        return n.offset <= t.oldScroll.x
                    })
                },
                right: function(t) {
                    return null == t && (t = r), h._filter(t, "horizontal", function(t, n) {
                        return n.offset > t.oldScroll.x
                    })
                },
                enable: function() {
                    return h._invoke("enable")
                },
                disable: function() {
                    return h._invoke("disable")
                },
                destroy: function() {
                    return h._invoke("destroy")
                },
                extendFn: function(t, n) {
                    return d[t] = n
                },
                _invoke: function(n) {
                    var e;
                    return e = t.extend({}, s.vertical, s.horizontal), t.each(e, function(t, e) {
                        return e[n](), !0
                    })
                },
                _filter: function(n, e, r) {
                    var i, o;
                    return (i = u[t(n)[0][a]]) ? (o = [], t.each(i.waypoints[e], function(t, n) {
                        return r(i, n) ? o.push(n) : void 0
                    }), o.sort(function(t, n) {
                        return t.offset - n.offset
                    }), t.map(o, function(t) {
                        return t.element
                    })) : []
                }
            }, t[m] = function() {
                var t, n;
                return n = arguments[0], t = 2 <= arguments.length ? e.call(arguments, 1) : [], h[n] ? h[n].apply(null, t) : h.aggregate.call(null, n)
            }, t[m].settings = {
                resizeThrottle: 100,
                scrollThrottle: 30
            }, i.on("load.waypoints", function() {
                return t[m]("refresh")
            })
        })
    }).call(this),
        function() {
            ! function(t, n) {
                return "function" == typeof i && i.amd ? i("waypoints-stickyelements", ["jquery", "waypoints"], n) : n(t.jQuery)
            }(t, function(t) {
                var n, e;
                return n = {
                    wrapper: '<div class="sticky-wrapper" />',
                    stuckClass: "stuck",
                    direction: "down right"
                }, e = function(t, n) {
                    var e;
                    return t.wrap(n.wrapper), e = t.parent(), e.data("isWaypointStickyWrapper", !0)
                }, t.waypoints("extendFn", "sticky", function(r) {
                    var i, o, l;
                    return o = t.extend({}, t.fn.waypoint.defaults, n, r), i = e(this, o), l = o.handler, o.handler = function(n) {
                        var e, r;
                        return e = t(this).children(":first"), r = -1 !== o.direction.indexOf(n), e.toggleClass(o.stuckClass, r), i.height(r ? e.outerHeight() : ""), null != l ? l.call(this, n) : void 0
                    }, i.waypoint(o), this.data("stuckClass", o.stuckClass)
                }), t.waypoints("extendFn", "unsticky", function() {
                    var t;
                    return t = this.parent(), t.data("isWaypointStickyWrapper") ? (t.waypoint("destroy"), this.unwrap(), this.removeClass(this.data("stuckClass"))) : this
                })
            })
        }.call(this), i("waypoints-bundle", function() {})
}(window, document, bnpp.sf31.requirejs, bnpp.sf31.requirejs, bnpp.sf31.define, bnpp.jquery, bnpp.jquery, bnpp.jquery);
//# sourceMappingURL=waypoints-bundle-2.0.5.js.map
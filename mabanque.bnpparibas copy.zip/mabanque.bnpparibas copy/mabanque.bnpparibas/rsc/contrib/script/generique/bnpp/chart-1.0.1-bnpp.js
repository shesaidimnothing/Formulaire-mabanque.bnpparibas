! function(t, i, e, s, o, h) {
    (function() {
        var e = this,
            s = e.Chart,
            h = function(t) {
                this.canvas = t.canvas, this.ctx = t;
                var e = function(t, e) {
                        return t["offset" + e] ? t["offset" + e] : i.defaultView.getComputedStyle(t).getPropertyValue(e)
                    },
                    s = this.width = e(t.canvas, "Width"),
                    o = this.height = e(t.canvas, "Height");
                return t.canvas.width = s, t.canvas.height = o, this.aspectRatio = this.width / this.height, a.retinaScale(this), this
            };
        h.defaults = {
            global: {
                animation: !0,
                animationSteps: 60,
                animationEasing: "easeOutQuart",
                showScale: !0,
                scaleOverride: !1,
                scaleSteps: null,
                scaleStepWidth: null,
                scaleStartValue: null,
                scaleLineColor: "rgba(0,0,0,.1)",
                scaleLineWidth: 1,
                scaleShowLabels: !0,
                scaleLabel: "<%=value%>",
                scaleIntegersOnly: !0,
                scaleBeginAtZero: !1,
                scaleFontFamily: "'Helvetica Neue', 'Helvetica', 'Arial', sans-serif",
                scaleFontSize: 12,
                scaleFontStyle: "normal",
                scaleFontColor: "#666",
                responsive: !1,
                maintainAspectRatio: !0,
                showTooltips: !0,
                customTooltips: !1,
                tooltipEvents: ["mousemove", "touchstart", "touchmove", "mouseout"],
                tooltipFillColor: "rgba(0,0,0,0.8)",
                tooltipFontFamily: "bnp_regular,Arial,sans-serif",
                tooltipFontSize: 14,
                tooltipFontStyle: "normal",
                tooltipFontColor: "#fff",
                tooltipTitleFontFamily: "'Helvetica Neue', 'Helvetica', 'Arial', sans-serif",
                tooltipTitleFontSize: 14,
                tooltipTitleFontStyle: "bold",
                tooltipTitleFontColor: "#fff",
                tooltipYPadding: 6,
                tooltipXPadding: 6,
                tooltipCaretSize: 8,
                tooltipCornerRadius: 6,
                tooltipXOffset: 10,
                tooltipTemplate: "<%if (label){%><%=label%>: <%}%><%= value %>",
                multiTooltipTemplate: "<%= value %>",
                multiTooltipKeyBackground: "#fff",
                onAnimationProgress: function() {},
                onAnimationComplete: function() {}
            }
        }, h.types = {};
        var a = h.helpers = {},
            n = a.each = function(t, i, e) {
                var s = Array.prototype.slice.call(arguments, 3);
                if (t)
                    if (t.length === +t.length) {
                        var o;
                        for (o = 0; o < t.length; o++) i.apply(e, [t[o], o].concat(s))
                    } else
                        for (var h in t) i.apply(e, [t[h], h].concat(s))
            },
            r = a.clone = function(t) {
                var i = {};
                return n(t, function(e, s) {
                    t.hasOwnProperty(s) && (i[s] = e)
                }), i
            },
            l = a.extend = function(t) {
                return n(Array.prototype.slice.call(arguments, 1), function(i) {
                    n(i, function(e, s) {
                        i.hasOwnProperty(s) && (t[s] = e)
                    })
                }), t
            },
            c = a.merge = function() {
                var t = Array.prototype.slice.call(arguments, 0);
                return t.unshift({}), l.apply(null, t)
            },
            d = a.indexOf = function(t, i) {
                if (Array.prototype.indexOf) return t.indexOf(i);
                for (var e = 0; e < t.length; e++)
                    if (t[e] === i) return e;
                return -1
            },
            p = (a.where = function(t, i) {
                var e = [];
                return a.each(t, function(t) {
                    i(t) && e.push(t)
                }), e
            }, a.findNextWhere = function(t, i, e) {
                e || (e = -1);
                for (var s = e + 1; s < t.length; s++) {
                    var o = t[s];
                    if (i(o)) return o
                }
            }, a.findPreviousWhere = function(t, i, e) {
                e || (e = t.length);
                for (var s = e - 1; s >= 0; s--) {
                    var o = t[s];
                    if (i(o)) return o
                }
            }, a.inherits = function(t) {
                var i = this,
                    e = t && t.hasOwnProperty("constructor") ? t.constructor : function() {
                        return i.apply(this, arguments)
                    },
                    s = function() {
                        this.constructor = e
                    };
                return s.prototype = i.prototype, e.prototype = new s, e.extend = p, t && l(e.prototype, t), e.__super__ = i.prototype, e
            }),
            u = a.noop = function() {},
            f = a.uid = function() {
                var t = 0;
                return function() {
                    return "chart-" + t++
                }
            }(),
            g = a.warn = function(i) {
                t.console && "function" == typeof t.console.warn && console.warn(i)
            },
            x = (a.amd = "function" == typeof o && o.amd, a.isNumber = function(t) {
                return !isNaN(parseFloat(t)) && isFinite(t)
            }),
            m = a.max = function(t) {
                return Math.max.apply(Math, t)
            },
            b = a.min = function(t) {
                return Math.min.apply(Math, t)
            },
            v = (a.cap = function(t, i, e) {
                if (x(i)) {
                    if (t > i) return i
                } else if (x(e) && e > t) return e;
                return t
            }, a.getDecimalPlaces = function(t) {
                return 0 !== t % 1 && x(t) ? t.toString().split(".")[1].length : 0
            }),
            S = a.radians = function(t) {
                return t * (Math.PI / 180)
            },
            y = (a.getAngleFromPoint = function(t, i) {
                var e = i.x - t.x,
                    s = i.y - t.y,
                    o = Math.sqrt(e * e + s * s),
                    h = 2 * Math.PI + Math.atan2(s, e);
                return 0 > e && 0 > s && (h += 2 * Math.PI), {
                    angle: h,
                    distance: o
                }
            }, a.aliasPixel = function(t) {
                return 0 === t % 2 ? 0 : .5
            }),
            C = (a.splineCurve = function(t, i, e, s) {
                var o = Math.sqrt(Math.pow(i.x - t.x, 2) + Math.pow(i.y - t.y, 2)),
                    h = Math.sqrt(Math.pow(e.x - i.x, 2) + Math.pow(e.y - i.y, 2)),
                    a = s * o / (o + h),
                    n = s * h / (o + h);
                return {
                    inner: {
                        x: i.x - a * (e.x - t.x),
                        y: i.y - a * (e.y - t.y)
                    },
                    outer: {
                        x: i.x + n * (e.x - t.x),
                        y: i.y + n * (e.y - t.y)
                    }
                }
            }, a.calculateOrderOfMagnitude = function(t) {
                return Math.floor(Math.log(t) / Math.LN10)
            }),
            w = (a.calculateScaleRange = function(t, i, e, s, o) {
                var h = 2,
                    a = Math.floor(i / (1.5 * e)),
                    n = h >= a,
                    r = m(t),
                    l = b(t);
                r === l && (r += .5, l >= .5 && !s ? l -= .5 : r += .5);
                for (var c = Math.abs(r - l), d = C(c), p = Math.ceil(r / (1 * Math.pow(10, d))) * Math.pow(10, d), u = s ? 0 : Math.floor(l / (1 * Math.pow(10, d))) * Math.pow(10, d), f = p - u, g = Math.pow(10, d), x = Math.round(f / g);
                    (x > a || a > 2 * x) && !n;)
                    if (x > a) g *= 2, x = Math.round(f / g), 0 !== x % 1 && (n = !0);
                    else if (o && d >= 0) {
                    if (0 !== g / 2 % 1) break;
                    g /= 2, x = Math.round(f / g)
                } else g /= 2, x = Math.round(f / g);
                return n && (x = h, g = f / x), {
                    steps: x,
                    stepValue: g,
                    min: u,
                    max: u + x * g
                }
            }, a.template = function(t, i) {
                function e(t, i) {
                    var e = /\W/.test(t) ? new Function("obj", "var p=[],print=function(){p.push.apply(p,arguments);};with(obj){p.push('" + t.replace(/[\r\t\n]/g, " ").split("<%").join("	").replace(/((^|%>)[^\t]*)'/g, "$1\r").replace(/\t=(.*?)%>/g, "',$1,'").split("	").join("');").split("%>").join("p.push('").split("\r").join("\\'") + "');}return p.join('');") : s[t] = s[t];
                    return i ? e(i) : e
                }
                if (t instanceof Function) return t(i);
                var s = {};
                return e(t, i)
            }),
            P = (a.generateLabels = function(t, i, e, s) {
                var o = new Array(i);
                return labelTemplateString && n(o, function(i, h) {
                    o[h] = w(t, {
                        value: e + s * (h + 1)
                    })
                }), o
            }, a.easingEffects = {
                linear: function(t) {
                    return t
                },
                easeInQuad: function(t) {
                    return t * t
                },
                easeOutQuad: function(t) {
                    return -1 * t * (t - 2)
                },
                easeInOutQuad: function(t) {
                    return (t /= .5) < 1 ? .5 * t * t : -.5 * (--t * (t - 2) - 1)
                },
                easeInCubic: function(t) {
                    return t * t * t
                },
                easeOutCubic: function(t) {
                    return 1 * ((t = t / 1 - 1) * t * t + 1)
                },
                easeInOutCubic: function(t) {
                    return (t /= .5) < 1 ? .5 * t * t * t : .5 * ((t -= 2) * t * t + 2)
                },
                easeInQuart: function(t) {
                    return t * t * t * t
                },
                easeOutQuart: function(t) {
                    return -1 * ((t = t / 1 - 1) * t * t * t - 1)
                },
                easeInOutQuart: function(t) {
                    return (t /= .5) < 1 ? .5 * t * t * t * t : -.5 * ((t -= 2) * t * t * t - 2)
                },
                easeInQuint: function(t) {
                    return 1 * (t /= 1) * t * t * t * t
                },
                easeOutQuint: function(t) {
                    return 1 * ((t = t / 1 - 1) * t * t * t * t + 1)
                },
                easeInOutQuint: function(t) {
                    return (t /= .5) < 1 ? .5 * t * t * t * t * t : .5 * ((t -= 2) * t * t * t * t + 2)
                },
                easeInSine: function(t) {
                    return -1 * Math.cos(t / 1 * (Math.PI / 2)) + 1
                },
                easeOutSine: function(t) {
                    return 1 * Math.sin(t / 1 * (Math.PI / 2))
                },
                easeInOutSine: function(t) {
                    return -.5 * (Math.cos(Math.PI * t / 1) - 1)
                },
                easeInExpo: function(t) {
                    return 0 === t ? 1 : 1 * Math.pow(2, 10 * (t / 1 - 1))
                },
                easeOutExpo: function(t) {
                    return 1 === t ? 1 : 1 * (-Math.pow(2, -10 * t / 1) + 1)
                },
                easeInOutExpo: function(t) {
                    return 0 === t ? 0 : 1 === t ? 1 : (t /= .5) < 1 ? .5 * Math.pow(2, 10 * (t - 1)) : .5 * (-Math.pow(2, -10 * --t) + 2)
                },
                easeInCirc: function(t) {
                    return t >= 1 ? t : -1 * (Math.sqrt(1 - (t /= 1) * t) - 1)
                },
                easeOutCirc: function(t) {
                    return 1 * Math.sqrt(1 - (t = t / 1 - 1) * t)
                },
                easeInOutCirc: function(t) {
                    return (t /= .5) < 1 ? -.5 * (Math.sqrt(1 - t * t) - 1) : .5 * (Math.sqrt(1 - (t -= 2) * t) + 1)
                },
                easeInElastic: function(t) {
                    var i = 1.70158,
                        e = 0,
                        s = 1;
                    return 0 === t ? 0 : 1 == (t /= 1) ? 1 : (e || (e = .3), s < Math.abs(1) ? (s = 1, i = e / 4) : i = e / (2 * Math.PI) * Math.asin(1 / s), -(s * Math.pow(2, 10 * (t -= 1)) * Math.sin(2 * (1 * t - i) * Math.PI / e)))
                },
                easeOutElastic: function(t) {
                    var i = 1.70158,
                        e = 0,
                        s = 1;
                    return 0 === t ? 0 : 1 == (t /= 1) ? 1 : (e || (e = .3), s < Math.abs(1) ? (s = 1, i = e / 4) : i = e / (2 * Math.PI) * Math.asin(1 / s), s * Math.pow(2, -10 * t) * Math.sin(2 * (1 * t - i) * Math.PI / e) + 1)
                },
                easeInOutElastic: function(t) {
                    var i = 1.70158,
                        e = 0,
                        s = 1;
                    return 0 === t ? 0 : 2 == (t /= .5) ? 1 : (e || (e = .3 * 1.5), s < Math.abs(1) ? (s = 1, i = e / 4) : i = e / (2 * Math.PI) * Math.asin(1 / s), 1 > t ? -.5 * s * Math.pow(2, 10 * (t -= 1)) * Math.sin(2 * (1 * t - i) * Math.PI / e) : .5 * s * Math.pow(2, -10 * (t -= 1)) * Math.sin(2 * (1 * t - i) * Math.PI / e) + 1)
                },
                easeInBack: function(t) {
                    var i = 1.70158;
                    return 1 * (t /= 1) * t * ((i + 1) * t - i)
                },
                easeOutBack: function(t) {
                    var i = 1.70158;
                    return 1 * ((t = t / 1 - 1) * t * ((i + 1) * t + i) + 1)
                },
                easeInOutBack: function(t) {
                    var i = 1.70158;
                    return (t /= .5) < 1 ? .5 * t * t * (((i *= 1.525) + 1) * t - i) : .5 * ((t -= 2) * t * (((i *= 1.525) + 1) * t + i) + 2)
                },
                easeInBounce: function(t) {
                    return 1 - P.easeOutBounce(1 - t)
                },
                easeOutBounce: function(t) {
                    return (t /= 1) < 1 / 2.75 ? 7.5625 * t * t : 2 / 2.75 > t ? 1 * (7.5625 * (t -= 1.5 / 2.75) * t + .75) : 2.5 / 2.75 > t ? 1 * (7.5625 * (t -= 2.25 / 2.75) * t + .9375) : 1 * (7.5625 * (t -= 2.625 / 2.75) * t + .984375)
                },
                easeInOutBounce: function(t) {
                    return .5 > t ? .5 * P.easeInBounce(2 * t) : .5 * P.easeOutBounce(2 * t - 1) + .5
                }
            }),
            T = a.requestAnimFrame = function() {
                return t.requestAnimationFrame || t.webkitRequestAnimationFrame || t.mozRequestAnimationFrame || t.oRequestAnimationFrame || t.msRequestAnimationFrame || function(i) {
                    return t.setTimeout(i, 1e3 / 60)
                }
            }(),
            L = (a.cancelAnimFrame = function() {
                return t.cancelAnimationFrame || t.webkitCancelAnimationFrame || t.mozCancelAnimationFrame || t.oCancelAnimationFrame || t.msCancelAnimationFrame || function(i) {
                    return t.clearTimeout(i, 1e3 / 60)
                }
            }(), a.animationLoop = function(t, i, e, s, o, h) {
                var a = 0,
                    n = P[e] || P.linear,
                    r = function() {
                        a++;
                        var e = a / i,
                            l = n(e);
                        t.call(h, l, e, a), s.call(h, l, e), i > a ? h.animationFrame = T(r) : o.apply(h)
                    };
                T(r)
            }, a.getRelativePosition = function(t) {
                var i, e, s = t.originalEvent || t,
                    o = t.currentTarget || t.srcElement,
                    h = o.getBoundingClientRect();
                return s.touches ? (i = s.touches[0].clientX - h.left, e = s.touches[0].clientY - h.top) : (i = s.clientX - h.left, e = s.clientY - h.top), {
                    x: i,
                    y: e
                }
            }, a.addEvent = function(t, i, e) {
                t.addEventListener ? t.addEventListener(i, e) : t.attachEvent ? t.attachEvent("on" + i, e) : t["on" + i] = e
            }),
            M = a.removeEvent = function(t, i, e) {
                t.removeEventListener ? t.removeEventListener(i, e, !1) : t.detachEvent ? t.detachEvent("on" + i, e) : t["on" + i] = u
            },
            k = (a.bindEvents = function(t, i, e) {
                t.events || (t.events = {}), n(i, function(i) {
                    t.events[i] = function() {
                        e.apply(t, arguments)
                    }, L(t.chart.canvas, i, t.events[i])
                })
            }, a.unbindEvents = function(t, i) {
                n(i, function(i, e) {
                    M(t.chart.canvas, e, i)
                })
            }),
            W = a.getMaximumWidth = function(t) {
                var i = t.parentNode;
                return i.clientWidth
            },
            B = a.getMaximumHeight = function(t) {
                var i = t.parentNode;
                return i.clientHeight
            },
            F = (a.getMaximumSize = a.getMaximumWidth, a.retinaScale = function(i) {
                var e = i.ctx,
                    s = i.canvas.width,
                    o = i.canvas.height;
                t.devicePixelRatio && (e.canvas.style.width = s + "px", e.canvas.style.height = o + "px", e.canvas.height = o * t.devicePixelRatio, e.canvas.width = s * t.devicePixelRatio, e.scale(t.devicePixelRatio, t.devicePixelRatio))
            }),
            R = a.clear = function(t) {
                t.ctx.clearRect(0, 0, t.width, t.height)
            },
            A = a.fontString = function(t, i, e) {
                return i + " " + t + "px " + e
            },
            z = a.longestText = function(t, i, e) {
                t.font = i;
                var s = 0;
                return n(e, function(i) {
                    var e = t.measureText(i).width;
                    s = e > s ? e : s
                }), s
            },
            O = a.drawRoundedRectangle = function(t, i, e, s, o, h) {
                t.beginPath(), t.moveTo(i + h, e), t.lineTo(i + s - h, e), t.quadraticCurveTo(i + s, e, i + s, e + h), t.lineTo(i + s, e + o - h), t.quadraticCurveTo(i + s, e + o, i + s - h, e + o), t.lineTo(i + h, e + o), t.quadraticCurveTo(i, e + o, i, e + o - h), t.lineTo(i, e + h), t.quadraticCurveTo(i, e, i + h, e), t.closePath()
            };
        h.instances = {}, h.Type = function(t, i, e) {
            this.options = i, this.chart = e, this.id = f(), h.instances[this.id] = this, i.responsive && this.resize(), this.initialize.call(this, t)
        }, l(h.Type.prototype, {
            initialize: function() {
                return this
            },
            clear: function() {
                return R(this.chart), this
            },
            stop: function() {
                return a.cancelAnimFrame.call(e, this.animationFrame), this
            },
            resize: function(t) {
                this.stop();
                var i = this.chart.canvas,
                    e = W(this.chart.canvas),
                    s = this.options.maintainAspectRatio ? e / this.chart.aspectRatio : B(this.chart.canvas);
                return i.width = this.chart.width = e, i.height = this.chart.height = s, F(this.chart), "function" == typeof t && t.apply(this, Array.prototype.slice.call(arguments, 1)), this
            },
            reflow: u,
            render: function(t) {
                return t && this.reflow(), this.options.animation && !t ? a.animationLoop(this.draw, this.options.animationSteps, this.options.animationEasing, this.options.onAnimationProgress, this.options.onAnimationComplete, this) : (this.draw(), this.options.onAnimationComplete.call(this)), this
            },
            generateLegend: function() {
                return w(this.options.legendTemplate, this)
            },
            destroy: function() {
                this.clear(), k(this, this.events);
                var t = this.chart.canvas;
                t.width = this.chart.width, t.height = this.chart.height, t.style.removeProperty ? (t.style.removeProperty("width"), t.style.removeProperty("height")) : (t.style.removeAttribute("width"), t.style.removeAttribute("height")), delete h.instances[this.id]
            },
            showTooltip: function(t, i) {
                "undefined" == typeof this.activeElements && (this.activeElements = []);
                var e = function(t) {
                    var i = !1;
                    return t.length !== this.activeElements.length ? i = !0 : (n(t, function(t, e) {
                        t !== this.activeElements[e] && (i = !0)
                    }, this), i)
                }.call(this, t);
                if (e || i) {
                    if (this.activeElements = t, this.draw(), this.options.customTooltips && this.options.customTooltips(!1), t.length > 0)
                        if (this.datasets && this.datasets.length > 1) {
                            for (var s, o, r = this.datasets.length - 1; r >= 0 && (s = this.datasets[r].points || this.datasets[r].bars || this.datasets[r].segments, o = d(s, t[0]), -1 === o); r--);
                            var l = [],
                                c = [],
                                p = function() {
                                    var t, i, e, s, h, n = [],
                                        r = [],
                                        d = [];
                                    return a.each(this.datasets, function(i) {
                                        t = i.points || i.bars || i.segments, t[o] && t[o].hasValue() && n.push(t[o])
                                    }), a.each(n, function(t) {
                                        r.push(t.x), d.push(t.y), l.push(a.template(this.options.multiTooltipTemplate, t)), c.push({
                                            fill: t._saved.fillColor || t.fillColor,
                                            stroke: t._saved.strokeColor || t.strokeColor
                                        })
                                    }, this), h = b(d), e = m(d), s = b(r), i = m(r), {
                                        x: s > this.chart.width / 2 ? s : i,
                                        y: (h + e) / 2
                                    }
                                }.call(this, o);
                            new h.MultiTooltip({
                                x: p.x,
                                y: p.y,
                                xPadding: this.options.tooltipXPadding,
                                yPadding: this.options.tooltipYPadding,
                                xOffset: this.options.tooltipXOffset,
                                fillColor: this.options.tooltipFillColor,
                                textColor: this.options.tooltipFontColor,
                                fontFamily: this.options.tooltipFontFamily,
                                fontStyle: this.options.tooltipFontStyle,
                                fontSize: this.options.tooltipFontSize,
                                titleTextColor: this.options.tooltipTitleFontColor,
                                titleFontFamily: this.options.tooltipTitleFontFamily,
                                titleFontStyle: this.options.tooltipTitleFontStyle,
                                titleFontSize: this.options.tooltipTitleFontSize,
                                cornerRadius: this.options.tooltipCornerRadius,
                                labels: l,
                                legendColors: c,
                                legendColorBackground: this.options.multiTooltipKeyBackground,
                                title: t[0].label,
                                chart: this.chart,
                                ctx: this.chart.ctx,
                                custom: this.options.customTooltips,
                                selectedEl: this.activeElements
                            }).draw()
                        } else n(t, function(t) {
                            var i = t.tooltipPosition();
                            new h.Tooltip({
                                x: Math.round(i.x),
                                y: Math.round(i.y),
                                xPadding: this.options.tooltipXPadding,
                                yPadding: this.options.tooltipYPadding,
                                fillColor: this.options.tooltipFillColor,
                                textColor: this.options.tooltipFontColor,
                                fontFamily: this.options.tooltipFontFamily,
                                fontStyle: this.options.tooltipFontStyle,
                                fontSize: this.options.tooltipFontSize,
                                caretHeight: this.options.tooltipCaretSize,
                                cornerRadius: this.options.tooltipCornerRadius,
                                text: w(this.options.tooltipTemplate, t),
                                chart: this.chart,
                                custom: this.options.customTooltips,
                                selectedEl: this.activeElements,
                                forceTooltip: this.options.forceTooltip
                            }).draw()
                        }, this);
                    return this
                }
            },
            toBase64Image: function() {
                return this.chart.canvas.toDataURL.apply(this.chart.canvas, arguments)
            }
        }), h.Type.extend = function(t) {
            var i = this,
                e = function() {
                    return i.apply(this, arguments)
                };
            if (e.prototype = r(i.prototype), l(e.prototype, t), e.extend = h.Type.extend, t.name || i.prototype.name) {
                var s = t.name || i.prototype.name,
                    o = h.defaults[i.prototype.name] ? r(h.defaults[i.prototype.name]) : {};
                h.defaults[s] = l(o, t.defaults), h.types[s] = e, h.prototype[s] = function(t, i) {
                    var o = c(h.defaults.global, h.defaults[s], i || {});
                    return new e(t, o, this)
                }
            } else g("Name not provided for this chart, so it hasn't been registered");
            return i
        }, h.Element = function(t) {
            l(this, t), this.initialize.apply(this, arguments), this.save()
        }, l(h.Element.prototype, {
            initialize: function() {},
            restore: function(t) {
                return t ? n(t, function(t) {
                    this[t] = this._saved[t]
                }, this) : l(this, this._saved), this
            },
            save: function() {
                return this._saved = r(this), delete this._saved._saved, this
            },
            update: function(t) {
                return n(t, function(t, i) {
                    this._saved[i] = this[i], this[i] = t
                }, this), this
            },
            transition: function(t, i) {
                return n(t, function(t, e) {
                    this[e] = (t - this._saved[e]) * i + this._saved[e]
                }, this), this
            },
            tooltipPosition: function() {
                return {
                    x: this.x,
                    y: this.y
                }
            },
            hasValue: function() {
                return x(this.value)
            }
        }), h.Element.extend = p, h.Point = h.Element.extend({
            display: !0,
            inRange: function(t, i) {
                var e = this.hitDetectionRadius + this.radius;
                return Math.pow(t - this.x, 2) + Math.pow(i - this.y, 2) < Math.pow(e, 2)
            },
            draw: function() {
                if (this.display) {
                    var t = this.ctx;
                    t.beginPath(), t.arc(this.x, this.y, this.radius, 0, 2 * Math.PI), t.closePath(), t.strokeStyle = this.strokeColor, t.lineWidth = this.strokeWidth, t.fillStyle = this.fillColor, t.fill(), t.stroke()
                }
            }
        }), h.Arc = h.Element.extend({
            inRange: function(t, i) {
                var e = a.getAngleFromPoint(this, {
                        x: t,
                        y: i
                    }),
                    s = e.angle >= this.startAngle && e.angle <= this.endAngle,
                    o = e.distance >= this.innerRadius && e.distance <= this.outerRadius;
                return s && o
            },
            tooltipPosition: function() {
                var t = this.startAngle + (this.endAngle - this.startAngle) / 2,
                    i = (this.outerRadius - this.innerRadius) / 2 + this.innerRadius;
                return {
                    x: this.x + Math.cos(t) * i,
                    y: this.y + Math.sin(t) * i
                }
            },
            draw: function() {
                var t = this.ctx;
                t.beginPath(), t.arc(this.x, this.y, this.outerRadius, this.startAngle, this.endAngle), t.arc(this.x, this.y, this.innerRadius, this.endAngle, this.startAngle, !0), t.closePath(), t.strokeStyle = this.strokeColor, t.lineWidth = this.strokeWidth, t.fillStyle = this.fillColor, t.fill(), t.lineJoin = "bevel", this.showStroke && t.stroke()
            }
        }), h.Rectangle = h.Element.extend({
            draw: function() {
                var t = this.ctx,
                    i = this.width / 2,
                    e = this.x - i,
                    s = this.x + i,
                    o = this.base - (this.base - this.y),
                    h = this.strokeWidth / 2;
                this.showStroke && (e += h, s -= h, o += h), t.beginPath(), t.fillStyle = this.fillColor, t.strokeStyle = this.strokeColor, t.lineWidth = this.strokeWidth, t.moveTo(e, this.base), t.lineTo(e, o), t.lineTo(s, o), t.lineTo(s, this.base), t.fill(), this.showStroke && t.stroke()
            },
            height: function() {
                return this.base - this.y
            },
            inRange: function(t, i) {
                return t >= this.x - this.width / 2 && t <= this.x + this.width / 2 && i >= this.y && i <= this.base
            }
        }), h.Tooltip = h.Element.extend({
            draw: function() {
                var t = this.chart.ctx;
                t.font = A(this.fontSize, this.fontStyle, this.fontFamily), this.xAlign = "center", this.yAlign = "above";
                var i = this.caretPadding = 2,
                    e = t.measureText(this.text).width + 2 * this.xPadding,
                    s = this.fontSize + 2 * this.yPadding,
                    o = s + this.caretHeight + i;
                this.x + e / 2 > this.chart.width ? this.xAlign = "left" : this.x - e / 2 < 0 && (this.xAlign = "right"), this.y - o < 0 && (this.yAlign = "below");
                var h = this.x - e / 2,
                    a = this.y - o;
                if (t.fillStyle = this.fillColor, this.custom && !this.forceTooltip) this.custom(this);
                else {
                    switch (this.custom && this.custom(this), this.yAlign) {
                        case "above":
                            t.beginPath(), t.moveTo(this.x, this.y - i), t.lineTo(this.x + this.caretHeight, this.y - (i + this.caretHeight)), t.lineTo(this.x - this.caretHeight, this.y - (i + this.caretHeight)), t.closePath(), t.fill();
                            break;
                        case "below":
                            a = this.y + i + this.caretHeight, t.beginPath(), t.moveTo(this.x, this.y + i), t.lineTo(this.x + this.caretHeight, this.y + i + this.caretHeight), t.lineTo(this.x - this.caretHeight, this.y + i + this.caretHeight), t.closePath(), t.fill()
                    }
                    switch (this.xAlign) {
                        case "left":
                            h = this.x - e + (this.cornerRadius + this.caretHeight);
                            break;
                        case "right":
                            h = this.x - (this.cornerRadius + this.caretHeight)
                    }
                    O(t, h, a, e, s, this.cornerRadius), t.fill(), t.fillStyle = this.textColor, t.textAlign = "center", t.textBaseline = "middle", t.fillText(this.text, h + e / 2, a + s / 2)
                }
            }
        }), h.MultiTooltip = h.Element.extend({
            initialize: function() {
                this.font = A(this.fontSize, this.fontStyle, this.fontFamily), this.titleFont = A(this.titleFontSize, this.titleFontStyle, this.titleFontFamily), this.height = this.labels.length * this.fontSize + (this.labels.length - 1) * (this.fontSize / 2) + 2 * this.yPadding + 1.5 * this.titleFontSize, this.ctx.font = this.titleFont;
                var t = this.ctx.measureText(this.title).width,
                    i = z(this.ctx, this.font, this.labels) + this.fontSize + 3,
                    e = m([i, t]);
                this.width = e + 2 * this.xPadding;
                var s = this.height / 2;
                this.y - s < 0 ? this.y = s : this.y + s > this.chart.height && (this.y = this.chart.height - s), this.x > this.chart.width / 2 ? this.x -= this.xOffset + this.width : this.x += this.xOffset
            },
            getLineHeight: function(t) {
                var i = this.y - this.height / 2 + this.yPadding,
                    e = t - 1;
                return 0 === t ? i + this.titleFontSize / 2 : i + (1.5 * this.fontSize * e + this.fontSize / 2) + 1.5 * this.titleFontSize
            },
            draw: function() {
                if (this.custom) this.custom(this);
                else {
                    O(this.ctx, this.x, this.y - this.height / 2, this.width, this.height, this.cornerRadius);
                    var t = this.ctx;
                    t.fillStyle = this.fillColor, t.fill(), t.closePath(), t.textAlign = "left", t.textBaseline = "middle", t.fillStyle = this.titleTextColor, t.font = this.titleFont, t.fillText(this.title, this.x + this.xPadding, this.getLineHeight(0)), t.font = this.font, a.each(this.labels, function(i, e) {
                        t.fillStyle = this.textColor, t.fillText(i, this.x + this.xPadding + this.fontSize + 3, this.getLineHeight(e + 1)), t.fillStyle = this.legendColorBackground, t.fillRect(this.x + this.xPadding, this.getLineHeight(e + 1) - this.fontSize / 2, this.fontSize, this.fontSize), t.fillStyle = this.legendColors[e].fill, t.fillRect(this.x + this.xPadding, this.getLineHeight(e + 1) - this.fontSize / 2, this.fontSize, this.fontSize)
                    }, this)
                }
            }
        }), h.Scale = h.Element.extend({
            initialize: function() {
                this.fit()
            },
            buildYLabels: function() {
                this.yLabels = [];
                for (var t = v(this.stepValue), i = 0; i <= this.steps; i++) this.yLabels.push(w(this.templateString, {
                    value: (this.min + i * this.stepValue).toFixed(t)
                }));
                this.yLabelWidth = this.display && this.showLabels ? z(this.ctx, this.font, this.yLabels) : 0
            },
            addXLabel: function(t) {
                this.xLabels.push(t), this.valuesCount++, this.fit()
            },
            removeXLabel: function() {
                this.xLabels.shift(), this.valuesCount--, this.fit()
            },
            fit: function() {
                this.startPoint = this.display ? this.fontSize : 0, this.endPoint = this.display ? this.height - 1.5 * this.fontSize - 5 : this.height, this.startPoint += this.padding, this.endPoint -= this.padding;
                var t, i = this.endPoint - this.startPoint;
                for (this.calculateYRange(i), this.buildYLabels(), this.calculateXLabelRotation(); i > this.endPoint - this.startPoint;) i = this.endPoint - this.startPoint, t = this.yLabelWidth, this.calculateYRange(i), this.buildYLabels(), t < this.yLabelWidth && this.calculateXLabelRotation()
            },
            calculateXLabelRotation: function() {
                this.ctx.font = this.font;
                var t, i, e = this.ctx.measureText(this.xLabels[0]).width,
                    s = this.ctx.measureText(this.xLabels[this.xLabels.length - 1]).width;
                if (this.xScalePaddingRight = s / 2 + 3, this.xScalePaddingLeft = e / 2 > this.yLabelWidth + 10 ? e / 2 : this.yLabelWidth + 10, this.xLabelRotation = 0, this.display) {
                    var o, h = z(this.ctx, this.font, this.xLabels);
                    this.xLabelWidth = h;
                    for (var a = Math.floor(this.calculateX(1) - this.calculateX(0)) - 6; this.xLabelWidth > a && 0 === this.xLabelRotation || this.xLabelWidth > a && this.xLabelRotation <= 90 && this.xLabelRotation > 0;) o = Math.cos(S(this.xLabelRotation)), t = o * e, i = o * s, t + this.fontSize / 2 > this.yLabelWidth + 8 && (this.xScalePaddingLeft = t + this.fontSize / 2), this.xScalePaddingRight = this.fontSize / 2, this.xLabelRotation++, this.xLabelWidth = o * h;
                    this.xLabelRotation > 0 && (this.endPoint -= Math.sin(S(this.xLabelRotation)) * h + 3)
                } else this.xLabelWidth = 0, this.xScalePaddingRight = this.padding, this.xScalePaddingLeft = this.padding
            },
            calculateYRange: u,
            drawingArea: function() {
                return this.startPoint - this.endPoint
            },
            calculateY: function(t) {
                var i = this.drawingArea() / (this.min - this.max);
                return this.endPoint - i * (t - this.min)
            },
            calculateX: function(t) {
                var i = (this.xLabelRotation > 0, this.width - (this.xScalePaddingLeft + this.xScalePaddingRight)),
                    e = i / (this.valuesCount - (this.offsetGridLines ? 0 : 1)),
                    s = e * t + this.xScalePaddingLeft;
                return this.offsetGridLines && (s += e / 2), Math.round(s)
            },
            update: function(t) {
                a.extend(this, t), this.fit()
            },
            draw: function() {
                var t = this.ctx,
                    i = (this.endPoint - this.startPoint) / this.steps,
                    e = Math.round(this.xScalePaddingLeft);
                this.display && (t.fillStyle = this.textColor, t.font = this.font, n(this.yLabels, function(s, o) {
                    var h = this.endPoint - i * o,
                        n = Math.round(h),
                        r = this.showHorizontalLines;
                    t.textAlign = "right", t.textBaseline = "middle", this.showLabels && t.fillText(s, e - 10, h), 0 !== o || r || (r = !0), r && t.beginPath(), o > 0 ? (t.lineWidth = this.gridLineWidth, t.strokeStyle = this.gridLineColor) : (t.lineWidth = this.lineWidth, t.strokeStyle = this.lineColor), n += a.aliasPixel(t.lineWidth), r && (t.moveTo(e, n), t.lineTo(this.width, n), t.stroke(), t.closePath()), t.lineWidth = this.lineWidth, t.strokeStyle = this.lineColor, t.beginPath(), t.moveTo(e - 5, n), t.lineTo(e, n), t.stroke(), t.closePath()
                }, this), n(this.xLabels, function(i, e) {
                    var s = this.calculateX(e) + y(this.lineWidth),
                        o = this.calculateX(e - (this.offsetGridLines ? .5 : 0)) + y(this.lineWidth),
                        h = this.xLabelRotation > 0,
                        a = this.showVerticalLines;
                    0 !== e || a || (a = !0), a && t.beginPath(), e > 0 ? (t.lineWidth = this.gridLineWidth, t.strokeStyle = this.gridLineColor) : (t.lineWidth = this.lineWidth, t.strokeStyle = this.lineColor), a && (t.moveTo(o, this.endPoint), t.lineTo(o, this.startPoint - 3), t.stroke(), t.closePath()), t.lineWidth = this.lineWidth, t.strokeStyle = this.lineColor, t.beginPath(), t.moveTo(o, this.endPoint), t.lineTo(o, this.endPoint + 5), t.stroke(), t.closePath(), t.save(), t.translate(s, h ? this.endPoint + 12 : this.endPoint + 8), t.rotate(-1 * S(this.xLabelRotation)), t.font = this.font, t.textAlign = h ? "right" : "center", t.textBaseline = h ? "middle" : "top", t.fillText(i, 0, 0), t.restore()
                }, this))
            }
        }), h.RadialScale = h.Element.extend({
            initialize: function() {
                this.size = b([this.height, this.width]), this.drawingArea = this.display ? this.size / 2 - (this.fontSize / 2 + this.backdropPaddingY) : this.size / 2
            },
            calculateCenterOffset: function(t) {
                var i = this.drawingArea / (this.max - this.min);
                return (t - this.min) * i
            },
            update: function() {
                this.lineArc ? this.drawingArea = this.display ? this.size / 2 - (this.fontSize / 2 + this.backdropPaddingY) : this.size / 2 : this.setScaleSize(), this.buildYLabels()
            },
            buildYLabels: function() {
                this.yLabels = [];
                for (var t = v(this.stepValue), i = 0; i <= this.steps; i++) this.yLabels.push(w(this.templateString, {
                    value: (this.min + i * this.stepValue).toFixed(t)
                }))
            },
            getCircumference: function() {
                return 2 * Math.PI / this.valuesCount
            },
            setScaleSize: function() {
                var t, i, e, s, o, h, a, n, r, l, c, d, p = b([this.height / 2 - this.pointLabelFontSize - 5, this.width / 2]),
                    u = this.width,
                    f = 0;
                for (this.ctx.font = A(this.pointLabelFontSize, this.pointLabelFontStyle, this.pointLabelFontFamily), i = 0; i < this.valuesCount; i++) t = this.getPointPosition(i, p), e = this.ctx.measureText(w(this.templateString, {
                    value: this.labels[i]
                })).width + 5, 0 === i || i === this.valuesCount / 2 ? (s = e / 2, t.x + s > u && (u = t.x + s, o = i), t.x - s < f && (f = t.x - s, a = i)) : i < this.valuesCount / 2 ? t.x + e > u && (u = t.x + e, o = i) : i > this.valuesCount / 2 && t.x - e < f && (f = t.x - e, a = i);
                r = f, l = Math.ceil(u - this.width), h = this.getIndexAngle(o), n = this.getIndexAngle(a), c = l / Math.sin(h + Math.PI / 2), d = r / Math.sin(n + Math.PI / 2), c = x(c) ? c : 0, d = x(d) ? d : 0, this.drawingArea = p - (d + c) / 2, this.setCenterPoint(d, c)
            },
            setCenterPoint: function(t, i) {
                var e = this.width - i - this.drawingArea,
                    s = t + this.drawingArea;
                this.xCenter = (s + e) / 2, this.yCenter = this.height / 2
            },
            getIndexAngle: function(t) {
                var i = 2 * Math.PI / this.valuesCount;
                return t * i - Math.PI / 2
            },
            getPointPosition: function(t, i) {
                var e = this.getIndexAngle(t);
                return {
                    x: Math.cos(e) * i + this.xCenter,
                    y: Math.sin(e) * i + this.yCenter
                }
            },
            draw: function() {
                if (this.display) {
                    var t = this.ctx;
                    if (n(this.yLabels, function(i, e) {
                            if (e > 0) {
                                var s, o = e * (this.drawingArea / this.steps),
                                    h = this.yCenter - o;
                                if (this.lineWidth > 0)
                                    if (t.strokeStyle = this.lineColor, t.lineWidth = this.lineWidth, this.lineArc) t.beginPath(), t.arc(this.xCenter, this.yCenter, o, 0, 2 * Math.PI), t.closePath(), t.stroke();
                                    else {
                                        t.beginPath();
                                        for (var a = 0; a < this.valuesCount; a++) s = this.getPointPosition(a, this.calculateCenterOffset(this.min + e * this.stepValue)), 0 === a ? t.moveTo(s.x, s.y) : t.lineTo(s.x, s.y);
                                        t.closePath(), t.stroke()
                                    }
                                if (this.showLabels) {
                                    if (t.font = A(this.fontSize, this.fontStyle, this.fontFamily), this.showLabelBackdrop) {
                                        var n = t.measureText(i).width;
                                        t.fillStyle = this.backdropColor, t.fillRect(this.xCenter - n / 2 - this.backdropPaddingX, h - this.fontSize / 2 - this.backdropPaddingY, n + 2 * this.backdropPaddingX, this.fontSize + 2 * this.backdropPaddingY)
                                    }
                                    t.textAlign = "center", t.textBaseline = "middle", t.fillStyle = this.fontColor, t.fillText(i, this.xCenter, h)
                                }
                            }
                        }, this), !this.lineArc) {
                        t.lineWidth = this.angleLineWidth, t.strokeStyle = this.angleLineColor;
                        for (var i = this.valuesCount - 1; i >= 0; i--) {
                            if (this.angleLineWidth > 0) {
                                var e = this.getPointPosition(i, this.calculateCenterOffset(this.max));
                                t.beginPath(), t.moveTo(this.xCenter, this.yCenter), t.lineTo(e.x, e.y), t.stroke(), t.closePath()
                            }
                            var s = this.getPointPosition(i, this.calculateCenterOffset(this.max) + 5);
                            t.font = A(this.pointLabelFontSize, this.pointLabelFontStyle, this.pointLabelFontFamily), t.fillStyle = this.pointLabelFontColor;
                            var o = this.labels.length,
                                h = this.labels.length / 2,
                                a = h / 2,
                                r = a > i || i > o - a,
                                l = i === a || i === o - a;
                            t.textAlign = 0 === i ? "center" : i === h ? "center" : h > i ? "left" : "right", t.textBaseline = l ? "middle" : r ? "bottom" : "top", t.fillText(this.labels[i], s.x, s.y)
                        }
                    }
                }
            }
        }), a.addEvent(t, "resize", function() {
            var t;
            return function() {
                clearTimeout(t), t = setTimeout(function() {
                    n(h.instances, function(t) {
                        t.options.responsive && t.resize(t.render, !0)
                    })
                }, 50)
            }
        }()), e.Chart = h, h.noConflict = function() {
            return e.Chart = s, h
        }
    }).call(this),
        function() {
            var t = this,
                i = t.Chart,
                e = i.helpers,
                s = {
                    scaleBeginAtZero: !0,
                    scaleShowGridLines: !0,
                    scaleGridLineColor: "rgba(0,0,0,.05)",
                    scaleGridLineWidth: 1,
                    scaleShowHorizontalLines: !0,
                    scaleShowVerticalLines: !0,
                    barShowStroke: !0,
                    barStrokeWidth: 2,
                    barValueSpacing: 5,
                    barDatasetSpacing: 1,
                    legendTemplate: '<ul class="<%=name.toLowerCase()%>-legend"><% for (var i=0; i<datasets.length; i++){%><li><span style="background-color:<%=datasets[i].fillColor%>"></span><%if(datasets[i].label){%><%=datasets[i].label%><%}%></li><%}%></ul>'
                };
            i.Type.extend({
                name: "Bar",
                defaults: s,
                initialize: function(t) {
                    var s = this.options;
                    this.ScaleClass = i.Scale.extend({
                        offsetGridLines: !0,
                        calculateBarX: function(t, i, e) {
                            var o = this.calculateBaseWidth(),
                                h = this.calculateX(e) - o / 2,
                                a = this.calculateBarWidth(t);
                            return h + a * i + i * s.barDatasetSpacing + a / 2
                        },
                        calculateBaseWidth: function() {
                            return this.calculateX(1) - this.calculateX(0) - 2 * s.barValueSpacing
                        },
                        calculateBarWidth: function(t) {
                            var i = this.calculateBaseWidth() - (t - 1) * s.barDatasetSpacing;
                            return i / t
                        }
                    }), this.datasets = [], this.options.showTooltips && e.bindEvents(this, this.options.tooltipEvents, function(t) {
                        var i = "mouseout" !== t.type ? this.getBarsAtEvent(t) : [];
                        this.eachBars(function(t) {
                            t.restore(["fillColor", "strokeColor"])
                        });
                        var s = this.options.hoverClass || "hover";
                        h(this.chart.canvas).removeClass(s), i.length > 0 && (this.eachBars(function(t) {
                            null != t.lowerFill && (t.fillColor = t.lowerFill)
                        }), h(this.chart.canvas).addClass(s)), e.each(i, function(t) {
                            t.fillColor = t.highlightFill, t.strokeColor = t.highlightStroke
                        }), this.showTooltip(i)
                    }), this.BarClass = i.Rectangle.extend({
                        strokeWidth: this.options.barStrokeWidth,
                        showStroke: this.options.barShowStroke,
                        ctx: this.chart.ctx
                    }), e.each(t.datasets, function(i) {
                        var s = {
                            label: i.label || null,
                            fillColor: i.fillColor,
                            strokeColor: i.strokeColor,
                            bars: []
                        };
                        this.datasets.push(s), e.each(i.data, function(e, o) {
                            s.bars.push(new this.BarClass({
                                value: e,
                                label: t.labels[o],
                                datasetLabel: i.label,
                                strokeColor: i.strokeColor,
                                fillColor: i.fillColor,
                                highlightFill: i.highlightFill || i.fillColor,
                                highlightStroke: i.highlightStroke || i.strokeColor,
                                lowerFill: i.lowerFill || null
                            }))
                        }, this)
                    }, this), this.buildScale(t.labels), this.BarClass.prototype.base = this.scale.endPoint, this.eachBars(function(t, i, s) {
                        e.extend(t, {
                            width: this.scale.calculateBarWidth(this.datasets.length),
                            x: this.scale.calculateBarX(this.datasets.length, s, i),
                            y: this.scale.endPoint
                        }), t.save()
                    }, this), this.render()
                },
                update: function() {
                    this.scale.update(), e.each(this.activeElements, function(t) {
                        t.restore(["fillColor", "strokeColor"])
                    }), this.eachBars(function(t) {
                        t.save()
                    }), this.render()
                },
                eachBars: function(t) {
                    e.each(this.datasets, function(i, s) {
                        e.each(i.bars, t, this, s)
                    }, this)
                },
                getBarsAtEvent: function(t) {
                    for (var i, s = [], o = e.getRelativePosition(t), h = function(t) {
                            s.push(t.bars[i])
                        }, a = 0; a < this.datasets.length; a++)
                        for (i = 0; i < this.datasets[a].bars.length; i++)
                            if (this.datasets[a].bars[i].inRange(o.x, o.y)) return e.each(this.datasets, h), s;
                    return s
                },
                buildScale: function(t) {
                    var i = this,
                        s = function() {
                            var t = [];
                            return i.eachBars(function(i) {
                                t.push(i.value)
                            }), t
                        },
                        o = {
                            templateString: this.options.scaleLabel,
                            height: this.chart.height,
                            width: this.chart.width,
                            ctx: this.chart.ctx,
                            textColor: this.options.scaleFontColor,
                            fontSize: this.options.scaleFontSize,
                            fontStyle: this.options.scaleFontStyle,
                            fontFamily: this.options.scaleFontFamily,
                            valuesCount: t.length,
                            beginAtZero: this.options.scaleBeginAtZero,
                            integersOnly: this.options.scaleIntegersOnly,
                            calculateYRange: function(t) {
                                var i = e.calculateScaleRange(s(), t, this.fontSize, this.beginAtZero, this.integersOnly);
                                e.extend(this, i)
                            },
                            xLabels: t,
                            font: e.fontString(this.options.scaleFontSize, this.options.scaleFontStyle, this.options.scaleFontFamily),
                            lineWidth: this.options.scaleLineWidth,
                            lineColor: this.options.scaleLineColor,
                            showHorizontalLines: this.options.scaleShowHorizontalLines,
                            showVerticalLines: this.options.scaleShowVerticalLines,
                            gridLineWidth: this.options.scaleShowGridLines ? this.options.scaleGridLineWidth : 0,
                            gridLineColor: this.options.scaleShowGridLines ? this.options.scaleGridLineColor : "rgba(0,0,0,0)",
                            padding: this.options.showScale ? 0 : this.options.barShowStroke ? this.options.barStrokeWidth : 0,
                            showLabels: this.options.scaleShowLabels,
                            display: this.options.showScale
                        };
                    this.options.scaleOverride && e.extend(o, {
                        calculateYRange: e.noop,
                        steps: this.options.scaleSteps,
                        stepValue: this.options.scaleStepWidth,
                        min: this.options.scaleStartValue,
                        max: this.options.scaleStartValue + this.options.scaleSteps * this.options.scaleStepWidth
                    }), this.scale = new this.ScaleClass(o)
                },
                addData: function(t, i) {
                    e.each(t, function(t, e) {
                        this.datasets[e].bars.push(new this.BarClass({
                            value: t,
                            label: i,
                            x: this.scale.calculateBarX(this.datasets.length, e, this.scale.valuesCount + 1),
                            y: this.scale.endPoint,
                            width: this.scale.calculateBarWidth(this.datasets.length),
                            base: this.scale.endPoint,
                            strokeColor: this.datasets[e].strokeColor,
                            fillColor: this.datasets[e].fillColor
                        }))
                    }, this), this.scale.addXLabel(i), this.update()
                },
                removeData: function() {
                    this.scale.removeXLabel(), e.each(this.datasets, function(t) {
                        t.bars.shift()
                    }, this), this.update()
                },
                reflow: function() {
                    e.extend(this.BarClass.prototype, {
                        y: this.scale.endPoint,
                        base: this.scale.endPoint
                    });
                    var t = e.extend({
                        height: this.chart.height,
                        width: this.chart.width
                    });
                    this.scale.update(t)
                },
                draw: function(t) {
                    var i = t || 1;
                    this.clear(), this.chart.ctx, this.scale.draw(i), e.each(this.datasets, function(t, s) {
                        e.each(t.bars, function(t, e) {
                            t.hasValue() && (t.base = this.scale.endPoint, t.transition({
                                x: this.scale.calculateBarX(this.datasets.length, s, e),
                                y: this.scale.calculateY(t.value),
                                width: this.scale.calculateBarWidth(this.datasets.length)
                            }, i).draw())
                        }, this)
                    }, this)
                }
            })
        }.call(this),
        function() {
            var t = this,
                i = t.Chart,
                e = i.helpers,
                s = {
                    segmentShowStroke: !1,
                    segmentStrokeColor: "#fff",
                    segmentStrokeWidth: 2,
                    percentageInnerCutout: 85,
                    animationSteps: 30,
                    animationEasing: "easeOutQuad",
                    animateRotate: !0,
                    animateScale: !1,
                    legendTemplate: '<ul class="<%=name.toLowerCase()%>-legend"><% for (var i=0; i<segments.length; i++){%><li><span style="background-color:<%=segments[i].fillColor%>"></span><%if(segments[i].label){%><%=segments[i].label%><%}%></li><%}%></ul>'
                };
            i.Type.extend({
                name: "Doughnut",
                defaults: s,
                initialize: function(t) {
                    this.segments = [], this.outerRadius = (e.min([this.chart.width, this.chart.height]) - this.options.segmentStrokeWidth / 2) / 2, this.SegmentArc = i.Arc.extend({
                        ctx: this.chart.ctx,
                        x: this.chart.width / 2,
                        y: this.chart.height / 2
                    }), this.options.showTooltips && e.bindEvents(this, this.options.tooltipEvents, function(t) {
                        var i = "mouseout" !== t.type ? this.getSegmentsAtEvent(t) : [];
                        e.each(this.segments, function(t) {
                            t.restore(["fillColor"])
                        }), e.each(i, function(t) {
                            t.fillColor = t.highlightColor
                        }), this.showTooltip(i)
                    }), this.calculateTotal(t), e.each(t, function(t, i) {
                        this.addData(t, i, !0)
                    }, this), this.render()
                },
                getSegmentsAtEvent: function(t) {
                    var i = [],
                        s = e.getRelativePosition(t);
                    return e.each(this.segments, function(t, e) {
                        t.inRange(s.x, s.y) && (t.index = e, i.push(t))
                    }, this), i
                },
                addData: function(t, i, e) {
                    var s = i || this.segments.length;
                    this.segments.splice(s, 0, new this.SegmentArc({
                        value: t.value,
                        outerRadius: this.options.animateScale ? 0 : this.outerRadius,
                        innerRadius: this.options.animateScale ? 0 : this.outerRadius / 100 * this.options.percentageInnerCutout,
                        fillColor: t.color,
                        highlightColor: t.highlight || t.color,
                        showStroke: this.options.segmentShowStroke,
                        strokeWidth: this.options.segmentStrokeWidth,
                        strokeColor: this.options.segmentStrokeColor,
                        startAngle: 1.5 * Math.PI,
                        circumference: this.options.animateRotate ? 0 : this.calculateCircumference(t.value),
                        label: t.label,
                        montant: "undefined" != typeof t.montant ? t.montant : null
                    })), e || (this.reflow(), this.update())
                },
                calculateCircumference: function(t) {
                    return 2 * Math.PI * (t / this.total)
                },
                calculateTotal: function(t) {
                    this.total = 0, e.each(t, function(t) {
                        this.total += t.value
                    }, this)
                },
                update: function() {
                    this.calculateTotal(this.segments), e.each(this.activeElements, function(t) {
                        t.restore(["fillColor"])
                    }), e.each(this.segments, function(t) {
                        t.save()
                    }), this.render()
                },
                removeData: function(t) {
                    var i = e.isNumber(t) ? t : this.segments.length - 1;
                    this.segments.splice(i, 1), this.reflow(), this.update()
                },
                reflow: function() {
                    e.extend(this.SegmentArc.prototype, {
                        x: this.chart.width / 2,
                        y: this.chart.height / 2
                    }), this.outerRadius = (e.min([this.chart.width, this.chart.height]) - this.options.segmentStrokeWidth / 2) / 2, e.each(this.segments, function(t) {
                        t.update({
                            outerRadius: this.outerRadius,
                            innerRadius: this.outerRadius / 100 * this.options.percentageInnerCutout
                        })
                    }, this)
                },
                draw: function(t) {
                    var i = t ? t : 1;
                    this.clear(), e.each(this.segments, function(t, e) {
                        t.transition({
                            circumference: this.calculateCircumference(t.value),
                            outerRadius: this.outerRadius,
                            innerRadius: this.outerRadius / 100 * this.options.percentageInnerCutout
                        }, i), t.endAngle = t.startAngle + t.circumference, t.draw(), 0 === e && (t.startAngle = 1.5 * Math.PI), e < this.segments.length - 1 && (this.segments[e + 1].startAngle = t.endAngle)
                    }, this)
                }
            }), i.types.Doughnut.extend({
                name: "Pie",
                defaults: e.merge(s, {
                    percentageInnerCutout: 0
                })
            })
        }.call(this),
        function() {
            var t = this,
                i = t.Chart,
                e = i.helpers,
                s = {
                    scaleShowGridLines: !0,
                    scaleGridLineColor: "rgba(0,0,0,.05)",
                    scaleGridLineWidth: 1,
                    scaleShowHorizontalLines: !0,
                    scaleShowVerticalLines: !0,
                    bezierCurve: !0,
                    bezierCurveTension: .4,
                    pointDot: !0,
                    pointDotRadius: 4,
                    pointDotStrokeWidth: 1,
                    pointHitDetectionRadius: 20,
                    datasetStroke: !0,
                    datasetStrokeWidth: 2,
                    datasetFill: !0,
                    legendTemplate: '<ul class="<%=name.toLowerCase()%>-legend"><% for (var i=0; i<datasets.length; i++){%><li><span style="background-color:<%=datasets[i].strokeColor%>"></span><%if(datasets[i].label){%><%=datasets[i].label%><%}%></li><%}%></ul>'
                };
            i.Type.extend({
                name: "Line",
                defaults: s,
                initialize: function(t) {
                    this.PointClass = i.Point.extend({
                        strokeWidth: this.options.pointDotStrokeWidth,
                        radius: this.options.pointDotRadius,
                        display: this.options.pointDot,
                        hitDetectionRadius: this.options.pointHitDetectionRadius,
                        ctx: this.chart.ctx,
                        inRange: function(t) {
                            return Math.pow(t - this.x, 2) < Math.pow(this.radius + this.hitDetectionRadius, 2)
                        }
                    }), this.datasets = [], this.options.showTooltips && e.bindEvents(this, this.options.tooltipEvents, function(t) {
                        var i = "mouseout" !== t.type ? this.getPointsAtEvent(t) : [];
                        this.eachPoints(function(t) {
                            t.restore(["fillColor", "strokeColor"])
                        }), e.each(i, function(t) {
                            t.fillColor = t.highlightFill, t.strokeColor = t.highlightStroke
                        }), this.showTooltip(i)
                    }), e.each(t.datasets, function(i) {
                        var s = {
                            label: i.label || null,
                            fillColor: i.fillColor,
                            strokeColor: i.strokeColor,
                            pointColor: i.pointColor,
                            pointStrokeColor: i.pointStrokeColor,
                            points: []
                        };
                        this.datasets.push(s), e.each(i.data, function(e, o) {
                            s.points.push(new this.PointClass({
                                value: e,
                                label: t.labels[o],
                                datasetLabel: i.label,
                                strokeColor: i.pointStrokeColor,
                                fillColor: i.pointColor,
                                highlightFill: i.pointHighlightFill || i.pointColor,
                                highlightStroke: i.pointHighlightStroke || i.pointStrokeColor
                            }))
                        }, this), this.buildScale(t.labels), this.eachPoints(function(t, i) {
                            e.extend(t, {
                                x: this.scale.calculateX(i),
                                y: this.scale.endPoint
                            }), t.save()
                        }, this)
                    }, this), this.render()
                },
                update: function() {
                    this.scale.update(), e.each(this.activeElements, function(t) {
                        t.restore(["fillColor", "strokeColor"])
                    }), this.eachPoints(function(t) {
                        t.save()
                    }), this.render()
                },
                eachPoints: function(t) {
                    e.each(this.datasets, function(i) {
                        e.each(i.points, t, this)
                    }, this)
                },
                getPointsAtEvent: function(t) {
                    var i = [],
                        s = e.getRelativePosition(t);
                    return e.each(this.datasets, function(t) {
                        e.each(t.points, function(t) {
                            t.inRange(s.x, s.y) && i.push(t)
                        })
                    }, this), i
                },
                buildScale: function(t) {
                    var s = this,
                        o = function() {
                            var t = [];
                            return s.eachPoints(function(i) {
                                t.push(i.value)
                            }), t
                        },
                        h = {
                            templateString: this.options.scaleLabel,
                            height: this.chart.height,
                            width: this.chart.width,
                            ctx: this.chart.ctx,
                            textColor: this.options.scaleFontColor,
                            fontSize: this.options.scaleFontSize,
                            fontStyle: this.options.scaleFontStyle,
                            fontFamily: this.options.scaleFontFamily,
                            valuesCount: t.length,
                            beginAtZero: this.options.scaleBeginAtZero,
                            integersOnly: this.options.scaleIntegersOnly,
                            calculateYRange: function(t) {
                                var i = e.calculateScaleRange(o(), t, this.fontSize, this.beginAtZero, this.integersOnly);
                                e.extend(this, i)
                            },
                            xLabels: t,
                            font: e.fontString(this.options.scaleFontSize, this.options.scaleFontStyle, this.options.scaleFontFamily),
                            lineWidth: this.options.scaleLineWidth,
                            lineColor: this.options.scaleLineColor,
                            showHorizontalLines: this.options.scaleShowHorizontalLines,
                            showVerticalLines: this.options.scaleShowVerticalLines,
                            gridLineWidth: this.options.scaleShowGridLines ? this.options.scaleGridLineWidth : 0,
                            gridLineColor: this.options.scaleShowGridLines ? this.options.scaleGridLineColor : "rgba(0,0,0,0)",
                            padding: this.options.showScale ? 0 : this.options.pointDotRadius + this.options.pointDotStrokeWidth,
                            showLabels: this.options.scaleShowLabels,
                            display: this.options.showScale
                        };
                    this.options.scaleOverride && e.extend(h, {
                        calculateYRange: e.noop,
                        steps: this.options.scaleSteps,
                        stepValue: this.options.scaleStepWidth,
                        min: this.options.scaleStartValue,
                        max: this.options.scaleStartValue + this.options.scaleSteps * this.options.scaleStepWidth
                    }), this.scale = new i.Scale(h)
                },
                addData: function(t, i) {
                    e.each(t, function(t, e) {
                        this.datasets[e].points.push(new this.PointClass({
                            value: t,
                            label: i,
                            x: this.scale.calculateX(this.scale.valuesCount + 1),
                            y: this.scale.endPoint,
                            strokeColor: this.datasets[e].pointStrokeColor,
                            fillColor: this.datasets[e].pointColor
                        }))
                    }, this), this.scale.addXLabel(i), this.update()
                },
                removeData: function() {
                    this.scale.removeXLabel(), e.each(this.datasets, function(t) {
                        t.points.shift()
                    }, this), this.update()
                },
                reflow: function() {
                    var t = e.extend({
                        height: this.chart.height,
                        width: this.chart.width
                    });
                    this.scale.update(t)
                },
                draw: function(t) {
                    var i = t || 1;
                    this.clear();
                    var s = this.chart.ctx,
                        o = function(t) {
                            return null !== t.value
                        },
                        h = function(t, i, s) {
                            return e.findNextWhere(i, o, s) || t
                        },
                        a = function(t, i, s) {
                            return e.findPreviousWhere(i, o, s) || t
                        };
                    this.scale.draw(i), e.each(this.datasets, function(t) {
                        var n = e.where(t.points, o);
                        e.each(t.points, function(t, e) {
                            t.hasValue() && t.transition({
                                y: this.scale.calculateY(t.value),
                                x: this.scale.calculateX(e)
                            }, i)
                        }, this), this.options.bezierCurve && e.each(n, function(t, i) {
                            var s = i > 0 && i < n.length - 1 ? this.options.bezierCurveTension : 0;
                            t.controlPoints = e.splineCurve(a(t, n, i), t, h(t, n, i), s), t.controlPoints.outer.y > this.scale.endPoint ? t.controlPoints.outer.y = this.scale.endPoint : t.controlPoints.outer.y < this.scale.startPoint && (t.controlPoints.outer.y = this.scale.startPoint), t.controlPoints.inner.y > this.scale.endPoint ? t.controlPoints.inner.y = this.scale.endPoint : t.controlPoints.inner.y < this.scale.startPoint && (t.controlPoints.inner.y = this.scale.startPoint)
                        }, this), s.lineWidth = this.options.datasetStrokeWidth, s.strokeStyle = t.strokeColor, s.beginPath(), e.each(n, function(t, i) {
                            if (0 === i) s.moveTo(t.x, t.y);
                            else if (this.options.bezierCurve) {
                                var e = a(t, n, i);
                                s.bezierCurveTo(e.controlPoints.outer.x, e.controlPoints.outer.y, t.controlPoints.inner.x, t.controlPoints.inner.y, t.x, t.y)
                            } else s.lineTo(t.x, t.y)
                        }, this), s.stroke(), this.options.datasetFill && n.length > 0 && (s.lineTo(n[n.length - 1].x, this.scale.endPoint), s.lineTo(n[0].x, this.scale.endPoint), s.fillStyle = t.fillColor, s.closePath(), s.fill()), e.each(n, function(t) {
                            t.draw()
                        })
                    }, this)
                }
            })
        }.call(this),
        function() {
            var t = this,
                i = t.Chart,
                e = i.helpers,
                s = {
                    scaleShowLabelBackdrop: !0,
                    scaleBackdropColor: "rgba(255,255,255,0.75)",
                    scaleBeginAtZero: !0,
                    scaleBackdropPaddingY: 2,
                    scaleBackdropPaddingX: 2,
                    scaleShowLine: !0,
                    segmentShowStroke: !0,
                    segmentStrokeColor: "#fff",
                    segmentStrokeWidth: 2,
                    animationSteps: 100,
                    animationEasing: "easeOutBounce",
                    animateRotate: !0,
                    animateScale: !1,
                    legendTemplate: '<ul class="<%=name.toLowerCase()%>-legend"><% for (var i=0; i<segments.length; i++){%><li><span style="background-color:<%=segments[i].fillColor%>"></span><%if(segments[i].label){%><%=segments[i].label%><%}%></li><%}%></ul>'
                };
            i.Type.extend({
                name: "PolarArea",
                defaults: s,
                initialize: function(t) {
                    this.segments = [], this.SegmentArc = i.Arc.extend({
                        showStroke: this.options.segmentShowStroke,
                        strokeWidth: this.options.segmentStrokeWidth,
                        strokeColor: this.options.segmentStrokeColor,
                        ctx: this.chart.ctx,
                        innerRadius: 0,
                        x: this.chart.width / 2,
                        y: this.chart.height / 2
                    }), this.scale = new i.RadialScale({
                        display: this.options.showScale,
                        fontStyle: this.options.scaleFontStyle,
                        fontSize: this.options.scaleFontSize,
                        fontFamily: this.options.scaleFontFamily,
                        fontColor: this.options.scaleFontColor,
                        showLabels: this.options.scaleShowLabels,
                        showLabelBackdrop: this.options.scaleShowLabelBackdrop,
                        backdropColor: this.options.scaleBackdropColor,
                        backdropPaddingY: this.options.scaleBackdropPaddingY,
                        backdropPaddingX: this.options.scaleBackdropPaddingX,
                        lineWidth: this.options.scaleShowLine ? this.options.scaleLineWidth : 0,
                        lineColor: this.options.scaleLineColor,
                        lineArc: !0,
                        width: this.chart.width,
                        height: this.chart.height,
                        xCenter: this.chart.width / 2,
                        yCenter: this.chart.height / 2,
                        ctx: this.chart.ctx,
                        templateString: this.options.scaleLabel,
                        valuesCount: t.length
                    }), this.updateScaleRange(t), this.scale.update(), e.each(t, function(t, i) {
                        this.addData(t, i, !0)
                    }, this), this.options.showTooltips && e.bindEvents(this, this.options.tooltipEvents, function(t) {
                        var i = "mouseout" !== t.type ? this.getSegmentsAtEvent(t) : [];
                        e.each(this.segments, function(t) {
                            t.restore(["fillColor"])
                        }), e.each(i, function(t) {
                            t.fillColor = t.highlightColor
                        }), this.showTooltip(i)
                    }), this.render()
                },
                getSegmentsAtEvent: function(t) {
                    var i = [],
                        s = e.getRelativePosition(t);
                    return e.each(this.segments, function(t) {
                        t.inRange(s.x, s.y) && i.push(t)
                    }, this), i
                },
                addData: function(t, i, e) {
                    var s = i || this.segments.length;
                    this.segments.splice(s, 0, new this.SegmentArc({
                        fillColor: t.color,
                        highlightColor: t.highlight || t.color,
                        label: t.label,
                        value: t.value,
                        outerRadius: this.options.animateScale ? 0 : this.scale.calculateCenterOffset(t.value),
                        circumference: this.options.animateRotate ? 0 : this.scale.getCircumference(),
                        startAngle: 1.5 * Math.PI
                    })), e || (this.reflow(), this.update())
                },
                removeData: function(t) {
                    var i = e.isNumber(t) ? t : this.segments.length - 1;
                    this.segments.splice(i, 1), this.reflow(), this.update()
                },
                calculateTotal: function(t) {
                    this.total = 0, e.each(t, function(t) {
                        this.total += t.value
                    }, this), this.scale.valuesCount = this.segments.length
                },
                updateScaleRange: function(t) {
                    var i = [];
                    e.each(t, function(t) {
                        i.push(t.value)
                    });
                    var s = this.options.scaleOverride ? {
                        steps: this.options.scaleSteps,
                        stepValue: this.options.scaleStepWidth,
                        min: this.options.scaleStartValue,
                        max: this.options.scaleStartValue + this.options.scaleSteps * this.options.scaleStepWidth
                    } : e.calculateScaleRange(i, e.min([this.chart.width, this.chart.height]) / 2, this.options.scaleFontSize, this.options.scaleBeginAtZero, this.options.scaleIntegersOnly);
                    e.extend(this.scale, s, {
                        size: e.min([this.chart.width, this.chart.height]),
                        xCenter: this.chart.width / 2,
                        yCenter: this.chart.height / 2
                    })
                },
                update: function() {
                    this.calculateTotal(this.segments), e.each(this.segments, function(t) {
                        t.save()
                    }), this.render()
                },
                reflow: function() {
                    e.extend(this.SegmentArc.prototype, {
                        x: this.chart.width / 2,
                        y: this.chart.height / 2
                    }), this.updateScaleRange(this.segments), this.scale.update(), e.extend(this.scale, {
                        xCenter: this.chart.width / 2,
                        yCenter: this.chart.height / 2
                    }), e.each(this.segments, function(t) {
                        t.update({
                            outerRadius: this.scale.calculateCenterOffset(t.value)
                        })
                    }, this)
                },
                draw: function(t) {
                    var i = t || 1;
                    this.clear(), e.each(this.segments, function(t, e) {
                        t.transition({
                            circumference: this.scale.getCircumference(),
                            outerRadius: this.scale.calculateCenterOffset(t.value)
                        }, i), t.endAngle = t.startAngle + t.circumference, 0 === e && (t.startAngle = 1.5 * Math.PI), e < this.segments.length - 1 && (this.segments[e + 1].startAngle = t.endAngle), t.draw()
                    }, this), this.scale.draw()
                }
            })
        }.call(this),
        function() {
            var t = this,
                i = t.Chart,
                e = i.helpers;
            i.Type.extend({
                name: "Radar",
                defaults: {
                    scaleShowLine: !0,
                    angleShowLineOut: !0,
                    scaleShowLabels: !1,
                    scaleBeginAtZero: !0,
                    angleLineColor: "rgba(0,0,0,.1)",
                    angleLineWidth: 1,
                    pointLabelFontFamily: "'Arial'",
                    pointLabelFontStyle: "normal",
                    pointLabelFontSize: 10,
                    pointLabelFontColor: "#666",
                    pointDot: !0,
                    pointDotRadius: 3,
                    pointDotStrokeWidth: 1,
                    pointHitDetectionRadius: 20,
                    datasetStroke: !0,
                    datasetStrokeWidth: 2,
                    datasetFill: !0,
                    legendTemplate: '<ul class="<%=name.toLowerCase()%>-legend"><% for (var i=0; i<datasets.length; i++){%><li><span style="background-color:<%=datasets[i].strokeColor%>"></span><%if(datasets[i].label){%><%=datasets[i].label%><%}%></li><%}%></ul>'
                },
                initialize: function(t) {
                    this.PointClass = i.Point.extend({
                        strokeWidth: this.options.pointDotStrokeWidth,
                        radius: this.options.pointDotRadius,
                        display: this.options.pointDot,
                        hitDetectionRadius: this.options.pointHitDetectionRadius,
                        ctx: this.chart.ctx
                    }), this.datasets = [], this.buildScale(t), this.options.showTooltips && e.bindEvents(this, this.options.tooltipEvents, function(t) {
                        var i = "mouseout" !== t.type ? this.getPointsAtEvent(t) : [];
                        this.eachPoints(function(t) {
                            t.restore(["fillColor", "strokeColor"])
                        }), e.each(i, function(t) {
                            t.fillColor = t.highlightFill, t.strokeColor = t.highlightStroke
                        }), this.showTooltip(i)
                    }), e.each(t.datasets, function(i) {
                        var s = {
                            label: i.label || null,
                            fillColor: i.fillColor,
                            strokeColor: i.strokeColor,
                            pointColor: i.pointColor,
                            pointStrokeColor: i.pointStrokeColor,
                            points: []
                        };
                        this.datasets.push(s), e.each(i.data, function(e, o) {
                            var h;
                            this.scale.animation || (h = this.scale.getPointPosition(o, this.scale.calculateCenterOffset(e))), s.points.push(new this.PointClass({
                                value: e,
                                label: t.labels[o],
                                datasetLabel: i.label,
                                x: this.options.animation ? this.scale.xCenter : h.x,
                                y: this.options.animation ? this.scale.yCenter : h.y,
                                strokeColor: i.pointStrokeColor,
                                fillColor: i.pointColor,
                                highlightFill: i.pointHighlightFill || i.pointColor,
                                highlightStroke: i.pointHighlightStroke || i.pointStrokeColor
                            }))
                        }, this)
                    }, this), this.render()
                },
                eachPoints: function(t) {
                    e.each(this.datasets, function(i) {
                        e.each(i.points, t, this)
                    }, this)
                },
                getPointsAtEvent: function(t) {
                    var i = e.getRelativePosition(t),
                        s = e.getAngleFromPoint({
                            x: this.scale.xCenter,
                            y: this.scale.yCenter
                        }, i),
                        o = 2 * Math.PI / this.scale.valuesCount,
                        h = Math.round((s.angle - 1.5 * Math.PI) / o),
                        a = [];
                    return (h >= this.scale.valuesCount || 0 > h) && (h = 0), s.distance <= this.scale.drawingArea && e.each(this.datasets, function(t) {
                        a.push(t.points[h])
                    }), a
                },
                buildScale: function(t) {
                    this.scale = new i.RadialScale({
                        display: this.options.showScale,
                        fontStyle: this.options.scaleFontStyle,
                        fontSize: this.options.scaleFontSize,
                        fontFamily: this.options.scaleFontFamily,
                        fontColor: this.options.scaleFontColor,
                        showLabels: this.options.scaleShowLabels,
                        showLabelBackdrop: this.options.scaleShowLabelBackdrop,
                        backdropColor: this.options.scaleBackdropColor,
                        backdropPaddingY: this.options.scaleBackdropPaddingY,
                        backdropPaddingX: this.options.scaleBackdropPaddingX,
                        lineWidth: this.options.scaleShowLine ? this.options.scaleLineWidth : 0,
                        lineColor: this.options.scaleLineColor,
                        angleLineColor: this.options.angleLineColor,
                        angleLineWidth: this.options.angleShowLineOut ? this.options.angleLineWidth : 0,
                        pointLabelFontColor: this.options.pointLabelFontColor,
                        pointLabelFontSize: this.options.pointLabelFontSize,
                        pointLabelFontFamily: this.options.pointLabelFontFamily,
                        pointLabelFontStyle: this.options.pointLabelFontStyle,
                        height: this.chart.height,
                        width: this.chart.width,
                        xCenter: this.chart.width / 2,
                        yCenter: this.chart.height / 2,
                        ctx: this.chart.ctx,
                        templateString: this.options.scaleLabel,
                        labels: t.labels,
                        valuesCount: t.datasets[0].data.length
                    }), this.scale.setScaleSize(), this.updateScaleRange(t.datasets), this.scale.buildYLabels()
                },
                updateScaleRange: function(t) {
                    var i = function() {
                            var i = [];
                            return e.each(t, function(t) {
                                t.data ? i = i.concat(t.data) : e.each(t.points, function(t) {
                                    i.push(t.value)
                                })
                            }), i
                        }(),
                        s = this.options.scaleOverride ? {
                            steps: this.options.scaleSteps,
                            stepValue: this.options.scaleStepWidth,
                            min: this.options.scaleStartValue,
                            max: this.options.scaleStartValue + this.options.scaleSteps * this.options.scaleStepWidth
                        } : e.calculateScaleRange(i, e.min([this.chart.width, this.chart.height]) / 2, this.options.scaleFontSize, this.options.scaleBeginAtZero, this.options.scaleIntegersOnly);
                    e.extend(this.scale, s)
                },
                addData: function(t, i) {
                    this.scale.valuesCount++, e.each(t, function(t, e) {
                        var s = this.scale.getPointPosition(this.scale.valuesCount, this.scale.calculateCenterOffset(t));
                        this.datasets[e].points.push(new this.PointClass({
                            value: t,
                            label: i,
                            x: s.x,
                            y: s.y,
                            strokeColor: this.datasets[e].pointStrokeColor,
                            fillColor: this.datasets[e].pointColor
                        }))
                    }, this), this.scale.labels.push(i), this.reflow(), this.update()
                },
                removeData: function() {
                    this.scale.valuesCount--, this.scale.labels.shift(), e.each(this.datasets, function(t) {
                        t.points.shift()
                    }, this), this.reflow(), this.update()
                },
                update: function() {
                    this.eachPoints(function(t) {
                        t.save()
                    }), this.reflow(), this.render()
                },
                reflow: function() {
                    e.extend(this.scale, {
                        width: this.chart.width,
                        height: this.chart.height,
                        size: e.min([this.chart.width, this.chart.height]),
                        xCenter: this.chart.width / 2,
                        yCenter: this.chart.height / 2
                    }), this.updateScaleRange(this.datasets), this.scale.setScaleSize(), this.scale.buildYLabels()
                },
                draw: function(t) {
                    var i = t || 1,
                        s = this.chart.ctx;
                    this.clear(), this.scale.draw(), e.each(this.datasets, function(t) {
                        e.each(t.points, function(t, e) {
                            t.hasValue() && t.transition(this.scale.getPointPosition(e, this.scale.calculateCenterOffset(t.value)), i)
                        }, this), s.lineWidth = this.options.datasetStrokeWidth, s.strokeStyle = t.strokeColor, s.beginPath(), e.each(t.points, function(t, i) {
                            0 === i ? s.moveTo(t.x, t.y) : s.lineTo(t.x, t.y)
                        }, this), s.closePath(), s.stroke(), s.fillStyle = t.fillColor, s.fill(), e.each(t.points, function(t) {
                            t.hasValue() && t.draw()
                        })
                    }, this)
                }
            })
        }.call(this),
        function() {
            var t = this,
                i = t.Chart;
            i.helpers, i.Type.extend({
                name: "ropBars",
                defaults: {
                    barsWidth: 30,
                    barSpacing: 52,
                    bottomSpace: 35,
                    minHeight: 5,
                    poignees: 40
                },
                initialize: function(t) {
                    var i = null,
                        e = null,
                        s = [];
                    for (var o in t.lastMonth) {
                        -1 == s.indexOf(o) && s.push(o);
                        var h = t.lastMonth[o].montant;
                        (i > h || null == i) && (i = h), (h > e || null == e) && (e = h)
                    }
                    for (var o in t.currentMonth) {
                        -1 == s.indexOf(o) && s.push(o);
                        var h = t.currentMonth[o].montant;
                        (i > h || null == i) && (i = h), (h > e || null == e) && (e = h)
                    }
                    var a = (s.length, Math.floor((this.chart.width - 3 * this.options.poignees) / (Number(this.options.barsWidth) + Number(this.options.barSpacing)))),
                        n = a * this.options.barsWidth + (a - 1) * this.options.barSpacing,
                        r = (this.chart.width - n) / 2,
                        l = 1,
                        e = Math.ceil(Math.round(e) / l) * l,
                        i = Math.floor(Math.round(i) / l) * l,
                        c = e - i,
                        d = (this.chart.height - this.options.bottomSpace) / c;
                    s.sort(arrayFunctions.sortMontant), this.draw(t, s, d, a, r, e, i, n)
                },
                draw: function(t, i, e, s, o, h, a, n) {
                    for (var r = (this.chart.height - this.options.bottomSpace) / 10, l = 1; 11 > l; l++) 0 == l % 2 && (this.chart.ctx.beginPath(), this.chart.ctx.strokeStyle = "rgba(0,0,0,.1)", this.chart.ctx.lineWidth = 1, this.chart.ctx.moveTo(o, l * r), this.chart.ctx.lineTo(o + n, l * r), this.chart.ctx.stroke(), this.chart.ctx.closePath());
                    this.chart.ctx.beginPath(), this.chart.ctx.arc(1.5 * this.options.poignees, this.chart.height / 2, this.options.poignees / 2, 0, 2 * Math.PI), this.chart.ctx.strokeStyle = "rgb(204, 204, 204)", this.chart.ctx.lineWidth = 2, this.chart.ctx.stroke(), this.chart.ctx.closePath(), this.chart.ctx.beginPath(), this.chart.ctx.moveTo(1.6 * this.options.poignees, this.chart.height / 2 - this.options.poignees / 5), this.chart.ctx.lineTo(1.4 * this.options.poignees, this.chart.height / 2), this.chart.ctx.lineTo(1.6 * this.options.poignees, this.chart.height / 2 + this.options.poignees / 5), this.chart.ctx.lineWidth = 3, this.chart.ctx.stroke(), this.chart.ctx.closePath(), this.chart.ctx.beginPath(), this.chart.ctx.arc(n + o + 1.5 * this.options.poignees, this.chart.height / 2, this.options.poignees / 2, 0, 2 * Math.PI), this.chart.ctx.strokeStyle = "rgb(204, 204, 204)", this.chart.ctx.lineWidth = 2, this.chart.ctx.stroke(), this.chart.ctx.closePath(), this.chart.ctx.beginPath(), this.chart.ctx.moveTo(n + o + 1.4 * this.options.poignees, this.chart.height / 2 - this.options.poignees / 5), this.chart.ctx.lineTo(n + o + 1.6 * this.options.poignees, this.chart.height / 2), this.chart.ctx.lineTo(n + o + 1.4 * this.options.poignees, this.chart.height / 2 + this.options.poignees / 5), this.chart.ctx.lineWidth = 3, this.chart.ctx.stroke(), this.chart.ctx.closePath();
                    for (var l = 0; s > l; l++) {
                        var c = i[l];
                        this.chart.ctx.fillStyle = "rgb(204, 204, 204)";
                        var d = l * this.options.barSpacing + l * this.options.barsWidth + o,
                            p = "undefined" != typeof t.lastMonth[c] ? this.chart.height - this.options.bottomSpace - e * t.lastMonth[c].montant : this.chart.height - this.options.bottomSpace - this.options.minHeight,
                            u = this.options.barsWidth / 2,
                            f = "undefined" != typeof t.lastMonth[c] ? e * t.lastMonth[c].montant : this.options.minHeight;
                        p > this.chart.height - this.options.bottomSpace - this.options.minHeight && (p = this.chart.height - this.options.bottomSpace - this.options.minHeight), f < this.options.minHeight && (f = this.options.minHeight), this.chart.ctx.fillRect(d, p, u, f), this.chart.ctx.fillStyle = helper_ropCateg[i[l]].color;
                        var d = l * this.options.barSpacing + l * this.options.barsWidth + this.options.barsWidth / 2 + o,
                            p = "undefined" != typeof t.currentMonth[c] ? this.chart.height - this.options.bottomSpace - e * t.currentMonth[c].montant : this.chart.height - this.options.bottomSpace - this.options.minHeight,
                            u = this.options.barsWidth / 2,
                            f = "undefined" != typeof t.currentMonth[c] ? e * t.currentMonth[c].montant : this.options.minHeight;
                        p > this.chart.height - this.options.bottomSpace - this.options.minHeight && (p = this.chart.height - this.options.bottomSpace - this.options.minHeight), f < this.options.minHeight && (f = this.options.minHeight), this.chart.ctx.fillRect(d, p, u, f), this.chart.ctx.fillStyle = "#424242", this.chart.ctx.font = "16px bnp_regular,Arial,sans-serif bold", this.chart.ctx.textAlign = "center", this.chart.ctx.fillText(addThousandsSep(formatNumber(t.currentMonth[c].montant, 2)) + " €", l * this.options.barSpacing + l * this.options.barsWidth + this.options.barsWidth / 2 + o, this.chart.height - 3)
                    }
                }
            })
        }.call(this),
        function() {
            var t = this,
                i = t.Chart,
                e = i.helpers;
            i.Type.extend({
                name: "risqueBars",
                defaults: {
                    bgColor: "#f3eee9",
                    barsColor: "#433931",
                    highlightColor: "rgba(67, 57, 49, 0.5)",
                    legendRightColor: "#cabbab",
                    leftTextWidth: 100,
                    rightTextWidth: 50,
                    textPaddingRight: 10,
                    bottomSpace: 20,
                    paddingTop: 10,
                    margesBarres: 4,
                    tooltipEvents: ["mousemove", "touchstart", "touchmove", "mouseout", "mouseup", "mousedown"],
                    tooltipHeight: 40,
                    maxHeight: 300,
                    maxWidth: 680,
                    mobileLeftTextWidth: 90,
                    mobileRightTextWidth: 30,
                    mobilePaddingTop: 0,
                    mobileMaxHeight: 340
                },
                initialize: function(t) {
                    this.data = JSON.parse(JSON.stringify(t)), this.options.showTooltips && e.bindEvents(this, this.options.tooltipEvents, function(t) {
                        var i = "mouseout" !== t.type ? this.getBarsAtEvent(t) : null;
                        if ("mobile" != DeviceSize.getDeviceState()) {
                            if (h(this.chart.canvas).removeClass("pointer"), this.clear(), this.draw(this.data), null != i) {
                                h(this.chart.canvas).addClass("pointer");
                                var e = JSON.parse(JSON.stringify(this.data));
                                e[i].hover = !0, this.clear(), this.draw(e)
                            }
                        } else if (h(this.chart.canvas).removeClass("pointer"), this.options.clicked = !1, null != i) {
                            if (h(this.chart.canvas).addClass("pointer"), "mousedown" == t.type) {
                                var e = JSON.parse(JSON.stringify(this.data));
                                e[i].hover = !0, this.options.clicked = !0, this.clear(), this.draw(e)
                            }
                        } else "mousedown" == t.type && (this.clear(), this.draw(this.data))
                    }), "mobile" == DeviceSize.getDeviceState() && (this.options.leftTextWidth = this.options.mobileLeftTextWidth, this.options.rightTextWidth = this.options.mobileRightTextWidth, this.options.paddingTop = this.options.mobilePaddingTop, this.options.maxHeight = this.options.mobileMaxHeight), this.draw(t)
                },
                draw: function(t) {
                    var i = null,
                        e = this.chart.width > this.options.maxWidth ? this.options.maxWidth : this.chart.width,
                        s = this.chart.height > this.options.maxHeight ? this.options.maxHeight : this.chart.height,
                        o = (this.chart.height - s) / 2,
                        a = (this.chart.width - e) / 2,
                        n = e - (this.options.leftTextWidth + 2 * this.options.textPaddingRight + this.options.rightTextWidth),
                        r = s - this.options.bottomSpace - this.options.paddingTop;
                    this.chart.ctx.fillStyle = this.options.bgColor, this.chart.ctx.fillRect(this.options.leftTextWidth + this.options.textPaddingRight + a, this.options.paddingTop + o, n, r);
                    var l = r / t.length,
                        c = n / 100;
                    this.bars = [];
                    for (var d = 0; d < t.length; d++) {
                        this.chart.ctx.font = "14px Arial,sans-serif", "mobile" == DeviceSize.getDeviceState() && (this.chart.ctx.font = "12px Arial,sans-serif"), this.chart.ctx.fillStyle = "#424242", this.options.clicked && "mobile" == DeviceSize.getDeviceState() && (this.chart.ctx.fillStyle = t[d].hover ? "#424242" : this.options.legendRightColor), this.chart.ctx.textAlign = "right", this.chart.ctx.textBaseline = "middle";
                        for (var p = t[d].label, u = this.fragmentText(p, this.options.leftTextWidth + a), f = 0; f < u.length; f++) {
                            var g = this.options.leftTextWidth + a,
                                x = +o + s - this.options.bottomSpace - (d + 1) * l + l / (u.length + 1) * (f + 1) + .4 * (f - 1) * (u.length + 1);
                            this.chart.ctx.fillText(u[f], g, x)
                        }
                        this.chart.ctx.fillStyle = t[d].hover ? this.options.highlightColor : this.options.barsColor, "mobile" == DeviceSize.getDeviceState() && this.options.clicked && (this.chart.ctx.fillStyle = t[d].hover ? this.options.barsColor : this.options.highlightColor);
                        var m = this.options.leftTextWidth + this.options.textPaddingRight + a,
                            b = +o + s - this.options.bottomSpace - (d + 1) * l + this.options.margesBarres,
                            v = t[d].value > 0 ? c * t[d].value : 0,
                            S = l - 2 * this.options.margesBarres;
                        this.chart.ctx.fillRect(m, b, v, S), this.bars.push({
                            x: m,
                            y: b,
                            x2: m + v,
                            y2: b + S
                        }), t[d].hover && (this.chart.ctx.font = "16px Arial,sans-serif", i = {
                            index: d,
                            x: m + v + 15,
                            y: s - this.options.bottomSpace - (d + 1) * l - (this.options.tooltipHeight - l) / 2,
                            w: this.chart.ctx.measureText(Math.round(t[d].value) + "%; " + addThousandsSep(formatNumber(t[d].montant, 2)) + " €").width + 30,
                            h: this.options.tooltipHeight,
                            montant: t[d].montant,
                            label: p,
                            value: t[d].value
                        }), this.chart.ctx.fillStyle = this.options.legendRightColor, "mobile" == DeviceSize.getDeviceState() && this.options.clicked && (this.chart.ctx.fillStyle = t[d].hover ? this.options.barsColor : this.options.legendRightColor), this.chart.ctx.textAlign = "left", this.chart.ctx.textBaseline = "middle", this.chart.ctx.fillText(d + 1, a + this.options.leftTextWidth + this.options.textPaddingRight + n - 20, o + s - this.options.bottomSpace - (d + 1) * l + l / 2), this.chart.ctx.beginPath(), this.chart.ctx.lineWidth = .2, this.chart.ctx.lineCap = "round", this.chart.ctx.strokeStyle = "rgba(66, 66, 66, 1)", this.chart.ctx.moveTo(a + this.options.leftTextWidth + this.options.textPaddingRight, o + s - this.options.bottomSpace - d * l), this.chart.ctx.lineTo(a + this.options.leftTextWidth + this.options.textPaddingRight + n, o + s - this.options.bottomSpace - d * l), this.chart.ctx.closePath(), this.chart.ctx.stroke()
                    }
                    this.chart.ctx.beginPath(), this.chart.ctx.lineWidth = .2, this.chart.ctx.lineCap = "round", this.chart.ctx.strokeStyle = "rgba(66, 66, 66, 1)", this.chart.ctx.moveTo(a + this.options.leftTextWidth + this.options.textPaddingRight, o + this.options.paddingTop), this.chart.ctx.lineTo(a + this.options.leftTextWidth + this.options.textPaddingRight + n, o + this.options.paddingTop), this.chart.ctx.closePath(), this.chart.ctx.stroke(), this.chart.ctx.beginPath(), this.chart.ctx.fillStyle = this.options.legendRightColor, this.chart.ctx.moveTo(a + this.options.leftTextWidth + this.options.textPaddingRight + n + this.options.rightTextWidth / 3, o + this.options.paddingTop + 3), this.chart.ctx.lineTo(a + this.options.leftTextWidth + this.options.textPaddingRight + n + this.options.rightTextWidth / 3 + 6, o + this.options.paddingTop + 11), this.chart.ctx.lineTo(a + this.options.leftTextWidth + this.options.textPaddingRight + n + this.options.rightTextWidth / 3 - 6, o + this.options.paddingTop + 11), this.chart.ctx.lineTo(a + this.options.leftTextWidth + this.options.textPaddingRight + n + this.options.rightTextWidth / 3, o + this.options.paddingTop + 3), this.chart.ctx.closePath(), this.chart.ctx.fill(), this.chart.ctx.beginPath(), this.chart.ctx.fillStyle = this.options.legendRightColor, this.chart.ctx.moveTo(a + this.options.leftTextWidth + this.options.textPaddingRight + n + this.options.rightTextWidth / 3, o + s - this.options.bottomSpace - 3), this.chart.ctx.lineTo(a + this.options.leftTextWidth + this.options.textPaddingRight + n + this.options.rightTextWidth / 3 + 6, o + s - this.options.bottomSpace - 11), this.chart.ctx.lineTo(a + this.options.leftTextWidth + this.options.textPaddingRight + n + this.options.rightTextWidth / 3 - 6, o + s - this.options.bottomSpace - 11), this.chart.ctx.lineTo(a + this.options.leftTextWidth + this.options.textPaddingRight + n + this.options.rightTextWidth / 3, o + s - this.options.bottomSpace - 3), this.chart.ctx.closePath(), this.chart.ctx.fill(), this.chart.ctx.font = "13px Arial,sans-serif", this.chart.ctx.textAlign = "left", this.chart.ctx.fillStyle = this.options.legendRightColor, this.chart.ctx.fillText("Fort", a + this.options.leftTextWidth + this.options.textPaddingRight + n + this.options.rightTextWidth / 5, o + this.options.paddingTop + 26), "mobile" == DeviceSize.getDeviceState() ? (this.chart.ctx.save(), this.chart.ctx.textAlign = "center", this.chart.ctx.textBaseline = "middle", this.chart.ctx.translate(a + this.options.leftTextWidth + this.options.textPaddingRight + n + this.options.rightTextWidth / 3, o + this.options.paddingTop + r / 2), this.chart.ctx.rotate(90 * (-Math.PI / 180)), this.chart.ctx.fillText("Risque", 0, 0), this.chart.ctx.restore(), this.chart.ctx.textAlign = "left", this.chart.ctx.textBaseline = "alphabetic") : this.chart.ctx.fillText("Risque", a + this.options.leftTextWidth + this.options.textPaddingRight + n + this.options.rightTextWidth / 5, o + this.options.paddingTop + r / 2), this.chart.ctx.fillText("Faible", a + this.options.leftTextWidth + this.options.textPaddingRight + n + this.options.rightTextWidth / 5, o + s - this.options.bottomSpace - 26);
                    for (var d = 0; 11 > d; d++)
                        if (!(420 >= e && d % 2 > 0)) {
                            this.chart.ctx.textAlign = "center", this.chart.ctx.textBaseline = "bottom", this.chart.ctx.fillStyle = "#424242";
                            var m = a + this.options.leftTextWidth + this.options.textPaddingRight + d * n / 10,
                                b = o + s;
                            this.chart.ctx.fillText(10 * d + "%", m, b)
                        }
                    if (null != i)
                        if ("mobile" != DeviceSize.getDeviceState()) {
                            var y = "right";
                            n - i.value * c < i.w + 10 && (y = "left"), this.chart.ctx.beginPath(), this.chart.ctx.lineWidth = .5, this.chart.ctx.fillStyle = "#fefefe", this.chart.ctx.strokeStyle = this.options.legendRightColor, this.chart.ctx.font = "16px Arial,sans-serif", this.chart.ctx.textAlign = "left", this.chart.ctx.textBaseline = "middle", this.chart.ctx.shadowColor = "rgba(0, 0, 0, 0.2)", this.chart.ctx.shadowBlur = 10;
                            var C = 10;
                            "right" == y ? (this.chart.ctx.moveTo(i.x + C, i.y + o), this.chart.ctx.lineTo(i.x + i.w - C, i.y + o), this.chart.ctx.arcTo(i.x + i.w, i.y + o, i.x + i.w, i.y + o + C, C), this.chart.ctx.lineTo(i.x + i.w, i.y + o + i.h - C), this.chart.ctx.arcTo(i.x + i.w, i.y + o + i.h, i.x + i.w - C, i.y + o + i.h, C), this.chart.ctx.lineTo(i.x + C, i.y + o + i.h), this.chart.ctx.arcTo(i.x, i.y + o + i.h, i.x, i.y + o + i.h - C, C), this.chart.ctx.lineTo(i.x, i.y + o + this.options.tooltipHeight / 2 + 6), this.chart.ctx.lineTo(i.x - 10, i.y + o + this.options.tooltipHeight / 2), this.chart.ctx.lineTo(i.x, i.y + o + this.options.tooltipHeight / 2 - 6), this.chart.ctx.lineTo(i.x, i.y + o + C), this.chart.ctx.arcTo(i.x, i.y + o, i.x + C, i.y + o, C)) : (i.x = this.options.leftTextWidth + this.options.textPaddingRight + a + n - 15, this.chart.ctx.moveTo(i.x - i.w + C, i.y + o), this.chart.ctx.lineTo(i.x - C, i.y + o), this.chart.ctx.arcTo(i.x, i.y + o, i.x, i.y + o + C, C), this.chart.ctx.lineTo(i.x, i.y + o + this.options.tooltipHeight / 2 - 6), this.chart.ctx.lineTo(i.x + 10, i.y + o + this.options.tooltipHeight / 2), this.chart.ctx.lineTo(i.x, i.y + o + this.options.tooltipHeight / 2 + 6), this.chart.ctx.lineTo(i.x, i.y + o + i.h - C), this.chart.ctx.arcTo(i.x, i.y + o + i.h, i.x - C, i.y + o + i.h, C), this.chart.ctx.lineTo(i.x - i.w + C, i.y + o + i.h), this.chart.ctx.arcTo(i.x - i.w, i.y + o + i.h, i.x - i.w, i.y + o + i.h - C, C), this.chart.ctx.lineTo(i.x - i.w, i.y + o + C), this.chart.ctx.arcTo(i.x - i.w, i.y + o, i.x + C, i.y + o, C)), this.chart.ctx.closePath(), this.chart.ctx.fill(), this.chart.ctx.stroke(), this.chart.ctx.shadowBlur = 0, this.chart.ctx.fillStyle = "#424242", "right" == y ? this.chart.ctx.fillText(Math.round(i.value) + "%; " + addThousandsSep(formatNumber(i.montant, 2)) + " €", i.x + 15, i.y + o + 20) : this.chart.ctx.fillText(Math.round(i.value) + "%; " + addThousandsSep(formatNumber(i.montant, 2)) + " €", i.x - i.w + 15, i.y + o + 20)
                        } else h(this.chart.canvas).parent().parent().append('<div class="riskTooltip"><span class="big strong">' + i.label + "</span><br><span>" + (addThousandsSep(formatNumber(i.montant, 2)) + " €") + " (" + i.value + "%)</span></div>");
                    else h(this.chart.canvas).parent().parent().find(".riskTooltip").remove()
                },
                fragmentText: function(t, i) {
                    var e = t.split(" "),
                        s = [],
                        o = "";
                    if (this.chart.ctx.measureText(t).width < i) return [t];
                    for (; e.length > 0;) {
                        for (; this.chart.ctx.measureText(e[0]).width >= i;) {
                            var h = e[0];
                            e[0] = h.slice(0, -1), e.length > 1 ? e[1] = h.slice(-1) + e[1] : e.push(h.slice(-1))
                        }
                        this.chart.ctx.measureText(o + e[0]).width < i ? o += e.shift() + " " : (s.push(o), o = ""), 0 === e.length && s.push(o)
                    }
                    return s
                },
                eachBars: function(t) {
                    e.each(this.datasets, function(i, s) {
                        e.each(i.bars, t, this, s)
                    }, this)
                },
                getBarsAtEvent: function(t) {
                    for (var i = e.getRelativePosition(t), s = 0; s < this.bars.length; s++)
                        if (this.checkHitPoint(this.bars[s], i)) return s;
                    return null
                },
                checkHitPoint: function(t, i) {
                    return i.x >= t.x && i.x <= t.x2 && i.y >= t.y && i.y <= t.y2 ? !0 : !1
                }
            })
        }.call(this),
        function() {
            var t = this,
                i = t.Chart;
            i.helpers, i.Type.extend({
                name: "risqueArc",
                defaults: {
                    bgColor: "rgba(243, 238, 233, 1)",
                    barsColor: "rgba(67,57,49, 1)",
                    legendColor: "rgba(202, 187, 171, 1)",
                    sidePadding: 30,
                    arcWidth: 22,
                    ratio: 2.13,
                    maxHeight: 260,
                    mobileMaxWidth: 180,
                    mobileMaxHeight: 320,
                    mobilePaddingTop: 25,
                    mobileBarWidth: 16
                },
                initialize: function(t) {
                    "mobile" == DeviceSize.getDeviceState() ? this.drawForMobile(t[0]) : this.draw(t[0])
                },
                draw: function(t) {
                    var i = this.chart.width > this.chart.height ? this.chart.height * this.options.ratio : this.chart.width,
                        e = i / this.options.ratio;
                    e > this.options.maxHeight && (e = this.options.maxHeight);
                    for (var s = e - this.options.sidePadding, o = s - this.options.arcWidth, h = (this.chart.height - e) / 2, a = 0; a < t.nbrOfLevels; a++) {
                        var n = this.chart.width / 2 - s * Math.cos(Math.PI / t.nbrOfLevels * a),
                            r = this.chart.height - h - s * Math.sin(Math.PI / t.nbrOfLevels * a),
                            l = this.chart.width / 2 - s * Math.cos(Math.PI / t.nbrOfLevels * (a + 1)),
                            c = this.chart.height - h - s * Math.sin(Math.PI / t.nbrOfLevels * (a + 1)),
                            d = this.chart.width / 2 - o * Math.cos(Math.PI / t.nbrOfLevels * a),
                            p = this.chart.height - h - o * Math.sin(Math.PI / t.nbrOfLevels * a),
                            u = this.chart.width / 2 - o * Math.cos(Math.PI / t.nbrOfLevels * (a + 1)),
                            f = this.chart.height - h - o * Math.sin(Math.PI / t.nbrOfLevels * (a + 1)),
                            g = this.chart.width / 2,
                            x = this.chart.height - h,
                            m = Math.PI + Math.PI / t.nbrOfLevels * a,
                            b = Math.PI + Math.PI / t.nbrOfLevels * (a + 1);
                        this.chart.ctx.beginPath(), this.chart.ctx.strokeStyle = "#FFFFFF", this.chart.ctx.lineWidth = .7, this.chart.ctx.fillStyle = a < t.risque ? this.options.barsColor : this.options.bgColor, this.chart.ctx.arc(g, x, s, m, b, !1), this.chart.ctx.lineTo(u, f), this.chart.ctx.arc(g, x, o, b, m, !0), this.chart.ctx.lineTo(n, r), this.chart.ctx.closePath(), this.chart.ctx.fill(), this.chart.ctx.stroke(), this.chart.ctx.fillStyle = a < t.risque ? this.options.bgColor : this.options.legendColor, this.chart.ctx.font = "14px Arial,sans-serif", this.chart.ctx.textAlign = "center", this.chart.ctx.textBaseline = "middle";
                        var v = s - this.options.arcWidth / 2,
                            S = this.chart.width / 2 - v * Math.cos(Math.PI / t.nbrOfLevels * (a + .5)),
                            y = this.chart.height - h - v * Math.sin(Math.PI / t.nbrOfLevels * (a + .5));
                        this.chart.ctx.save(), this.chart.ctx.translate(S, y), this.chart.ctx.rotate(Math.PI + Math.PI / t.nbrOfLevels * (a + .5) + 90 * (Math.PI / 180)), this.chart.ctx.fillText(a + 1, 0, 0), this.chart.ctx.restore()
                    }
                    this.chart.ctx.fillStyle = this.options.legendColor, this.chart.ctx.font = "15px Arial,sans-serif", this.chart.ctx.textAlign = "left", this.chart.ctx.textBaseline = "middle";
                    var C = s + this.options.arcWidth / 2,
                        S = this.chart.width / 2 - C * Math.cos(0),
                        y = this.chart.height - h - C * Math.sin(0);
                    this.chart.ctx.save(), this.chart.ctx.translate(S, y), this.chart.ctx.rotate(-Math.PI / 2), this.chart.ctx.fillText("Faible", 0, 0), this.chart.ctx.restore(), this.chart.ctx.textAlign = "right";
                    var S = this.chart.width / 2 - C * Math.cos(Math.PI),
                        y = this.chart.height - h - C * Math.sin(Math.PI);
                    this.chart.ctx.save(), this.chart.ctx.translate(S, y), this.chart.ctx.rotate(Math.PI / 2), this.chart.ctx.fillText("Fort", 0, 0), this.chart.ctx.restore();
                    var w = e / 2.5;
                    this.chart.ctx.fillStyle = this.options.barsColor, this.chart.ctx.font = Math.round(w / 6) + "px Arial,sans-serif", this.chart.ctx.textAlign = "center", this.chart.ctx.textBaseline = "top", this.chart.ctx.fillText("RISQUE GLOBAL", this.chart.width / 2, this.chart.height - h - w - 5), this.chart.ctx.font = Math.round(w) + "px Arial,sans-serif", this.chart.ctx.textBaseline = "alphabetic", this.chart.ctx.fillText(t.risque, this.chart.width / 2, this.chart.height - h - 5), this.chart.ctx.beginPath();
                    var n = this.chart.width / 2 - (s + .5 * this.options.arcWidth) * Math.cos(Math.PI / t.nbrOfLevels * t.risque - Math.PI / t.nbrOfLevels / 2),
                        r = this.chart.height - h - (s + .5 * this.options.arcWidth) * Math.sin(Math.PI / t.nbrOfLevels * t.risque - Math.PI / t.nbrOfLevels / 2),
                        l = this.chart.width / 2 - (s + 1.2 * this.options.arcWidth) * Math.cos(Math.PI / t.nbrOfLevels * (t.risque - .15) - Math.PI / t.nbrOfLevels / 2),
                        c = this.chart.height - h - (s + 1.2 * this.options.arcWidth) * Math.sin(Math.PI / t.nbrOfLevels * (t.risque - .15) - Math.PI / t.nbrOfLevels / 2),
                        d = this.chart.width / 2 - (s + 1.2 * this.options.arcWidth) * Math.cos(Math.PI / t.nbrOfLevels * (t.risque + .15) - Math.PI / t.nbrOfLevels / 2),
                        p = this.chart.height - h - (s + 1.2 * this.options.arcWidth) * Math.sin(Math.PI / t.nbrOfLevels * (t.risque + .15) - Math.PI / t.nbrOfLevels / 2);
                    this.chart.ctx.moveTo(n, r), this.chart.ctx.lineTo(l, c), this.chart.ctx.lineTo(d, p), this.chart.ctx.lineTo(n, r), this.chart.ctx.closePath(), this.chart.ctx.fill()
                },
                drawForMobile: function(t) {
                    for (var i = this.chart.width > this.options.mobileMaxWidth ? this.options.mobileMaxWidth : this.chart.width, e = this.chart.height > this.options.mobileMaxHeight ? this.options.mobileMaxHeight : this.chart.height, s = Math.round((this.chart.height - e) / 2), o = Math.round((this.chart.width - i) / 2), h = Math.round((e - 2 * this.options.mobilePaddingTop) / t.nbrOfLevels), a = 0; a < t.nbrOfLevels; a++) {
                        var n = o,
                            r = s + this.options.mobilePaddingTop + (t.nbrOfLevels - 1 - a) * h + 1,
                            l = this.options.mobileBarWidth,
                            c = h - 2;
                        this.chart.ctx.lineWidth = 2, this.chart.ctx.fillStyle = a < t.risque ? this.options.barsColor : this.options.bgColor, this.chart.ctx.fillRect(n, r, l, c), this.chart.ctx.textAlign = "center", this.chart.ctx.textBaseline = "middle", this.chart.ctx.fillStyle = a < t.risque ? "#FFF" : this.options.legendColor, this.chart.ctx.font = "14px Arial,sans-serif", this.chart.ctx.fillText(a + 1, o + this.options.mobileBarWidth / 2, s + this.options.mobilePaddingTop + (t.nbrOfLevels - 1 - a) * h + .5 * h)
                    }
                    this.chart.ctx.fillStyle = this.options.legendColor, this.chart.ctx.font = "15px Arial,sans-serif", this.chart.ctx.textAlign = "center", this.chart.ctx.textBaseline = "bottom", this.chart.ctx.fillText("Faible", o + this.options.mobileBarWidth / 2, this.chart.height - s), this.chart.ctx.textBaseline = "top", this.chart.ctx.fillText("Fort", o + this.options.mobileBarWidth / 2, s), this.chart.ctx.fillStyle = this.options.barsColor, this.chart.ctx.font = "15px Arial,sans-serif", this.chart.ctx.textAlign = "center", this.chart.ctx.textBaseline = "bottom";
                    var n = o + 1.8 * this.options.mobileBarWidth + this.options.mobileBarWidth + i / 2,
                        r = s + this.options.mobilePaddingTop + (e - this.options.mobilePaddingTop) / 2;
                    this.chart.ctx.fillText("RISQUE GLOBAL", n, .7 * r), this.chart.ctx.font = "90px Arial,sans-serif", this.chart.ctx.textBaseline = "top", this.chart.ctx.fillText(t.risque, n, .75 * r), this.chart.ctx.beginPath(), this.chart.ctx.fillStyle = this.options.barsColor;
                    var n = o + 1.8 * this.options.mobileBarWidth,
                        r = s + this.options.mobilePaddingTop + (t.nbrOfLevels + 1 - t.risque) * h - h / 2,
                        d = n + this.options.mobileBarWidth,
                        p = r - .7 * this.options.mobileBarWidth,
                        u = n + this.options.mobileBarWidth,
                        f = r + .7 * this.options.mobileBarWidth;
                    this.chart.ctx.moveTo(n, r), this.chart.ctx.lineTo(d, p), this.chart.ctx.lineTo(u, f), this.chart.ctx.lineTo(n, r), this.chart.ctx.closePath(), this.chart.ctx.fill()
                }
            })
        }.call(this),
        function() {
            var t = this,
                i = t.Chart,
                e = i.helpers;
            i.Type.extend({
                name: "accueilCircle",
                defaults: {
                    bgColor: "#f9f7f8",
                    circleColor: "#28bb69",
                    insideColor: "#f5f5f5",
                    insideColorEnd: "#dcdfe0",
                    textColor: "#999999",
                    shadowColor: "#CCC"
                },
                initialize: function(t) {
                    this.data = t, this.data.color && (this.options.circleColor = this.data.color), e.animationLoop(this.draw, 30, "easeOutQuad", function() {}, function() {}, this)
                },
                draw: function(t) {
                    var i = this.chart.width / 15,
                        e = this.chart.width - 2 * i,
                        s = this.chart.height - 2 * i,
                        o = this.chart.width / 12.5,
                        h = this.chart.width / 10,
                        a = Math.round(this.chart.width / 3.125),
                        n = Math.round(this.chart.width / 7.895);
                    this.chart.ctx.clearRect(0, 0, this.chart.width, this.chart.height), this.chart.ctx.beginPath();
                    var r = this.chart.ctx.createLinearGradient(0, this.chart.height, this.chart.width, 0);
                    r.addColorStop(0, this.options.bgColor), r.addColorStop(1, this.options.insideColor), this.chart.ctx.fillStyle = r, this.chart.ctx.arc(i + e / 2, i + s / 2, e / 2, 0, 2 * Math.PI, !1), this.chart.ctx.shadowColor = this.options.shadowColor, this.chart.ctx.shadowBlur = o, this.chart.ctx.shadowOffsetX = 0, this.chart.ctx.shadowOffsetY = 0, this.chart.ctx.fill(), this.chart.ctx.closePath(), this.chart.ctx.shadowBlur = 0, this.chart.ctx.beginPath(), this.chart.ctx.strokeStyle = this.options.circleColor, this.chart.ctx.lineWidth = h, this.chart.ctx.arc(i + e / 2, i + s / 2, e / 2 - o, -Math.PI / 2, -Math.PI / 2 + 2 * t * Math.PI / 100 * this.data.pourc, !1), this.chart.ctx.stroke(), this.chart.ctx.closePath(), this.chart.ctx.beginPath();
                    var r = this.chart.ctx.createLinearGradient(0, 0, 0, this.chart.height);
                    r.addColorStop(0, this.options.insideColor), r.addColorStop(1, this.options.insideColorEnd), this.chart.ctx.arc(i + e / 2, i + e / 2, e / 2 - n, 0, 2 * Math.PI, !1), this.chart.ctx.fillStyle = r, this.chart.ctx.shadowColor = this.options.shadowColor, this.chart.ctx.shadowBlur = o, this.chart.ctx.shadowOffsetX = 0, this.chart.ctx.shadowOffsetY = 0, this.chart.ctx.fill(), this.chart.ctx.strokeStyle = this.options.textColor, this.chart.ctx.lineWidth = 1, this.chart.ctx.stroke(), this.chart.ctx.closePath(), this.chart.ctx.shadowBlur = 0, this.chart.ctx.fillStyle = this.options.textColor, this.chart.ctx.font = a + "px bnpp_sans_condensed_light,arial", this.chart.ctx.textAlign = "center", this.chart.ctx.textBaseline = "middle", this.chart.ctx.fillText(Math.round(t * this.data.pourc) + "%", this.chart.width / 2, this.chart.height / 2 + 5)
                }
            })
        }.call(this),
        function() {
            var t = this,
                i = t.Chart,
                e = i.helpers;
            i.Type.extend({
                name: "chartPieWithPourc",
                defaults: {
                    bgCircleColor: "#e7e7e7",
                    innerCircleColor: "#FFF",
                    portionColor: "#2491ee",
                    textColor: "#2491ee",
                    marges: 0
                },
                initialize: function(t) {
                    this.data = t, e.animationLoop(this.draw, 30, "easeOutQuad", function() {}, function() {}, this)
                },
                draw: function(t) {
                    var i = this.chart.width - 2 * this.options.marges,
                        e = this.chart.height - 2 * this.options.marges,
                        s = this.options.marges,
                        o = this.options.marges;
                    i > e ? (i = e, s = (this.chart.width - i) / 2) : (e = i, o = (this.chart.width - e) / 2), this.chart.ctx.clearRect(0, 0, this.chart.width, this.chart.height), this.chart.ctx.beginPath(), this.chart.ctx.fillStyle = this.options.bgCircleColor, this.chart.ctx.arc(s + i / 2, o + e / 2, i / 2, 0, 2 * Math.PI, !1), this.chart.ctx.fill(), this.chart.ctx.closePath(), this.chart.ctx.beginPath(), this.chart.ctx.strokeStyle = this.options.portionColor, this.chart.ctx.lineWidth = Math.round(i / 10), this.chart.ctx.arc(s + i / 2, o + e / 2, i / 2 - .7 * Math.round(i / 10), -Math.PI / 2, -Math.PI / 2 + 2 * t * Math.PI / 100 * this.data.pourc, !1), this.chart.ctx.stroke(), this.chart.ctx.closePath(), this.chart.ctx.beginPath(), this.chart.ctx.arc(s + i / 2, o + e / 2, i / 2 - Math.round(i / 10), 0, 2 * Math.PI, !1), this.chart.ctx.fillStyle = this.options.innerCircleColor, this.chart.ctx.fill(), this.chart.ctx.closePath(), this.chart.ctx.fillStyle = this.options.textColor, this.chart.ctx.font = Math.round(i / 4) + "px bnp_bold,arial", this.chart.ctx.textAlign = "center", this.chart.ctx.textBaseline = "middle", this.chart.ctx.fillText(Math.round(t * this.data.pourc) + "%", this.chart.width / 2, this.chart.height / 2)
                }
            })
        }.call(this),
        function() {
            var t = this,
                i = t.Chart,
                e = i.helpers;
            i.Type.extend({
                name: "udcBars",
                defaults: {
                    blueBarTopColor: "#08c2d7",
                    blueBarBottomColor: "#0392b4",
                    blueBarTopBorderColor: "#06e8fe",
                    redBarTopColor: "#fc444e",
                    redBarBottomColor: "#ff5a6c",
                    bgBarsColor: "rgba(0, 0, 0, 0.20)",
                    textColor: "#b3b3b3",
                    boldTextColor: "#FFF",
                    margeTop: 40,
                    margeBottom: 50,
                    margeLeft: 40,
                    margeRight: 70,
                    barsInterspace: 5,
                    boardsInterspace: 30,
                    maxBarsWidth: 30,
                    graphDeadZone: 15,
                    exceeding: 3,
                    rBoardLineHeight: 25,
                    rBoardMarginTop: 22,
                    rBoardLeftExceeding: 15,
                    animationType: "all"
                },
                initialize: function(t) {
                    this.data = h.extend(!0, {}, t), e.animationLoop(this.draw, 30, "easeOutQuad", function() {}, function() {}, this)
                },
                draw: function(t, i) {
                    this.chart.ctx.clearRect(0, 0, this.chart.width, this.chart.height);
                    var e = this.chart.height - this.options.margeTop - this.options.margeBottom,
                        s = this.chart.width - this.options.margeLeft - this.options.margeRight;
                    if (!(0 >= e || 0 >= s)) {
                        var o = (this.chart.height - e) / 2,
                            a = ((this.chart.width - s) / 2, 40),
                            n = 182,
                            r = s - n - this.options.boardsInterspace,
                            l = (r - this.data.bars.length * this.options.barsInterspace) / this.data.bars.length;
                        l > this.options.maxBarsWidth && (l = this.options.maxBarsWidth, this.options.barsInterspace = (r - this.data.bars.length * l) / this.data.bars.length);
                        var c = this.chart.ctx;
                        c.lineWidth = .5;
                        for (var d = [], p = !1, u = 0, f = o + (e - a) / 2, g = 0, x = 0, m = 0; m < this.data.bars.length; m++) Math.abs(this.data.bars[m].value) > g && (g = Math.abs(this.data.bars[m].value)), Math.abs(this.data.bars[m].value) < x && (x = Math.abs(this.data.bars[m].value));
                        for (var b = (e - a - 2 * this.options.graphDeadZone) / 2 / (g - x), m = 0; m < this.data.bars.length; m++) {
                            var v = this.options.margeLeft + this.options.exceeding + m * l + m * this.options.barsInterspace,
                                S = o,
                                y = o + e - a;
                            c.beginPath(), c.fillStyle = this.options.bgBarsColor, c.moveTo(v, S + l / 2), c.arcTo(v, S, v + l / 2, S, l / 2), c.arcTo(v + l, S, v + l, S + l / 2, l / 2), c.lineTo(v + l, y - l / 2), c.arcTo(v + l, y, v + l / 2, y, l / 2), c.arcTo(v, y, v, y - l / 2, l / 2), c.lineTo(v, S + l / 2), c.fill(), c.closePath();
                            var C = f - b * this.data.bars[m].value;
                            if (this.data.bars[m].value > 0) {
                                "progressive" == this.options.animationType ? m < Math.floor(this.data.bars.length * i) ? (C = f - t * (f - C), l / 2 > f - C && (C = f - l / 2)) : C = f - l / 2 : (C = f - t * (f - C), l / 2 > f - C && (C = f - l / 2));
                                var w = c.createLinearGradient(v, C, v, f);
                                w.addColorStop(0, this.options.blueBarTopColor), w.addColorStop(1, this.options.blueBarBottomColor), c.fillStyle = w;
                                var P = c.createLinearGradient(v, C, v, f);
                                P.addColorStop(0, this.options.blueBarTopBorderColor), P.addColorStop(.005, this.options.blueBarTopBorderColor), P.addColorStop(1, this.options.blueBarBottomColor), c.lineWidth = 1.5, c.strokeStyle = P, c.beginPath(), c.moveTo(v, C + l / 2), c.arcTo(v, C, v + l / 2, C, l / 2), c.arcTo(v + l, C, v + l, C + l / 2, l / 2), c.lineTo(v + l, f), c.lineTo(v, f), c.lineTo(v, C + l / 2), c.fill(), c.stroke(), c.closePath()
                            } else {
                                "progressive" == this.options.animationType ? m < Math.floor(this.data.bars.length * i) ? (C = f + t * (C - f), l / 2 > C - f && (C = f + l / 2)) : C = f + l / 2 : (C = f + t * (C - f), l / 2 > C - f && (C = f + l / 2));
                                var w = c.createLinearGradient(v, C, v, f);
                                w.addColorStop(0, this.options.redBarBottomColor), w.addColorStop(1, this.options.redBarTopColor), c.fillStyle = w, c.beginPath(), c.moveTo(v + l, f), c.lineTo(v + l, C - l / 2), c.arcTo(v + l, C, v + l / 2, C, l / 2), c.arcTo(v, C, v, C - l / 2, l / 2), c.lineTo(v, f), c.fill(), c.closePath()
                            }
                            if (c.lineWidth = .5, -1 == h.inArray(this.data.bars[m].month, d)) {
                                if (d.push(this.data.bars[m].month), c.strokeStyle = this.options.textColor, c.beginPath(), c.moveTo(v, y + a / 4), c.lineTo(v, y + 3 * a / 4), c.closePath(), c.stroke(), p) {
                                    c.font = '15px "hello_typeregular", Arial, sans-serif', c.textBaseline = "middle", c.textAlign = "center", c.fillStyle = this.options.textColor;
                                    var T = v - u,
                                        L = this.data.bars[m - 1].month.toUpperCase();
                                    .8 * T <= c.measureText(L).width && (L = L.substr(0, 3)), c.fillText(L, v - (v - u) / 2, y + a / 2)
                                } else p = !0;
                                u = v
                            }
                        }
                        c.lineWidth = 1, c.strokeStyle = "#FFF", c.beginPath(), c.moveTo(this.options.margeLeft, f), c.lineTo(this.options.margeLeft + r, f), c.closePath(), c.stroke(), c.font = '15px "hello_typeregular", Arial, sans-serif', c.textBaseline = "middle", c.textAlign = "center", c.fillStyle = this.options.textColor;
                        var M = this.options.margeLeft + this.options.exceeding + r,
                            T = M - u,
                            L = this.data.bars[this.data.bars.length - 1].month.toUpperCase();
                        .8 * T <= c.measureText(L).width && (L = L.substr(0, 3)), c.fillText(L, M - (M - u) / 2, y + a / 2), c.font = '11px "hello_typeregular", Arial, sans-serif', c.textBaseline = "top", c.textAlign = "left", c.fillStyle = this.options.boldTextColor;
                        var k = "Dernières opérations";
                        c.fillText(k.toUpperCase(), this.options.margeLeft + s - n + this.options.rBoardLeftExceeding, o);
                        for (var m = 0; m < this.data.lastOP.length; m++) c.beginPath(), c.strokeStyle = this.options.textColor, c.lineWidth = .1, c.moveTo(this.options.margeLeft + s - n, o + this.options.rBoardMarginTop + m * this.options.rBoardLineHeight), c.lineTo(this.options.margeLeft + s, o + this.options.rBoardMarginTop + m * this.options.rBoardLineHeight), c.closePath(), c.stroke(), c.textBaseline = "middle", c.textAlign = "left", c.fillStyle = this.options.textColor, c.fillText(this.data.lastOP[m].date, this.options.margeLeft + s - n + this.options.rBoardLeftExceeding, o + this.options.rBoardMarginTop + (m + 1) * this.options.rBoardLineHeight - this.options.rBoardLineHeight / 2), c.textAlign = "right", c.fillText(addThousandsSep(formatNumber(this.data.lastOP[m].montant, 2)) + " €", this.options.margeLeft + s - this.options.rBoardLeftExceeding, o + this.options.rBoardMarginTop + (m + 1) * this.options.rBoardLineHeight - this.options.rBoardLineHeight / 2);
                        c.textAlign = "left", c.textBaseline = "top", c.fillStyle = this.options.boldTextColor, k = "Opérations à venir", c.fillText(k.toUpperCase(), this.options.margeLeft + s - n + this.options.rBoardLeftExceeding, f);
                        for (var m = 0; m < this.data.nextOP.length; m++) c.beginPath(), c.strokeStyle = this.options.textColor, c.lineWidth = .1, c.moveTo(this.options.margeLeft + s - n, f + this.options.rBoardMarginTop + m * this.options.rBoardLineHeight), c.lineTo(this.options.margeLeft + s, f + this.options.rBoardMarginTop + m * this.options.rBoardLineHeight), c.closePath(), c.stroke(), c.textBaseline = "middle", c.textAlign = "left", c.fillStyle = this.options.textColor, c.fillText(this.data.nextOP[m].date, this.options.margeLeft + s - n + this.options.rBoardLeftExceeding, f + this.options.rBoardMarginTop + (m + 1) * this.options.rBoardLineHeight - this.options.rBoardLineHeight / 2), c.textAlign = "right", c.fillText(addThousandsSep(formatNumber(this.data.nextOP[m].montant, 2)) + " €", this.options.margeLeft + s - this.options.rBoardLeftExceeding, f + this.options.rBoardMarginTop + (m + 1) * this.options.rBoardLineHeight - this.options.rBoardLineHeight / 2)
                    }
                }
            })
        }.call(this),
        function() {
            var t = this,
                i = t.Chart,
                e = i.helpers;
            i.Type.extend({
                name: "handle",
                defaults: {
                    type: "left",
                    color: "rgba(255, 255, 255, 0.7)",
                    hoverColor: "#FFF",
                    clickColor: "#09cbdc",
                    marges: 2,
                    tooltipEvents: ["mousemove", "touchstart", "touchmove", "mouseout", "mouseup", "mousedown"]
                },
                initialize: function(t) {
                    this.data = h.extend(!0, {}, t), e.bindEvents(this, this.options.tooltipEvents, function(t) {
                        "mousemove" == t.type ? this.draw(this.options.hoverColor, 2.5) : "mousedown" == t.type ? this.draw(this.options.clickColor, 2.5) : this.draw(this.options.color, 2)
                    }), this.draw(this.options.color, 2)
                },
                draw: function(t, i) {
                    var e = this.chart.ctx;
                    e.clearRect(0, 0, this.chart.width, this.chart.height), e.beginPath(), this.options.handlerBlur && (e.shadowBlur = this.chart.width / 6, e.shadowColor = "rgba(0, 0, 0, 0.8)", this.options.marges = this.chart.width / 6), "left" == this.options.type ? (e.moveTo(this.chart.width - this.options.marges, this.options.marges), e.lineTo(this.options.marges, this.chart.height / 2), e.lineTo(this.chart.width - this.options.marges, this.chart.height - this.options.marges)) : (e.moveTo(this.options.marges, this.options.marges), e.lineTo(this.chart.width - this.options.marges, this.chart.height / 2), e.lineTo(this.options.marges, this.chart.height - this.options.marges)), e.strokeStyle = t, e.lineWidth = i, e.stroke(), e.closePath()
                }
            })
        }.call(this), o("chart", function(t) {
            return function() {
                var i;
                return i || t.Chart
            }
        }(this))
}(window, document, bnpp.sf31.requirejs, bnpp.sf31.requirejs, bnpp.sf31.define, bnpp.jquery, bnpp.jquery, bnpp.jquery);
//# sourceMappingURL=chart-1.0.1-bnpp.js.map
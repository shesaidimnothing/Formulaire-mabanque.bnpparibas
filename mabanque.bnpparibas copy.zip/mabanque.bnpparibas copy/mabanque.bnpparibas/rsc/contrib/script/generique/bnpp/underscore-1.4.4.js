! function(n, t, r, e, u) {
    u("underscore", ["require", "exports", "module"], function(n, t, r) {
        (function() {
            var n = this,
                e = n._,
                u = {},
                i = Array.prototype,
                a = Object.prototype,
                o = Function.prototype,
                c = i.push,
                l = i.slice,
                f = i.concat,
                s = a.toString,
                p = a.hasOwnProperty,
                h = i.forEach,
                v = i.map,
                d = i.reduce,
                g = i.reduceRight,
                m = i.filter,
                y = i.every,
                b = i.some,
                _ = i.indexOf,
                x = i.lastIndexOf,
                j = Array.isArray,
                w = Object.keys,
                A = o.bind,
                O = function(n) {
                    return n instanceof O ? n : this instanceof O ? (this._wrapped = n, void 0) : new O(n)
                };
            "undefined" != typeof t ? ("undefined" != typeof r && r.exports && (t = r.exports = O), t._ = O) : n._ = O, O.VERSION = "1.4.4";
            var E = O.each = O.forEach = function(n, t, r) {
                if (null != n)
                    if (h && n.forEach === h) n.forEach(t, r);
                    else if (n.length === +n.length) {
                    for (var e = 0, i = n.length; i > e; e++)
                        if (t.call(r, n[e], e, n) === u) return
                } else
                    for (var a in n)
                        if (O.has(n, a) && t.call(r, n[a], a, n) === u) return
            };
            O.map = O.collect = function(n, t, r) {
                var e = [];
                return null == n ? e : v && n.map === v ? n.map(t, r) : (E(n, function(n, u, i) {
                    e[e.length] = t.call(r, n, u, i)
                }), e)
            };
            var k = "Reduce of empty array with no initial value";
            O.reduce = O.foldl = O.inject = function(n, t, r, e) {
                var u = arguments.length > 2;
                if (null == n && (n = []), d && n.reduce === d) return e && (t = O.bind(t, e)), u ? n.reduce(t, r) : n.reduce(t);
                if (E(n, function(n, i, a) {
                        u ? r = t.call(e, r, n, i, a) : (r = n, u = !0)
                    }), !u) throw new TypeError(k);
                return r
            }, O.reduceRight = O.foldr = function(n, t, r, e) {
                var u = arguments.length > 2;
                if (null == n && (n = []), g && n.reduceRight === g) return e && (t = O.bind(t, e)), u ? n.reduceRight(t, r) : n.reduceRight(t);
                var i = n.length;
                if (i !== +i) {
                    var a = O.keys(n);
                    i = a.length
                }
                if (E(n, function(o, c, l) {
                        c = a ? a[--i] : --i, u ? r = t.call(e, r, n[c], c, l) : (r = n[c], u = !0)
                    }), !u) throw new TypeError(k);
                return r
            }, O.find = O.detect = function(n, t, r) {
                var e;
                return F(n, function(n, u, i) {
                    return t.call(r, n, u, i) ? (e = n, !0) : void 0
                }), e
            }, O.filter = O.select = function(n, t, r) {
                var e = [];
                return null == n ? e : m && n.filter === m ? n.filter(t, r) : (E(n, function(n, u, i) {
                    t.call(r, n, u, i) && (e[e.length] = n)
                }), e)
            }, O.reject = function(n, t, r) {
                return O.filter(n, function(n, e, u) {
                    return !t.call(r, n, e, u)
                }, r)
            }, O.every = O.all = function(n, t, r) {
                t || (t = O.identity);
                var e = !0;
                return null == n ? e : y && n.every === y ? n.every(t, r) : (E(n, function(n, i, a) {
                    return (e = e && t.call(r, n, i, a)) ? void 0 : u
                }), !!e)
            };
            var F = O.some = O.any = function(n, t, r) {
                t || (t = O.identity);
                var e = !1;
                return null == n ? e : b && n.some === b ? n.some(t, r) : (E(n, function(n, i, a) {
                    return e || (e = t.call(r, n, i, a)) ? u : void 0
                }), !!e)
            };
            O.contains = O.include = function(n, t) {
                return null == n ? !1 : _ && n.indexOf === _ ? -1 != n.indexOf(t) : F(n, function(n) {
                    return n === t
                })
            }, O.invoke = function(n, t) {
                var r = l.call(arguments, 2),
                    e = O.isFunction(t);
                return O.map(n, function(n) {
                    return (e ? t : n[t]).apply(n, r)
                })
            }, O.pluck = function(n, t) {
                return O.map(n, function(n) {
                    return n[t]
                })
            }, O.where = function(n, t, r) {
                return O.isEmpty(t) ? r ? null : [] : O[r ? "find" : "filter"](n, function(n) {
                    for (var r in t)
                        if (t[r] !== n[r]) return !1;
                    return !0
                })
            }, O.findWhere = function(n, t) {
                return O.where(n, t, !0)
            }, O.max = function(n, t, r) {
                if (!t && O.isArray(n) && n[0] === +n[0] && n.length < 65535) return Math.max.apply(Math, n);
                if (!t && O.isEmpty(n)) return -1 / 0;
                var e = {
                    computed: -1 / 0,
                    value: -1 / 0
                };
                return E(n, function(n, u, i) {
                    var a = t ? t.call(r, n, u, i) : n;
                    a >= e.computed && (e = {
                        value: n,
                        computed: a
                    })
                }), e.value
            }, O.min = function(n, t, r) {
                if (!t && O.isArray(n) && n[0] === +n[0] && n.length < 65535) return Math.min.apply(Math, n);
                if (!t && O.isEmpty(n)) return 1 / 0;
                var e = {
                    computed: 1 / 0,
                    value: 1 / 0
                };
                return E(n, function(n, u, i) {
                    var a = t ? t.call(r, n, u, i) : n;
                    a < e.computed && (e = {
                        value: n,
                        computed: a
                    })
                }), e.value
            }, O.shuffle = function(n) {
                var t, r = 0,
                    e = [];
                return E(n, function(n) {
                    t = O.random(r++), e[r - 1] = e[t], e[t] = n
                }), e
            };
            var q = function(n) {
                return O.isFunction(n) ? n : function(t) {
                    return t[n]
                }
            };
            O.sortBy = function(n, t, r) {
                var e = q(t);
                return O.pluck(O.map(n, function(n, t, u) {
                    return {
                        value: n,
                        index: t,
                        criteria: e.call(r, n, t, u)
                    }
                }).sort(function(n, t) {
                    var r = n.criteria,
                        e = t.criteria;
                    if (r !== e) {
                        if (r > e || void 0 === r) return 1;
                        if (e > r || void 0 === e) return -1
                    }
                    return n.index < t.index ? -1 : 1
                }), "value")
            };
            var R = function(n, t, r, e) {
                var u = {},
                    i = q(t || O.identity);
                return E(n, function(t, a) {
                    var o = i.call(r, t, a, n);
                    e(u, o, t)
                }), u
            };
            O.groupBy = function(n, t, r) {
                return R(n, t, r, function(n, t, r) {
                    (O.has(n, t) ? n[t] : n[t] = []).push(r)
                })
            }, O.countBy = function(n, t, r) {
                return R(n, t, r, function(n, t) {
                    O.has(n, t) || (n[t] = 0), n[t]++
                })
            }, O.sortedIndex = function(n, t, r, e) {
                r = null == r ? O.identity : q(r);
                for (var u = r.call(e, t), i = 0, a = n.length; a > i;) {
                    var o = i + a >>> 1;
                    r.call(e, n[o]) < u ? i = o + 1 : a = o
                }
                return i
            }, O.toArray = function(n) {
                return n ? O.isArray(n) ? l.call(n) : n.length === +n.length ? O.map(n, O.identity) : O.values(n) : []
            }, O.size = function(n) {
                return null == n ? 0 : n.length === +n.length ? n.length : O.keys(n).length
            }, O.first = O.head = O.take = function(n, t, r) {
                return null == n ? void 0 : null == t || r ? n[0] : l.call(n, 0, t)
            }, O.initial = function(n, t, r) {
                return l.call(n, 0, n.length - (null == t || r ? 1 : t))
            }, O.last = function(n, t, r) {
                return null == n ? void 0 : null == t || r ? n[n.length - 1] : l.call(n, Math.max(n.length - t, 0))
            }, O.rest = O.tail = O.drop = function(n, t, r) {
                return l.call(n, null == t || r ? 1 : t)
            }, O.compact = function(n) {
                return O.filter(n, O.identity)
            };
            var S = function(n, t, r) {
                return E(n, function(n) {
                    O.isArray(n) ? t ? c.apply(r, n) : S(n, t, r) : r.push(n)
                }), r
            };
            O.flatten = function(n, t) {
                return S(n, t, [])
            }, O.without = function(n) {
                return O.difference(n, l.call(arguments, 1))
            }, O.uniq = O.unique = function(n, t, r, e) {
                O.isFunction(t) && (e = r, r = t, t = !1);
                var u = r ? O.map(n, r, e) : n,
                    i = [],
                    a = [];
                return E(u, function(r, e) {
                    (t ? e && a[a.length - 1] === r : O.contains(a, r)) || (a.push(r), i.push(n[e]))
                }), i
            }, O.union = function() {
                return O.uniq(f.apply(i, arguments))
            }, O.intersection = function(n) {
                var t = l.call(arguments, 1);
                return O.filter(O.uniq(n), function(n) {
                    return O.every(t, function(t) {
                        return O.indexOf(t, n) >= 0
                    })
                })
            }, O.difference = function(n) {
                var t = f.apply(i, l.call(arguments, 1));
                return O.filter(n, function(n) {
                    return !O.contains(t, n)
                })
            }, O.zip = function() {
                for (var n = l.call(arguments), t = O.max(O.pluck(n, "length")), r = new Array(t), e = 0; t > e; e++) r[e] = O.pluck(n, "" + e);
                return r
            }, O.object = function(n, t) {
                if (null == n) return {};
                for (var r = {}, e = 0, u = n.length; u > e; e++) t ? r[n[e]] = t[e] : r[n[e][0]] = n[e][1];
                return r
            }, O.indexOf = function(n, t, r) {
                if (null == n) return -1;
                var e = 0,
                    u = n.length;
                if (r) {
                    if ("number" != typeof r) return e = O.sortedIndex(n, t), n[e] === t ? e : -1;
                    e = 0 > r ? Math.max(0, u + r) : r
                }
                if (_ && n.indexOf === _) return n.indexOf(t, r);
                for (; u > e; e++)
                    if (n[e] === t) return e;
                return -1
            }, O.lastIndexOf = function(n, t, r) {
                if (null == n) return -1;
                var e = null != r;
                if (x && n.lastIndexOf === x) return e ? n.lastIndexOf(t, r) : n.lastIndexOf(t);
                for (var u = e ? r : n.length; u--;)
                    if (n[u] === t) return u;
                return -1
            }, O.range = function(n, t, r) {
                arguments.length <= 1 && (t = n || 0, n = 0), r = arguments[2] || 1;
                for (var e = Math.max(Math.ceil((t - n) / r), 0), u = 0, i = new Array(e); e > u;) i[u++] = n, n += r;
                return i
            }, O.bind = function(n, t) {
                if (n.bind === A && A) return A.apply(n, l.call(arguments, 1));
                var r = l.call(arguments, 2);
                return function() {
                    return n.apply(t, r.concat(l.call(arguments)))
                }
            }, O.partial = function(n) {
                var t = l.call(arguments, 1);
                return function() {
                    return n.apply(this, t.concat(l.call(arguments)))
                }
            }, O.bindAll = function(n) {
                var t = l.call(arguments, 1);
                return 0 === t.length && (t = O.functions(n)), E(t, function(t) {
                    n[t] = O.bind(n[t], n)
                }), n
            }, O.memoize = function(n, t) {
                var r = {};
                return t || (t = O.identity),
                    function() {
                        var e = t.apply(this, arguments);
                        return O.has(r, e) ? r[e] : r[e] = n.apply(this, arguments)
                    }
            }, O.delay = function(n, t) {
                var r = l.call(arguments, 2);
                return setTimeout(function() {
                    return n.apply(null, r)
                }, t)
            }, O.defer = function(n) {
                return O.delay.apply(O, [n, 1].concat(l.call(arguments, 1)))
            }, O.throttle = function(n, t) {
                var r, e, u, i, a = 0,
                    o = function() {
                        a = new Date, u = null, i = n.apply(r, e)
                    };
                return function() {
                    var c = new Date,
                        l = t - (c - a);
                    return r = this, e = arguments, 0 >= l ? (clearTimeout(u), u = null, a = c, i = n.apply(r, e)) : u || (u = setTimeout(o, l)), i
                }
            }, O.debounce = function(n, t, r) {
                var e, u;
                return function() {
                    var i = this,
                        a = arguments,
                        o = function() {
                            e = null, r || (u = n.apply(i, a))
                        },
                        c = r && !e;
                    return clearTimeout(e), e = setTimeout(o, t), c && (u = n.apply(i, a)), u
                }
            }, O.once = function(n) {
                var t, r = !1;
                return function() {
                    return r ? t : (r = !0, t = n.apply(this, arguments), n = null, t)
                }
            }, O.wrap = function(n, t) {
                return function() {
                    var r = [n];
                    return c.apply(r, arguments), t.apply(this, r)
                }
            }, O.compose = function() {
                var n = arguments;
                return function() {
                    for (var t = arguments, r = n.length - 1; r >= 0; r--) t = [n[r].apply(this, t)];
                    return t[0]
                }
            }, O.after = function(n, t) {
                return 0 >= n ? t() : function() {
                    return --n < 1 ? t.apply(this, arguments) : void 0
                }
            }, O.keys = w || function(n) {
                if (n !== Object(n)) throw new TypeError("Invalid object");
                var t = [];
                for (var r in n) O.has(n, r) && (t[t.length] = r);
                return t
            }, O.values = function(n) {
                var t = [];
                for (var r in n) O.has(n, r) && t.push(n[r]);
                return t
            }, O.pairs = function(n) {
                var t = [];
                for (var r in n) O.has(n, r) && t.push([r, n[r]]);
                return t
            }, O.invert = function(n) {
                var t = {};
                for (var r in n) O.has(n, r) && (t[n[r]] = r);
                return t
            }, O.functions = O.methods = function(n) {
                var t = [];
                for (var r in n) O.isFunction(n[r]) && t.push(r);
                return t.sort()
            }, O.extend = function(n) {
                return E(l.call(arguments, 1), function(t) {
                    if (t)
                        for (var r in t) n[r] = t[r]
                }), n
            }, O.pick = function(n) {
                var t = {},
                    r = f.apply(i, l.call(arguments, 1));
                return E(r, function(r) {
                    r in n && (t[r] = n[r])
                }), t
            }, O.omit = function(n) {
                var t = {},
                    r = f.apply(i, l.call(arguments, 1));
                for (var e in n) O.contains(r, e) || (t[e] = n[e]);
                return t
            }, O.defaults = function(n) {
                return E(l.call(arguments, 1), function(t) {
                    if (t)
                        for (var r in t) null == n[r] && (n[r] = t[r])
                }), n
            }, O.clone = function(n) {
                return O.isObject(n) ? O.isArray(n) ? n.slice() : O.extend({}, n) : n
            }, O.tap = function(n, t) {
                return t(n), n
            };
            var I = function(n, t, r, e) {
                if (n === t) return 0 !== n || 1 / n == 1 / t;
                if (null == n || null == t) return n === t;
                n instanceof O && (n = n._wrapped), t instanceof O && (t = t._wrapped);
                var u = s.call(n);
                if (u != s.call(t)) return !1;
                switch (u) {
                    case "[object String]":
                        return n == String(t);
                    case "[object Number]":
                        return n != +n ? t != +t : 0 == n ? 1 / n == 1 / t : n == +t;
                    case "[object Date]":
                    case "[object Boolean]":
                        return +n == +t;
                    case "[object RegExp]":
                        return n.source == t.source && n.global == t.global && n.multiline == t.multiline && n.ignoreCase == t.ignoreCase
                }
                if ("object" != typeof n || "object" != typeof t) return !1;
                for (var i = r.length; i--;)
                    if (r[i] == n) return e[i] == t;
                r.push(n), e.push(t);
                var a = 0,
                    o = !0;
                if ("[object Array]" == u) {
                    if (a = n.length, o = a == t.length)
                        for (; a-- && (o = I(n[a], t[a], r, e)););
                } else {
                    var c = n.constructor,
                        l = t.constructor;
                    if (c !== l && !(O.isFunction(c) && c instanceof c && O.isFunction(l) && l instanceof l)) return !1;
                    for (var f in n)
                        if (O.has(n, f) && (a++, !(o = O.has(t, f) && I(n[f], t[f], r, e)))) break;
                    if (o) {
                        for (f in t)
                            if (O.has(t, f) && !a--) break;
                        o = !a
                    }
                }
                return r.pop(), e.pop(), o
            };
            O.isEqual = function(n, t) {
                return I(n, t, [], [])
            }, O.isEmpty = function(n) {
                if (null == n) return !0;
                if (O.isArray(n) || O.isString(n)) return 0 === n.length;
                for (var t in n)
                    if (O.has(n, t)) return !1;
                return !0
            }, O.isElement = function(n) {
                return !(!n || 1 !== n.nodeType)
            }, O.isArray = j || function(n) {
                return "[object Array]" == s.call(n)
            }, O.isObject = function(n) {
                return n === Object(n)
            }, E(["Arguments", "Function", "String", "Number", "Date", "RegExp"], function(n) {
                O["is" + n] = function(t) {
                    return s.call(t) == "[object " + n + "]"
                }
            }), O.isArguments(arguments) || (O.isArguments = function(n) {
                return !(!n || !O.has(n, "callee"))
            }), "function" != typeof /./ && (O.isFunction = function(n) {
                return "function" == typeof n
            }), O.isFinite = function(n) {
                return isFinite(n) && !isNaN(parseFloat(n))
            }, O.isNaN = function(n) {
                return O.isNumber(n) && n != +n
            }, O.isBoolean = function(n) {
                return n === !0 || n === !1 || "[object Boolean]" == s.call(n)
            }, O.isNull = function(n) {
                return null === n
            }, O.isUndefined = function(n) {
                return void 0 === n
            }, O.has = function(n, t) {
                return p.call(n, t)
            }, O.noConflict = function() {
                return n._ = e, this
            }, O.identity = function(n) {
                return n
            }, O.times = function(n, t, r) {
                for (var e = Array(n), u = 0; n > u; u++) e[u] = t.call(r, u);
                return e
            }, O.random = function(n, t) {
                return null == t && (t = n, n = 0), n + Math.floor(Math.random() * (t - n + 1))
            };
            var M = {
                escape: {
                    "&": "&amp;",
                    "<": "&lt;",
                    ">": "&gt;",
                    '"': "&quot;",
                    "'": "&#x27;",
                    "/": "&#x2F;"
                }
            };
            M.unescape = O.invert(M.escape);
            var N = {
                escape: new RegExp("[" + O.keys(M.escape).join("") + "]", "g"),
                unescape: new RegExp("(" + O.keys(M.unescape).join("|") + ")", "g")
            };
            O.each(["escape", "unescape"], function(n) {
                O[n] = function(t) {
                    return null == t ? "" : ("" + t).replace(N[n], function(t) {
                        return M[n][t]
                    })
                }
            }), O.result = function(n, t) {
                if (null == n) return null;
                var r = n[t];
                return O.isFunction(r) ? r.call(n) : r
            }, O.mixin = function(n) {
                E(O.functions(n), function(t) {
                    var r = O[t] = n[t];
                    O.prototype[t] = function() {
                        var n = [this._wrapped];
                        return c.apply(n, arguments), C.call(this, r.apply(O, n))
                    }
                })
            };
            var T = 0;
            O.uniqueId = function(n) {
                var t = ++T + "";
                return n ? n + t : t
            }, O.templateSettings = {
                evaluate: /<%([\s\S]+?)%>/g,
                interpolate: /<%=([\s\S]+?)%>/g,
                escape: /<%-([\s\S]+?)%>/g
            };
            var B = /(.)^/,
                D = {
                    "'": "'",
                    "\\": "\\",
                    "\r": "r",
                    "\n": "n",
                    "	": "t",
                    "\u2028": "u2028",
                    "\u2029": "u2029"
                },
                z = /\\|'|\r|\n|\t|\u2028|\u2029/g;
            O.template = function(n, t, r) {
                var e;
                r = O.defaults({}, r, O.templateSettings);
                var u = new RegExp([(r.escape || B).source, (r.interpolate || B).source, (r.evaluate || B).source].join("|") + "|$", "g"),
                    i = 0,
                    a = "__p+='";
                n.replace(u, function(t, r, e, u, o) {
                    return a += n.slice(i, o).replace(z, function(n) {
                        return "\\" + D[n]
                    }), r && (a += "'+\n((__t=(" + r + "))==null?'':_.escape(__t))+\n'"), e && (a += "'+\n((__t=(" + e + "))==null?'':__t)+\n'"), u && (a += "';\n" + u + "\n__p+='"), i = o + t.length, t
                }), a += "';\n", r.variable || (a = "with(obj||{}){\n" + a + "}\n"), a = "var __t,__p='',__j=Array.prototype.join,print=function(){__p+=__j.call(arguments,'');};\n" + a + "return __p;\n";
                try {
                    e = new Function(r.variable || "obj", "_", a)
                } catch (o) {
                    throw o.source = a, o
                }
                if (t) return e(t, O);
                var c = function(n) {
                    return e.call(this, n, O)
                };
                return c.source = "function(" + (r.variable || "obj") + "){\n" + a + "}", c
            }, O.chain = function(n) {
                return O(n).chain()
            };
            var C = function(n) {
                return this._chain ? O(n).chain() : n
            };
            O.mixin(O), E(["pop", "push", "reverse", "shift", "sort", "splice", "unshift"], function(n) {
                var t = i[n];
                O.prototype[n] = function() {
                    var r = this._wrapped;
                    return t.apply(r, arguments), "shift" != n && "splice" != n || 0 !== r.length || delete r[0], C.call(this, r)
                }
            }), E(["concat", "join", "slice"], function(n) {
                var t = i[n];
                O.prototype[n] = function() {
                    return C.call(this, t.apply(this._wrapped, arguments))
                }
            }), O.extend(O.prototype, {
                chain: function() {
                    return this._chain = !0, this
                },
                value: function() {
                    return this._wrapped
                }
            })
        }).call(this)
    })
}(window, document, bnpp.sf31.requirejs, bnpp.sf31.requirejs, bnpp.sf31.define, bnpp.jquery, bnpp.jquery, bnpp.jquery);
//# sourceMappingURL=underscore-1.4.4.js.map
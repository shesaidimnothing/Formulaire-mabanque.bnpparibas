(function(t, e, i, s, n, r, a, o, h, u) {
    (function() {
        var s, n = this,
            r = n.Backbone,
            a = [],
            o = a.push,
            h = a.slice,
            c = a.splice;
        s = "undefined" != typeof u ? u : n.Backbone = {}, s.VERSION = "1.0.0";
        var l = n._;
        l || "undefined" == typeof i || (l = i("underscore")), s.$ = n.jQuery || n.Zepto || n.ender || n.$, s.noConflict = function() {
            return n.Backbone = r, this
        }, s.emulateHTTP = !1, s.emulateJSON = !1;
        var d = s.Events = {
                on: function(t, e, i) {
                    if (!p(this, "on", t, [e, i]) || !e) return this;
                    this._events || (this._events = {});
                    var s = this._events[t] || (this._events[t] = []);
                    return s.push({
                        callback: e,
                        context: i,
                        ctx: i || this
                    }), this
                },
                once: function(t, e, i) {
                    if (!p(this, "once", t, [e, i]) || !e) return this;
                    var s = this,
                        n = l.once(function() {
                            s.off(t, n), e.apply(this, arguments)
                        });
                    return n._callback = e, this.on(t, n, i)
                },
                off: function(t, e, i) {
                    var s, n, r, a, o, h, u, c;
                    if (!this._events || !p(this, "off", t, [e, i])) return this;
                    if (!t && !e && !i) return this._events = {}, this;
                    for (a = t ? [t] : l.keys(this._events), o = 0, h = a.length; h > o; o++)
                        if (t = a[o], r = this._events[t]) {
                            if (this._events[t] = s = [], e || i)
                                for (u = 0, c = r.length; c > u; u++) n = r[u], (e && e !== n.callback && e !== n.callback._callback || i && i !== n.context) && s.push(n);
                            s.length || delete this._events[t]
                        }
                    return this
                },
                trigger: function(t) {
                    if (!this._events) return this;
                    var e = h.call(arguments, 1);
                    if (!p(this, "trigger", t, e)) return this;
                    var i = this._events[t],
                        s = this._events.all;
                    return i && g(i, e), s && g(s, arguments), this
                },
                stopListening: function(t, e, i) {
                    var s = this._listeners;
                    if (!s) return this;
                    var n = !e && !i;
                    "object" == typeof e && (i = this), t && ((s = {})[t._listenerId] = t);
                    for (var r in s) s[r].off(e, i, this), n && delete this._listeners[r];
                    return this
                }
            },
            f = /\s+/,
            p = function(t, e, i, s) {
                if (!i) return !0;
                if ("object" == typeof i) {
                    for (var n in i) t[e].apply(t, [n, i[n]].concat(s));
                    return !1
                }
                if (f.test(i)) {
                    for (var r = i.split(f), a = 0, o = r.length; o > a; a++) t[e].apply(t, [r[a]].concat(s));
                    return !1
                }
                return !0
            },
            g = function(t, e) {
                var i, s = -1,
                    n = t.length,
                    r = e[0],
                    a = e[1],
                    o = e[2];
                switch (e.length) {
                    case 0:
                        for (; ++s < n;)(i = t[s]).callback.call(i.ctx);
                        return;
                    case 1:
                        for (; ++s < n;)(i = t[s]).callback.call(i.ctx, r);
                        return;
                    case 2:
                        for (; ++s < n;)(i = t[s]).callback.call(i.ctx, r, a);
                        return;
                    case 3:
                        for (; ++s < n;)(i = t[s]).callback.call(i.ctx, r, a, o);
                        return;
                    default:
                        for (; ++s < n;)(i = t[s]).callback.apply(i.ctx, e)
                }
            },
            v = {
                listenTo: "on",
                listenToOnce: "once"
            };
        l.each(v, function(t, e) {
            d[e] = function(e, i, s) {
                var n = this._listeners || (this._listeners = {}),
                    r = e._listenerId || (e._listenerId = l.uniqueId("l"));
                return n[r] = e, "object" == typeof i && (s = this), e[t](i, s, this), this
            }
        }), d.bind = d.on, d.unbind = d.off, l.extend(s, d);
        var m = s.Model = function(t, e) {
                var i, s = t || {};
                e || (e = {}), this.cid = l.uniqueId("c"), this.attributes = {}, l.extend(this, l.pick(e, y)), e.parse && (s = this.parse(s, e) || {}), (i = l.result(this, "defaults")) && (s = l.defaults({}, s, i)), this.set(s, e), this.changed = {}, this.initialize.apply(this, arguments)
            },
            y = ["url", "urlRoot", "collection"];
        l.extend(m.prototype, d, {
            changed: null,
            validationError: null,
            idAttribute: "id",
            initialize: function() {},
            toJSON: function() {
                return l.clone(this.attributes)
            },
            sync: function() {
                return s.sync.apply(this, arguments)
            },
            get: function(t) {
                return this.attributes[t]
            },
            escape: function(t) {
                return l.escape(this.get(t))
            },
            has: function(t) {
                return null != this.get(t)
            },
            set: function(t, e, i) {
                var s, n, r, a, o, h, u, c;
                if (null == t) return this;
                if ("object" == typeof t ? (n = t, i = e) : (n = {})[t] = e, i || (i = {}), !this._validate(n, i)) return !1;
                r = i.unset, o = i.silent, a = [], h = this._changing, this._changing = !0, h || (this._previousAttributes = l.clone(this.attributes), this.changed = {}), c = this.attributes, u = this._previousAttributes, this.idAttribute in n && (this.id = n[this.idAttribute]);
                for (s in n) e = n[s], l.isEqual(c[s], e) || a.push(s), l.isEqual(u[s], e) ? delete this.changed[s] : this.changed[s] = e, r ? delete c[s] : c[s] = e;
                if (!o) {
                    a.length && (this._pending = !0);
                    for (var d = 0, f = a.length; f > d; d++) this.trigger("change:" + a[d], this, c[a[d]], i)
                }
                if (h) return this;
                if (!o)
                    for (; this._pending;) this._pending = !1, this.trigger("change", this, i);
                return this._pending = !1, this._changing = !1, this
            },
            unset: function(t, e) {
                return this.set(t, void 0, l.extend({}, e, {
                    unset: !0
                }))
            },
            clear: function(t) {
                var e = {};
                for (var i in this.attributes) e[i] = void 0;
                return this.set(e, l.extend({}, t, {
                    unset: !0
                }))
            },
            hasChanged: function(t) {
                return null == t ? !l.isEmpty(this.changed) : l.has(this.changed, t)
            },
            changedAttributes: function(t) {
                if (!t) return this.hasChanged() ? l.clone(this.changed) : !1;
                var e, i = !1,
                    s = this._changing ? this._previousAttributes : this.attributes;
                for (var n in t) l.isEqual(s[n], e = t[n]) || ((i || (i = {}))[n] = e);
                return i
            },
            previous: function(t) {
                return null != t && this._previousAttributes ? this._previousAttributes[t] : null
            },
            previousAttributes: function() {
                return l.clone(this._previousAttributes)
            },
            fetch: function(t) {
                t = t ? l.clone(t) : {}, void 0 === t.parse && (t.parse = !0);
                var e = this,
                    i = t.success;
                return t.success = function(s) {
                    return e.set(e.parse(s, t), t) ? (i && i(e, s, t), e.trigger("sync", e, s, t), void 0) : !1
                }, J(this, t), this.sync("read", this, t)
            },
            save: function(t, e, i) {
                var s, n, r, a = this.attributes;
                if (null == t || "object" == typeof t ? (s = t, i = e) : (s = {})[t] = e, !(!s || i && i.wait || this.set(s, i))) return !1;
                if (i = l.extend({
                        validate: !0
                    }, i), !this._validate(s, i)) return !1;
                s && i.wait && (this.attributes = l.extend({}, a, s)), void 0 === i.parse && (i.parse = !0);
                var o = this,
                    h = i.success;
                return i.success = function(t) {
                    o.attributes = a;
                    var e = o.parse(t, i);
                    return i.wait && (e = l.extend(s || {}, e)), l.isObject(e) && !o.set(e, i) ? !1 : (h && h(o, t, i), o.trigger("sync", o, t, i), void 0)
                }, J(this, i), n = this.isNew() ? "create" : i.patch ? "patch" : "update", "patch" === n && (i.attrs = s), r = this.sync(n, this, i), s && i.wait && (this.attributes = a), r
            },
            destroy: function(t) {
                t = t ? l.clone(t) : {};
                var e = this,
                    i = t.success,
                    s = function() {
                        e.trigger("destroy", e, e.collection, t)
                    };
                if (t.success = function(n) {
                        (t.wait || e.isNew()) && s(), i && i(e, n, t), e.isNew() || e.trigger("sync", e, n, t)
                    }, this.isNew()) return t.success(), !1;
                J(this, t);
                var n = this.sync("delete", this, t);
                return t.wait || s(), n
            },
            url: function() {
                var t = l.result(this, "urlRoot") || l.result(this.collection, "url") || M();
                return this.isNew() ? t : t + ("/" === t.charAt(t.length - 1) ? "" : "/") + encodeURIComponent(this.id)
            },
            parse: function(t) {
                return t
            },
            clone: function() {
                return new this.constructor(this.attributes)
            },
            isNew: function() {
                return null == this.id
            },
            isValid: function(t) {
                return this._validate({}, l.extend(t || {}, {
                    validate: !0
                }))
            },
            _validate: function(t, e) {
                if (!e.validate || !this.validate) return !0;
                t = l.extend({}, this.attributes, t);
                var i = this.validationError = this.validate(t, e) || null;
                return i ? (this.trigger("invalid", this, i, l.extend(e || {}, {
                    validationError: i
                })), !1) : !0
            }
        });
        var _ = ["keys", "values", "pairs", "invert", "pick", "omit"];
        l.each(_, function(t) {
            m.prototype[t] = function() {
                var e = h.call(arguments);
                return e.unshift(this.attributes), l[t].apply(l, e)
            }
        });
        var b = s.Collection = function(t, e) {
                e || (e = {}), e.url && (this.url = e.url), e.model && (this.model = e.model), void 0 !== e.comparator && (this.comparator = e.comparator), this._reset(), this.initialize.apply(this, arguments), t && this.reset(t, l.extend({
                    silent: !0
                }, e))
            },
            x = {
                add: !0,
                remove: !0,
                merge: !0
            },
            w = {
                add: !0,
                merge: !1,
                remove: !1
            };
        l.extend(b.prototype, d, {
            model: m,
            initialize: function() {},
            toJSON: function(t) {
                return this.map(function(e) {
                    return e.toJSON(t)
                })
            },
            sync: function() {
                return s.sync.apply(this, arguments)
            },
            add: function(t, e) {
                return this.set(t, l.defaults(e || {}, w))
            },
            remove: function(t, e) {
                t = l.isArray(t) ? t.slice() : [t], e || (e = {});
                var i, s, n, r;
                for (i = 0, s = t.length; s > i; i++) r = this.get(t[i]), r && (delete this._byId[r.id], delete this._byId[r.cid], n = this.indexOf(r), this.models.splice(n, 1), this.length--, e.silent || (e.index = n, r.trigger("remove", r, this, e)), this._removeReference(r));
                return this
            },
            set: function(t, e) {
                e = l.defaults(e || {}, x), e.parse && (t = this.parse(t, e)), l.isArray(t) || (t = t ? [t] : []);
                var i, s, n, r, a, h = e.at,
                    u = this.comparator && null == h && e.sort !== !1,
                    d = l.isString(this.comparator) ? this.comparator : null,
                    f = [],
                    p = [],
                    g = {};
                for (i = 0, s = t.length; s > i; i++)(n = this._prepareModel(t[i], e)) && ((r = this.get(n)) ? (e.remove && (g[r.cid] = !0), e.merge && (r.set(n.attributes, e), u && !a && r.hasChanged(d) && (a = !0))) : e.add && (f.push(n), n.on("all", this._onModelEvent, this), this._byId[n.cid] = n, null != n.id && (this._byId[n.id] = n)));
                if (e.remove) {
                    for (i = 0, s = this.length; s > i; ++i) g[(n = this.models[i]).cid] || p.push(n);
                    p.length && this.remove(p, e)
                }
                if (f.length && (u && (a = !0), this.length += f.length, null != h ? c.apply(this.models, [h, 0].concat(f)) : o.apply(this.models, f)), a && this.sort({
                        silent: !0
                    }), e.silent) return this;
                for (i = 0, s = f.length; s > i; i++)(n = f[i]).trigger("add", n, this, e);
                return a && this.trigger("sort", this, e), this
            },
            reset: function(t, e) {
                e || (e = {});
                for (var i = 0, s = this.models.length; s > i; i++) this._removeReference(this.models[i]);
                return e.previousModels = this.models, this._reset(), this.add(t, l.extend({
                    silent: !0
                }, e)), e.silent || this.trigger("reset", this, e), this
            },
            push: function(t, e) {
                return t = this._prepareModel(t, e), this.add(t, l.extend({
                    at: this.length
                }, e)), t
            },
            pop: function(t) {
                var e = this.at(this.length - 1);
                return this.remove(e, t), e
            },
            unshift: function(t, e) {
                return t = this._prepareModel(t, e), this.add(t, l.extend({
                    at: 0
                }, e)), t
            },
            shift: function(t) {
                var e = this.at(0);
                return this.remove(e, t), e
            },
            slice: function(t, e) {
                return this.models.slice(t, e)
            },
            get: function(t) {
                return null == t ? void 0 : this._byId[null != t.id ? t.id : t.cid || t]
            },
            at: function(t) {
                return this.models[t]
            },
            where: function(t, e) {
                return l.isEmpty(t) ? e ? void 0 : [] : this[e ? "find" : "filter"](function(e) {
                    for (var i in t)
                        if (t[i] !== e.get(i)) return !1;
                    return !0
                })
            },
            findWhere: function(t) {
                return this.where(t, !0)
            },
            sort: function(t) {
                if (!this.comparator) throw new Error("Cannot sort a set without a comparator");
                return t || (t = {}), l.isString(this.comparator) || 1 === this.comparator.length ? this.models = this.sortBy(this.comparator, this) : this.models.sort(l.bind(this.comparator, this)), t.silent || this.trigger("sort", this, t), this
            },
            sortedIndex: function(t, e, i) {
                e || (e = this.comparator);
                var s = l.isFunction(e) ? e : function(t) {
                    return t.get(e)
                };
                return l.sortedIndex(this.models, t, s, i)
            },
            pluck: function(t) {
                return l.invoke(this.models, "get", t)
            },
            fetch: function(t) {
                t = t ? l.clone(t) : {}, void 0 === t.parse && (t.parse = !0);
                var e = t.success,
                    i = this;
                return t.success = function(s) {
                    var n = t.reset ? "reset" : "set";
                    i[n](s, t), e && e(i, s, t), i.trigger("sync", i, s, t)
                }, J(this, t), this.sync("read", this, t)
            },
            create: function(t, e) {
                if (e = e ? l.clone(e) : {}, !(t = this._prepareModel(t, e))) return !1;
                e.wait || this.add(t, e);
                var i = this,
                    s = e.success;
                return e.success = function(n) {
                    e.wait && i.add(t, e), s && s(t, n, e)
                }, t.save(null, e), t
            },
            parse: function(t) {
                return t
            },
            clone: function() {
                return new this.constructor(this.models)
            },
            _reset: function() {
                this.length = 0, this.models = [], this._byId = {}
            },
            _prepareModel: function(t, e) {
                if (t instanceof m) return t.collection || (t.collection = this), t;
                e || (e = {}), e.collection = this;
                var i = new this.model(t, e);
                return i._validate(t, e) ? i : (this.trigger("invalid", this, t, e), !1)
            },
            _removeReference: function(t) {
                this === t.collection && delete t.collection, t.off("all", this._onModelEvent, this)
            },
            _onModelEvent: function(t, e, i, s) {
                ("add" !== t && "remove" !== t || i === this) && ("destroy" === t && this.remove(e, s), e && t === "change:" + e.idAttribute && (delete this._byId[e.previous(e.idAttribute)], null != e.id && (this._byId[e.id] = e)), this.trigger.apply(this, arguments))
            }
        });
        var E = ["forEach", "each", "map", "collect", "reduce", "foldl", "inject", "reduceRight", "foldr", "find", "detect", "filter", "select", "reject", "every", "all", "some", "any", "include", "contains", "invoke", "max", "min", "toArray", "size", "first", "head", "take", "initial", "rest", "tail", "drop", "last", "without", "indexOf", "shuffle", "lastIndexOf", "isEmpty", "chain"];
        l.each(E, function(t) {
            b.prototype[t] = function() {
                var e = h.call(arguments);
                return e.unshift(this.models), l[t].apply(l, e)
            }
        });
        var k = ["groupBy", "countBy", "sortBy"];
        l.each(k, function(t) {
            b.prototype[t] = function(e, i) {
                var s = l.isFunction(e) ? e : function(t) {
                    return t.get(e)
                };
                return l[t](this.models, s, i)
            }
        });
        var S = s.View = function(t) {
                this.cid = l.uniqueId("view"), this._configure(t || {}), this._ensureElement(), this.initialize.apply(this, arguments), this.delegateEvents()
            },
            $ = /^(\S+)\s*(.*)$/,
            T = ["model", "collection", "el", "id", "attributes", "className", "tagName", "events"];
        l.extend(S.prototype, d, {
            tagName: "div",
            $: function(t) {
                return this.$el.find(t)
            },
            initialize: function() {},
            render: function() {
                return this
            },
            remove: function() {
                return this.$el.remove(), this.stopListening(), this
            },
            setElement: function(t, e) {
                return this.$el && this.undelegateEvents(), this.$el = t instanceof s.$ ? t : s.$(t), this.el = this.$el[0], e !== !1 && this.delegateEvents(), this
            },
            delegateEvents: function(t) {
                if (!t && !(t = l.result(this, "events"))) return this;
                this.undelegateEvents();
                for (var e in t) {
                    var i = t[e];
                    if (l.isFunction(i) || (i = this[t[e]]), i) {
                        var s = e.match($),
                            n = s[1],
                            r = s[2];
                        i = l.bind(i, this), n += ".delegateEvents" + this.cid, "" === r ? this.$el.on(n, i) : this.$el.on(n, r, i)
                    }
                }
                return this
            },
            undelegateEvents: function() {
                return this.$el.off(".delegateEvents" + this.cid), this
            },
            _configure: function(t) {
                this.options && (t = l.extend({}, l.result(this, "options"), t)), l.extend(this, l.pick(t, T)), this.options = t
            },
            _ensureElement: function() {
                if (this.el) this.setElement(l.result(this, "el"), !1);
                else {
                    var t = l.extend({}, l.result(this, "attributes"));
                    this.id && (t.id = l.result(this, "id")), this.className && (t["class"] = l.result(this, "className"));
                    var e = s.$("<" + l.result(this, "tagName") + ">").attr(t);
                    this.setElement(e, !1)
                }
            }
        }), s.sync = function(e, i, n) {
            var r = A[e];
            l.defaults(n || (n = {}), {
                emulateHTTP: s.emulateHTTP,
                emulateJSON: s.emulateJSON
            });
            var a = {
                type: r,
                dataType: "json"
            };
            if (n.url || (a.url = l.result(i, "url") || M()), null != n.data || !i || "create" !== e && "update" !== e && "patch" !== e || (a.contentType = "application/json", a.data = JSON.stringify(n.attrs || i.toJSON(n))), n.emulateJSON && (a.contentType = "application/x-www-form-urlencoded", a.data = a.data ? {
                    model: a.data
                } : {}), n.emulateHTTP && ("PUT" === r || "DELETE" === r || "PATCH" === r)) {
                a.type = "POST", n.emulateJSON && (a.data._method = r);
                var o = n.beforeSend;
                n.beforeSend = function(t) {
                    return t.setRequestHeader("X-HTTP-Method-Override", r), o ? o.apply(this, arguments) : void 0
                }
            }
            "GET" === a.type || n.emulateJSON || (a.processData = !1), "PATCH" !== a.type || !t.ActiveXObject || t.external && t.external.msActiveXFilteringEnabled || (a.xhr = function() {
                return new ActiveXObject("Microsoft.XMLHTTP")
            });
            var h = n.xhr = s.ajax(l.extend(a, n));
            return i.trigger("request", i, h, n), h
        };
        var A = {
            create: "POST",
            update: "PUT",
            patch: "PATCH",
            "delete": "DELETE",
            read: "GET"
        };
        s.ajax = function() {
            return s.$.ajax.apply(s.$, arguments)
        };
        var H = s.Router = function(t) {
                t || (t = {}), t.routes && (this.routes = t.routes), this._bindRoutes(), this.initialize.apply(this, arguments)
            },
            N = /\((.*?)\)/g,
            O = /(\(\?)?:\w+/g,
            j = /\*\w+/g,
            I = /[\-{}\[\]+?.,\\\^$|#\s]/g;
        l.extend(H.prototype, d, {
            initialize: function() {},
            route: function(t, e, i) {
                l.isRegExp(t) || (t = this._routeToRegExp(t)), l.isFunction(e) && (i = e, e = ""), i || (i = this[e]);
                var n = this;
                return s.history.route(t, function(r) {
                    var a = n._extractParameters(t, r);
                    i && i.apply(n, a), n.trigger.apply(n, ["route:" + e].concat(a)), n.trigger("route", e, a), s.history.trigger("route", n, e, a)
                }), this
            },
            navigate: function(t, e) {
                return s.history.navigate(t, e), this
            },
            _bindRoutes: function() {
                if (this.routes) {
                    this.routes = l.result(this, "routes");
                    for (var t, e = l.keys(this.routes); null != (t = e.pop());) this.route(t, this.routes[t])
                }
            },
            _routeToRegExp: function(t) {
                return t = t.replace(I, "\\$&").replace(N, "(?:$1)?").replace(O, function(t, e) {
                    return e ? t : "([^/]+)"
                }).replace(j, "(.*?)"), new RegExp("^" + t + "$")
            },
            _extractParameters: function(t, e) {
                var i = t.exec(e).slice(1);
                return l.map(i, function(t) {
                    return t ? decodeURIComponent(t) : null
                })
            }
        });
        var P = s.History = function() {
                this.handlers = [], l.bindAll(this, "checkUrl"), "undefined" != typeof t && (this.location = t.location, this.history = t.history)
            },
            C = /^[#\/]|\s+$/g,
            U = /^\/+|\/+$/g,
            R = /msie [\w.]+/,
            q = /\/$/;
        P.started = !1, l.extend(P.prototype, d, {
            interval: 50,
            getHash: function(t) {
                var e = (t || this).location.href.match(/#(.*)$/);
                return e ? e[1] : ""
            },
            getFragment: function(t, e) {
                if (null == t)
                    if (this._hasPushState || !this._wantsHashChange || e) {
                        t = this.location.pathname;
                        var i = this.root.replace(q, "");
                        t.indexOf(i) || (t = t.substr(i.length))
                    } else t = this.getHash();
                return t.replace(C, "")
            },
            start: function(i) {
                if (P.started) throw new Error("Backbone.history has already been started");
                P.started = !0, this.options = l.extend({}, {
                    root: "/"
                }, this.options, i), this.root = this.options.root, this._wantsHashChange = this.options.hashChange !== !1, this._wantsPushState = !!this.options.pushState, this._hasPushState = !!(this.options.pushState && this.history && this.history.pushState);
                var n = this.getFragment(),
                    r = e.documentMode,
                    a = R.exec(navigator.userAgent.toLowerCase()) && (!r || 7 >= r);
                this.root = ("/" + this.root + "/").replace(U, "/"), a && this._wantsHashChange && (this.iframe = s.$('<iframe src="javascript:0" tabindex="-1" />').hide().appendTo("body")[0].contentWindow, this.navigate(n)), this._hasPushState ? s.$(t).on("popstate", this.checkUrl) : this._wantsHashChange && "onhashchange" in t && !a ? s.$(t).on("hashchange", this.checkUrl) : this._wantsHashChange && (this._checkUrlInterval = setInterval(this.checkUrl, this.interval)), this.fragment = n;
                var o = this.location,
                    h = o.pathname.replace(/[^\/]$/, "$&/") === this.root;
                return this._wantsHashChange && this._wantsPushState && !this._hasPushState && !h ? (this.fragment = this.getFragment(null, !0), this.location.replace(this.root + this.location.search + "#" + this.fragment), !0) : (this._wantsPushState && this._hasPushState && h && o.hash && (this.fragment = this.getHash().replace(C, ""), this.history.replaceState({}, e.title, this.root + this.fragment + o.search)), this.options.silent ? void 0 : this.loadUrl())
            },
            stop: function() {
                s.$(t).off("popstate", this.checkUrl).off("hashchange", this.checkUrl), clearInterval(this._checkUrlInterval), P.started = !1
            },
            route: function(t, e) {
                this.handlers.unshift({
                    route: t,
                    callback: e
                })
            },
            checkUrl: function() {
                var t = this.getFragment();
                return t === this.fragment && this.iframe && (t = this.getFragment(this.getHash(this.iframe))), t === this.fragment ? !1 : (this.iframe && this.navigate(t), this.loadUrl() || this.loadUrl(this.getHash()), void 0)
            },
            loadUrl: function(t) {
                var e = this.fragment = this.getFragment(t),
                    i = l.any(this.handlers, function(t) {
                        return t.route.test(e) ? (t.callback(e), !0) : void 0
                    });
                return i
            },
            navigate: function(t, i) {
                if (!P.started) return !1;
                if (i && i !== !0 || (i = {
                        trigger: i
                    }), t = this.getFragment(t || ""), this.fragment !== t) {
                    this.fragment = t;
                    var s = this.root + t;
                    if (this._hasPushState) this.history[i.replace ? "replaceState" : "pushState"]({}, e.title, s);
                    else {
                        if (!this._wantsHashChange) return this.location.assign(s);
                        this._updateHash(this.location, t, i.replace), this.iframe && t !== this.getFragment(this.getHash(this.iframe)) && (i.replace || this.iframe.document.open().close(), this._updateHash(this.iframe.location, t, i.replace))
                    }
                    i.trigger && this.loadUrl(t)
                }
            },
            _updateHash: function(t, e, i) {
                if (i) {
                    var s = t.href.replace(/(javascript:|#).*$/, "");
                    t.replace(s + "#" + e)
                } else t.hash = "#" + e
            }
        }), s.history = new P;
        var F = function(t, e) {
            var i, s = this;
            i = t && l.has(t, "constructor") ? t.constructor : function() {
                return s.apply(this, arguments)
            }, l.extend(i, s, e);
            var n = function() {
                this.constructor = i
            };
            return n.prototype = s.prototype, i.prototype = new n, t && l.extend(i.prototype, t), i.__super__ = s.prototype, i
        };
        m.extend = b.extend = H.extend = S.extend = P.extend = F;
        var M = function() {
                throw new Error('A "url" property or function must be specified')
            },
            J = function(t, e) {
                var i = e.error;
                e.error = function(s) {
                    i && i(t, s, e), t.trigger("error", t, s, e)
                }
            }
    }).call(this);
    var c = {
        ie: "Microsoft Internet Explorer" == navigator.appName,
        java: navigator.javaEnabled(),
        ns: "Netscape" == navigator.appName,
        ua: navigator.userAgent.toLowerCase(),
        version: parseFloat(navigator.appVersion.substr(21)) || parseFloat(navigator.appVersion),
        win: "Win32" == navigator.platform
    };
    c.mac = c.ua.indexOf("mac") >= 0, c.ua.indexOf("opera") >= 0 && (c.ie = c.ns = !1, c.opera = !0), c.ua.indexOf("gecko") >= 0 && (c.ie = c.ns = !1, c.gecko = !0), n("backbone", ["underscore", "jquery"], function(t) {
        return function() {
            var e;
            return e || t.Backbone
        }
    }(this))
}).call({
    $: bnpp.jquery
}, window, document, bnpp.sf31.require, bnpp.sf31.require, bnpp.sf31.define, bnpp.jquery, bnpp.jquery, bnpp.jquery);
//# sourceMappingURL=backbone-1.0.0.js.map
! function(t, e, i, n, s, r, h, o) {
    s(function(i, n) {
        (function() {
            var i, r = function(t, e) {
                    return function() {
                        return t.apply(e, arguments)
                    }
                },
                h = [].indexOf || function(t) {
                    for (var e = 0, i = this.length; i > e; e++)
                        if (e in this && this[e] === t) return e;
                    return -1
                },
                u = [].slice,
                a = {}.hasOwnProperty,
                l = function(t, e) {
                    function i() {
                        this.constructor = t
                    }
                    for (var n in e) a.call(e, n) && (t[n] = e[n]);
                    return i.prototype = e.prototype, t.prototype = new i, t.__super__ = e.prototype, t
                };
            i = {
                binders: {},
                components: {},
                formatters: {},
                adapters: {},
                config: {
                    prefix: "rv",
                    templateDelimiters: ["{", "}"],
                    rootInterface: ".",
                    preloadData: !0,
                    handler: function(t, e, i) {
                        return this.call(t, e, i.view.models)
                    }
                }
            }, i.Util = {
                bindEvent: function(e, i, n) {
                    return null != t.jQuery ? (e = o(e), null != e.on ? e.on(i, n) : e.bind(i, n)) : null != t.addEventListener ? e.addEventListener(i, n, !1) : (i = "on" + i, e.attachEvent(i, n))
                },
                unbindEvent: function(e, i, n) {
                    return null != t.jQuery ? (e = o(e), null != e.off ? e.off(i, n) : e.unbind(i, n)) : null != t.removeEventListener ? e.removeEventListener(i, n, !1) : (i = "on" + i, e.detachEvent(i, n))
                },
                getInputValue: function(e) {
                    var i, n, s, r;
                    if (null != t.jQuery) switch (e = o(e), e[0].type) {
                        case "checkbox":
                            return e.is(":checked");
                        default:
                            return e.val()
                    } else switch (e.type) {
                        case "checkbox":
                            return e.checked;
                        case "select-multiple":
                            for (r = [], n = 0, s = e.length; s > n; n++) i = e[n], i.selected && r.push(i.value);
                            return r;
                        default:
                            return e.value
                    }
                }
            }, i.View = function() {
                function t(t, e, n) {
                    var s, h, o, u, a, l, p, d, c;
                    for (this.els = t, this.models = e, this.options = null != n ? n : {}, this.update = r(this.update, this), this.publish = r(this.publish, this), this.sync = r(this.sync, this), this.unbind = r(this.unbind, this), this.bind = r(this.bind, this), this.select = r(this.select, this), this.build = r(this.build, this), this.componentRegExp = r(this.componentRegExp, this), this.bindingRegExp = r(this.bindingRegExp, this), this.els.jquery || this.els instanceof Array || (this.els = [this.els]), p = ["config", "binders", "formatters", "adapters"], a = 0, l = p.length; l > a; a++) {
                        if (h = p[a], this[h] = {}, this.options[h]) {
                            d = this.options[h];
                            for (s in d) o = d[s], this[h][s] = o
                        }
                        c = i[h];
                        for (s in c) o = c[s], null == (u = this[h])[s] && (u[s] = o)
                    }
                    this.build()
                }
                return t.prototype.bindingRegExp = function() {
                    return new RegExp("^" + this.config.prefix + "-")
                }, t.prototype.componentRegExp = function() {
                    return new RegExp("^" + this.config.prefix.toUpperCase() + "-")
                }, t.prototype.build = function() {
                    var t, n, s, r, o, u, a, l, p, d = this;
                    for (this.bindings = [], u = [], t = this.bindingRegExp(), s = this.componentRegExp(), n = function(t, e, n, s) {
                            var r, h, o, u, a, l, p;
                            return a = {}, p = function() {
                                var t, e, i, n;
                                for (i = s.split("|"), n = [], t = 0, e = i.length; e > t; t++) l = i[t], n.push(l.trim());
                                return n
                            }(), r = function() {
                                var t, e, i, n;
                                for (i = p.shift().split("<"), n = [], t = 0, e = i.length; e > t; t++) h = i[t], n.push(h.trim());
                                return n
                            }(), u = r.shift(), a.formatters = p, (o = r.shift()) && (a.dependencies = o.split(/\s+/)), d.bindings.push(new i[t](d, e, n, u, a))
                        }, o = function(r) {
                            var a, l, p, c, f, b, v, y, g, m, w, k, x, E, j, N, O, R, B, V, C, P, U, A, T, L, S, _, q, F;
                            if (h.call(u, r) < 0) {
                                if (3 === r.nodeType) {
                                    if (y = i.TextTemplateParser, (f = d.config.templateDelimiters) && (k = y.parse(r.data, f)).length && (1 !== k.length || k[0].type !== y.types.text)) {
                                        for (j = 0, B = k.length; B > j; j++) w = k[j], m = e.createTextNode(w.value), r.parentNode.insertBefore(m, r), 1 === w.type && n("TextBinding", m, null, w.value);
                                        r.parentNode.removeChild(r)
                                    }
                                } else if (s.test(r.tagName)) x = r.tagName.replace(s, "").toLowerCase(), d.bindings.push(new i.ComponentBinding(d, r, x));
                                else if (null != r.attributes) {
                                    for (T = r.attributes, N = 0, V = T.length; V > N; N++)
                                        if (a = T[N], t.test(a.name)) {
                                            if (x = a.name.replace(t, ""), !(p = d.binders[x])) {
                                                L = d.binders;
                                                for (b in L) E = L[b], "*" !== b && -1 !== b.indexOf("*") && (g = new RegExp("^" + b.replace("*", ".+") + "$"), g.test(x) && (p = E))
                                            }
                                            if (p || (p = d.binders["*"]), p.block) {
                                                for (S = r.childNodes, O = 0, C = S.length; C > O; O++) v = S[O], u.push(v);
                                                l = [a]
                                            }
                                        }
                                    for (_ = l || r.attributes, R = 0, P = _.length; P > R; R++) a = _[R], t.test(a.name) && (x = a.name.replace(t, ""), n("Binding", r, x, a.value))
                                }
                                for (q = function() {
                                        var t, e, i, n;
                                        for (i = r.childNodes, n = [], e = 0, t = i.length; t > e; e++) v = i[e], n.push(v);
                                        return n
                                    }(), F = [], A = 0, U = q.length; U > A; A++) c = q[A], F.push(o(c));
                                return F
                            }
                        }, p = this.els, a = 0, l = p.length; l > a; a++) r = p[a], o(r)
                }, t.prototype.select = function(t) {
                    var e, i, n, s, r;
                    for (s = this.bindings, r = [], i = 0, n = s.length; n > i; i++) e = s[i], t(e) && r.push(e);
                    return r
                }, t.prototype.bind = function() {
                    var t, e, i, n, s;
                    for (n = this.bindings, s = [], e = 0, i = n.length; i > e; e++) t = n[e], s.push(t.bind());
                    return s
                }, t.prototype.unbind = function() {
                    var t, e, i, n, s;
                    for (n = this.bindings, s = [], e = 0, i = n.length; i > e; e++) t = n[e], s.push(t.unbind());
                    return s
                }, t.prototype.sync = function() {
                    var t, e, i, n, s;
                    for (n = this.bindings, s = [], e = 0, i = n.length; i > e; e++) t = n[e], s.push(t.sync());
                    return s
                }, t.prototype.publish = function() {
                    var t, e, i, n, s;
                    for (n = this.select(function(t) {
                            return t.binder.publishes
                        }), s = [], e = 0, i = n.length; i > e; e++) t = n[e], s.push(t.publish());
                    return s
                }, t.prototype.update = function(t) {
                    var e, i, n, s, r, h, o;
                    null == t && (t = {});
                    for (i in t) n = t[i], this.models[i] = n;
                    for (h = this.bindings, o = [], s = 0, r = h.length; r > s; s++) e = h[s], o.push(e.update(t));
                    return o
                }, t
            }(), i.Binding = function() {
                function t(t, e, i, n, s) {
                    this.view = t, this.el = e, this.type = i, this.keypath = n, this.options = null != s ? s : {}, this.update = r(this.update, this), this.unbind = r(this.unbind, this), this.bind = r(this.bind, this), this.publish = r(this.publish, this), this.sync = r(this.sync, this), this.set = r(this.set, this), this.eventHandler = r(this.eventHandler, this), this.formattedValue = r(this.formattedValue, this), this.setObserver = r(this.setObserver, this), this.setBinder = r(this.setBinder, this), this.formatters = this.options.formatters || [], this.dependencies = [], this.setBinder(), this.setObserver()
                }
                return t.prototype.setBinder = function() {
                    var t, e, i, n;
                    if (!(this.binder = this.view.binders[this.type])) {
                        n = this.view.binders;
                        for (t in n) i = n[t], "*" !== t && -1 !== t.indexOf("*") && (e = new RegExp("^" + t.replace("*", ".+") + "$"), e.test(this.type) && (this.binder = i, this.args = new RegExp("^" + t.replace("*", "(.+)") + "$").exec(this.type), this.args.shift()))
                    }
                    return this.binder || (this.binder = this.view.binders["*"]), this.binder instanceof Function ? this.binder = {
                        routine: this.binder
                    } : void 0
                }, t.prototype.setObserver = function() {
                    var t = this;
                    return this.observer = new i.KeypathObserver(this.view, this.view.models, this.keypath, function(e) {
                        return t.key && t.unbind(!0), t.model = e.target, t.key && t.bind(!0), t.sync()
                    }), this.key = this.observer.key, this.model = this.observer.target
                }, t.prototype.formattedValue = function(t) {
                    var e, i, n, s, r, h;
                    for (h = this.formatters, s = 0, r = h.length; r > s; s++) i = h[s], e = i.split(/\s+/), n = e.shift(), i = this.view.formatters[n], (null != i ? i.read : void 0) instanceof Function ? t = i.read.apply(i, [t].concat(u.call(e))) : i instanceof Function && (t = i.apply(null, [t].concat(u.call(e))));
                    return t
                }, t.prototype.eventHandler = function(t) {
                    var e, i;
                    return i = (e = this).view.config.handler,
                        function(n) {
                            return i.call(t, this, n, e)
                        }
                }, t.prototype.set = function(t) {
                    var e;
                    return t = t instanceof Function && !this.binder["function"] ? this.formattedValue(t.call(this.model)) : this.formattedValue(t), null != (e = this.binder.routine) ? e.call(this, this.el, t) : void 0
                }, t.prototype.sync = function() {
                    return this.set(this.key ? this.view.adapters[this.key["interface"]].read(this.model, this.key.path) : this.model)
                }, t.prototype.publish = function() {
                    var t, e, n, s, r, h, o, a, l;
                    for (s = i.Util.getInputValue(this.el), o = this.formatters.slice(0).reverse(), r = 0, h = o.length; h > r; r++) e = o[r], t = e.split(/\s+/), n = t.shift(), (null != (a = this.view.formatters[n]) ? a.publish : void 0) && (s = (l = this.view.formatters[n]).publish.apply(l, [s].concat(u.call(t))));
                    return this.view.adapters[this.key["interface"]].publish(this.model, this.key.path, s)
                }, t.prototype.bind = function(t) {
                    var e, n, s, r, h, o, u, a, l, p = this;
                    if (null == t && (t = !1), t || null != (o = this.binder.bind) && o.call(this, this.el), this.key && this.view.adapters[this.key["interface"]].subscribe(this.model, this.key.path, this.sync), (t ? void 0 : this.view.config.preloadData) && this.sync(), null != (u = this.options.dependencies) ? u.length : void 0) {
                        for (a = this.options.dependencies, l = [], r = 0, h = a.length; h > r; r++) e = a[r], s = new i.KeypathObserver(this.view, this.model, e, function(t, e) {
                            var i;
                            return i = t.key, p.view.adapters[i["interface"]].unsubscribe(e, i.path, p.sync), p.view.adapters[i["interface"]].subscribe(t.target, i.path, p.sync), p.sync()
                        }), n = s.key, this.view.adapters[n["interface"]].subscribe(s.target, n.path, this.sync), l.push(this.dependencies.push(s));
                        return l
                    }
                }, t.prototype.unbind = function(t) {
                    var e, i, n, s, r, h;
                    if (null == t && (t = !1), t || (null != (r = this.binder.unbind) && r.call(this, this.el), this.observer.unobserve()), this.key && this.view.adapters[this.key["interface"]].unsubscribe(this.model, this.key.path, this.sync), this.dependencies.length) {
                        for (h = this.dependencies, n = 0, s = h.length; s > n; n++) i = h[n], e = i.key, this.view.adapters[e["interface"]].unsubscribe(i.target, e.path, this.sync);
                        return this.dependencies = []
                    }
                }, t.prototype.update = function(t) {
                    var e;
                    return null == t && (t = {}), null != (e = this.binder.update) ? e.call(this, t) : void 0
                }, t
            }(), i.ComponentBinding = function(t) {
                function e(t, e, n) {
                    var s, o, u, a, l;
                    for (this.view = t, this.el = e, this.type = n, this.unbind = r(this.unbind, this), this.bind = r(this.bind, this), this.update = r(this.update, this), this.locals = r(this.locals, this), this.component = i.components[this.type], this.attributes = {}, this.inflections = {}, a = this.el.attributes || [], o = 0, u = a.length; u > o; o++) s = a[o], l = s.name, h.call(this.component.attributes, l) >= 0 ? this.attributes[s.name] = s.value : this.inflections[s.name] = s.value
                }
                return l(e, t), e.prototype.sync = function() {}, e.prototype.locals = function(t) {
                    var e, i, n, s, r, h, o, u, a;
                    null == t && (t = this.view.models), r = {}, u = this.inflections;
                    for (i in u)
                        for (e = u[i], a = e.split("."), h = 0, o = a.length; o > h; h++) s = a[h], r[i] = (r[i] || t)[s];
                    for (i in t) n = t[i], null == r[i] && (r[i] = n);
                    return r
                }, e.prototype.update = function(t) {
                    var e;
                    return null != (e = this.componentView) ? e.update(this.locals(t)) : void 0
                }, e.prototype.bind = function() {
                    var t, e;
                    return null != this.componentView ? null != (e = this.componentView) ? e.bind() : void 0 : (t = this.component.build.call(this.attributes), (this.componentView = new i.View(t, this.locals(), this.view.options)).bind(), this.el.parentNode.replaceChild(t, this.el))
                }, e.prototype.unbind = function() {
                    var t;
                    return null != (t = this.componentView) ? t.unbind() : void 0
                }, e
            }(i.Binding), i.TextBinding = function(t) {
                function e(t, e, i, n, s) {
                    this.view = t, this.el = e, this.type = i, this.keypath = n, this.options = null != s ? s : {}, this.sync = r(this.sync, this), this.formatters = this.options.formatters || [], this.dependencies = [], this.setObserver()
                }
                return l(e, t), e.prototype.binder = {
                    routine: function(t, e) {
                        return t.data = null != e ? e : ""
                    }
                }, e.prototype.sync = function() {
                    return e.__super__.sync.apply(this, arguments)
                }, e
            }(i.Binding), i.KeypathParser = function() {
                function t() {}
                return t.parse = function(t, e, i) {
                    var n, s, r, o, u;
                    for (r = [], s = {
                            "interface": i,
                            path: ""
                        }, o = 0, u = t.length; u > o; o++) n = t[o], h.call(e, n) >= 0 ? (r.push(s), s = {
                        "interface": n,
                        path: ""
                    }) : s.path += n;
                    return r.push(s), r
                }, t
            }(), i.TextTemplateParser = function() {
                function t() {}
                return t.types = {
                    text: 0,
                    binding: 1
                }, t.parse = function(t, e) {
                    var i, n, s, r, h, o, u;
                    for (o = [], r = t.length, i = 0, n = 0; r > n;) {
                        if (i = t.indexOf(e[0], n), 0 > i) {
                            o.push({
                                type: this.types.text,
                                value: t.slice(n)
                            });
                            break
                        }
                        if (i > 0 && i > n && o.push({
                                type: this.types.text,
                                value: t.slice(n, i)
                            }), n = i + e[0].length, i = t.indexOf(e[1], n), 0 > i) {
                            h = t.slice(n - e[1].length), s = o[o.length - 1], (null != s ? s.type : void 0) === this.types.text ? s.value += h : o.push({
                                type: this.types.text,
                                value: h
                            });
                            break
                        }
                        u = t.slice(n, i).trim(), o.push({
                            type: this.types.binding,
                            value: u
                        }), n = i + e[1].length
                    }
                    return o
                }, t
            }(), i.KeypathObserver = function() {
                function t(t, e, i, n) {
                    this.view = t, this.model = e, this.keypath = i, this.callback = n, this.unobserve = r(this.unobserve, this), this.realize = r(this.realize, this), this.update = r(this.update, this), this.parse = r(this.parse, this), this.parse(), this.objectPath = [], this.target = this.realize()
                }
                return t.prototype.parse = function() {
                    var t, e, n, s, r, o;
                    return t = function() {
                        var t, i;
                        t = this.view.adapters, i = [];
                        for (e in t) r = t[e], i.push(e);
                        return i
                    }.call(this), o = this.keypath[0], h.call(t, o) >= 0 ? (s = this.keypath[0], n = this.keypath.substr(1)) : (s = this.view.config.rootInterface, n = this.keypath), this.tokens = i.KeypathParser.parse(n, t, s), this.key = this.tokens.pop()
                }, t.prototype.update = function() {
                    var t, e;
                    return (t = this.realize()) !== this.target ? (e = this.target, this.target = t, this.callback(this, e)) : void 0
                }, t.prototype.realize = function() {
                    var t, e, i, n, s, r, h;
                    for (t = this.model, h = this.tokens, e = s = 0, r = h.length; r > s; e = ++s) n = h[e], null != this.objectPath[e] ? t !== (i = this.objectPath[e]) && (this.view.adapters[n["interface"]].unsubscribe(i, n.path, this.update), this.view.adapters[n["interface"]].subscribe(t, n.path, this.update), this.objectPath[e] = t) : (this.view.adapters[n["interface"]].subscribe(t, n.path, this.update), this.objectPath[e] = t), t = this.view.adapters[n["interface"]].read(t, n.path);
                    return t
                }, t.prototype.unobserve = function() {
                    var t, e, i, n, s, r, h;
                    for (r = this.tokens, h = [], t = n = 0, s = r.length; s > n; t = ++n) i = r[t], (e = this.objectPath[t]) ? h.push(this.view.adapters[i["interface"]].unsubscribe(e, i.path, this.update)) : h.push(void 0);
                    return h
                }, t
            }(), i.binders.text = function(t, e) {
                return null != t.textContent ? t.textContent = null != e ? e : "" : t.innerText = null != e ? e : ""
            }, i.binders.html = function(t, e) {
                return t.innerHTML = null != e ? e : ""
            }, i.binders.show = function(t, e) {
                return t.style.display = e ? "" : "none"
            }, i.binders.hide = function(t, e) {
                return t.style.display = e ? "none" : ""
            }, i.binders.enabled = function(t, e) {
                return t.disabled = !e
            }, i.binders.disabled = function(t, e) {
                return t.disabled = !!e
            }, i.binders.checked = {
                publishes: !0,
                bind: function(t) {
                    return i.Util.bindEvent(t, "change", this.publish)
                },
                unbind: function(t) {
                    return i.Util.unbindEvent(t, "change", this.publish)
                },
                routine: function(t, e) {
                    var i;
                    return t.checked = "radio" === t.type ? (null != (i = t.value) ? i.toString() : void 0) === (null != e ? e.toString() : void 0) : !!e
                }
            }, i.binders.unchecked = {
                publishes: !0,
                bind: function(t) {
                    return i.Util.bindEvent(t, "change", this.publish)
                },
                unbind: function(t) {
                    return i.Util.unbindEvent(t, "change", this.publish)
                },
                routine: function(t, e) {
                    var i;
                    return t.checked = "radio" === t.type ? (null != (i = t.value) ? i.toString() : void 0) !== (null != e ? e.toString() : void 0) : !e
                }
            }, i.binders.value = {
                publishes: !0,
                bind: function(t) {
                    return i.Util.bindEvent(t, "change", this.publish)
                },
                unbind: function(t) {
                    return i.Util.unbindEvent(t, "change", this.publish)
                },
                routine: function(e, i) {
                    var n, s, r, u, a, l, p;
                    if (null != t.jQuery) {
                        if (e = o(e), (null != i ? i.toString() : void 0) !== (null != (u = e.val()) ? u.toString() : void 0)) return e.val(null != i ? i : "")
                    } else if ("select-multiple" === e.type) {
                        if (null != i) {
                            for (p = [], s = 0, r = e.length; r > s; s++) n = e[s], p.push(n.selected = (a = n.value, h.call(i, a) >= 0));
                            return p
                        }
                    } else if ((null != i ? i.toString() : void 0) !== (null != (l = e.value) ? l.toString() : void 0)) return e.value = null != i ? i : ""
                }
            }, i.binders["if"] = {
                block: !0,
                bind: function(t) {
                    var i, n;
                    return null == this.marker ? (i = [this.view.config.prefix, this.type].join("-").replace("--", "-"), n = t.getAttribute(i), this.marker = e.createComment(" rivets: " + this.type + " " + n + " "), t.removeAttribute(i), t.parentNode.insertBefore(this.marker, t), t.parentNode.removeChild(t)) : void 0
                },
                unbind: function() {
                    var t;
                    return null != (t = this.nested) ? t.unbind() : void 0
                },
                routine: function(t, e) {
                    var n, s, r, h, o;
                    if (!!e == (null == this.nested)) {
                        if (e) {
                            r = {}, o = this.view.models;
                            for (n in o) s = o[n], r[n] = s;
                            return h = {
                                binders: this.view.options.binders,
                                formatters: this.view.options.formatters,
                                adapters: this.view.options.adapters,
                                config: this.view.options.config
                            }, (this.nested = new i.View(t, r, h)).bind(), this.marker.parentNode.insertBefore(t, this.marker.nextSibling)
                        }
                        return t.parentNode.removeChild(t), this.nested.unbind(), delete this.nested
                    }
                },
                update: function(t) {
                    var e;
                    return null != (e = this.nested) ? e.update(t) : void 0
                }
            }, i.binders.unless = {
                block: !0,
                bind: function(t) {
                    return i.binders["if"].bind.call(this, t)
                },
                unbind: function() {
                    return i.binders["if"].unbind.call(this)
                },
                routine: function(t, e) {
                    return i.binders["if"].routine.call(this, t, !e)
                },
                update: function(t) {
                    return i.binders["if"].update.call(this, t)
                }
            }, i.binders["on-*"] = {
                "function": !0,
                unbind: function(t) {
                    return this.handler ? i.Util.unbindEvent(t, this.args[0], this.handler) : void 0
                },
                routine: function(t, e) {
                    return this.handler && i.Util.unbindEvent(t, this.args[0], this.handler), i.Util.bindEvent(t, this.args[0], this.handler = this.eventHandler(e))
                }
            }, i.binders["each-*"] = {
                block: !0,
                bind: function(t) {
                    var i;
                    return null == this.marker ? (i = [this.view.config.prefix, this.type].join("-").replace("--", "-"), this.marker = e.createComment(" rivets: " + this.type + " "), this.iterated = [], t.removeAttribute(i), t.parentNode.insertBefore(this.marker, t), t.parentNode.removeChild(t)) : void 0
                },
                unbind: function() {
                    var t, e, i, n, s;
                    if (null != this.iterated) {
                        for (n = this.iterated, s = [], e = 0, i = n.length; i > e; e++) t = n[e], s.push(t.unbind());
                        return s
                    }
                },
                routine: function(t, e) {
                    var n, s, r, h, o, u, a, l, p, d, c, f, b, v, y, g, m, w, k, x, E, j, N, O;
                    if (l = this.args[0], e = e || [], this.iterated.length > e.length)
                        for (x = Array(this.iterated.length - e.length), v = 0, m = x.length; m > v; v++) r = x[v], b = this.iterated.pop(), b.unbind(), this.marker.parentNode.removeChild(b.els[0]);
                    for (h = y = 0, w = e.length; w > y; h = ++y)
                        if (a = e[h], s = {}, s[l] = a, null == this.iterated[h]) {
                            E = this.view.models;
                            for (u in E) a = E[u], null == s[u] && (s[u] = a);
                            d = this.iterated.length ? this.iterated[this.iterated.length - 1].els[0] : this.marker, p = {
                                binders: this.view.options.binders,
                                formatters: this.view.options.formatters,
                                adapters: this.view.options.adapters,
                                config: {}
                            }, j = this.view.options.config;
                            for (o in j) f = j[o], p.config[o] = f;
                            p.config.preloadData = !0, c = t.cloneNode(!0), b = new i.View(c, s, p), b.bind(), this.iterated.push(b), this.marker.parentNode.insertBefore(c, d.nextSibling)
                        } else this.iterated[h].models[l] !== a && this.iterated[h].update(s);
                    if ("OPTION" === t.nodeName) {
                        for (N = this.view.bindings, O = [], g = 0, k = N.length; k > g; g++) n = N[g], n.el === this.marker.parentNode && "value" === n.type ? O.push(n.sync()) : O.push(void 0);
                        return O
                    }
                },
                update: function(t) {
                    var e, i, n, s, r, h, o, u;
                    e = {};
                    for (i in t) n = t[i], i !== this.args[0] && (e[i] = n);
                    for (o = this.iterated, u = [], r = 0, h = o.length; h > r; r++) s = o[r], u.push(s.update(e));
                    return u
                }
            }, i.binders["class-*"] = function(t, e) {
                var i;
                return i = " " + t.className + " ", !e == (-1 !== i.indexOf(" " + this.args[0] + " ")) ? t.className = e ? "" + t.className + " " + this.args[0] : i.replace(" " + this.args[0] + " ", " ").trim() : void 0
            }, i.binders["*"] = function(t, e) {
                return e ? t.setAttribute(this.type, e) : t.removeAttribute(this.type)
            }, i.adapters["."] = {
                id: "_rv",
                counter: 0,
                weakmap: {},
                weakReference: function(t) {
                    var e;
                    return null == t[this.id] && (e = this.counter++, this.weakmap[e] = {
                        callbacks: {}
                    }, Object.defineProperty(t, this.id, {
                        value: e
                    })), this.weakmap[t[this.id]]
                },
                stubFunction: function(t, e) {
                    var i, n, s;
                    return n = t[e], i = this.weakReference(t), s = this.weakmap, t[e] = function() {
                        var e, r, h, o, u, a, l, p, d, c;
                        o = n.apply(t, arguments), l = i.pointers;
                        for (h in l)
                            for (r = l[h], c = null != (p = null != (d = s[h]) ? d.callbacks[r] : void 0) ? p : [], u = 0, a = c.length; a > u; u++) e = c[u], e();
                        return o
                    }
                },
                observeMutations: function(t, e, i) {
                    var n, s, r, o, u, a;
                    if (Array.isArray(t)) {
                        if (r = this.weakReference(t), null == r.pointers)
                            for (r.pointers = {}, s = ["push", "pop", "shift", "unshift", "sort", "reverse", "splice"], u = 0, a = s.length; a > u; u++) n = s[u], this.stubFunction(t, n);
                        if (null == (o = r.pointers)[e] && (o[e] = []), h.call(r.pointers[e], i) < 0) return r.pointers[e].push(i)
                    }
                },
                unobserveMutations: function(t, e, i) {
                    var n, s;
                    return Array.isArray(t && null != t[this.id]) && (n = null != (s = this.weakReference(t).pointers) ? s[e] : void 0) ? n.splice(n.indexOf(i), 1) : void 0
                },
                subscribe: function(t, e, i) {
                    var n, s, r = this;
                    return n = this.weakReference(t).callbacks, null == n[e] && (n[e] = [], s = t[e], Object.defineProperty(t, e, {
                        get: function() {
                            return s
                        },
                        set: function(h) {
                            var o, u, a;
                            if (h !== s) {
                                for (s = h, a = n[e], o = 0, u = a.length; u > o; o++) i = a[o], i();
                                return r.observeMutations(h, t[r.id], e)
                            }
                        }
                    })), h.call(n[e], i) < 0 && n[e].push(i), this.observeMutations(t[e], t[this.id], e)
                },
                unsubscribe: function(t, e, i) {
                    var n;
                    return n = this.weakmap[t[this.id]].callbacks[e], n.splice(n.indexOf(i), 1), this.unobserveMutations(t[e], t[this.id], e)
                },
                read: function(t, e) {
                    return t[e]
                },
                publish: function(t, e, i) {
                    return t[e] = i
                }
            }, i.factory = function(t) {
                return t._ = i, t.binders = i.binders, t.components = i.components, t.formatters = i.formatters, t.adapters = i.adapters, t.config = i.config, t.configure = function(t) {
                    var e, n;
                    null == t && (t = {});
                    for (e in t) n = t[e], i.config[e] = n
                }, t.bind = function(t, e, n) {
                    var s;
                    return null == e && (e = {}), null == n && (n = {}), s = new i.View(t, e, n), s.bind(), s
                }
            }, "object" == typeof n ? i.factory(n) : "function" == typeof s && s.amd ? s("rivets-src", ["exports"], function(t) {
                return i.factory(this.rivets = t), t
            }) : i.factory(this.rivets = {})
        }).call(this), s("rivets", function() {})
    })
}({
    jQuery: bnpp.jQuery,
    addEventListener: window.addEventListener,
    removeEventListener: window.removeEventListener
}, document, bnpp.sf31.requirejs, bnpp.sf31.requirejs, bnpp.sf31.define, bnpp.jquery, bnpp.jquery, bnpp.jquery);
//# sourceMappingURL=rivets-0.6.5-bnpp1.js.map
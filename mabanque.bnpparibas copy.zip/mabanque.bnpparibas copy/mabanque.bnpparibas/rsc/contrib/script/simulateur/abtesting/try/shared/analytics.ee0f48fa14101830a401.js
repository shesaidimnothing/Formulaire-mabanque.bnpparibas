"use strict";
(self.webpackChunktag = self.webpackChunktag || []).push([
    [153], {
        206: (e, t, n) => {
            n.r(t), n.d(t, {
                AT_HIT_LABEL: () => he,
                HitType: () => a.YQ,
                aggregateActionTracking: () => qe,
                dispatchBatch: () => Q,
                dispatchHit: () => we,
                getCurrentScrollPercent: () => ve,
                notifyHit: () => be,
                setGlobals: () => Ee
            });
            var a = n(1492),
                r = n(648),
                o = n(9578),
                i = n(3002),
                s = n(3595),
                c = n(8009);
            const l = "https://ariane.abtasty.com",
                p = {
                    "chrome mobile": 78,
                    chrome: 77,
                    firefox: 70,
                    edge: 77,
                    opera: 64,
                    safari: 12,
                    "uc browser": 12
                };
            let d, u, y = [];
            async function g(e) {
                let t = arguments.length > 1 && void 0 !== arguments[1] && arguments[1],
                    n = arguments.length > 2 && void 0 !== arguments[2] ? arguments[2] : l;
                if ((new c.NO).haveConsent([c.rv.collect]) || function(e) {
                        const t = e.h;
                        return !!Array.isArray(t) && t.some((e => e.t === a.YQ.consent && "no" === e.co))
                    }(e))
                    if (t) {
                        const [a, r] = await (0, i.g)(!0, ["browser.name", "browser.version"]);
                        ! function(e, t) {
                            return !!e && !!t && !!p[e.toLowerCase()] && parseInt(t, 10) <= p[e.toLowerCase()]
                        }(a, r) ? function(e, t) {
                            navigator.sendBeacon(e, JSON.stringify(t))
                        }(n, e) : m(e, !t, n)
                    } else if (window.fetch) {
                    let t = {};
                    if (!u) try {
                        u = new AbortController, t = {
                            signal: u.signal
                        }
                    } catch (e) {
                        r.z3("[Hit] Error creating AbortController", e)
                    }
                    d = {
                        args: e,
                        endpoint: n
                    }, await fetch(n, { ...t,
                        mode: "no-cors",
                        method: "POST",
                        headers: {
                            "Content-type": "text/plain"
                        },
                        cache: "no-store",
                        body: JSON.stringify(e)
                    }), d = null
                } else d = {
                    args: e,
                    endpoint: n
                }, m(e, !t, n);
                else {
                    if (0 === y.length) {
                        const e = () => {
                            y.forEach((e => {
                                g(e.args, e.sync, e.endpoint)
                            })), y = []
                        };
                        window.addEventListener(`abtasty_${o.u.Name.consentValid}`, (t => {
                            const {
                                detail: n
                            } = t;
                            n && n.consentFor.includes(c.rv.collect) && e()
                        }))
                    }
                    y.push({
                        args: e,
                        sync: t,
                        endpoint: n
                    })
                }
            }

            function m(e) {
                let t = !(arguments.length > 1 && void 0 !== arguments[1]) || arguments[1],
                    n = arguments.length > 2 ? arguments[2] : void 0;
                try {
                    const a = new XMLHttpRequest;
                    a.open("POST", n, t), a.setRequestHeader("Content-type", "text/plain"), a.send(JSON.stringify(e)), a.onload = function() {
                        d = null
                    }, u || (u = a)
                } catch (e) {
                    console.error(`${e} - Raw UserAgent: ${navigator.userAgent} - Parsed UserAgent: ${JSON.stringify((0,i.a)())}`)
                }
            }

            function h(e, t, n) {
                r.$e(`AB Tasty warning: '${e}' hit cannot be sent, format is not correct.`, ...t, n)
            }
            var f = n(5437),
                b = n(7471),
                w = n(1134),
                q = n(1873),
                v = n(7725);

            function E(e) {
                const t = function(e) {
                    const t = (0, w.F5)().toleranceParams;
                    if (!t || !t.length || !e) return e;
                    try {
                        const n = e,
                            a = e.split("?")[0],
                            r = (0, f.Uv)(e);
                        return 0 === Object.keys(r).length ? n : (t.forEach((e => {
                            delete r[e]
                        })), `${a}?${Object.keys(r).map((e=>void 0===r[e]?"":`${e}=${r[e]}`)).join("&")}`)
                    } catch (t) {
                        return (0, r.$e)("[ABTasty]: Sensitive data restriction can't be applied", t), e
                    }
                }(e);
                return function(e) {
                    const t = (0, w.F5)().toleranceRegex,
                        n = e;
                    if (!t) return n;
                    try {
                        const e = new RegExp(t).exec(n);
                        if (e) return e.shift(), e.join("")
                    } catch (e) {
                        (0, r.$e)(`[ABTasty] The sensitive data regexp "${t}" can't be applied`, e)
                    }
                    return n
                }(t)
            }

            function T(e) {
                const {
                    campaignHistory: t,
                    visitorId: n,
                    currentSessionTimestamp: a,
                    numberOfSessions: r
                } = e, o = new b.n;
                let i = o.getReferrer();
                !i && o.isItNewSession() && (i = document.referrer);
                const s = {
                    c: t ? .() || {},
                    cid: (0, w.pw)(),
                    vid: n,
                    dr: encodeURIComponent(E(i)),
                    pt: encodeURIComponent(document.title),
                    de: encodeURIComponent(document.characterSet),
                    dl: encodeURIComponent(E(document.location.href)),
                    cst: a,
                    sn: r,
                    lv: (0, q.D0)()
                };
                return (0, v.vm)() && (s.qa = !0), s
            }
            var S = n(7643);
            let A, z = [];
            const C = e => {
                z.push(e),
                    function() {
                        A && "number" == typeof A && clearTimeout(A);
                        A = setTimeout((() => {
                            Q()
                        }), 500)
                    }(), JSON.stringify(z).length >= 40960 && Q()
            };
            const Q = function() {
                let e = arguments.length > 0 && void 0 !== arguments[0] && arguments[0];
                const t = S.n.getCommonDataRefresher();
                if (t) {
                    const n = t();
                    if (!z || !z.length) return void(e && u && (u.abort(), (0, s.g)(d) || g(d.args, !0, d.endpoint)));
                    z.map((e => {
                        e.qt = Date.now() - e.qt
                    }));
                    const o = { ...T(n),
                        tv: "latest",
                        tch: `${"312835dc".substring(0,5)}`,
                        h: z,
                        t: a.YQ.batch
                    };
                    g(o, e), (0, r.B6)("A batch hit has been sent. Data:", o), z = []
                } else(0, r.$e)("[CollectFacade] common data refresher is not set")
            };
            var $ = n(8689);
            const Y = {
                t: {
                    label: "Hit Type",
                    required: !0,
                    types: [{
                        type: a.qz.String
                    }],
                    allowedValues: Object.values(a.YQ)
                },
                ib: {
                    label: "Is a bot",
                    required: !1,
                    types: [{
                        type: a.qz.Boolean
                    }]
                }
            };

            function I(e, t) {
                const {
                    type: n,
                    condition: r,
                    model: o,
                    allowEmpty: i = !0
                } = t, c = typeof e;
                switch (n) {
                    case a.qz.Boolean:
                        return c === n || ["number", "string"].some((e => e === c)) && [0, 1, "true", "false", "0", "1"].includes(e);
                    case a.qz.IntegerArray:
                        return Array.isArray(e) && (!i && e.length > 0 || i) && e.every((e => I(e, {
                            type: a.qz.Integer,
                            condition: r
                        })));
                    case a.qz.Integer:
                        return "boolean" !== c && !isNaN(e) && Number(e) % 1 == 0 && (!r || r && r(Number(e)));
                    case a.qz.FloatArray:
                        return Array.isArray(e) && (!i && e.length > 0 || i) && e.every((e => I(e, {
                            type: a.qz.Float,
                            condition: r
                        })));
                    case a.qz.Float:
                        return "boolean" !== c && !isNaN(e) && (!r || r && r(Number(e)));
                    case a.qz.ArrayArray:
                        return Array.isArray(e) && (!i && e.length > 0 || i) && e.every((e => I(e, {
                            type: a.qz.Array,
                            condition: r
                        })));
                    case a.qz.Array:
                        return Array.isArray(e) && (!i && e.length > 0 || i);
                    case a.qz.ObjectArray:
                        return Array.isArray(e) && (!i && e.length > 0 || i) && e.every((e => I(e, {
                            type: a.qz.Object,
                            model: o,
                            condition: r,
                            allowEmpty: i
                        })));
                    case a.qz.Object:
                        return c === n && !Array.isArray(e) && (!(!i && Object.keys(e).length <= 0) && (!o || Object.entries(e).every((e => {
                            let [t, n] = e;
                            return I(t, o.key) && I(n, o.value)
                        }))));
                    case a.qz.StringArray:
                        return Array.isArray(e) && (!i && e.length > 0 || i) && e.every((e => I(e, {
                            type: a.qz.String,
                            condition: r
                        })));
                    case a.qz.String:
                        return (c === n || ["number", "boolean"].some((e => e === c)) && !isNaN(e)) && !(0, s.g)(e) && (!i && ("" + e).length > 0 || i) && (!r || r && r("" + e));
                    default:
                        return c === n
                }
            }

            function k(e, t) {
                const n = { ...Y,
                    ...t
                };
                return Object.keys(n).reduce(((t, a) => {
                    const r = n[a];
                    if (r) {
                        const {
                            label: n,
                            required: o,
                            types: i,
                            maxLength: c,
                            allowedValues: l
                        } = r, p = e[a];
                        if (o && ((0, s.g)(p) || (0, $.I)(p))) t.push(`Argument '${a}' (${n}) is missing`);
                        else if (void 0 !== p && i && i.length > 0) {
                            const r = i.map((t => {
                                const r = e[a],
                                    o = typeof r;
                                if (!I(r, t)) return `Argument '${a}' (${n}) is of wrong type ${o} (expected ${JSON.stringify(t)})`;
                                switch (t.type.toLowerCase()) {
                                    case "boolean":
                                        e[a] = !["0", "false", 0, !1].includes(r) && !!r;
                                        break;
                                    case "integer":
                                    case "float":
                                        e[a] = Number(r);
                                        break;
                                    case "string":
                                        !["number", "boolean"].some((e => e === o)) || isNaN(r) || void 0 === r || (0, s.g)(r) || (e[a] = "" + r)
                                }
                            }));
                            r.every((e => e && e.length > 0)) && r.forEach((e => t.push(e)))
                        }
                        if (null != p && l && -1 === l.indexOf(p)) {
                            const e = l.map((e => `"${e}"`)).join(", ");
                            t.push(`Argument '${a}' (${n}) value is not allowed (expected one of ${e}, received ${p})`)
                        }
                        null != p && c && p.length > c && t.push(`Argument '${a}' (${n}) is too long (length of ${p.length}, expected ${c})`)
                    }
                    return t
                }), [])
            }
            var O = n(7765);
            const N = e => {
                const t = {};
                (0, O.o9)() && !(0, s.g)((0, O.kQ)().previousLogicalView) && (t.pea = "INVALIDATE", t.pev = (0, O.kQ)().previousLogicalView);
                const n = { ...e,
                        ...t,
                        t: a.YQ.pageview
                    },
                    o = function(e) {
                        return k(e, {
                            pea: {
                                label: "PostEdit Action",
                                required: !1,
                                types: [{
                                    type: a.qz.String,
                                    allowEmpty: !1
                                }]
                            },
                            pev: {
                                label: "PostEdit LogicalView",
                                required: !1,
                                types: [{
                                    type: a.qz.String,
                                    allowEmpty: !1
                                }]
                            }
                        })
                    }(n);
                o.length ? h(a.YQ.pageview, o, n) : (C(n), (0, r.B6)("Pageview hit has been aggregated. Data:", n))
            };
            const P = e => {
                const t = window.ABTasty.results,
                    n = e.caid && t && t[e.caid] && Object.keys(t[e.caid].targetings.qaParameters).length > 0 || (0, v.vm)(),
                    o = { ...e,
                        t: a.YQ.campaign
                    };
                n && (o.qa = !0);
                const i = function(e) {
                    return k(e, {
                        caid: {
                            label: "Campaign ID",
                            required: !0,
                            types: [{
                                type: a.qz.String,
                                allowEmpty: !1
                            }]
                        },
                        vaid: {
                            label: "Variation ID",
                            required: !0,
                            types: [{
                                type: a.qz.String,
                                allowEmpty: !1
                            }]
                        }
                    })
                }(o);
                i.length ? h(a.YQ.campaign, i, o) : (C(o), (0, r.B6)("Campaign hit has been aggregated. Data:", o))
            };
            var D = n(6257),
                x = n(2039),
                j = n(8445);
            const B = (e, t) => e.map((e => {
                for (const n in e) {
                    if ("qt" === n) continue;
                    const a = e[n];
                    (0, s.g)(t[n]) || t[n] != a || delete e[n]
                }
                return e
            })).filter((e => {
                const t = Object.keys(e);
                return !(1 === t.length && "qt" === t[0])
            }));
            const L = e => {
                const t = { ...e,
                        t: a.YQ.segment
                    },
                    n = function(e) {
                        return k(e, {
                            s: {
                                label: "Segments",
                                required: !0,
                                types: [{
                                    type: a.qz.Object,
                                    model: {
                                        key: {
                                            type: a.qz.String
                                        },
                                        value: {
                                            type: a.qz.String
                                        }
                                    }
                                }]
                            },
                            pa: {
                                label: "Provider",
                                required: !1,
                                types: [{
                                    type: a.qz.String,
                                    required: !1
                                }]
                            }
                        })
                    }(t);
                n.length ? h(a.YQ.segment, n, t) : (Array.isArray(t.s) ? t.s.forEach((t => {
                    const n = { ...e,
                        t: a.YQ.segment
                    };
                    n.s = t, C(n)
                })) : C(t), function(e) {
                    if (!e.s && "object" != typeof e.s) return;
                    if (e.pa && "string" != typeof e.pa) return;
                    const t = new D.x;
                    let n = t.getSegments() || [];
                    const a = e.pa ? { ...e.s,
                        pa: e.pa
                    } : e.s;
                    n = B(n, a), t.setSegments([...n, { ...a,
                        qt: e.qt
                    }])
                }(e), (e => {
                    if (!e.s && "object" != typeof e.s) return;
                    if (e.pa && "string" != typeof e.pa) return;
                    let t = JSON.parse(x.Ks.getItem(x.b1, j.o.CUSTOM_SEGMENTS)) || [];
                    const n = e.pa ? { ...e.s,
                        pa: e.pa
                    } : e.s;
                    t = B(t, n), x.Ks.setItem(x.b1, j.o.CUSTOM_SEGMENTS, JSON.stringify([...t, { ...n,
                        qt: e.qt
                    }]))
                })(e), (0, r.pq)("Segment hit has been aggregated. Data:", t))
            };
            n(88);
            const R = e => {
                const t = { ...e,
                        t: a.YQ.event
                    },
                    n = function(e) {
                        return k(e, {
                            ec: {
                                label: "Event Category",
                                required: !0,
                                types: [{
                                    type: a.qz.String,
                                    allowEmpty: !1
                                }]
                            },
                            ea: {
                                label: "Event Action",
                                required: !0,
                                types: [{
                                    type: a.qz.String,
                                    allowEmpty: !1
                                }]
                            },
                            el: {
                                label: "Event Label",
                                required: !1,
                                types: [{
                                    type: a.qz.String,
                                    allowEmpty: !0
                                }]
                            },
                            ev: {
                                label: "Event Value",
                                required: !1,
                                types: [{
                                    type: a.qz.Integer,
                                    condition: e => e >= 0
                                }]
                            },
                            caid: {
                                label: "Campaign Id",
                                required: !1,
                                types: [{
                                    type: a.qz.String,
                                    allowEmpty: !1
                                }]
                            },
                            vaid: {
                                label: "Variation Id",
                                required: !1,
                                types: [{
                                    type: a.qz.String,
                                    allowEmpty: !1
                                }]
                            }
                        })
                    }(t);
                n.length ? h(a.YQ.event, n, t) : (C(t), "csat" === t.ec && t.caid && t.vaid && t.caid && t.ev && (new D.x).addVote({
                    vaid: `${t.vaid}`,
                    caid: `${t.caid}`,
                    score: t.ev,
                    maxScore: Number((t.cv && t.cv[2] || "").replace(/\D/g, ""))
                }), t.ec === he && t.caid ? (0, r.pq)(`Event of category "${t.ec}" has been aggregated for campaign ${t.caid} and variation ${t.vaid}. Data:`, t) : (0, r.pq)(`Event of category "${t.ec}" has been aggregated. Data:`, t))
            };
            const M = e => {
                const t = { ...e,
                        t: a.YQ.transaction
                    },
                    n = function(e) {
                        return k(e, {
                            tid: {
                                label: "Transaction ID",
                                required: !0,
                                types: [{
                                    type: a.qz.String,
                                    allowEmpty: !1
                                }]
                            },
                            ta: {
                                label: "Transaction Affiliation",
                                required: !0,
                                types: [{
                                    type: a.qz.String,
                                    allowEmpty: !1
                                }]
                            },
                            tr: {
                                label: "Transaction Revenue",
                                required: !1,
                                types: [{
                                    type: a.qz.Float,
                                    condition: e => e >= 0
                                }]
                            },
                            ts: {
                                label: "Transaction Shipping",
                                required: !1,
                                types: [{
                                    type: a.qz.Float,
                                    condition: e => e >= 0
                                }]
                            },
                            tt: {
                                label: "Transaction Tax",
                                required: !1,
                                types: [{
                                    type: a.qz.Float,
                                    condition: e => e >= 0
                                }]
                            },
                            tc: {
                                label: "Transaction Currency",
                                required: !1,
                                types: [{
                                    type: a.qz.String,
                                    allowEmpty: !0
                                }],
                                maxLength: 10
                            },
                            tcc: {
                                label: "Transaction Coupon Code",
                                required: !1,
                                types: [{
                                    type: a.qz.String,
                                    allowEmpty: !0
                                }]
                            },
                            pm: {
                                label: "Transaction Payment Method",
                                required: !1,
                                types: [{
                                    type: a.qz.String,
                                    allowEmpty: !0
                                }]
                            },
                            sm: {
                                label: "Transaction Shipping Method",
                                required: !1,
                                types: [{
                                    type: a.qz.String,
                                    allowEmpty: !0
                                }]
                            },
                            icn: {
                                label: "Transaction Number of Items",
                                required: !1,
                                types: [{
                                    type: a.qz.Integer,
                                    condition: e => e >= 0
                                }]
                            }
                        })
                    }(t);
                n.length ? h(a.YQ.transaction, n, t) : (C(t), function(e) {
                    const t = {
                        id: e.tid || e.id,
                        value: e.tr,
                        shipping: e.sm,
                        payment: e.pm,
                        coupon: e.tcc,
                        tax: e.tt,
                        shipping_cost: e.ts,
                        currency: e.tc,
                        name: e.name,
                        quantity: e.quantity,
                        affiliation: e.ta,
                        time: e.time || (new Date).getTime()
                    };
                    (new D.x).addTransaction(t)
                }(e), (0, r.pq)(`Transaction "${t.ta}" has been aggregated. Data:`, t))
            };
            const V = e => {
                const t = { ...e,
                        t: a.YQ.item
                    },
                    n = function(e) {
                        return k(e, {
                            tid: {
                                label: "Transaction ID",
                                required: !0,
                                types: [{
                                    type: a.qz.String,
                                    allowEmpty: !1
                                }]
                            },
                            in: {
                                label: "Item Name",
                                required: !0,
                                types: [{
                                    type: a.qz.String,
                                    allowEmpty: !1
                                }]
                            },
                            ip: {
                                label: "Item Price",
                                required: !1,
                                types: [{
                                    type: "float"
                                }]
                            },
                            iq: {
                                label: "Item Quantity",
                                required: !1,
                                types: [{
                                    type: "integer"
                                }]
                            },
                            ic: {
                                label: "Item Code",
                                required: !1,
                                types: [{
                                    type: a.qz.String,
                                    allowEmpty: !0
                                }],
                                maxLength: 500
                            },
                            iv: {
                                label: "Item Category",
                                required: !1,
                                types: [{
                                    type: a.qz.String,
                                    allowEmpty: !0
                                }],
                                maxLength: 500
                            }
                        })
                    }(t);
                n.length ? h(a.YQ.item, n, t) : (C(t), function(e) {
                    const t = {
                        transactionId: e.tid,
                        name: e.in,
                        quantity: e.iq,
                        revenue: e.iq && e.ip ? e.iq * e.ip : 0,
                        local_revenue: e.iq && e.ip ? e.iq * e.ip : 0,
                        sku: e.ic,
                        category: e.iv,
                        time: (new Date).getTime()
                    };
                    (new D.x).addItem(t)
                }(e), (0, r.pq)("Item hit has been aggregated. Data:", t))
            };
            var _ = n(108),
                H = n(3663),
                F = n(5415);
            const U = {
                [F.UT]: "==",
                [F.sz]: "=@",
                [F.Wm]: "=~"
            };
            const X = e => t => {
                    let {
                        qt: n,
                        ...o
                    } = t;
                    const {
                        waitForConsent: i
                    } = (0, w.F5)(), s = (e => {
                        let {
                            mode: t,
                            data: n
                        } = e;
                        switch (t) {
                            case _.Ey.customJs:
                                return "custom";
                            case _.Ey.didomi:
                                return "string" == typeof n && n ? n : H.M;
                            case _.Ey.specificCookie:
                                if ("object" == typeof n) {
                                    const {
                                        name: e,
                                        value: t,
                                        condition: a
                                    } = n;
                                    return `${e}${a&&U[a]?U[a]:U[F.UT]}${t}`
                                }
                            default:
                                return ""
                        }
                    })(i), c = (e => {
                        let {
                            campaignRestrictions: t
                        } = e;
                        return Object.keys(t).length > 0 && 0 === Object.values(t).filter((e => e)).length ? a.R1.strict : a.R1.permissive
                    })(i), l = (e => {
                        let {
                            mode: t
                        } = e;
                        return Object.keys(a.aE).includes(t) ? a.aE[t] : void 0
                    })(i), p = (e => {
                        let {
                            campaignRestrictions: t
                        } = e;
                        return Object.keys(t).filter((e => t[e])).reduce(((e, t) => e + _.gp[t]), 0)
                    })(i), d = Date.now(), u = { ...o,
                        qt: d - n,
                        me: s,
                        om: c,
                        sco: `${p}`,
                        t: a.YQ.consent,
                        ts: d
                    };
                    l && (u.op = l);
                    const y = function(e) {
                            return k(e, {
                                co: {
                                    label: "Consent",
                                    required: !0,
                                    types: [{
                                        type: a.qz.Boolean,
                                        allowEmpty: !1
                                    }]
                                }
                            })
                        }(u),
                        m = { ...T(e),
                            tv: "latest",
                            tch: `${"312835dc".substring(0,5)}`,
                            h: [u],
                            t: a.YQ.batch
                        };
                    y.length ? h(a.YQ.consent, y, u) : (g(m), (0, r.B6)("Consent hit has been sent. Data:", u))
                },
                J = {
                    ps: {
                        label: "Product SKU",
                        required: !0,
                        types: [{
                            type: a.qz.String,
                            allowEmpty: !1
                        }]
                    },
                    pn: {
                        label: "Product name",
                        required: !1,
                        types: [{
                            type: a.qz.String,
                            allowEmpty: !1
                        }]
                    },
                    pq: {
                        label: "Product quantity",
                        required: !0,
                        types: [{
                            type: a.qz.Integer,
                            allowEmpty: !1
                        }]
                    },
                    pp: {
                        label: "Product price",
                        required: !0,
                        types: [{
                            type: a.qz.Float,
                            allowEmpty: !1
                        }]
                    },
                    pcid: {
                        label: "Product cart Id",
                        required: !0,
                        types: [{
                            type: a.qz.String,
                            allowEmpty: !1
                        }]
                    }
                },
                K = {
                    pq: {
                        label: "Product quantity",
                        required: !0,
                        types: [{
                            type: a.qz.Integer,
                            allowEmpty: !1
                        }]
                    },
                    pp: {
                        label: "Product price",
                        required: !0,
                        types: [{
                            type: a.qz.Float,
                            allowEmpty: !1
                        }]
                    },
                    pcid: {
                        label: "Product cart Id",
                        required: !0,
                        types: [{
                            type: a.qz.String,
                            allowEmpty: !1
                        }]
                    }
                },
                W = {
                    pp: {
                        label: "Product price",
                        required: !1,
                        types: [{
                            type: a.qz.Float,
                            allowEmpty: !1
                        }]
                    },
                    ps: {
                        label: "Product SKU",
                        required: !0,
                        types: [{
                            type: a.qz.String,
                            allowEmpty: !1
                        }]
                    },
                    pn: {
                        label: "Product name",
                        required: !1,
                        types: [{
                            type: a.qz.String,
                            allowEmpty: !1
                        }]
                    }
                },
                G = [a.X8.CART_ITEM, a.X8.CART_TOTAL, a.X8.VIEW];
            const Z = e => {
                const t = { ...e,
                        t: a.YQ.product
                    },
                    n = function(e) {
                        return k(e, {
                            pit: {
                                label: "Product interaction type",
                                required: !0,
                                types: [{
                                    type: "string",
                                    allowEmpty: !1,
                                    value: G,
                                    condition: e => G.some((t => t === e))
                                }]
                            },
                            ...e.pit === a.X8.CART_ITEM ? J : {},
                            ...e.pit === a.X8.CART_TOTAL ? K : {},
                            ...e.pit === a.X8.VIEW ? W : {}
                        })
                    }(t);
                n.length > 0 ? h(a.YQ.product, n, t) : (C(t), (0, r.pq)("Product hit has been aggregated. Data:", t))
            };

            function ee(e) {
                if (!(e instanceof Element)) return null;
                const t = [];
                let n = e;
                for (; n && n.nodeType === Node.ELEMENT_NODE;) {
                    let e = n.nodeName.toLowerCase();
                    if (n.id) {
                        e += "#" + n.id, t.unshift(e);
                        break
                    } {
                        let t = n,
                            a = 1;
                        for (; t = t.previousElementSibling;) t.nodeName.toLowerCase() === e && a++;
                        a > 1 && (e += ":nth-of-type(" + a + ")")
                    }
                    t.unshift(e), n = n.parentNode
                }
                return t.join(" > ")
            }
            const te = Object.keys({
                click: "click",
                over: "over",
                scroll: "scroll"
            });

            function ne(e, t) {
                const n = {};
                if (e && e !== document) {
                    const a = t.elementsMap.get(e);
                    n.tecp = encodeURIComponent(ee(e)), e.id && (n.teid = e.id), a && a.enterTime && (n.otbe = Date.now() - a.enterTime), n.tc = e.getAttribute("class") || "";
                    const {
                        left: r,
                        top: o,
                        width: i,
                        height: s
                    } = function(e) {
                        const t = e.getBoundingClientRect(),
                            n = document.body,
                            a = document.documentElement,
                            r = window.pageYOffset || a.scrollTop || n.scrollTop,
                            o = window.pageXOffset || a.scrollLeft || n.scrollLeft,
                            i = a.clientTop || n.clientTop || 0,
                            s = a.clientLeft || n.clientLeft || 0,
                            c = t.top + r - i,
                            l = t.left + o - s;
                        return {
                            top: Math.round(c),
                            left: Math.round(l),
                            width: Math.round(t.width),
                            height: Math.round(t.height)
                        }
                    }(e);
                    n.tes = `${i}x${s}`, n.tep = `${r}x${o}`, n.tcec = e.childElementCount || 0, n.tet = e.tagName
                }
                return n
            }
            const ae = (e, t, n) => {
                const {
                    pageX: r,
                    pageY: o
                } = t.mouse, i = void 0 !== n.pageX ? `${n.pageX}x${n.pageY}` : `${r}x${o}`, s = { ...ne(n.target, t),
                    esp: ve(),
                    cp: i,
                    ...e,
                    t: a.YQ.visitorevent
                }, c = function(e) {
                    return k(e, {
                        et: {
                            label: "Event Type",
                            required: !0,
                            types: [{
                                type: a.qz.String
                            }],
                            allowedValues: te
                        }
                    })
                }(s);
                c.length ? h(a.YQ.visitorevent, c, s) : C(s)
            };
            const re = e => {
                let {
                    caid: t,
                    vaid: n,
                    ...o
                } = e;
                const i = { ...o,
                        t: a.YQ.nps
                    },
                    s = function(e) {
                        return k(e, {
                            ns: {
                                label: "The NPS score ranging from -100 to 100",
                                required: !0,
                                types: [{
                                    type: a.qz.Integer
                                }]
                            },
                            nf: {
                                label: "The NPS feedbacks from visitors",
                                required: !1,
                                types: [{
                                    type: a.qz.String,
                                    allowEmpty: !0
                                }]
                            }
                        })
                    }(i);
                s.length ? h(a.YQ.nps, s, i) : (n && t && o.ns && (new D.x).addVote({
                    vaid: `${n}`,
                    caid: `${t}`,
                    score: o.ns
                }), C(i), (0, r.B6)("NPS hit has been aggregated. Data:", i))
            };
            const oe = e => t => {
                    const n = { ...T(e),
                            ...t,
                            t: a.YQ.datalayer
                        },
                        o = function(e) {
                            return k(e, {
                                dlr: {
                                    label: "Datalayer content",
                                    required: !0,
                                    types: [{
                                        type: a.qz.Object
                                    }, {
                                        type: a.qz.Array
                                    }]
                                }
                            })
                        }(n);
                    o.length ? h(a.YQ.datalayer, o, n) : (g(n, null, "https://ariane.abtasty.com/datalayer"), (0, r.B6)("Datalayer hit has been send. Data:", n))
                },
                ie = e => t => {
                    if (window.Cypress) return Promise.resolve();
                    const n = { ...T(e),
                            ...t,
                            t: a.YQ.usage
                        },
                        r = k(n, {
                            cv: {
                                label: "Custom values",
                                required: !0,
                                types: [{
                                    type: a.qz.Object
                                }]
                            }
                        });
                    return r.length ? (h(a.YQ.usage, r, n), Promise.resolve()) : g(n, !1, "https://ariane.abtasty.com/analytics")
                };
            var se = n(3476),
                ce = n(6332);
            const le = e => {
                (0, ce.j3)({
                    deprecate: "window._abtasty.push()",
                    el: `push-${e}`,
                    type: "function"
                })
            };
            const pe = function() {
                (arguments.length > 0 && void 0 !== arguments[0] ? arguments[0] : window._abtasty).forEach((e => {
                    if (Array.isArray(e) && Object.keys(e).length) switch (e[0].toString().toLowerCase()) {
                        case "transaction":
                            (e => {
                                const t = e[1].toString(),
                                    n = {
                                        tid: e[2],
                                        tr: (0, s.g)(e[3]) ? 0 : parseFloat(e[3].toString().replace(",", ".")),
                                        icn: Number(e[4]) || 0,
                                        ta: t
                                    };
                                we(a.YQ.transaction, n)
                            })(e), le("transaction");
                            break;
                        case "cv":
                            (e => {
                                const t = e[1] || "",
                                    n = e[2] || "";
                                if ("string" != typeof t || "" === t || ("string" != typeof n || "" === n) && "number" != typeof n) return void(0, r.$e)("CV informations are not valid, please, check that your second and third argument are not empty strings");
                                const o = {
                                    category: se.a.CV,
                                    action: t,
                                    value: "string" == typeof n ? n.substring(0, 65) : n,
                                    time: Date.now()
                                };
                                (new D.x).addCustomVariable(o);
                                const i = {
                                    [t]: "string" == typeof n ? n.substring(0, 65) : n
                                };
                                we(a.YQ.segment, {
                                    s: i
                                })
                            })(e), le("cv");
                            break;
                        case "eco":
                            (e => {
                                const t = e[1] || "",
                                    n = e[2] || "";
                                if ("string" != typeof t || "" === t || ("string" != typeof n || "" === n) && "number" != typeof n) return void(0, r.$e)("ECO informations are not valid, please, check that your second and third argument are not empty strings");
                                const o = {
                                    action: t,
                                    category: se.a.ECO,
                                    value: "string" == typeof n ? n.substring(0, 65) : n,
                                    time: Date.now()
                                };
                                (new D.x).addCustomVariable(o);
                                const i = {
                                    ec: "eco",
                                    ea: t,
                                    el: n
                                };
                                we(a.YQ.event, i)
                            })(e), le("eco");
                            break;
                        default:
                            (0, r.z3)("Wrong format to push (nothing was sent)", e)
                    } else(0, r.z3)("Please give at least one parameter for the/these arrays !", e)
                })), window._abtasty = [], window._abtasty.push = function() {
                    return pe([arguments[0]]), Array.prototype.push.apply(this, arguments)
                }
            };
            var de = n(9700),
                ue = n(6381),
                ye = n(5712);
            const ge = e => t => {
                if (window.Cypress) return Promise.resolve();
                const n = {
                        cv: t.cv,
                        t: a.YQ.troubleshooting,
                        cid: (0, w.pw)(),
                        vid: e.visitorId
                    },
                    r = k(n, {
                        cv: {
                            label: "Custom values",
                            required: !0,
                            types: [{
                                type: a.qz.Object
                            }]
                        }
                    });
                return r.length ? (h(a.YQ.troubleshooting, r, n), Promise.resolve()) : g(n, !1, "https://ariane.abtasty.com/troubleshooting")
            };
            const me = e => {
                    try {
                        const t = { ...e,
                                tv: "latest",
                                tch: `${"312835dc".substring(0,5)}`,
                                t: a.YQ.performance
                            },
                            n = function(e) {
                                return k(e, {
                                    tv: {
                                        label: "Tag Version",
                                        required: !0,
                                        types: [{
                                            type: a.qz.String,
                                            allowEmpty: !1
                                        }]
                                    },
                                    tch: {
                                        label: "Tag commit hash",
                                        required: !0,
                                        types: [{
                                            type: a.qz.String,
                                            allowEmpty: !1
                                        }]
                                    },
                                    ext: {
                                        label: "Execution Time",
                                        required: !0,
                                        types: [{
                                            type: a.qz.Integer,
                                            allowEmpty: !1
                                        }]
                                    }
                                })
                            }(t);
                        n.length ? h(a.YQ.performance, n, t) : (C(t), (0, r.pq)("Performance hit has been aggregated. Data:", t))
                    } catch (e) {
                        (0, r.z3)("Performance hit can't be aggregated. Error:", e.message)
                    }
                },
                he = "Action Tracking",
                fe = {
                    elementsMap: new Map,
                    mouse: {
                        pageX: 0,
                        pageY: 0
                    }
                },
                be = (e, t, a, r, o) => {
                    if (Promise.resolve().then(n.bind(n, 5258)).then((n => {
                            let {
                                recheckTargetingByHit: a
                            } = n;
                            a(e, t)
                        })), window.frames.ABTastyQaAssistant) {
                        const n = { ...t,
                            qt: a,
                            event: r,
                            path: o,
                            name: "ABTasty_event",
                            type: e.toUpperCase()
                        };
                        window.postMessage(n, document.location.origin), window.frames.ABTastyQaAssistant.postMessage(n, "*")
                    }
                    ye.g.getInstance().emit(e.toUpperCase(), t, a)
                },
                we = function(e, t) {
                    let n = arguments.length > 2 && void 0 !== arguments[2] ? arguments[2] : void 0,
                        o = arguments.length > 3 && void 0 !== arguments[3] ? arguments[3] : void 0;
                    const i = S.n.getCommonDataRefresher();
                    if (i) {
                        const r = t.qt || Date.now();
                        be(e, t, r, n, o), (e => ({
                            [a.YQ.consent]: X(e),
                            [a.YQ.campaign]: P,
                            [a.YQ.event]: R,
                            [a.YQ.item]: V,
                            [a.YQ.pageview]: N,
                            [a.YQ.segment]: L,
                            [a.YQ.transaction]: M,
                            [a.YQ.visitorevent]: ae,
                            [a.YQ.nps]: re,
                            [a.YQ.datalayer]: oe(e),
                            [a.YQ.product]: Z,
                            [a.YQ.usage]: ie(e),
                            [a.YQ.troubleshooting]: ge(e),
                            [a.YQ.performance]: me
                        }))(i())[e.toUpperCase()]({ ...t,
                            qt: r
                        }, { ...fe
                        }, n)
                    } else(0, r.$e)("[CollectFacade] common data refresher is not set")
                };
            const qe = (e, t, n, r, o) => {
                const i = {
                    name: e,
                    value: 0,
                    time: o || Date.now()
                };
                (new D.x).addActionTracking(i);
                const s = ee(r),
                    c = {
                        ec: he,
                        ea: e,
                        qt: o
                    };
                n && (c.caid = n.toString()), we(a.YQ.event, c, void 0, s)
            };

            function ve() {
                const e = 100 * (document.body.scrollTop || document.documentElement.scrollTop) / (Math.max(document.body.scrollHeight, document.documentElement.scrollHeight, document.body.offsetHeight, document.documentElement.offsetHeight, document.body.clientHeight, document.documentElement.clientHeight) - window.innerHeight);
                return Math.round(e)
            }
            const Ee = e => {
                S.n.setCommonDataRefresher(e), (() => {
                        if (window.abtasty) {
                            const e = window.abtasty.send;
                            window.abtasty.send = (t, n) => {
                                we(t, n), e && e(t, n)
                            }
                        } else window.abtasty = {
                            send: (e, t) => {
                                we(e, t)
                            }
                        };
                        if ("function" == typeof window.ABTastyClickTracking) {
                            const e = window.ABTastyClickTracking;
                            window.ABTastyClickTracking = (t, n, a) => {
                                qe(t, n, a, null), e(t, n, a)
                            }
                        } else window.ABTastyClickTracking = qe;
                        if ("function" == typeof window.ABTastyEvent) {
                            const e = window.ABTastyEvent;
                            window.ABTastyEvent = (t, n, a) => {
                                qe(t, n, a, null), e(t, n, a)
                            }
                        } else window.ABTastyEvent = qe
                    })(), window._abtasty = window._abtasty || [], pe(window._abtasty),
                    function() {
                        const e = (0, de.aR)() ? "pagehide" : "beforeunload";
                        window.addEventListener(e, (() => (Q(!0), null)))
                    }(), S.n.getCollectHit().forEach((e => {
                        we(e.type, {
                            qt: e.time,
                            ...e.args
                        }, void 0, void 0)
                    })), S.n.getEventTracking().forEach((e => {
                        qe(e.name, e.data, e.campaignId, void 0, e.time)
                    })), (new ue.k).dispatchCustomEvent(o.u.Name.analyticsLoaded)
            }
        }
    }
]);
"use strict";
(self.webpackChunktag = self.webpackChunktag || []).push([
    [693], {
        9290: (e, t, r) => {
            Object.defineProperty(t, "__esModule", {
                value: !0
            }), t.deleteEvents = t.setEvents = t.setModificationDuringClick = t.isModificationDuringClick = t.isClickInProgress = void 0;
            var n = r(4476),
                a = r(3478),
                o = !1,
                i = !1,
                u = (t.isClickInProgress = function() {
                    return o
                }, t.isModificationDuringClick = function() {
                    return i
                }, t.setModificationDuringClick = function(e) {
                    i = e
                }),
                l = function() {
                    o = !1, i && ((0, n.getWindow)().requestAnimationFrame(a.startLoop), u(!1))
                },
                d = function(e) {
                    var t = e.type;
                    o = !0, "mouseup" === t && setTimeout((function() {
                        return o && l()
                    }), 16)
                },
                c = {
                    passive: !0,
                    capture: !0
                },
                f = {
                    mousedown: d,
                    mouseup: d,
                    click: function() {
                        return setTimeout(l, 0)
                    }
                },
                s = Object.keys(f);
            t.setEvents = function() {
                s.forEach((function(e) {
                    document.addEventListener(e, f[e], c)
                }))
            }, t.deleteEvents = function() {
                s.forEach((function(e) {
                    document.removeEventListener(e, f[e], c)
                }))
            }
        },
        107: (e, t, r) => {
            Object.defineProperty(t, "__esModule", {
                value: !0
            }), t.rerun = t.simpleRollbackAndStop = t.stop = t.start = t.rollbackAndRun = t.addModification = t.rollback = void 0;
            var n = function(e) {
                    return e && e.__esModule ? e : {
                        default: e
                    }
                }(r(5607)),
                a = r(8341),
                o = r(9290),
                i = r(3478),
                u = r(4476);

            function l(e) {
                if (Array.isArray(e)) {
                    for (var t = 0, r = Array(e.length); t < e.length; t++) r[t] = e[t];
                    return r
                }
                return (0, n.default)(e)
            }
            var d = !1,
                c = ["checked", "class", "disabled", "form", "hidden", "href", "icon", "id", "label", "max", "min", "maxLength", "minLength", "method", "name", "novalidate", "placeholder", "readonly", "rel", "required", "selected", "size", "span", "src", "target", "title", "type", "value"];
            (0, a.createObserver)((function(e) {
                if (e && e.length) {
                    var t = (0, i.getTargetElements)(),
                        r = (0, i.getModificationEngineElements)();
                    if (!t.length && !r.length) return;
                    if (!e.some((function(e) {
                            var n = e.addedNodes,
                                a = e.removedNodes,
                                o = e.target,
                                u = [],
                                d = null;
                            if ("attributes" === e.type) return [].concat(l(r), l(t)).some((function(e) {
                                return e === o
                            }));
                            if (n.length) {
                                if ([].concat(l(n)).some((function(e) {
                                        return r.includes(e)
                                    }))) return !1;
                                u.push.apply(u, l(n)), d = "addedNodes"
                            } else a.length ? (u.push.apply(u, l(a)), d = "removedNodes") : u.push(o);
                            return (0, i.modificationIsChildOf)(u, r, t, d)
                        }))) return
                }
                d && (0, i.run)()
            }));
            var f = function e() {
                    Object.prototype.hasOwnProperty.call(window, "ABTastyEditor") || ((0, u.getDocument)() ? ((0, a.getObserver)().observe((0, u.getDocument)(), {
                        attributes: !0,
                        childList: !0,
                        characterData: !0,
                        subtree: !0,
                        attributeFilter: c
                    }), (0, o.setEvents)()) : (0, u.getWindow)().setTimeout(e, 50))
                },
                s = (t.rollback = i.clean, t.addModification = function(e) {
                    e && (0, i.add)(e)
                }),
                v = (t.rollbackAndRun = function(e) {
                    (0, i.clean)(), s(e)
                }, t.start = function(e, t) {
                    (0, u.setDocument)(t), s(e), d || (d = !0, f(), document.addEventListener("abtasty_resetActionTracking", (function() {
                        d = !1
                    }), {
                        once: !0
                    }))
                }),
                p = t.stop = function() {
                    d = !1, (0, a.getObserver)().disconnect(), (0, o.deleteEvents)()
                };
            t.simpleRollbackAndStop = function() {
                p(), (0, i.partialClean)()
            }, t.rerun = v
        },
        3478: (e, t, r) => {
            Object.defineProperty(t, "__esModule", {
                value: !0
            }), t.modificationIsChildOf = t.getTargetElements = t.getModificationEngineElements = t.isParentOf = t.add = t.run = t.startLoop = t.clean = t.partialClean = t.rollback = void 0;
            var n = function(e) {
                    return e && e.__esModule ? e : {
                        default: e
                    }
                }(r(5607)),
                a = Object.assign || function(e) {
                    for (var t = 1; t < arguments.length; t++) {
                        var r = arguments[t];
                        for (var n in r) Object.prototype.hasOwnProperty.call(r, n) && (e[n] = r[n])
                    }
                    return e
                },
                o = r(4476),
                i = r(8341),
                u = r(9290),
                l = function(e) {
                    if (e && e.__esModule) return e;
                    var t = {};
                    if (null != e)
                        for (var r in e) Object.prototype.hasOwnProperty.call(e, r) && (t[r] = e[r]);
                    return t.default = e, t
                }(r(7186));

            function d(e) {
                if (Array.isArray(e)) {
                    for (var t = 0, r = Array(e.length); t < e.length; t++) r[t] = e[t];
                    return r
                }
                return (0, n.default)(e)
            }
            var c = [],
                f = !1,
                s = {
                    applied: [],
                    operation: null
                },
                v = t.rollback = function() {
                    var e = !(arguments.length > 0 && void 0 !== arguments[0]) || arguments[0];
                    c.slice().reverse().forEach((function(t) {
                        var r = t.applied;
                        (void 0 === r ? [] : r).forEach((function(t) {
                            var r = t.rollbacks;
                            (void 0 === r ? [] : r).forEach((function(t) {
                                null != t && t(e)
                            }))
                        }))
                    }))
                },
                p = t.partialClean = function() {
                    v(), f = !1
                },
                h = (t.clean = function() {
                    p(), c.length = 0
                }, t.startLoop = function() {
                    f = !1, v(!1), g()
                }),
                g = function() {
                    c = c.map((function(e) {
                        var t = e.applied,
                            r = e.operation,
                            n = r.type,
                            a = r.value,
                            o = l[n];
                        return "function" == typeof o && "function" != typeof a ? {
                            operation: r,
                            applied: o(r, t)
                        } : e
                    })), (0, i.getObserver)().takeRecords()
                },
                b = t.run = function() {
                    var e = (0, u.isClickInProgress)();
                    f || e ? (0, u.setModificationDuringClick)(!0) : (f = !0, (0, o.getWindow)().requestAnimationFrame(h))
                },
                y = (t.add = function(e) {
                    var t;
                    Array.isArray(e) && e.length ? (t = c).push.apply(t, d(e.map((function(e) {
                        return a({}, s, {
                            operation: e
                        })
                    })))) : c.push(a({}, s, {
                        operation: e
                    }));
                    b()
                }, t.isParentOf = function e(t, r) {
                    return t && "BODY" !== t.tagName ? t === r || e(t.parentNode, r) : t === r
                }),
                m = function(e) {
                    return [].concat(d(new Set(e.filter((function(e) {
                        return e
                    })))))
                };
            t.getModificationEngineElements = function() {
                return m(c.reduce((function(e, t) {
                    var r = t.applied.map((function(e) {
                        var t = e.elements.children;
                        return (void 0 === t ? [] : t).reduce((function(e, t) {
                            return e.concat(t)
                        }), [])
                    })).reduce((function(e, t) {
                        return e.concat(t)
                    }), []);
                    return [].concat(d(e), d(r)).filter((function(e) {
                        return null !== e
                    }))
                }), []))
            }, t.getTargetElements = function() {
                return m(c.reduce((function(e, t) {
                    var r = ["editStyleCSS", "addCSS", "hideCSS"].includes(t.operation.type) ? [] : (0, o.qsa)(t.operation.selector);
                    return [].concat(d(e), d(r))
                }), []))
            }, t.modificationIsChildOf = function(e, t, r, n) {
                switch (n) {
                    case "addedNodes":
                        return r.some((function(t) {
                            return !!e.includes(t) || e.some((function(e) {
                                return y(t, e)
                            }))
                        }));
                    case "removedNodes":
                        return t.some((function(e) {
                            return !e.isConnected
                        }));
                    default:
                        return t.some((function(t) {
                            return !!t && e.some((function(e) {
                                return e.isSameNode(t) || y(t, e) || y(e, t)
                            }))
                        }))
                }
            }
        },
        8341: (e, t) => {
            Object.defineProperty(t, "__esModule", {
                value: !0
            });
            var r = void 0;
            t.createObserver = function(e) {
                r = new MutationObserver(e)
            }, t.getObserver = function() {
                return r
            }
        },
        3187: (e, t) => {
            Object.defineProperty(t, "__esModule", {
                value: !0
            });
            t.createAppliedModification = function() {
                return {
                    rollbacks: [],
                    target: null,
                    elements: {},
                    savedState: null
                }
            }
        },
        4476: (e, t, r) => {
            Object.defineProperty(t, "__esModule", {
                value: !0
            }), t.setNodeStyle = t.isEqualLink = t.setAttribute = t.qsa = t.isEqualNode = t.moveSiblingNode = t.moveChildNode = t.removeNode = t.addSiblingNode = t.addChildNode = t.getData = t.setData = t.getDocument = t.getWindow = t.setDocument = void 0;
            var n = function(e) {
                return e && e.__esModule ? e : {
                    default: e
                }
            }(r(5607));
            var a = void 0,
                o = function(e, t, r) {
                    return function() {
                        e.removeAttribute("data-ab-tasty-moved");
                        var n = t.parentNode,
                            a = r.isSameNode(n) || r.isEqualNode(n);
                        t.isConnected && a && t.parentNode.insertBefore(e, t), t.remove()
                    }
                },
                i = (t.setDocument = function() {
                    var e = arguments.length > 0 && void 0 !== arguments[0] ? arguments[0] : document;
                    a = e
                }, t.getWindow = function() {
                    return r.g || window
                }),
                u = t.getDocument = function() {
                    return a || i().document
                },
                l = t.setData = function(e, t, r) {
                    var n = e;
                    n.dataset ? n.dataset[t] = r : n.setAttribute(t, r)
                },
                d = t.getData = function(e, t) {
                    return e.dataset ? e.dataset[t] : e.getAttribute(t)
                },
                c = t.addChildNode = function(e, t) {
                    return e.appendChild(t),
                        function() {
                            if (e.contains(t)) try {
                                e.removeChild(t)
                            } catch (e) {
                                window.console.warn("The modification isn't correct. Please contact AB Tasty support team! \n " + e)
                            }
                        }
                },
                f = t.addSiblingNode = function(e, t) {
                    var r = !(arguments.length > 2 && void 0 !== arguments[2]) || arguments[2];
                    if (e && t && e.parentNode && !e.parentNode.contains(t)) {
                        var n = e.parentNode;
                        return r ? n.insertBefore(t, e.nextSibling) : n.insertBefore(t, e),
                            function() {
                                if (n.contains(t)) try {
                                    n.removeChild(t)
                                } catch (e) {
                                    window.console.warn("The modification isn't correct. Please contact AB Tasty support team! \n " + e)
                                }
                            }
                    }
                };
            t.removeNode = function(e) {
                var t = e,
                    r = !1,
                    n = null,
                    a = void 0;
                if (t && t.parentNode && (t.nodeType === Node.TEXT_NODE || !t.style || "none" !== t.style.display)) return t.nodeType === Node.TEXT_NODE ? (r = !0, n = t.textContent, t.textContent = "") : (a = i().getComputedStyle(t).display, t.style.setProperty("display", "none", "important")),
                    function() {
                        t.parentNode && (r ? t.textContent = n : (t.style.display = a, t.attributes.style && "" === t.attributes.style.value && t.removeAttribute("style")))
                    }
            }, t.moveChildNode = function(e, t) {
                var r = e,
                    n = r.parentNode;
                if (!t || !r || d(r, "abTastyMoved")) return null;
                var a = r.cloneNode(!0);
                return a.style.display = "none", a.id = "", a.className = "", l(a, "abTastyMoved", 1), l(r, "abTastyMoved", 1), n.replaceChild(a, r), c(t, r), o(r, a, n)
            }, t.moveSiblingNode = function(e, t) {
                var r = !(arguments.length > 2 && void 0 !== arguments[2]) || arguments[2],
                    n = e,
                    a = n.parentNode;
                if (!t || !n || d(n, "abTastyMoved")) return null;
                var i = n.cloneNode(!0);
                return i.style.display = "none", l(i, "abTastyMoved", 1), l(n, "abTastyMoved", 1), a.replaceChild(i, n), f(t, n, r), o(n, i, a)
            }, t.isEqualNode = function(e, t) {
                return e && t && (e.isEqualNode(t) || e.nodeType !== Node.TEXT_NODE && e.tagName === t.tagName && e.innerHTML === t.innerHTML)
            }, t.qsa = function(e) {
                try {
                    var t = u();
                    return [].concat(function(e) {
                        if (Array.isArray(e)) {
                            for (var t = 0, r = Array(e.length); t < e.length; t++) r[t] = e[t];
                            return r
                        }
                        return (0, n.default)(e)
                    }(t.querySelectorAll(e)))
                } catch (e) {
                    return []
                }
            }, t.setAttribute = function(e, t, r) {
                var n = arguments.length > 3 && void 0 !== arguments[3] ? arguments[3] : "edit",
                    a = e.getAttribute(t);
                return "edit" === n ? e.setAttribute(t, r) : e.removeAttribute(t),
                    function() {
                        null == a ? e.removeAttribute(t) : e.setAttribute(t, a)
                    }
            }, t.isEqualLink = function(e, t) {
                return e.nodeType !== Node.TEXT_NODE && e.tagName === t.tagName && d(e, "abTastyLink") === d(t, "abTastyLink") && e.href === t.href
            }, t.setNodeStyle = function(e, t, r) {
                var n = e,
                    a = n.style[t];
                return n.style[t] = r,
                    function() {
                        n.parentNode && (n.style[t] = a)
                    }
            }
        },
        7186: (e, t, r) => {
            Object.defineProperty(t, "__esModule", {
                value: !0
            });
            var n = r(1210);
            Object.defineProperty(t, "editStyleCSS", {
                enumerable: !0,
                get: function() {
                    return M(n).default
                }
            });
            var a = r(3917);
            Object.defineProperty(t, "editText", {
                enumerable: !0,
                get: function() {
                    return M(a).default
                }
            }), Object.defineProperty(t, "editDirect", {
                enumerable: !0,
                get: function() {
                    return M(a).default
                }
            });
            var o = r(4390);
            Object.defineProperty(t, "hide", {
                enumerable: !0,
                get: function() {
                    return M(o).default
                }
            }), Object.defineProperty(t, "hideCSS", {
                enumerable: !0,
                get: function() {
                    return M(o).default
                }
            }), Object.defineProperty(t, "hideByClassCSS", {
                enumerable: !0,
                get: function() {
                    return M(o).default
                }
            });
            var i = r(4925);
            Object.defineProperty(t, "hideContent", {
                enumerable: !0,
                get: function() {
                    return M(i).default
                }
            });
            var u = r(4819);
            Object.defineProperty(t, "editHtml", {
                enumerable: !0,
                get: function() {
                    return M(u).default
                }
            }), Object.defineProperty(t, "editHTML", {
                enumerable: !0,
                get: function() {
                    return M(u).default
                }
            });
            var l = r(1426);
            Object.defineProperty(t, "addHtml", {
                enumerable: !0,
                get: function() {
                    return M(l).default
                }
            }), Object.defineProperty(t, "addHTML", {
                enumerable: !0,
                get: function() {
                    return M(l).default
                }
            });
            var d = r(962);
            Object.defineProperty(t, "sort", {
                enumerable: !0,
                get: function() {
                    return M(d).default
                }
            });
            var c = r(6923);
            Object.defineProperty(t, "copy", {
                enumerable: !0,
                get: function() {
                    return M(c).default
                }
            });
            var f = r(8265);
            Object.defineProperty(t, "copyAfter", {
                enumerable: !0,
                get: function() {
                    return M(f).default
                }
            });
            var s = r(8188);
            Object.defineProperty(t, "copyBefore", {
                enumerable: !0,
                get: function() {
                    return M(s).default
                }
            });
            var v = r(1994);
            Object.defineProperty(t, "addImage", {
                enumerable: !0,
                get: function() {
                    return M(v).default
                }
            });
            var p = r(4376);
            Object.defineProperty(t, "cut", {
                enumerable: !0,
                get: function() {
                    return M(p).default
                }
            });
            var h = r(1088);
            Object.defineProperty(t, "cutAfter", {
                enumerable: !0,
                get: function() {
                    return M(h).default
                }
            }), Object.defineProperty(t, "advancedSort", {
                enumerable: !0,
                get: function() {
                    return M(h).default
                }
            });
            var g = r(8467);
            Object.defineProperty(t, "cutBefore", {
                enumerable: !0,
                get: function() {
                    return M(g).default
                }
            });
            var b = r(4053);
            Object.defineProperty(t, "addParagraph", {
                enumerable: !0,
                get: function() {
                    return M(b).default
                }
            });
            var y = r(1039);
            Object.defineProperty(t, "editAttributes", {
                enumerable: !0,
                get: function() {
                    return M(y).default
                }
            });
            var m = r(1030);
            Object.defineProperty(t, "editPicture", {
                enumerable: !0,
                get: function() {
                    return M(m).default
                }
            });
            var N = r(2629);
            Object.defineProperty(t, "changeImage", {
                enumerable: !0,
                get: function() {
                    return M(N).default
                }
            });
            var _ = r(7642);
            Object.defineProperty(t, "changeLink", {
                enumerable: !0,
                get: function() {
                    return M(_).default
                }
            });
            var O = r(4043);
            Object.defineProperty(t, "addLink", {
                enumerable: !0,
                get: function() {
                    return M(O).default
                }
            });
            var A = r(2096);

            function M(e) {
                return e && e.__esModule ? e : {
                    default: e
                }
            }
            Object.defineProperty(t, "addCSS", {
                enumerable: !0,
                get: function() {
                    return M(A).default
                }
            })
        },
        2096: (e, t, r) => {
            Object.defineProperty(t, "__esModule", {
                value: !0
            });
            var n = function(e) {
                return e && e.__esModule ? e : {
                    default: e
                }
            }(r(5607));
            t.default = function() {
                var e = (arguments.length > 0 && void 0 !== arguments[0] ? arguments[0] : {}).value,
                    t = arguments.length > 1 && void 0 !== arguments[1] ? arguments[1] : [],
                    r = '<style type="text/css">' + e + "</style>",
                    n = (0, o.qsa)("head");
                return n.length && "" !== e ? [].concat(i(n)).map((function(e) {
                    var n = t.find((function(e) {
                        return e.elements.children.every((function(e) {
                            return e.isConnected
                        }))
                    }));
                    if (n) return n;
                    var u = (0, a.createAppliedModification)(),
                        l = e.cloneNode(!0),
                        d = (0, o.getDocument)().createElement("div");
                    d.innerHTML = r;
                    var c = [].concat(i(d.childNodes));
                    return c.forEach((function(e) {
                        return (0, o.addChildNode)(l, e)
                    })), (0, o.isEqualNode)(u.savedState, l) ? u.elements.children.forEach((function(t) {
                        return (0, o.addChildNode)(e, t)
                    })) : (u.rollbacks = c.map((function(t) {
                        return (0, o.addChildNode)(e, t)
                    })), u.target = e, u.elements.children = c, u.savedState = e.cloneNode(!0)), u
                })) : []
            };
            var a = r(3187),
                o = r(4476);

            function i(e) {
                if (Array.isArray(e)) {
                    for (var t = 0, r = Array(e.length); t < e.length; t++) r[t] = e[t];
                    return r
                }
                return (0, n.default)(e)
            }
        },
        1426: (e, t, r) => {
            Object.defineProperty(t, "__esModule", {
                value: !0
            });
            var n = function(e) {
                return e && e.__esModule ? e : {
                    default: e
                }
            }(r(5607));
            t.default = function() {
                var e = arguments.length > 0 && void 0 !== arguments[0] ? arguments[0] : {},
                    t = e.selector,
                    r = e.value,
                    n = arguments.length > 1 && void 0 !== arguments[1] ? arguments[1] : [];
                if (!t) return [];
                var u = (0, o.qsa)(t);
                return u.length ? [].concat(i(u)).map((function(e) {
                    var t = n.find((function(e) {
                        return e.elements.children.every((function(e) {
                            return e.isConnected
                        }))
                    }));
                    if (t) return t;
                    var u = (0, a.createAppliedModification)(),
                        l = e.cloneNode(!0),
                        d = (0, o.getDocument)().createElement("div");
                    d.innerHTML = r;
                    var c = [].concat(i(d.childNodes));
                    return c.forEach((function(e) {
                        return (0, o.addChildNode)(l, e)
                    })), (0, o.isEqualNode)(u.savedState, l) ? u.elements.children.forEach((function(t) {
                        return (0, o.addChildNode)(e, t)
                    })) : (u.rollbacks = c.map((function(t) {
                        return (0, o.addChildNode)(e, t)
                    })), u.target = e, u.elements.children = c, u.savedState = e.cloneNode(!0)), u
                })) : []
            };
            var a = r(3187),
                o = r(4476);

            function i(e) {
                if (Array.isArray(e)) {
                    for (var t = 0, r = Array(e.length); t < e.length; t++) r[t] = e[t];
                    return r
                }
                return (0, n.default)(e)
            }
        },
        1994: (e, t, r) => {
            Object.defineProperty(t, "__esModule", {
                value: !0
            });
            var n = Object.assign || function(e) {
                for (var t = 1; t < arguments.length; t++) {
                    var r = arguments[t];
                    for (var n in r) Object.prototype.hasOwnProperty.call(r, n) && (e[n] = r[n])
                }
                return e
            };
            t.default = function() {
                var e = arguments.length > 0 && void 0 !== arguments[0] ? arguments[0] : {},
                    t = arguments.length > 1 && void 0 !== arguments[1] ? arguments[1] : [];
                if (!e) return [];
                var r = "<img src=" + e.value + " />";
                return (0, a.default)(n({}, e, {
                    value: r
                }), t)
            };
            var a = function(e) {
                return e && e.__esModule ? e : {
                    default: e
                }
            }(r(1426))
        },
        4043: (e, t, r) => {
            Object.defineProperty(t, "__esModule", {
                value: !0
            });
            var n = function(e) {
                return e && e.__esModule ? e : {
                    default: e
                }
            }(r(5607));
            t.default = function(e) {
                var t = e.selector,
                    r = e.value,
                    n = arguments.length > 1 && void 0 !== arguments[1] ? arguments[1] : [];
                if (!t) return [];
                var l = (0, o.qsa)(t);
                return l.length ? [].concat(i(l)).map((function(e) {
                    var t = n.find((function(e) {
                        return e.elements.link.isConnected
                    }));
                    if (t) return t;
                    var l = (0, a.createAppliedModification)(),
                        d = e.parentNode.cloneNode(!0),
                        c = [].concat(i(e.parentNode.childNodes)).indexOf(e),
                        f = d.childNodes[c],
                        s = u(r);
                    return (0, o.addSiblingNode)(f, s), (0, o.moveChildNode)(f, s), (0, o.isEqualNode)(l.savedState, d) ? ((0, o.addSiblingNode)(e, l.elements.link), (0, o.moveChildNode)(e, l.elements.link)) : (s = u(r), l.rollbacks = [(0, o.addSiblingNode)(e, s), (0, o.moveChildNode)(e, s)], l.target = e, l.elements.link = s, l.savedState = e.parentNode.cloneNode(!0)), l
                })) : []
            };
            var a = r(3187),
                o = r(4476);

            function i(e) {
                if (Array.isArray(e)) {
                    for (var t = 0, r = Array(e.length); t < e.length; t++) r[t] = e[t];
                    return r
                }
                return (0, n.default)(e)
            }
            var u = function(e) {
                var t = (0, o.getDocument)().createElement("a");
                return t.href = e.url, t.target = e.target || "_self", (0, o.setData)(t, "abTastyLink", 1), t
            }
        },
        4053: (e, t, r) => {
            Object.defineProperty(t, "__esModule", {
                value: !0
            });
            var n = Object.assign || function(e) {
                for (var t = 1; t < arguments.length; t++) {
                    var r = arguments[t];
                    for (var n in r) Object.prototype.hasOwnProperty.call(r, n) && (e[n] = r[n])
                }
                return e
            };
            t.default = function() {
                var e = arguments.length > 0 && void 0 !== arguments[0] ? arguments[0] : {},
                    t = arguments.length > 1 && void 0 !== arguments[1] ? arguments[1] : [];
                if (!e) return [];
                var r = "<p>" + e.value + "</p>";
                return (0, a.default)(n({}, e, {
                    value: r
                }), t)
            };
            var a = function(e) {
                return e && e.__esModule ? e : {
                    default: e
                }
            }(r(1426))
        },
        2629: (e, t, r) => {
            Object.defineProperty(t, "__esModule", {
                value: !0
            }), t.default = function() {
                var e = arguments.length > 0 && void 0 !== arguments[0] ? arguments[0] : {},
                    t = e.selector,
                    r = e.value;
                return t && r ? (0, n.default)({
                    selector: t,
                    value: [{
                        attributeName: "src",
                        attributeValue: r
                    }]
                }) : []
            };
            var n = function(e) {
                return e && e.__esModule ? e : {
                    default: e
                }
            }(r(1039))
        },
        7642: (e, t, r) => {
            Object.defineProperty(t, "__esModule", {
                value: !0
            }), t.default = function(e) {
                var t = e.selector,
                    r = e.value,
                    a = r.url,
                    o = r.target;
                return (0, n.default)({
                    selector: t,
                    value: [{
                        attributeName: "href",
                        attributeValue: a
                    }, {
                        attributeName: "target",
                        attributeValue: o
                    }]
                })
            };
            var n = function(e) {
                return e && e.__esModule ? e : {
                    default: e
                }
            }(r(1039))
        },
        6923: (e, t, r) => {
            Object.defineProperty(t, "__esModule", {
                value: !0
            }), t.default = function() {
                var e = arguments.length > 0 && void 0 !== arguments[0] ? arguments[0] : {},
                    t = e.selector,
                    r = e.value,
                    o = (0, a.qsa)(t),
                    i = (0, a.qsa)(r);
                if (!o.length || !i.length) return [];
                var u = o[0],
                    l = i[0],
                    d = u.cloneNode(!0);
                d.id = "";
                var c = (0, n.createAppliedModification)();
                return c.rollbacks.push((0, a.addChildNode)(l, d)), [c]
            };
            var n = r(3187),
                a = r(4476)
        },
        8265: (e, t, r) => {
            Object.defineProperty(t, "__esModule", {
                value: !0
            }), t.default = function(e) {
                var t = e.selector,
                    r = e.value,
                    o = (0, a.qsa)(t),
                    i = (0, a.qsa)(r);
                if (!o.length || !i.length) return [];
                var u = o[0],
                    l = i[0],
                    d = u.cloneNode(!0);
                d.id = "";
                var c = (0, n.createAppliedModification)();
                return c.rollbacks.push((0, a.addSiblingNode)(l, d)), [c]
            };
            var n = r(3187),
                a = r(4476)
        },
        8188: (e, t, r) => {
            Object.defineProperty(t, "__esModule", {
                value: !0
            }), t.default = function(e) {
                var t = e.selector,
                    r = e.value,
                    o = (0, a.qsa)(t),
                    i = (0, a.qsa)(r);
                if (!o.length || !i.length) return [];
                var u = o[0],
                    l = i[0],
                    d = u.cloneNode(!0);
                d.id = "";
                var c = (0, n.createAppliedModification)();
                return c.rollbacks.push((0, a.addSiblingNode)(l, d, !1)), [c]
            };
            var n = r(3187),
                a = r(4476)
        },
        4376: (e, t, r) => {
            Object.defineProperty(t, "__esModule", {
                value: !0
            }), t.default = function(e) {
                var t = e.selector,
                    r = e.value,
                    o = (0, a.qsa)(t),
                    i = (0, a.qsa)(r);
                if (!o.length || !i.length) return [];
                var u = o[0],
                    l = i[0];
                u.cloneNode(!0).id = "";
                var d = (0, n.createAppliedModification)();
                return d.rollbacks.push((0, a.moveChildNode)(u, l)), [d]
            };
            var n = r(3187),
                a = r(4476)
        },
        1088: (e, t, r) => {
            Object.defineProperty(t, "__esModule", {
                value: !0
            }), t.default = function(e) {
                var t = e.selector,
                    r = e.value,
                    o = (0, a.qsa)(t),
                    i = (0, a.qsa)(r);
                if (!o.length || !i.length) return [];
                var u = o[0],
                    l = i[0];
                u.cloneNode(!0).id = "";
                var d = (0, n.createAppliedModification)();
                return d.rollbacks.push((0, a.moveSiblingNode)(u, l)), [d]
            };
            var n = r(3187),
                a = r(4476)
        },
        8467: (e, t, r) => {
            Object.defineProperty(t, "__esModule", {
                value: !0
            }), t.default = function() {
                var e = arguments.length > 0 && void 0 !== arguments[0] ? arguments[0] : {},
                    t = e.selector,
                    r = e.value,
                    o = (0, a.qsa)(t),
                    i = (0, a.qsa)(r);
                if (!o.length || !i.length) return [];
                var u = o[0],
                    l = i[0];
                u.cloneNode(!0).id = "";
                var d = (0, n.createAppliedModification)();
                return d.rollbacks.push((0, a.moveSiblingNode)(u, l, !1)), [d]
            };
            var n = r(3187),
                a = r(4476)
        },
        1039: (e, t, r) => {
            Object.defineProperty(t, "__esModule", {
                value: !0
            });
            var n = function(e) {
                return e && e.__esModule ? e : {
                    default: e
                }
            }(r(5607));
            t.default = function(e) {
                var t = e.selector,
                    r = e.value;
                if (!t) return [];
                var i = (0, o.qsa)(t);
                return i.length ? [].concat(function(e) {
                    if (Array.isArray(e)) {
                        for (var t = 0, r = Array(e.length); t < e.length; t++) r[t] = e[t];
                        return r
                    }
                    return (0, n.default)(e)
                }(i)).map((function(e) {
                    var t = (0, a.createAppliedModification)();
                    return r.forEach((function(r) {
                        var n = r.action,
                            a = r.attributeName,
                            i = r.attributeValue;
                        "string" == typeof a && (null != e.getAttribute(a) && e.getAttribute(a) === i || t.rollbacks.push((0, o.setAttribute)(e, a, i, n)))
                    })), t
                })) : []
            };
            var a = r(3187),
                o = r(4476)
        },
        4819: (e, t, r) => {
            Object.defineProperty(t, "__esModule", {
                value: !0
            });
            var n = function(e) {
                return e && e.__esModule ? e : {
                    default: e
                }
            }(r(5607));
            t.default = function() {
                var e = arguments.length > 0 && void 0 !== arguments[0] ? arguments[0] : {},
                    t = e.selector,
                    r = e.value,
                    n = arguments.length > 1 && void 0 !== arguments[1] ? arguments[1] : [];
                if (!t) return [];
                var u = (0, o.qsa)(t);
                return u.length ? [].concat(i(u)).map((function(e) {
                    var t = n.find((function(e) {
                        return e.elements.children.every((function(e) {
                            return e.isConnected
                        }))
                    }));
                    if (t) return t;
                    var u = (0, a.createAppliedModification)(),
                        l = e.parentNode.cloneNode(!0),
                        d = [].concat(i(e.parentNode.childNodes)).indexOf(e),
                        c = l.childNodes[d],
                        f = (0, o.getDocument)().createElement("div");
                    f.innerHTML = r;
                    var s = [].concat(i(f.childNodes));
                    return s.forEach((function(e) {
                        return (0, o.addSiblingNode)(c, e)
                    })), (0, o.removeNode)(c), (0, o.isEqualNode)(u.savedState, l) ? (u.elements.children.forEach((function(t) {
                        return (0, o.addSiblingNode)(e, t, !1)
                    })), (0, o.removeNode)(e)) : (u.rollbacks = [].concat(i(s.map((function(t) {
                        return (0, o.addSiblingNode)(e, t, !1)
                    }))), [(0, o.removeNode)(e)]), u.target = e, u.elements.children = s, u.savedState = e.cloneNode(!0)), u
                })) : []
            };
            var a = r(3187),
                o = r(4476);

            function i(e) {
                if (Array.isArray(e)) {
                    for (var t = 0, r = Array(e.length); t < e.length; t++) r[t] = e[t];
                    return r
                }
                return (0, n.default)(e)
            }
        },
        1030: (e, t, r) => {
            Object.defineProperty(t, "__esModule", {
                value: !0
            });
            var n = function(e) {
                    return e && e.__esModule ? e : {
                        default: e
                    }
                }(r(5607)),
                a = function(e, t) {
                    if (Array.isArray(e)) return e;
                    if (Symbol.iterator in Object(e)) return function(e, t) {
                        var r = [],
                            n = !0,
                            a = !1,
                            o = void 0;
                        try {
                            for (var i, u = e[Symbol.iterator](); !(n = (i = u.next()).done) && (r.push(i.value), !t || r.length !== t); n = !0);
                        } catch (e) {
                            a = !0, o = e
                        } finally {
                            try {
                                !n && u.return && u.return()
                            } finally {
                                if (a) throw o
                            }
                        }
                        return r
                    }(e, t);
                    throw new TypeError("Invalid attempt to destructure non-iterable instance")
                };
            t.default = function(e) {
                var t = e.selector,
                    r = e.value;
                if (!t) return [];
                var u = (0, i.qsa)(t);
                return u.length ? [].concat(function(e) {
                    if (Array.isArray(e)) {
                        for (var t = 0, r = Array(e.length); t < e.length; t++) r[t] = e[t];
                        return r
                    }
                    return (0, n.default)(e)
                }(u)).map((function(e) {
                    var t = (0, o.createAppliedModification)(),
                        n = e.getAttribute("srcset");
                    switch (r.type) {
                        case "picture":
                            r.values.forEach((function(r) {
                                var o = r.attribute,
                                    u = r.srcset,
                                    l = function(e) {
                                        if (e.includes(" & ")) {
                                            var t = e.split(" & "),
                                                r = a(t, 2);
                                            return 'source[type="' + r[0] + '"][media="' + r[1] + '"]'
                                        }
                                        if (e.startsWith("image/")) return 'source[type="' + e + '"]:not([media])';
                                        if ("" === e) return "source:not([media]):not([type])";
                                        return 'source[media="' + e + '"]:not([type])'
                                    }(o),
                                    d = e.parentElement.querySelector(l);
                                (n = d && d.getAttribute("srcset")) && n !== u && t.rollbacks.push((0, i.setAttribute)(d, "srcset", u), (0, i.setAttribute)(d, "data-ab-original-srcset", n))
                            }));
                            break;
                        case "img":
                            null != n && n === r.srcset || t.rollbacks.push((0, i.setAttribute)(e, "srcset", r.srcset), (0, i.setAttribute)(e, "data-ab-original-srcset", n))
                    }
                    return t
                })) : []
            };
            var o = r(3187),
                i = r(4476)
        },
        1210: (e, t, r) => {
            Object.defineProperty(t, "__esModule", {
                value: !0
            });
            var n = Object.assign || function(e) {
                    for (var t = 1; t < arguments.length; t++) {
                        var r = arguments[t];
                        for (var n in r) Object.prototype.hasOwnProperty.call(r, n) && (e[n] = r[n])
                    }
                    return e
                },
                a = function(e, t) {
                    if (Array.isArray(e)) return e;
                    if (Symbol.iterator in Object(e)) return function(e, t) {
                        var r = [],
                            n = !0,
                            a = !1,
                            o = void 0;
                        try {
                            for (var i, u = e[Symbol.iterator](); !(n = (i = u.next()).done) && (r.push(i.value), !t || r.length !== t); n = !0);
                        } catch (e) {
                            a = !0, o = e
                        } finally {
                            try {
                                !n && u.return && u.return()
                            } finally {
                                if (a) throw o
                            }
                        }
                        return r
                    }(e, t);
                    throw new TypeError("Invalid attempt to destructure non-iterable instance")
                };
            t.default = function(e, t) {
                if (!e.selector || !e.value) return [];
                var r = '<style type="text/css">' + i(e.selector, e.value) + "</style>";
                return (0, o.default)(n({}, e, {
                    selector: "head",
                    value: r
                }), t)
            };
            var o = function(e) {
                return e && e.__esModule ? e : {
                    default: e
                }
            }(r(1426));
            var i = function(e, t) {
                return e + " {" + Object.entries(t).reduce((function(e, t) {
                    var r = a(t, 2),
                        n = r[0],
                        o = r[1];
                    return o && o.length && "!important" !== o ? "" + e + n + ":" + o + ";" : e
                }), "") + "}"
            }
        },
        3917: (e, t, r) => {
            Object.defineProperty(t, "__esModule", {
                value: !0
            });
            var n = function(e) {
                return e && e.__esModule ? e : {
                    default: e
                }
            }(r(5607));
            t.default = function() {
                var e = arguments.length > 0 && void 0 !== arguments[0] ? arguments[0] : {},
                    t = e.selector,
                    r = e.value,
                    n = arguments.length > 1 && void 0 !== arguments[1] ? arguments[1] : [];
                if (!t) return [];
                var u = (0, o.qsa)(t);
                return u.length ? [].concat(i(u)).map((function(e) {
                    var t, u = n.find((function(e) {
                        return e.elements.children.every((function(e) {
                            return e.isConnected
                        }))
                    }));
                    if (u) return u;
                    var l = (0, a.createAppliedModification)(),
                        d = [].concat(i(e.childNodes));
                    if (l.rollbacks = [], d.forEach((function(e) {
                            if (e.nodeType === Node.TEXT_NODE || e.style && "none" !== e.style.display) {
                                var t = (0, o.removeNode)(e);
                                t && l.rollbacks.push(t)
                            }
                        })), !l.elements || !l.elements.children) {
                        var c = (0, o.getDocument)().createElement("div");
                        c.innerHTML = r, l.elements = {
                            children: [].concat(i(c.childNodes))
                        }
                    }
                    var f = l.elements.children.map((function(t) {
                        return (0, o.addChildNode)(e, t)
                    }));
                    return (t = l.rollbacks).push.apply(t, i(f)), l
                })) : []
            };
            var a = r(3187),
                o = r(4476);

            function i(e) {
                if (Array.isArray(e)) {
                    for (var t = 0, r = Array(e.length); t < e.length; t++) r[t] = e[t];
                    return r
                }
                return (0, n.default)(e)
            }
        },
        4390: (e, t, r) => {
            Object.defineProperty(t, "__esModule", {
                value: !0
            }), t.default = function() {
                var e = (arguments.length > 0 && void 0 !== arguments[0] ? arguments[0] : {}).selector;
                return (0, n.default)({
                    selector: e,
                    value: {
                        display: "none !important"
                    }
                })
            };
            var n = function(e) {
                return e && e.__esModule ? e : {
                    default: e
                }
            }(r(1210))
        },
        4925: (e, t, r) => {
            Object.defineProperty(t, "__esModule", {
                value: !0
            }), t.default = function() {
                var e = (arguments.length > 0 && void 0 !== arguments[0] ? arguments[0] : {}).selector;
                return (0, n.default)({
                    selector: e + " *",
                    value: {
                        visibility: "hidden"
                    }
                })
            };
            var n = function(e) {
                return e && e.__esModule ? e : {
                    default: e
                }
            }(r(1210))
        },
        962: (e, t, r) => {
            Object.defineProperty(t, "__esModule", {
                value: !0
            });
            var n = function(e) {
                return e && e.__esModule ? e : {
                    default: e
                }
            }(r(5607));
            t.default = function(e) {
                var t = e.selector,
                    r = e.value;
                if (!t) return [];
                var n = (0, o.qsa)(t);
                if (!n.length) return [];
                var u = [].concat(i(n)).map((function(e) {
                    var t = (0, a.createAppliedModification)(),
                        n = [].concat(i(e.children)).filter((function(e) {
                            return "SCRIPT" !== e.tagName
                        })),
                        u = [].concat(i(e.children)),
                        l = u.length;
                    return r.length !== n.length || r.filter((function(e) {
                        return e > l - 1
                    })).length > 0 || u.some((function(e) {
                        return (0, o.getData)(e, "abTastySorted")
                    })) || (u.forEach((function(t) {
                        e.removeChild(t)
                    })), r.forEach((function(t) {
                        e.appendChild(u[t]), (0, o.setData)(u[t], "abTastySorted", 1)
                    })), t.rollbacks.push((function() {
                        arguments.length > 0 && void 0 !== arguments[0] && !arguments[0] && u.some((function(e) {
                            return (0, o.getData)(e, "abTastySorted")
                        })) || u.forEach((function(e) {
                            e.removeAttribute("data-ab-tasty-sorted");
                            var t = e.parentNode;
                            t && (t.removeChild(e), t.appendChild(e))
                        }))
                    }))), t
                }));
                return u
            };
            var a = r(3187),
                o = r(4476);

            function i(e) {
                if (Array.isArray(e)) {
                    for (var t = 0, r = Array(e.length); t < e.length; t++) r[t] = e[t];
                    return r
                }
                return (0, n.default)(e)
            }
        }
    }
]);
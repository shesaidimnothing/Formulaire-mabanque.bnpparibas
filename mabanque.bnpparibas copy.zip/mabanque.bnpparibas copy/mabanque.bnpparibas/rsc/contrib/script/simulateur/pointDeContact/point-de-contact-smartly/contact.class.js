var Contact = function() {
    var _this = this;

    if (sessionStorage.contact) {
        try {
            this._parametrage = JSON.parse(sessionStorage.contact);
        } catch (e) {
            this._parametrage = {}
        }
    } else
        this._parametrage = {};

    var site = (this.site() === 'hellobank') ? 'hb' : this.site()

    this._step = [{
            name: "button",
            tools: 'nextoutils_point-de-contact-button_' + site,
            function: function() {
                if (window.initBtn) window.initBtn()

                if (window.MyObjContact.isAuth()) {
                    accestoken = window.MyObjContact.accessToken()
                }
            }
        },
        {
            name: "chatbot",
            tools: "nextoutils_point-de-contact-chatbot",
            function: function() {
                $("#nextoutils_pointDeContact_chatbot").show();
                if (window.openChatbot) openChatbot();
            }
        },
        {
            name: "chat",
            tools: "nextoutils_point-de-contact-chat",
            function: function() {}
        },
        {
            name: "sondage",
            tools: "nextoutils_point-de-contact-sondage",
            function: function() {
                $('#nextoutils_questionnaire_json_sondage').remove()
                if (window.openSondage) window.openSondage()
            }
        }
    ];

    if (this.isProd())
        this._apiMasterBotServer = "https://apis.smartly.ai";

    else if (window.ENVIRONNEMENT == 'QUALIF' && this.site() == 'part')
        this._apiMasterBotServer = "https://apis.smartly.ai";

    else
        this._apiMasterBotServer = "https://apis.smartly.ai";

    this._apiMasterBot = {
        dialog: {
            path: "/api/dialog/",
            method: "POST"
        },
        authorizeBNPAPI: {
            url: "/oidc/authorize",
            method: "GET",
            type: "html"
        },
        getAuthorize: {
            url: "/rsc/contrib/script/simulateur/pointDeContact/authorize.html",
            method: "GET",
            type: "html"
        },
    }

    this._accessTokenMasterBot = {
        "PROD": {
            "mb": {
                "token": "eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJ1c2VyX2lkIjoiNWFhYThjMTBlZGViZTM1NjdhNjVlNDlhIiwic2tpbGxfaWQiOiJhcGlfdG9rZW4iLCJpYXQiOjE1MzQ5NDgzODV9.iIDYHeJkobYv9e7CFuJEp10ugDlwdtanb7SnvpQvge8",
                "skill": {
                    "part": "5d136d45fe5343001dab0d0d",
                    "bpf": "5d3cddbef4106c86a9fd9ac1",
                    "pro": "5e1c43d592979bf35adb3fa0"
                }
            },
            "hb": {
                "token": "eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJ1c2VyX2lkIjoiNWFhZmNmM2Q4ZWNhNWI0NTgxYzFiMmViIiwic2tpbGxfaWQiOiJhcGlfdG9rZW4iLCJpYXQiOjE1MjQ4MzkwNDR9.X4_XPzeBWRsIR6mheYDxmg97goonHtPv773jT6t8IzY",
                // "token": "eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJ1c2VyX2lkIjoiNWRjNTZlNDk2ZDM3YjY4YjA5ODBmYzM3Iiwic2tpbGxfaWQiOiJhcGlfdG9rZW4iLCJpYXQiOjE1ODM1OTIxNDF9.2qtLqRh29z6LBV2nHxH1D8lMLE8PEn5c8cvsQyduqYQ",

                "skill": {
                    "hellobank": "5ce7acc7b192362bd69de730",
                    "hbpro": "60d5f19ac790c657a4105255"
                }
            }
        },
        "PREVIEW": {
            "mb": {
                "token": "eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJ1c2VyX2lkIjoiNWRjNTZlNDk2ZDM3YjY4YjA5ODBmYzM3Iiwic2tpbGxfaWQiOiJhcGlfdG9rZW4iLCJpYXQiOjE1ODM1OTIxNDF9.2qtLqRh29z6LBV2nHxH1D8lMLE8PEn5c8cvsQyduqYQ",
                "skill": {
                    "part": "5f96ea2932c6b02b05290654",
                    "bpf": "5eaac7303c1be495422d4197",
                    "pro": "60d04fe0db774bce9bc274bd"
                }
            },
            "hb": {
                "token": "eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJ1c2VyX2lkIjoiNWRjNTZlNDk2ZDM3YjY4YjA5ODBmYzM3Iiwic2tpbGxfaWQiOiJhcGlfdG9rZW4iLCJpYXQiOjE1ODM1OTIxNDF9.2qtLqRh29z6LBV2nHxH1D8lMLE8PEn5c8cvsQyduqYQ",
                "skill": {
                    "hellobank": "6385c9cf09f69d43fcc66682",
                    "hbpro": "60c708ee7025958d36d1518f"
                }
            }
        },
        "QUALIF": {
            "mb": {
                "token": "eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJ1c2VyX2lkIjoiNWRjNTZlNDk2ZDM3YjY4YjA5ODBmYzM3Iiwic2tpbGxfaWQiOiJhcGlfdG9rZW4iLCJpYXQiOjE1ODM1OTIxNDF9.2qtLqRh29z6LBV2nHxH1D8lMLE8PEn5c8cvsQyduqYQ",
                "skill": {
                    "part": "5f96ea2932c6b02b05290654",
                    "bpf": "5eaac7303c1be495422d4197",
                    "pro": "60d04fe0db774bce9bc274bd"
                }
            },
            "hb": {
                "token": "eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJ1c2VyX2lkIjoiNWRjNTZlNDk2ZDM3YjY4YjA5ODBmYzM3Iiwic2tpbGxfaWQiOiJhcGlfdG9rZW4iLCJpYXQiOjE1ODM1OTIxNDF9.2qtLqRh29z6LBV2nHxH1D8lMLE8PEn5c8cvsQyduqYQ",
                "skill": {
                    "hellobank": "6385c9cf09f69d43fcc66682",
                    "hbpro": "60c708ee7025958d36d1518f"
                }
            }
        },
        "LOCAL": {
            "mb": {
                "token": "eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJ1c2VyX2lkIjoiNWRjNTZlNDk2ZDM3YjY4YjA5ODBmYzM3Iiwic2tpbGxfaWQiOiJhcGlfdG9rZW4iLCJpYXQiOjE1ODM1OTIxNDF9.2qtLqRh29z6LBV2nHxH1D8lMLE8PEn5c8cvsQyduqYQ",
                "skill": {
                    "part": "618a4cd9b01c2c1bd9428981",
                    "bpf": "5eaac7303c1be495422d4197",
                    "pro": "612f79339311a2f2c69193ac"
                }
            },
            "hb": {
                "token": "eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJ1c2VyX2lkIjoiNWRjNTZlNDk2ZDM3YjY4YjA5ODBmYzM3Iiwic2tpbGxfaWQiOiJhcGlfdG9rZW4iLCJpYXQiOjE1ODM1OTIxNDF9.2qtLqRh29z6LBV2nHxH1D8lMLE8PEn5c8cvsQyduqYQ",
                "skill": {
                    "hellobank": "613f64e772783f8765236dfc",
                    "hbpro": "60c708ee7025958d36d1518f"
                }
            }
        }
    }

    if (this.isProd())
        this._apiBotTransactionnelServer = "//web-bnpp.cbw.worldline-solutions.com";
    //this._apiBotTransactionnelServer = "//web.bnpp-cbw.as8677.net";
    else
        this._apiBotTransactionnelServer = "//web-eacc74-bnpp.cbw-qlf.worldline-solutions.com";
    if (this.isProd())
        this._apiBotTransactionnel = {
            startConversation: {
                url: "//web-bnpp.cbw.worldline-solutions.com/exchange_server/api/authent/startConversation"
            },
            getAuthorize: {
                path: "/rsc/contrib/script/simulateur/pointDeContact/authorize.html"
            },
            message: {
                path: "/exchange_server/api/messages/",
                method: "POST",
                stringify: true
            }
        }
    else
        this._apiBotTransactionnel = {
            startConversation: {
                url: "//web-eacc74-bnpp.cbw-qlf.worldline-solutions.com/exchange_server/api/authent/startConversation"
            },
            getAuthorize: {
                path: "/rsc/contrib/script/simulateur/pointDeContact/authorize.html"
            },
            message: {
                path: "/exchange_server/api/messages/",
                method: "POST",
                stringify: true
            }
        }

    this._oidc = {
        BotTransactionnel: {
            interval: {
                interval: 500,
                max: 10000
            },
            client_id: "",
            expire: 9 * 60
        }
    }

    if (this.isProd())
        this._oidc.BotTransactionnel.client_id = "";
    else
        this._oidc.BotTransactionnel.client_id = "";

    // this._sgi;
    this._sgi = (window.ENVIRONNEMENT && window.ENVIRONNEMENT === "LOCAL") ? "localhost" : undefined; // Problème pour le dev en local
    try {
        var infoClt = JSON.parse(sessionStorage.info_client);
        var compte = infoClt.data.contrat.comptePrincipal;
        if (!compte)
            compte = infoClt.data.contrat.comptes[0];
        this._sgi = compte.identifiantSGIRattache;
    } catch (e) {}

    this.parametrage("sgi", this._sgi, true);

    // Ajout historique pour le conseiller
    if (this.parametrage("messageConseiller")) {
        this._messageConseiller = this.parametrage("messageConseiller");
    }

    // this.init();
}

Contact.prototype.site = function() {
    var site;
    var host = location.host

    if (window.GlobalSite && window.GlobalSite.BY_SITE_VARS) {
        site = (typeof GlobalSite.BY_SITE_VARS.typeClient === 'string' && GlobalSite.BY_SITE_VARS.typeClient.toLowerCase() === 'hb') ? 'hellobank' : GlobalSite.BY_SITE_VARS.typeClient.toLowerCase();
    } else if (/canalnet-part/gim.test(host) || /mabanque./gim.test(host)) {
        site = 'part'
    } else if (/canalnet-pro/gim.test(host) || /mabanquepro./gim.test(host)) {
        site = 'pro'
    } else if (/canalnet-bpf/gim.test(host) || /mabanqueprivee./gim.test(host)) {
        site = 'bpf'
    } else if (/hellobank-part/gim.test(host) || /hellobank./gim.test(host)) {
        site = 'hellobank'
    } else if (/hellobank-pro/gim.test(host) || /hellobank-pro/gim.test(location.host)) {
        site = 'hbpro'
    } else site = window.sfSiteId

    return site;
}

Contact.prototype.client = function(callback, callws) {
    var dfd = jQuery.Deferred();
    var _this = this;
    var client = {}

    if (window.OApp && (callws || !sessionStorage.info_client)) {
        OApp.get("/serviceinfosclient-wspl/rpc/InfosClient", function(data) {
            dfd.resolve(data)
            if (data && data.message == "OK" && data.data && data.data.statut !== 115)
                sessionStorage.info_client = JSON.stringify(data);
            if (!callback) _this.client(callback, false)
        });
    } else dfd.resolve(null)

    try {
        tmp = JSON.parse(sessionStorage.info_client)
        client = {
            civilite: tmp.data.client.civilite,
            ikpi: tmp.data.client.ikpiPersonne,
            nom: tmp.data.client.nomComplet,
            prenom: tmp.data.client.prenom
        }

        if (callback) callback(client);
    } catch (e) {
        if (callback) callback(client);
    }
    if (!callback) return dfd.promise()
}

Contact.prototype.getCookie = function(cookiename) {
    var cookiestring = RegExp("" + cookiename + "[^;]+").exec(document.cookie);
    return decodeURIComponent(!!cookiestring ? cookiestring.toString().replace(/^[^=]+./, "") : "");
}

Contact.prototype.parametrage = function(key, value, reset) {
    var parametrage = this._parametrage || {}
    if (!value && !reset) return parametrage[key]

    if (reset) {
        delete parametrage[key]
    } else {
        if (key !== 'sgi') parametrage[key] = value
    }

    this._parametrage = parametrage
    sessionStorage.contact = JSON.stringify(this._parametrage)
}

Contact.prototype.isProd = function() {
    return (window.ENVIRONNEMENT && (ENVIRONNEMENT == "PROD" || ENVIRONNEMENT == "PREVIEW" || ENVIRONNEMENT == "MACHINE"))
}

Contact.prototype.isConnected = function() {
    var info_client = null
    try {
        if (sessionStorage.info_client && JSON.parse(sessionStorage.info_client).message !== "user not connected") info_client = true
    } catch (e) {}

    return !!((window.ENVIRONNEMENT && window.ENVIRONNEMENT == "LOCAL") || this._sgi || info_client)
}

Contact.prototype.isAuth = function() {
    try {
        if (JSON.parse(sessionStorage.info_client).message === "OK") return true;
        // return (JSON.parse(sessionStorage.info_client).message === "Ok") ? true : false;
    } catch (e) {
        return false
    }
}

Contact.prototype.randomString = function(length) {
    var text = "";
    var possible = "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789";
    for (var i = 0; i < length; i++) {
        text += possible.charAt(Math.floor(Math.random() * possible.length));
    }
    return text;
}

Contact.prototype.getUrlParameter = function getUrlParameter(sParam) {
    var sPageURL = window.location.search.substring(1),
        sURLVariables = sPageURL.split('&'),
        sParameterName,
        i;

    for (i = 0; i < sURLVariables.length; i++) {
        sParameterName = sURLVariables[i].split('=');

        if (sParameterName[0] === sParam) {
            return sParameterName[1] === undefined ? true : decodeURIComponent(sParameterName[1]);
        }
    }
};

Contact.prototype.getUrl = function(url, api, params) {
    var url = api.url ? api.url : url + api.path;
    if (params) {
        var tmpUrl = url;
        for (var param in params)
            url = url.replace(param, params[param]);
        if (tmpUrl == url) {
            var bEt = url.indexOf("?") >= 0;
            for (var param in params) {
                url += (bEt ? "&" : "?") + param + "=" + params[param];
                bEt = true;
            }
        }
    }

    return url;
}

Contact.prototype.accesstokenMasterBot = function() {
    if (!this.parametrage("accesstokenMasterBot")) {
        var tmp;
        if (window.ENVIRONNEMENT && this._accessTokenMasterBot[window.ENVIRONNEMENT])
            tmp = this._accessTokenMasterBot[window.ENVIRONNEMENT];
        else
            tmp = this._accessTokenMasterBot["DEFAULT"];

        this.parametrage("accesstokenMasterBot", tmp[this.site() == "hellobank" ? "hb" : "mb"]["token"]);
    }

    return this.parametrage("accesstokenMasterBot");
}

Contact.prototype.accesstokenBotTransactionnel = function(value) {
    if (value === undefined) {
        if (this.parametrage("accesstokenBotTransactionnel") && this.parametrage("expireBotTransactionnel") < (new Date()).getTime() / 1000)
            this.parametrage("accesstokenBotTransactionnel", null);
        return this.parametrage("accesstokenBotTransactionnel");
    } else {
        this.parametrage("accesstokenBotTransactionnel", value);
        this.parametrage("expireBotTransactionnel", (new Date()).getTime() / 1000 + this._oidc.BotTransactionnel.expire);
    }
}

Contact.prototype.skillId = function() {
    if (!this.parametrage("skillId")) {
        var tmp;
        if (window.ENVIRONNEMENT && this._accessTokenMasterBot[window.ENVIRONNEMENT])
            tmp = this._accessTokenMasterBot[window.ENVIRONNEMENT];
        else
            tmp = this._accessTokenMasterBot["DEFAULT"];
        var skill = tmp[this.site() == "hellobank" ? "hb" : "mb"]["skill"];
        this.parametrage("skillId", skill[this.site()]);
    }
    return this.parametrage("skillId");
}

Contact.prototype.callapiPromiseMasterBot = function(api, data, auth) {
    var settings = {
        url: this.getUrl(this._apiMasterBotServer, api),
        type: api.method,
        cache: api.cache || false
    };
    if (data) settings.data = api.stringify ? JSON.stringify(data) : data;
    if (auth)
        settings.headers = {
            Authorization: "Bearer " + this.accesstokenMasterBot()
        };
    //settings.dataType = api.type || "json";
    //settings.contentType = "application/json;charset=UTF-8";

    return $.ajax(settings);
};

Contact.prototype.callapiMasterBot = function(api, data, auth, callback) {
    this.callapiPromiseMasterBot(api, data, auth).done(callback).fail(function(jqXHR, textStatus) {
        callback(null, textStatus, jqXHR);
    });
};

Contact.prototype.dialog = function(data, callback) {
    data.platform = "api";
    data.lang = "fr-fr";
    this.callapiMasterBot(this._apiMasterBot.dialog, data, true, function(data) {
        if (callback) callback(data);
    });
}

Contact.prototype.callapiPromiseBotTransactionnel = function(api, data, auth) {
    var settings = {
        url: this.getUrl(this._apiBotTransactionnelServer, api),
        type: api.method,
        cache: api.cache || false,
        dataType: "JSON"
    };
    if (data) settings.data = api.stringify ? JSON.stringify(data) : data;
    if (auth)
        settings.headers = {
            Authorization: "Bearer " + this.accesstokenBotTransactionnel()
        };
    //settings.dataType = api.type || "json";
    settings.contentType = "application/json;charset=UTF-8";

    return $.ajax(settings);
};

Contact.prototype.callapiBotTransactionnel = function(api, data, auth, callback) {
    this.callapiPromiseBotTransactionnel(api, data, auth).done(callback).fail(function(jqXHR, textStatus) {
        callback(null, textStatus, jqXHR);
    });
};

Contact.prototype.reset = function() {
    this.Step(0);

    for (var key in this._parametrage) {
        if (key !== 'sgi') {
            this.parametrage(key, null, true);
        }
    }
    this.init();
}

Contact.prototype.initBotTransactionnel = function(callback) {
    if (this.accesstokenBotTransactionnel() || window.ENVIRONNEMENT == 'LOCAL') {
        var state = (window.ENVIRONNEMENT === 'LOCAL') ? 'local' : undefined
        callback(state);
    } else {
        var _this = this;
        var param = {}
        param.redirect_jwe = encodeURI("https://" + document.location.host + _this._apiBotTransactionnel.getAuthorize.path);

        if ($("#oidc_bottransactionnel").length > 0)
            $("#oidc_bottransactionnel").remove();
        if ($("#oidc_bottransactionnel").length == 0)
            $("body").append($("<iframe id='oidc_bottransactionnel' class='hidden'>"));
        $("#oidc_bottransactionnel").on("load", function() {
            var tokenInteval = JSON.parse(JSON.stringify(_this._oidc.BotTransactionnel.interval));
            tokenInteval.cpt = 0;
            tokenInteval.token = setInterval(function() {
                tokenInteval.cpt++;
                try {
                    if ($("#oidc_bottransactionnel")[0].contentWindow.document.location.search) {
                        clearInterval(tokenInteval.token);
                        var params = $("#oidc_bottransactionnel")[0].contentWindow.document.location.search.substring(1).split("&");
                        var access_token;
                        var expiration_date;
                        for (var cptI = 0; cptI < params.length; cptI++) {
                            var param = params[cptI].split("=");
                            if (param[0] == "jwe")
                                access_token = decodeURIComponent(param[1]);
                            if (param[0] == "expiration_date")
                                expiration_date = param[1];
                        }
                        _this.accesstokenBotTransactionnel(access_token);

                        callback();
                    }
                } catch (e) {
                    console.log(e)
                    clearInterval(tokenInteval.token)
                    callback('error');
                }
                if (tokenInteval.cpt * tokenInteval.interval > tokenInteval.max && tokenInteval.token) {
                    clearInterval(tokenInteval.token);
                    callback('timeout');
                }
            }, tokenInteval.interval);
        });
        $("#oidc_bottransactionnel").attr('src', _this.getUrl("", _this._apiBotTransactionnel.startConversation, param));
    }
}

Contact.prototype.BOTInit = function(callback) {
    data = {
        'event_name': "NEW_DIALOG_SESSION",
        'user_id': this.userID(),
        'skill_id': this.skillId(),
        'user_data': {
            "dateUser": {
                "timezone": new Date().getTimezoneOffset()
            },
            "geolocation": this.geolocation,
            "site": this.site(),
            "env": window.ENVIRONNEMENT,
            "auth": this.isConnected()
        },
        'input': ""
    };

    try {
        data.user_data.client = {
            civilite: JSON.parse(sessionStorage.info_client).data.client.civilite,
            nom: JSON.parse(sessionStorage.info_client).data.client.nomComplet
        }
    } catch (e) {}
    data.user_data.iAdvize = true;
    var _this = this;
    this.dialog(data, function(data) {
        if (data.payload) data.payload.origin = "smartly";
        this.messages(true, "bot", data.answer, data.rich_text, data.payload);
        if (this.Step() === 0) this.nextStep();
        this.newMessageAdvisor(data.answer);
        if (callback) callback(data);
    }.bind(this));
}

Contact.prototype.messageUser = function(payload) {
    var data = {};
    if (typeof payload === "string") {
        return payload
            .replace(/&nbsp;/gim, "")
            .replace(/\n/gim, "")
            .replace(/\r/gim, "")
            .trim();
    } else if (payload.reply) {
        return payload;
    } else {
        return data.message;
    }
}

// Message transact
// Contact.prototype.BotTransactionnelGetSolde = function (token, message, callback) {
//     var _this = this;
//     var data = {
//         type: "TEXT",
//         text: message,
//         platformOverride: "NATIVE",
//         locale: "fr",
//         pageAccesToken: token
//     };
//     //data.sessionId="em5p-f5fs9ff1-at8meg9sgh8g5fae8jds";
//     this.initBotTransactionnel(function () {
//         _this.callapiBotTransactionnel(_this._apiBotTransactionnel.message, data, true, function (data) {
//             if (data)
//                 MyObjContact.parametrage("infoTransac", {
//                     userId: data[0].userId,
//                     sessionId: data[0].sessionId,
//                     pageAccesToken: token
//                 });
//             if (callback) callback(data);
//         });
//     });
// }
// Contact.prototype.BotTransactionnelGetSoldePayload = function (payload, callback) {
//     var _this = this;
//     var data = {
//         type: "QUICK_REPLY",
//         payload: payload,
//         platformOverride: "NATIVE",
//         locale: "FRENCH",
//         userId: MyObjContact.parametrage("infoTransac").userId,
//         sessionId: MyObjContact.parametrage("infoTransac").sessionId,
//         pageAccesToken: MyObjContact.parametrage("infoTransac").pageAccesToken,
//     };
//     this.initBotTransactionnel(function () {
//         _this.callapiBotTransactionnel(_this._apiBotTransactionnel.message, data, true, function (dataAtos) {
//             _this.MessageAtosTraitement(dataAtos);
//             if (callback) callback(data);
//         });
//     });
// }

Contact.prototype.BotTransactionnelGetRDVPayload = function(payload, callback) {
    var _this = this;
    var data = {
        type: "TEXT",
        text: payload,
        platformOverride: "NATIVE",
        locale: "FRENCH",
        userId: MyObjContact.parametrage("infoTransac").userId,
        sessionId: MyObjContact.parametrage("infoTransac").sessionId,
        pageAccesToken: MyObjContact.parametrage("infoTransac").pageAccesToken,
    };
    this.initBotTransactionnel(function() {
        _this.callapiBotTransactionnel(_this._apiBotTransactionnel.message, data, true, function(dataAtos) {
            _this.MessageAtosTraitement(dataAtos);
            if (callback) callback(data);
        });
    });
}

Contact.prototype.traitement = function(data, cb) {
    if (!data) {
        cb(data);
        return;
    }

    if (typeof data.payload.adobeTracking === "object") {
        for (var i = 0; i < data.payload.adobeTracking.length; i += 1) {
            _satellite.track(data.payload.adobeTracking[i]);
        }
    } else if (window._satellite && data.payload && data.payload.adobeTracking) _satellite.track(data.payload.adobeTracking);


    if (data.payload.hiddenMessage) {
        delete data.payload.origin;
        this.parametrage("origin", "transactionnel");

        this.BOTMessageTransactionel(data.payload, "test", function(dataAtos) {
            if (cb) cb(dataAtos);
        });
    } else {
        this.parametrage("info_maps", data.payload.localisation)

        if (!data.payload.conseiller) {
            if (data.payload.reset_position) this.parametrage("coords", null, true);
            this.messages(false, "bot", data.answer, data.rich_text, data.payload);


            if (data.payload.redirectConnect) { ///// ACTION APRES REDIRECTION
                if (!data.payload.transacAuth) {
                    this.parametrage("demandeChat", true);
                    if (window._satellite) _satellite.track("Chatbot - redirConseil");
                }
                this.parametrage("transaction", data.payload.transacAuth);
                setTimeout(function() {
                    window.location = window.location.origin += data.payload.redirectConnect;
                }, 3000);
            } else if (data.payload.path || data.payload.localisation) {
                if (data.payload.path && data.payload.path !== location.pathname) {
                    this.parametrage("info_maps", {
                        count: data.payload.count,
                        localisation: data.payload.localisation
                    });
                    setTimeout(function() {
                        window.location = window.location.origin += data.payload.path;
                    }, 3000);
                }
            }
            if (cb) cb(data);
        } else if (data.payload.conseiller) {
            this.messages(false, "bot", data.answer, data.rich_text, data.payload);
            if (window._satellite) _satellite.track("Chatbot - redirConseil");
            setTimeout(function() {
                if (data.payload.chatRegle) this.parametrage('chatRegle', data.payload.chatRegle)
                var regle = (this.parametrage('chatRegle')) ? this.parametrage('chatRegle') : '?escalationChatbot'
                if (this.Step() === 1) this.nextStep();

                if (window.iAdvize && window.iAdvize.navigate && window.iAdvize.navigate(regle));
            }.bind(this), 3000);
        }
    }
}

/// Enlever _ preciser promise
Contact.prototype.login_idz_to_uid = function(id) {
    return $.ajax({
        "url": "https://w-services.bnpparibas.net/services/apiDF/public/api/iAdvize/get_login_or_id",
        "method": "POST",
        "data": {
            "idIadvize": id
        }
    });
}

Contact.prototype.getUidAdvisor = function(id) {
    return $.ajax({
        "url": "https://w-services.bnpparibas.net/services/apiDF/public/api/iAdvize/get_login_or_id",
        "method": "POST",
        "data": {
            "idIadvize": id
        }
    });
}

Contact.prototype.BOTMessageTransactionel = function(payload, message, cb) {
    this.BotTransactionnelGetSolde(payload.hiddenMessage.pageAccesToken, message, function(dataAtos) {
        if (dataAtos)
            this.MessageAtosTraitement(dataAtos);
        else
            this.MessageAtosTraitement([{
                type: 'TEXT',
                data: {
                    subtype: 'STOP',
                    Error: 'une erreur s\'est produite lors du chargement des informations.'
                }
            }]);
        if (cb) cb();
    }.bind(this));
}

Contact.prototype.MessageAtosTraitement = function(message) {
    message.forEach(function(element) {
        switch (element.type) {
            case 'TEXT':
                switch (element.data.subtype) {
                    case 'STOP':
                        if (window._satellite) _satellite.track('Chatbot - ctaMenu');
                        this.BOTMessage("Revenir au menu principal", function(data) {
                            if (element.data.Error)
                                this.messages(true, "bot", element.data.Error, [], data.payload);
                        }.bind(this), 'Revenir_au_menu_principal');
                        break;
                    case 'TRANSACTIONS_FUTURES':
                        if (window._satellite) _satellite.track('Chatbot - opeAVenir');
                        this.messages(false, "bot", element.text, [], {
                            subtype: element.data.subtype,
                            transactions: JSON.parse(element.data.futureTransactions)
                        });
                        break;
                    case 'TRANSACTIONS_PASSEES':
                        if (window._satellite) _satellite.track('Chatbot - dernieresOpe');
                        this.messages(false, "bot", element.text, [], {
                            subtype: element.data.subtype,
                            transactions: JSON.parse(element.data.oldTransactions)
                        });
                        break;
                    default:
                        this.messages(false, "bot", element.text, [], {
                            subtype: element.data.subtype
                        });
                }
                break;
            case 'QUICK_REPLY':
                var replys = {
                    'subtype': element.data.subtype,
                    'text': element.text,
                    'button': [],
                };

                switch (element.data.subtype) {
                    case 'DOUBLE_LINE_ACCOUNTS':
                        if (window._satellite) _satellite.track('Chatbot - SoldeMiddle');
                        element.quickReplies.forEach(function(reply) {
                            replys.button.push({
                                message: {
                                    "accountLabel": reply.data.account.accountLabel,
                                    "accountNumber": reply.data.account.accountNumber,
                                    "accountStatus": reply.data.account.psuStatus
                                },
                                pageAccessToken: MyObjContact.parametrage("infoTransac").pageAccesToken,
                                payload: reply.payload,
                                type: 'replyAtos'
                            })
                        });
                        break;
                    default:
                        element.quickReplies.forEach(function(reply) {
                            replys.button.push({
                                message: reply.text,
                                pageAccessToken: MyObjContact.parametrage("infoTransac").pageAccesToken,
                                payload: reply.payload,
                                type: 'replyAtos'
                            })
                        });
                }
                this.messages(false, "bot", "", [], replys);
                break;
            default:
        }
    }.bind(this));
};

// Fonction échange smartly
Contact.prototype.BOTMessage = function(message, callback, add) {
    var inputMessage = (message.payload) ? message.payload : message,
        userMessage = (message.message) ? message.message : message;

    var data = {
        'event_name': "NEW_INPUT",
        'user_id': this.userID(),
        'skill_id': this.skillId(),
        'user_data': {
            "dateUser": {
                "timezone": new Date().getTimezoneOffset()
            },
            "geolocation": this.geolocation,
            "env": window.ENVIRONNEMENT,
            "address": this._saisieAdresseUtilisateur,
            "critere": this._critere,
            "path": location.pathname,
            "auth": this.isConnected()
        },
        'input': (inputMessage) ? inputMessage : message
    };
    if (this.parametrage("coords")) {
        data.user_data.geoloc = {};
        data.user_data.geoloc.lat = this.parametrage("coords").lat;
        data.user_data.geoloc.lng = this.parametrage("coords").lng;
    }

    var _this = this;
    if (!add)
        _this.messages(false, "user", (window.MyObjContact._saisieAdresseUtilisateur) ? window.MyObjContact._saisieAdresseUtilisateur : userMessage, [], {});

    _this.dialog(data, function(data) {
        if (data.payload) data.payload.origin = "smartly";
        _this.parametrage("origin", "smartly");
        _this.newMessageAdvisor(data.answer, data.input);
        _this.traitement(data, callback);
    });
}

Contact.prototype.fullScreen = function() {
    if (window.GetURLParameter && GetURLParameter("rc") == "mobile")
        return true;
    return false;
}

// Fonction récupération d'identifiant utilisateur smartly
Contact.prototype.userID = function() {
    if (!this.parametrage("userID")) {
        if (this.getCookie("s_fid"))
            this.parametrage("userID", this.getCookie("s_fid"));
        else
            this.parametrage("userID", Date.now() + this.randomString(20));
    }

    return this.parametrage("userID");
}

Contact.prototype._messages = function(first, sender, message, rich_text, payload) {
    var messages = this.parametrage("messages") || [];
    if (sender !== undefined && ((first && messages.length == 0) || !first)) {
        messages.push({
            sender: sender,
            message: message,
            rich_text: rich_text,
            payload: payload
        });
        this.parametrage("messages", messages);
        // sauvegarder messages
    } else
        return messages;
}

Contact.prototype.init = function() {
    var step = this.parametrage("step") || 0;

    var obj = this._step[step];

    if (obj.tools && window.OApp) {
        OApp.runLoading(obj.tools);

        OApp.displayOutil(obj.tools);
        if (obj.function)
            obj.function();
    } else if (obj.function) {
        obj.function();
    }
}

// retourne àétape suivante
Contact.prototype.nextStep = function() {
    var step = this.Step();
    step++;
    if (this.Step(step) == 0 && step > 0)
        this.reset();
    else
        this.init();
}

// retourne à étape précédente
Contact.prototype.prevStep = function() {
    var step = this.Step();
    if (step > 0)
        step--;
    if (this.Step(step) == 0)
        this.reset();
    else
        this.init();
}

// Retourne l'étape en cours (0 affichage bouton, 1 echange chatbot, 2 mise en relation conseiller, 3 sondage)
Contact.prototype.Step = function(value) {
    if (value !== undefined)
        this.parametrage("step", value % this._step.length);
    return this.parametrage("step") || 0;
}

// Filtre/actualisaation de la carte de la chatbox
Contact.prototype.critere = function(filter, tabFilter) { // filter // tabFilter (récupérer depuis le appli chatbot.js)
    var itemFilter = null;
    for (var i = 0; i < tabFilter.length; i += 1) {
        if (tabFilter[i].text === filter && itemFilter === null) {
            itemFilter = tabFilter[i].type;
            break;
        }
    }
    if (this._critere.length === 0) return this._critere = itemFilter;
    var filters = this._critere.split(",");

    for (var i = 0; i < filters.length; i += 1) {
        if (filters[i] === itemFilter) {
            var newFilters = filters.filter(function(item) {
                return item !== itemFilter
            })
            return this._critere = newFilters.join(",");
        } else if (i === (filters.length - 1)) {
            filters.push(itemFilter);
            this._critere = filters.join(",");
            return this._critere;
        }
    }
}

// Ajout historique pour le conseiller
Contact.prototype.newMessageAdvisor = function(msgBot, msgUser) {
    if (this._messageConseiller !== undefined) {
        this._messageConseiller += "Internaute : " + msgUser + "  /  Chatbot : " + msgBot + "  /  ";
        this.parametrage("messageConseiller", this._messageConseiller);
    } else {
        this._messageConseiller = "Chatbot : " + msgBot + "  /  ";
        this.parametrage("messageConseiller", this._messageConseiller);
    }
}

// Message transact
Contact.prototype.BotTransactionnelMessage = function(message, callback) {
    var _this = this;
    var data = {
        type: "TEXT",
        text: message,
        platformOverride: "NATIVE",
        locale: "fr",
        pageAccesToken: "5f6dfa70-ebe5-496a-80a3-28b425df1069"
    };
    //data.sessionId="em5p-f5fs9ff1-at8meg9sgh8g5fae8jds";
    this.initBotTransactionnel(function() {
        _this.callapiBotTransactionnel(_this._apiBotTransactionnel.message, data, true, function(data) {
            if (callback) callback(data);
        });
    });
}

// Récupération de la position lat, lng user
Contact.prototype.getCurrentPosition = function(callback) {
    function geolocation(state, callback) {
        navigator.geolocation.getCurrentPosition(function(pos) {
            var crd = pos.coords;
            callback({
                "lat": crd.latitude,
                "lng": crd.longitude
            }, state);
        }, function() {
            callback({
                "error": true
            }, state);
        }, {
            enableHighAccuracy: true,
            timeout: 100000,
            maximumAge: 0
        });
    }
    try {
        navigator.permissions.query({
            name: 'geolocation'
        }).then(function(permission) {
            var state = permission.state;
            geolocation(state, function(position) {
                callback(position);
            });
        });
    } catch (e) {
        geolocation(true, function(position) {
            callback(position);
        });
    }
}

Contact.prototype.getUrlParameters = function(key) {
    var varviableURL = window.location.search.substring(1).split('&'),
        dataUrl = {}

    varviableURL.forEach(function(data) {
        data = data.split('=')
        dataUrl[data[0]] = data[1]
    })
    if (key) return dataUrl[key]
    if (!varviableURL[0].length) return {}

    return dataUrl
}

// Récupération de l'historique smartly pour les mobiles
Contact.prototype.historyMobile = function(id) {
    var dataUser = {
            platform: "api",
            event_name: "NEW_INPUT",
            user_id: (this.getUrlParameters("sfIaParam")) ? this.getUrlParameters("sfIaParam") : id,
            skill_id: "5bfc241c95f03f515170f5d1",
            lang: "fr-fr",
            user_data: null,
            input: "conseiller"
        },
        headers = null,
        _sfSiteId = (this.site() !== "acquisition") ? this.site() : "hellobank";

    if (_sfSiteId === "hellobank") {
        headers = {
            Authorization: "Bearer eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJ1c2VyX2lkIjoiNWFhZmNmM2Q4ZWNhNWI0NTgxYzFiMmViIiwic2tpbGxfaWQiOiJhcGlfdG9rZW4iLCJpYXQiOjE1MjQ4MzkwNDR9.X4_XPzeBWRsIR6mheYDxmg97goonHtPv773jT6t8IzY"
        }
    } else {
        headers = {
            Authorization: "Bearer eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJ1c2VyX2lkIjoiNWFhYThjMTBlZGViZTM1NjdhNjVlNDlhIiwic2tpbGxfaWQiOiJhcGlfdG9rZW4iLCJpYXQiOjE1MzQ5NDgzODV9.iIDYHeJkobYv9e7CFuJEp10ugDlwdtanb7SnvpQvge8"
        }
        dataUser.skill_id = '5dc3ea3644a3ac1eaa299c2a';
    }

    return $.ajax({
        method: "post",
        url: "https://apis.smartly.ai/api/dialog/",
        headers: headers,
        data: dataUser
    });
}

Contact.prototype.refreshMap = function(adresse) {
    var timer = {
        wait: null,
        time: 0,
        maxTime: 10000
    }
    timer.wait = setInterval(function() {
        timer.time = timer.time += 1000;
        if ($("#nextoutils_nousTrouver")[0] || timer.time > timer.maxTime) {
            clearInterval(timer.wait);
            if (!$("#nextoutils_nousTrouver")[0]) return;

            $("#nextoutils_nousTrouver").find("iframe").attr("src", "https://agences.mabanque.bnpparibas/nextagence/?v2=1&adresse=" + adresse);
            $("html, body").animate({
                scrollTop: $("#nextoutils_nousTrouver").offset().top - (($(window).height() - $("#nextoutils_nousTrouver").height()) / 2)
            }, 700)
            var lastMessageUser = document.querySelectorAll('.list-messages .message')[document.querySelectorAll('.list-messages .message').length - 2];
            if (lastMessageUser) lastMessageUser.scrollIntoView({
                block: 'start',
                inline: 'end',
                behavior: 'smooth'
            });
        }
    });
}

Contact.prototype.isMobile = function() {
    var href = location.href;
    return (window.ENVIRONNEMENT === "MOBILE" || (/m-service/gi.test(href) || /m-webservices/gi.test(href) || /rc=mobile/gi.test(href)));
}

Contact.prototype.configBtnChat = function(cb) {
    function checkConfigBtn(config, cb) {
        var colonneConfig = config.colonneConfig;
        for (var i = 0; i < colonneConfig.length; i += 1) {
            var url = colonneConfig[i].url.indexOf('/fr/') === 0 ? colonneConfig[i].url : "/fr" + colonneConfig[i].url
            if (url === location.pathname) {
                cb(colonneConfig[i]);
                break;
            }
        }
    }
    if (sessionStorage.colonneContact) {
        checkConfigBtn(JSON.parse(sessionStorage.colonneContact), cb);
    } else {
        var url = "/rsc/contrib/script/simulateur/pointDeContact/colonneContactConfig.json"
        //if (window.ENVIRONNEMENT === "PROD") url = "/rsc/contrib/script/chat/colonneContactConfig.json"
        $.ajax({
            url: url,
            method: "GET",
            success: function(config) {
                sessionStorage.colonneContact = JSON.stringify(config);
                checkConfigBtn(config, cb)
            }
        });
    }
}

Contact.prototype.version = function() {
    try {
        var vs = JSON.parse(sessionStorage.app).nextoutils_pointDeContact;
        if (vs) return vs + "/"
        return ''
    } catch (e) {
        return ''
    }
}


/// CHAT v2
Contact.prototype.get = function(url) {
    return $.ajax({
        url: url,
        method: 'GET'
    });
}

Contact.prototype.getConfigChatbot = function() {
    return this.get('/rsc/contrib/script/simulateur/pointDeContact/json/chatbot.json')
}

Contact.prototype.userData = function(key, value, remove) {
    function userInfo() {
        try {
            var infoClient = JSON.parse(sessionStorage.info_client)
            var civilite = 'Inconnu'

            if (infoClient.data.client.civilite === 1) civilite = 'Monsieur'
            if (infoClient.data.client.civilite === 3 || infoClient.data.client.civilite === 2) civilite = 'Madame'
            return {
                auth: 'true',
                civilite: civilite,
                nom: infoClient.data.client.nomComplet,
            }
        } catch (e) {
            return undefined
        }
    }
    var userData = this.parametrage('user_data') || {}
    if (remove) {
        delete userData[key]
        this.parametrage('user_data', userData)
        return userData
    }
    var site = (this.site() === 'hellobank' || this.site() === 'hbpro') ? 'hb' : 'mb'

    userData.user = userInfo()
    userData.pathname = location.pathname
    var date = new Date()
    userData.time = {
        h: date.getHours(),
        m: date.getMinutes(),
        s: date.getSeconds()
    }
    userData.authorization = this._accessTokenMasterBot[window.ENVIRONNEMENT][site].token
    userData.env = window.ENVIRONNEMENT
    userData.origin = location.origin

    if (this.parametrage('chatbotTest')) {
        userData.chatbotTest = this.parametrage('chatbotTest')
    }

    this.parametrage('user_data', userData)

    if (!key) return userData

    userData[key] = value
    this.parametrage('user_data', userData)
    return userData
}

Contact.prototype.getConfigButton = function(url, site) {
    var dfd = jQuery.Deferred();

    function getConfig(buttons) {
        return buttons.filter(function(btn) {
            return btn.chatbot && location.pathname === btn.url
        })
    }

    this.get(url).then(function(res) {
        var buttonsList = (this.site() === 'part') ? res.colonneConfig : res[this.site()]
        dfd.resolve(getConfig(buttonsList)[0])
    }.bind(this))

    return dfd.promise();
}

Contact.prototype.getConfigBtn = function() {
    var url = "/rsc/contrib/script/simulateur/pointDeContact/colonneContactConfig.json"
    return this.get(url)
}

Contact.prototype.sendBotMessage = function(input = '', input_type) {
    var site = (this.site() === 'hellobank' || this.site() === 'hbpro') ? 'hb' : 'mb'

    var api = {
        url: this._apiMasterBotServer + this._apiMasterBot.dialog.path,
        type: this._apiMasterBot.dialog.method,
        headers: {
            Authorization: 'Bearer ' + this._accessTokenMasterBot[window.ENVIRONNEMENT][site].token
        },
        data: {
            event_name: this.messages().length ? 'NEW_INPUT' : 'NEW_DIALOG_SESSION',
            input: input,
            lang: "fr-fr",
            platform: "api",
            input_type: input_type,
            skill_id: this._accessTokenMasterBot[window.ENVIRONNEMENT][site].skill[this.site()],
            user_data: this.userData(),
            user_id: this.userID(),
        }
    }

    return $.ajax(api)
}

Contact.prototype.isBotTransactional = function() {
    return !!this.parametrage('pageAccesToken')
}

Contact.prototype.messages = function(newMessages) {
    var messages = this.parametrage("messages") || []
    if (!newMessages) return messages

    if (newMessages.length) {
        newMessages.forEach(function(message) {
            messages.push(message)
        })
        this.parametrage("messages", messages);

        return messages
    } else if (typeof newMessages === 'object') {
        messages.push(newMessages)
        this.parametrage("messages", messages);

        return messages
    }
}

Contact.prototype.conversationChatbot = function() {
    var msg = ''

    document.querySelectorAll(".message-conversation").forEach(el => {
        let key = [...el.classList].includes('message-user') ? '👤 Utilisateur :' : '🤖 Chatbot :'
        msg += `${key} ${el.querySelector(".message")?.innerText}\n `
    })


    window.idzCustomData = {
        "conversationChatbot": msg
    }

    return msg
}

Contact.prototype.isNotTransactional = function(state) {
    if (!this.parametrage('isNotTransactional')) this.parametrage('isNotTransactional', [1])
    var stateSave = this.parametrage('isNotTransactional')

    if (typeof state === 'boolean') {
        if (state && !stateSave.length)
            stateSave.push(1)
        else if (!state) stateSave.pop()

        this.parametrage('isNotTransactional', stateSave)
    } else return stateSave
}

Contact.prototype.commentMode = function(state) {
    if (!this.parametrage('commentMode')) this.parametrage('commentMode', [])
    var stateSave = this.parametrage('commentMode')

    if (typeof state === 'boolean') {
        if (state && !stateSave.length)
            stateSave.push(1)
        else if (!state) stateSave.pop()

        this.parametrage('commentMode', stateSave)
    } else return stateSave
}

Contact.prototype.authClient = function() {
    var dfd = jQuery.Deferred();

    try {
        window.OApp.get("/serviceinfosclient-wspl/rpc/InfosClient", function(data) {
            dfd.resolve(data)
            if (data && data.message === "OK" && data.data)
                sessionStorage.info_client = JSON.stringify(data)
        }.bind(this));
    } catch (e) {
        dfd.resolve(e)
    }

    return dfd.promise()
}

Contact.prototype.BotTransactionnelGetSoldePayload = function(payload, callback) {
    var _this = this;
    var data = {
        type: "QUICK_REPLY",
        payload: payload,
        platformOverride: "NATIVE",
        locale: "FRENCH",
        userId: MyObjContact.parametrage("infoTransac").userId,
        sessionId: MyObjContact.parametrage("infoTransac").sessionId,
        pageAccesToken: MyObjContact.parametrage("infoTransac").pageAccesToken,
    };
    this.initBotTransactionnel(function() {
        _this.callapiBotTransactionnel(_this._apiBotTransactionnel.message, data, true, function(dataAtos) {
            _this.MessageAtosTraitement(dataAtos);
            if (callback) callback(data);
        });
    });
}

Contact.prototype.accessToken = function() {
    var dfd = jQuery.Deferred();
    var apigeeExist = $('#nextoutils_pointDeContact_apigee').length > 0
    var MyAPIM = new APIM(apigeeExist);

    if (MyAPIM.tokenApigee) {
        MyAPIM.tokenApigee(function(accessTokenApigee) {
            dfd.resolve(accessTokenApigee)
        })
    }

    return dfd.promise();
}

Contact.prototype.sendTransactionalMessage = function(token, message = 'test', type = 'TEXT') {
    var dfd = jQuery.Deferred();
    var _this = this;
    var data = {
        type: type,
        text: message,
        platformOverride: "NATIVE",
        locale: "fr",
        pageAccesToken: token
    };

    if (type === 'QUICK_REPLY') {
        data.locale = 'FRENCH'
        delete data.text
        data.payload = message
    }

    if (this.parametrage("infoTransac")) {
        data.userId = this.parametrage('infoTransac').userId
        data.sessionId = this.parametrage('infoTransac').sessionId
        data.pageAccesToken = this.parametrage('infoTransac').pageAccesToken
    }

    this.initBotTransactionnel(function(state) {
        if (state) {
            dfd.resolve({
                state: state
            })
        } else {
            _this.callapiBotTransactionnel(_this._apiBotTransactionnel.message, data, true, function(data) {
                if (data && data.length)
                    var infoTransac = _this.parametrage('infoTransac') || {}
                infoTransac.userId = data[0].userId
                infoTransac.sessionId = data[0].sessionId
                infoTransac.pageAccesToken = data[0].pageAccesToken

                _this.parametrage('infoTransac', infoTransac);

                dfd.resolve(data)
            });
        }
    });

    return dfd.promise();
}

if (!window.MyObjContact) {
    window.Contact = Contact
}
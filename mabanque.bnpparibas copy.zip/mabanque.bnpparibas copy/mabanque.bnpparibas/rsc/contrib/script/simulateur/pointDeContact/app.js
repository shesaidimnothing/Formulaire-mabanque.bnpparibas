const site = () => {
    var site;
    var host = location.host;

    if (window.GlobalSite && window.GlobalSite.BY_SITE_VARS) {
        site = typeof GlobalSite.BY_SITE_VARS.typeClient === "string" && GlobalSite.BY_SITE_VARS.typeClient.toLowerCase() === "hb" ? "hellobank" : GlobalSite.BY_SITE_VARS.typeClient.toLowerCase();
    } else if (/canalnet-part/gim.test(host) || /mabanque./gim.test(host)) {
        site = "part";
    } else if (/canalnet-pro/gim.test(host) || /mabanquepro./gim.test(host)) {
        site = "pro";
    } else if (/canalnet-bpf/gim.test(host) || /mabanqueprivee./gim.test(host)) {
        site = "bpf";
    } else if (/hellobank-part/gim.test(host) || /hellobank./gim.test(host)) {
        site = "hellobank";
    } else if (/hellobank-pro/gim.test(host) || /hellobank-pro/gim.test(location.host)) {
        site = "hbpro";
    } else
        site = window.sfSiteId;

    return site;
}

async function launchApp() {
    const isQualif2 = GlobalSite.clientUtils && GlobalSite.clientUtils.isQualif2();

    var config = {
        part: {
            INTE: 'smartly',
            QUALIF: 'smartly',
            LOCAL: 'smartly',
            PREVIEW: 'smartly',
            PROD: 'smartly',
            MOBILE: 'smartly',
            MACHINE: 'smartly'
        },
        pro: {
            INTE: 'worldline',
            QUALIF: 'worldline',
            LOCAL: 'worldline',
            PREVIEW: 'worldline',
            PROD: 'worldline',
            MOBILE: 'worldline',
            MACHINE: 'worldline'

        },
        hellobank: {
            INTE: 'worldline',
            QUALIF: isQualif2 ? 'worldline' : 'smartly',
            LOCAL: 'worldline',
            PREVIEW: 'smartly',
            PROD: 'smartly',
            MOBILE: 'smartly',
            MACHINE: 'smartly'
        },
        hbpro: {
            INTE: 'worldline',
            QUALIF: 'worldline',
            LOCAL: 'worldline',
            PREVIEW: 'worldline',
            PROD: 'worldline',
            MOBILE: 'worldline',
            MACHINE: 'worldline'
        }
    }

    var currentConfig = config[site()][window.ENVIRONNEMENT] || sessionStorage.currentConfigChatbot



    var outils = {
        name: 'pointDeContact_contact_' + currentConfig,
        tools: 'nextoutils_pointDeContact_' + currentConfig
    }


    OApp.runLoading(outils.tools)
    OApp.displayOutil(outils.tools)
}
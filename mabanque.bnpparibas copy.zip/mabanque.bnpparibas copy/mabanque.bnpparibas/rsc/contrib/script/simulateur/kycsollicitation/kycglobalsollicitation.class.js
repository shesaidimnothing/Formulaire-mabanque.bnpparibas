(function() {

    if (/rc\=nopopin/.test(document.location.search) || sessionStorage.getItem('nopopin'))
        return;
    if (/rc\=webview/.test(document.location.search) || /rc\=mobile/.test(document.location.search) || /redir\=webview/.test(document.location.search) || /mode\=webview/.test(document.location.search))
        return;
    if (/\/fr\/secure\/webview/.test(document.location.pathname))
        return;

    kycglobalsollicication = function() {
        this._key = {
            STATUS: "gsk_status",
            TIME: "gsk_time"
        };

        this.popinSelector = "#popup-template";

        if (this.canLoad()) {
            this.callSollicitation();
        }
    }

    kycglobalsollicication.prototype.canLoad = function() {
        return this.env() != "hbpro" && this.isConnected() && this.isActive() && !this.isBlackListPage();
    }

    kycglobalsollicication.prototype.getOrigine = function() {
        return this.getOriginePrefixe() + (this.isIncitationPage() ? "BLOC" : "POPUP");
    }

    kycglobalsollicication.prototype.getOriginePrefixe = function() {
        var prefixes = {
            part: "IB",
            hb: "IH",
            bpf: "IP",
            pro: "IBP",
            hbpro: ""
        };

        return (prefixes[this.env()] || '') + "_";
    }

    kycglobalsollicication.prototype.env = function() {
        switch (true) {
            case GlobalSite.clientUtils.isBpf && GlobalSite.clientUtils.isBpf():
                return "bpf";
            case GlobalSite.clientUtils.isPart && GlobalSite.clientUtils.isPro():
                return "pro";
            case GlobalSite.clientUtils.isHb && GlobalSite.clientUtils.isHb():
                return "hb";
            case GlobalSite.clientUtils.isHbPro && GlobalSite.clientUtils.isHbPro():
                return "hbpro";
            default:
                return "part";
        }
    }

    kycglobalsollicication.prototype.timeout = function() {
        return GlobalSite ? .KycSollicitationConf ? .ws_timeout || null;
    }

    kycglobalsollicication.prototype.isBlackListPage = function() {
        return (GlobalSite ? .KycSollicitationConf ? .page_blacklist || [])
            .some((item) => document.location.pathname.endsWith(item));
    }

    kycglobalsollicication.prototype.isIncitationPage = function() {
        return (GlobalSite ? .KycSollicitationConf ? .page_incitation || [])
            .some((item) => document.location.pathname.endsWith(item));
    }

    kycglobalsollicication.prototype.isSpecifiquePage = function() {
        return GlobalSite ? .KycSollicitationConf &&
            /\/(mes-comptes|comptes-et-contrats)\/mes-cartes($|\/)/.test(document.location.pathname) ? ".btn-modifier" : false;
    }

    kycglobalsollicication.prototype.isConnected = function() {
        return GlobalSite.isConnected || GlobalSite ? .clientUtils ? .isEspaceClient();
    }

    kycglobalsollicication.prototype.isActive = function() {
        /* SWITCH GLOBAL POUR ACTIVATION */
        this.checkCache();
        if (sessionStorage[this._key.STATUS]) {
            if (sessionStorage[this._key.STATUS] == "inactive" || (!this.isIncitationPage() && !this.isSpecifiquePage()))
                return false;
        }
        if (!GlobalSite ? .KycSollicitationConf)
            return true;

        return GlobalSite ? .KycSollicitationConf ? .global_activation == true;
    }

    kycglobalsollicication.prototype.isActiveSollicitation = function(sollicitation) {
        if (!["solicitationDoc", "solicitationData"].includes(sollicitation))
            return false;

        if (!GlobalSite ? .KycSollicitationConf)
            return true;

        return GlobalSite.KycSollicitationConf[sollicitation == "solicitationDoc" ? "activation.kyc_doc" : "activation.kyc_data"] == true;
    }

    kycglobalsollicication.prototype.callSollicitation = function() {
        $.ajax({
            url: "/kyc-wspl/rest/getGlobalSollicitation",
            method: "POST",
            contentType: "application/json",
            processData: false,
            headers: {
                "X-SourceId": 0,
                customerId: 0,
                Channel: 0
            },
            data: JSON.stringify({
                "origine": this.getOrigine()
            }),
            timeout: this.timeout(),
            cache: false
        }).done(({
            data
        }) => this.incitation(data));
    }

    kycglobalsollicication.prototype.checkCache = function() {
        var time = null;
        try {
            time = (JSON.parse(sessionStorage.info_client)).dateServeur;
        } catch (e) {}

        if (sessionStorage[this._key.TIME] != time) {
            sessionStorage.removeItem(this._key.TIME);
            sessionStorage.removeItem(this._key.STATUS);
            sessionStorage.removeItem("gsk_sollicitations");
        }
    }

    kycglobalsollicication.prototype.setCache = function(status, data) {
        try {
            sessionStorage[this._key.TIME] = (JSON.parse(sessionStorage.info_client)).dateServeur;
        } catch (e) {}

        sessionStorage[this._key.STATUS] = status;
        sessionStorage.gsk_sollicitations = JSON.stringify(data);
    }

    kycglobalsollicication.prototype.showPopin = function(prioritySolicitation, status, isConnection) {
        var itemTpl = $('script[data-template="listitem"]').text().split(/\$\{(.+?)\}/g);
        var render = (props) => (tok, i) => (i % 2) ? props[tok] : tok;
        var sitename = this.env() == "hb" ? "hb" : "default";
        var jsonPath = '/content/dam/mabanque/rsc/contrib/script/simulateur/kycsollicitation/content-popin/' + sitename + '/' + prioritySolicitation.toLowerCase() + '/popins.json';

        return fetch(jsonPath)
            .then((response) => response.json())
            .then((json) => {
                var data = (isConnection) ? (json[status].connection || json[status]) :
                    (json[status].blocked || json[status]);

                var $popin = $(this.popinSelector);

                $popin.html(itemTpl.map(render(data)).join(''))
                    .addClass(sitename)
                    .removeClass("hidden")
                    .addClass("popin-alert")
                    .parents(".hidden")
                    .removeClass("hidden");

                this.addEvent();
                Popin.init();
                Popin.showPopin($popin);
            });
    }

    kycglobalsollicication.prototype.incitation = function(data) {
        var status = "done"
        var prioritySolicitation = data ? .prioritySolicitation;
        var sollicitation = prioritySolicitation ? (data[prioritySolicitation] || null) : null;

        if (this.isActiveSollicitation(prioritySolicitation) && sollicitation && sollicitation.solicitationStatus == "OK") {

            if (sessionStorage[this._key.STATUS] && sollicitation.coercition.status == "ETAPE_1")
                return;

            var status = sollicitation.coercition.status;

            if (this.isIncitationPage()) {
                var custom = this.isSpecifiquePage();
                if (custom && status != "ETAPE_1") {
                    var targetNode = document.getElementById('id_balise_div');
                    if (targetNode == null)
                        targetNode = document.getElementById('id_balise_div_mes_cartes');
                    var config = {
                        childList: true,
                        subtree: true
                    };
                    var _this = this;
                    var callback = function() {
                        if ($(custom).length > 0)
                            $(custom).click(function(event) {
                                if (status == "ETAPE_4") {
                                    event.stopPropagation();
                                    event.stopImmediatePropagation();
                                }
                                _this.showPopin(prioritySolicitation, status);
                            });
                    };
                    var observer = new MutationObserver(callback);
                    observer.observe(targetNode, config);
                } else {
                    this.showPopin(prioritySolicitation, status);
                    this.incitationLock(status);
                }
            } else {
                this.showPopin(prioritySolicitation, status, true);
            }

        } else {
            status = "inactive";
        }

        this.setCache(status, {
            data
        });
    }

    kycglobalsollicication.prototype.incitationLock = function(status) {
        if (status != "ETAPE_3" && status != "ETAPE_4")
            return;
        $selector = $(".page-content>.pam>.wrapper-ia");
        if ($selector.length == 0)
            $selector = $(".mainContent, .page-content");
        $selector.prepend("<div class='full-cache' style='position:absolute;z-index:2;opacity:1'></div>");
    }

    kycglobalsollicication.prototype.addEvent = function() {
        var _this = this;

        $(_this.popinSelector + " .btn-primary").on('click', function() {
            if ($(this).data("url")) {
                document.location.href = $(this).data("url") + _this.getOrigine();
            }
        });

        $(_this.popinSelector + " .btn-secondary").on('click', function() {
            if ($(this).data("url")) {
                document.location.href = $(this).data("url");
            } else {
                $(_this.popinSelector).addClass("hidden");
                Popin.hidePopin(_this.popinSelector);
            }
        });


    }

    GlobalSite.KycGlobalSollicication = new kycglobalsollicication();
})();
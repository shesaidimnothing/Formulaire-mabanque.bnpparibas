(function() {
    if (/rc\=nopopin/.test(document.location.search) || sessionStorage.getItem('nopopin'))
        return;
    if (/rc\=webview/.test(document.location.search) || /rc\=mobile/.test(document.location.search) || /redir\=webview/.test(document.location.search) || /mode\=webview/.test(document.location.search))
        return;
    if (/\/fr\/secure\/webview/.test(document.location.pathname))
        return;
    kycaeoi = function() {
        this._key = {
            STATUS: "kycaeoi_status",
            TIME: "kycaeoi_time"
        };
        if (ENVIRONNEMENT == "PROD" || ENVIRONNEMENT == "PREVIEW" || ENVIRONNEMENT == "MACHINE" || ENVIRONNEMENT == "MOBILE" || document.location.hostname == "pro.hellobank.fr" || /prev-(.)*.hellobank-(part|pro|bpf).hellobank.fr/.test(window.location.host))
            this._urlService = "https://w-services.bnpparibas.net/services/apiDF/public/api/kyc/get-state";
        else
            this._urlService = "https://staging-bnp.synten.com/services/apiDF/public/api/kyc/get-state";
        if (this.env() == "hb" || this.env() == "hbpro")
            this._pathRedirect = "/fr/secure/mon-profil/formulaire-auto-certification";
        else
            this._pathRedirect = "/fr/secure/mes-outils/profil/formulaire-auto-certification";
        if (this.isConnected() && this.isActive() && this.ikpi()) {
            var _this = this;
            this.callAeoi(function(data) {
                _this.redirect(data);
            });
        }
    }
    kycaeoi.prototype.env = function() {
        if (/hellobank-pro-qual1-acqui|hellobankpro/.test(document.location.hostname))
            return "hbpro-acqui";
        if (/hellobank-pro-|pro\.hellobank/.test(document.location.hostname))
            return "hbpro";
        if (/canalnet-pro|mabanquepro|pro\./.test(document.location.hostname))
            return "pro";
        if (/canalnet-bpf|mabanqueprivee|privee\./.test(document.location.hostname))
            return "bpf";
        if (/hellobank/.test(document.location.hostname))
            return "hb";
        return $("body").hasClass("hb") ? "hb" : "part";
    }
    kycaeoi.prototype.isConnected = function() {
        var ESPACE_CLIENT_SELECTOR = this.env() == "hb" || this.env() == "hbpro" ? ".to-deconnexion" : ["#logoutCAS", "#logoutCas", ".bottom-header-logoff a[href*=logoff]:visible", "#logout-button"].join(",");

        var res = $(ESPACE_CLIENT_SELECTOR);
        return window.GlobalSite.isConnected || res.length >= 1;
    }
    kycaeoi.prototype.redirect = function(data) {
        this.setCache("done");
        if (data.statut == 0 && data.codeRetour == 0)
            document.location.href = this._pathRedirect;
    }
    kycaeoi.prototype.checkCache = function() {
        var time = null;
        try {
            time = (JSON.parse(sessionStorage.info_client)).dateServeur;
        } catch (e) {}
        if (sessionStorage[this._key.TIME] != time) {
            sessionStorage.removeItem(this._key.TIME);
            sessionStorage.removeItem(this._key.STATUS);
        }
    }
    kycaeoi.prototype.setCache = function(status) {
        try {
            sessionStorage[this._key.TIME] = (JSON.parse(sessionStorage.info_client)).dateServeur;
        } catch (e) {}
        sessionStorage[this._key.STATUS] = status;
    }
    kycaeoi.prototype.isActive = function() {
        /* SWITCH GLOBAL POUR ACTIVATION */
        this.checkCache();
        if (sessionStorage[this._key.STATUS])
            return false;
        return true;
    }
    kycaeoi.prototype.ikpi = function() {
        var ikpi = null;
        try {
            ikpi = JSON.parse(sessionStorage.info_client).data.client.ikpiPersonne
        } catch (e) {}
        return ikpi;
    }
    kycaeoi.prototype.callAeoi = function(callback) {
        $.ajax({
            url: this._urlService,
            method: "POST",
            dataType: "json",
            data: {
                idRpp: this.ikpi()
            },
            cache: false
        }).done(function(data) {
            callback(data);
        });
    }
    GlobalSite.KycAeoiSollicication = new kycaeoi();
})();
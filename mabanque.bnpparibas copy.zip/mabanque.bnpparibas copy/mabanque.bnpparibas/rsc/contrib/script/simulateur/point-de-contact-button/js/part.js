function injectBtn(buttonClass) {
    var dfd = jQuery.Deferred()

    if (!$('.openChat_' + buttonClass + '_configDefault')[0]) {
        $.get('/rsc/contrib/script/simulateur/point-de-contact-button/template/Chat_MB_Contacts.html').then(function(html) {
            $('#main-content').append(html)
            dfd.resolve(buttonClass)
        })
    } else dfd.resolve(buttonClass)

    return dfd.promise()
}

function getConfig() {
    var dfd = jQuery.Deferred();

    function findBtn(arr) {
        return arr.filter(function(btn) {
            return (btn.url === location.pathname)
        })[0]
    }

    if (sessionStorage.configBtn) {
        var btn = findBtn(JSON.parse(sessionStorage.configBtn))
        dfd.resolve(btn)
    } else {
        $.get('/rsc/contrib/script/simulateur/point-de-contact-button/point-entree/part.json').then(function(config) {
            var btn = findBtn(config)
            sessionStorage.configBtn = JSON.stringify(config)
            dfd.resolve(btn)
        })
    }

    return dfd.promise()
}

function setStyle(classe, options = {}) {
    if (options.typeColonne !== 9) return false
    var body = $('body')
    var btn = $(classe)
    var page = $('#main-content')
    var blockFooter = $('.signal-problem-content').length ? $('.signal-problem-content') : $('#footer-content')
    var heightSignalProblem = 0
    var maxScrollBottom = page.height()

    heightSignalProblem = (blockFooter.height() + parseFloat(blockFooter.css('padding-top')) + parseFloat(blockFooter.css('padding-bottom'))) * 2
    heightSignalProblem = isNaN(heightSignalProblem) ? 0 : heightSignalProblem

    maxScrollBottom -= heightSignalProblem
    maxScrollBottom += $('.header').height()

    $('.content-bt-chat').css({
        position: 'inherit',
        height: '0'
    })

    btn.css({
        height: '80px',
        zIndex: 100
    })

    if (blockFooter && (blockFooter[0].getBoundingClientRect().top > $(window).height())) {
        btn.css({
            position: 'fixed',
            right: body[0].getBoundingClientRect().left + 'px',
            top: (window.innerHeight - btn.height() - 20) + 'px',
            bottom: 'inherit'
        })
    } else {
        if (options.connected) {
            btn.css({
                position: 'absolute',
                right: 0,
                top: 'inherit',
                bottom: (btn.height() / 2) - 13 + 'px'
            })
        } else {
            var heightSignalerProblemContent = $('.signal-problem-content').height() * $('.signal-problem-content').length

            if ($('.signal-problem-content').length > 1) {
                heightSignalerProblemContent += btn.height() + parseFloat($('.signal-problem-content').css('padding-bottom'))
            } else heightSignalerProblemContent += parseFloat($('.signal-problem-content').css('padding-top')) * 2

            if (isNaN(heightSignalerProblemContent)) heightSignalerProblemContent = 0

            btn.css({
                position: 'absolute',
                right: MyObjContact.isAuth() ? 0 : $('body')[0].getBoundingClientRect().left,
                top: MyObjContact.isAuth() ? ($('#main-content').height() - heightSignalerProblemContent - btn.height() - parseFloat($('.signal-problem-content').css('padding-bottom'))) : $('#main-content').height() - heightSignalerProblemContent
            })
        }
    }
}

function initBtn() {
    function showBtn(btnConfig) {
        if (!btnConfig || (btnConfig.connected && (btnConfig.connected && !MyObjContact.isAuth())) ||
            btnConfig && (!btnConfig.chatbot && !btnConfig.chat)) return false

        if (btnConfig.footerConstraint && !$('.chatbot-button-space').length) {
            $("#main-content").append('<div class="chatbot-button-space"></div>')
        }

        injectBtn(btnConfig.classeAppel).then(function() {
            var classe = '.openChat_' + btnConfig.classeAppel + '_configDefault'

            MyObjContact.parametrage('nameBtnChatbot', classe)
            MyObjContact.nameBtnChatbot = btnConfig.classeAppel

            setStyle(classe, btnConfig)

            window.addEventListener('scroll', function() {
                setStyle(classe, btnConfig)
            })

            window.addEventListener('resize', function() {
                setStyle(classe, btnConfig)
            })

            var btn = $(classe)
            if (btnConfig.chatbot || btnConfig.chat) {
                btn.show()
            }

            $('.chatbot-button-space').css({
                height: (btn.height() * 1.8) + 'px'
            })
            if (btnConfig.chatbot) {
                btn.on('click', function() {
                    if (MyObjContact.Step() === 0 || MyObjContact.Step().step === 0) {
                        MyObjContact.nextStep()
                        btn.hide()
                    }
                })
            } else if (btnConfig.chat) {
                btn.on('click', function() {
                    if (MyObjContact.Step() === 0 || MyObjContact.Step().step === 0) {
                        MyObjContact.Step(2)
                        MyObjContact.init()
                        btn.hide()
                    }
                })
            }
        })
    }

    getConfig().then(showBtn)
}
(function() {
    function FACILITY() {
        this._local = true;
        var env = this.env();
        var client = /\/secure\//.test(document.location.pathname);
        if (env != "part")
            return;
        var usrID = client ? "d97244bc-6346-11e8-a878-000c298ed446" : "78e9cfc9-f816-11e6-973b-000c298ed446";

        (function(w, d, s, f) {
            w[f] = w[f] || {
                conf: function() {
                    (w[f].data = w[f].data || []).push(arguments);
                }
            };
            var l = d.createElement(s),
                e = d.getElementsByTagName(s)[0];
            l.async = 1;
            l.src = '/rsc/contrib/script/simulateur/faciliti/faciliti-tag.min.js';
            l.setAttribute("data-application-identifier", usrID);
            e.parentNode.insertBefore(l, e);
        }(window, document, 'script', 'FACIL_ITI'));
        FACIL_ITI.conf('userId', usrID);
    }

    FACILITY.prototype.env = function() {
        if (/hellobank-pro-|hellobankpro./.test(document.location.hostname))
            return "hbpro";
        if (/pro-|mabanquepro|pro./.test(document.location.hostname))
            return "pro";
        if (/bpf-|mabanqueprivee|privee./.test(document.location.hostname))
            return "bpf";
        if (/hellobank/.test(document.location.hostname))
            return "hb";
        return "part";
    }
    if (!window.bnpp)
        window.bnpp = {};
    window.bnpp.abtesting = new FACILITY();
})();
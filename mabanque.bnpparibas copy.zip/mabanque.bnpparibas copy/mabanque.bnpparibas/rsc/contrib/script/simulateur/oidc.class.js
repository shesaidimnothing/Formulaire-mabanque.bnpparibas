(function() {
    function OIDC(partenaire) {
        this._sgi;
        try {
            var infoClt = JSON.parse(sessionStorage.info_client);
            var compte = infoClt.data.contrat.comptePrincipal;
            if (!compte) compte = infoClt.data.contrat.comptes[0];
            this._sgi = compte.identifiantSGIRattache;
        } catch (e) {}
        this.partenaire = partenaire;
        if (sessionStorage[partenaire]) {
            try {
                this[partenaire] = JSON.parse(sessionStorage[partenaire]);
            } catch (e) {}
        } else this[partenaire] = {};
        this.parametrage('sgi', this._sgi, true);
        if (Object.keys(this[partenaire]).length)
            this.parametrage('sgi', this._sgi, true, partenaire);

        var access_token;
        var state = this.readParamQuery('state');
        if (state) access_token = this.readParamQuery('access_token');
        if (Object.keys(this[partenaire]).length && state == this.state()) {
            if (!access_token) access_token = this.readParamQuery('code');
            if (access_token) this.accesstoken(access_token);
            else if (this.readParamQuery('error')) this.accesstoken('error');
        }

        this._ieVersion = (function() {
            var rv = false;
            if (navigator.appName == 'Microsoft Internet Explorer') {
                var ua = navigator.userAgent;
                var re = new RegExp('MSIE ([0-9]{1,}[.0-9]{0,})');
                if (re.exec(ua) != null) rv = parseFloat(RegExp.$1);
            } else if (navigator.appName == 'Netscape') {
                var ua = navigator.userAgent;
                var re = new RegExp('Trident/.*rv:([0-9]{1,}[.0-9]{0,})');
                if (re.exec(ua) != null) rv = parseFloat(RegExp.$1);
            }
            return rv;
        })();

        try {
            if (window.GlobalSite && !GlobalSite.getBrowser) {
                GlobalSite.getBrowser = function() {
                    var ua = navigator.userAgent,
                        tem,
                        M =
                        ua.match(
                            /(opera|chrome|safari|firefox|msie|trident(?=\/))\/?\s*(\d+)/i
                        ) || [];
                    if (/trident/i.test(M[1])) {
                        tem = /\brv[ :]+(\d+)/g.exec(ua) || [];
                        return 'IE ' + (tem[1] || '');
                    }
                    if (M[1] === 'Chrome') {
                        tem = ua.match(/\bOPR\/(\d+)/);
                        if (tem != null) return 'Opera ' + tem[1];
                    }
                    M = M[2] ?
                        [M[1], M[2]] :
                        [navigator.appName, navigator.appVersion, '-?'];
                    if ((tem = ua.match(/version\/(\d+)/i)) != null)
                        M.splice(1, 1, tem[1]);
                    return M.join(' ');
                };
            }
            this._isSafari = /Safari/.test(GlobalSite.getBrowser());
        } catch (e) {}
        this._noIframe = false;
        this._noInitFullPage = false;
        if (this._isSafari && !sessionStorage.noOIDCIframe) this._noIframe = true;
        if (/\/webview\//.test(document.location.pathname)) this._noIframe = true;
        this._noIframe =
            sessionStorage.noOIDCIframe == 'true' ? true : this._noIframe;
        this._noInitFullPage =
            sessionStorage.noOIDCFullPage == 'true' ? true : this._noInitFullPage;
    }

    OIDC.prototype.env = function() {
        if (/localhost/.test(document.location.hostname))
            return /part/.test(document.body.className) ?
                'part' :
                /hb/.test(document.body.className) ?
                'hb' :
                'pro';
        if (
            /hellobank-pro-qual1-acqui|hellobankpro/.test(document.location.hostname)
        )
            return 'hbpro-acqui';
        if (/hellobank-pro-|pro\.hellobank/.test(document.location.hostname))
            return 'hbpro';
        if (/canalnet-pro|mabanquepro|pro\./.test(document.location.hostname))
            return 'pro';
        if (/canalnet-bpf|mabanqueprivee|privee\./.test(document.location.hostname))
            return 'bpf';
        if (/hellobank/.test(document.location.hostname)) return 'hb';
        return 'part';
    };

    OIDC.prototype.readParamQuery = function(key) {
        return (
            this.readParameter(key, document.location.hash) ||
            this.readParameter(key, document.location.search)
        );
    };

    OIDC.prototype.readParameter = function(key, paramsString) {
        var result = paramsString.match(
            new RegExp('(\\?|\\#|&)' + key + '(\\[\\])?=([^&]*)')
        );

        return result ? decodeURIComponent(result[3]) : undefined;
    };

    OIDC.prototype.parametrage = function(key, value, reset) {
        if (!this.partenaire) return;
        if (value === undefined) return this[this.partenaire][key];
        else {
            var save = this[this.partenaire][key] != value;
            this[this.partenaire][key] = value;
            if (save || key == 'cache') {
                if (reset) {
                    for (key in this[this.partenaire]) {
                        if (key != 'sgi') delete this[this.partenaire][key];
                    }
                }
                sessionStorage[this.partenaire] = JSON.stringify(this[this.partenaire]);
            }
        }
    };

    OIDC.prototype.cache = function(name, value) {
        var cache = this.parametrage('cache') || {};
        if (value === undefined) return cache[name];
        else {
            if (value == null) console.log('empty cache');
            if (this.parametrage('nocache')) return;
            cache[name] = value;
            this.parametrage('cache', cache);
        }
    };

    OIDC.prototype.state = function(value) {
        if (value === false)
            this.parametrage('state', null, undefined, this.partenaire);
        if (value) {
            return (
                this.parametrage('state', undefined, undefined, this.partenaire) ==
                value
            );
        } else {
            if (!this.parametrage('state', undefined, undefined, this.partenaire))
                this.parametrage(
                    'state',
                    btoa(this.randomString(21)),
                    undefined,
                    this.partenaire
                );
            return this.parametrage('state', undefined, undefined, this.partenaire);
        }
    };

    OIDC.prototype.redirect = function(value) {
        if (value === undefined)
            return this.parametrage(
                'redirect',
                undefined,
                undefined,
                this.partenaire
            );
        else {
            this.parametrage('redirect', value, undefined, this.partenaire);
        }
    };

    OIDC.prototype.nonce = function(value) {
        if (value === false)
            this.parametrage('nonce', null, undefined, this.partenaire);
        if (value) {
            return (
                this.parametrage('nonce', undefined, undefined, this.partenaire) ==
                value
            );
        } else {
            if (!this.parametrage('nonce', undefined, undefined, this.partenaire))
                this.parametrage(
                    'nonce',
                    btoa(this.randomString(21)),
                    undefined,
                    this.partenaire
                );
            return this.parametrage('nonce', undefined, undefined, this.partenaire);
        }
    };

    OIDC.prototype.accesstoken = function(value) {
        if (value === undefined) {
            if (
                this.parametrage(
                    'access_token',
                    undefined,
                    undefined,
                    this.partenaire
                ) &&
                this.parametrage('expire', undefined, undefined, this.partenaire) <
                new Date().getTime() / 1000
            )
                this.parametrage('access_token', null, undefined, this.partenaire);
            return this.parametrage(
                'access_token',
                undefined,
                undefined,
                this.partenaire
            );
        } else {
            this.parametrage('access_token', value, undefined, this.partenaire);
            this.parametrage(
                'expire',
                new Date().getTime() / 1000 + (this._expireToken || 600),
                undefined,
                this.partenaire
            );
        }
    };

    OIDC.prototype.randomString = function(length) {
        var text = '';
        var possible =
            'ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789';
        for (var i = 0; i < length; i++) {
            text += possible.charAt(Math.floor(Math.random() * possible.length));
        }
        return text;
    };

    OIDC.prototype.getUrl = function(url, params) {
        if (params) {
            var tmpUrl = url;
            for (var param in params) {
                var tmp = url;
                if (typeof params[param] !== 'object') {
                    url = url.replace(param, params[param]);
                    if (tmp != url) delete params[param];
                }
            }
            if (tmpUrl == url) {
                var bEt = url.indexOf('?') >= 0;
                for (var param in params) {
                    if (typeof params[param] !== 'object') {
                        url += (bEt ? '&' : '?') + param + '=' + params[param];
                        bEt = true;
                    }
                }
            }
        }

        return url;
    };

    OIDC.prototype.initialize = function(url, params, callback) {
        this.parametrage('sgi', this._sgi, true);
        if (window.ENVIRONNEMENT == 'LOCAL') callback(true);
        if (this.accesstoken(undefined)) {
            callback(true);
            return;
        }
        var _this = this;
        params = params || {};
        params.state = _this.state(false);
        params[this.paramnamecallback || 'redirect_uri'] = encodeURI(
            'https://' +
            document.location.host +
            this.pathcallback +
            (this.addstateoncallback ? '?state=' + params.state : '')
        );
        if (this.clientid) params.client_id = this.clientid;

        $('#oidc_' + this.partenaire).remove();
        $('body').append(
            $("<iframe id='oidc_" + this.partenaire + "' class='hidden'>")
        );

        $('#oidc_' + this.partenaire).on('load', function() {
            window.tokenInteval = {
                interval: 500,
                max: 10000
            };
            tokenInteval.cpt = 0;
            tokenInteval.token = setInterval(function() {
                tokenInteval.cpt++;
                try {
                    console.log('on load iframe ' + this.partenaire);
                    if (
                        $('#oidc_' + _this.partenaire)[0].contentWindow.document.location
                    ) {
                        console.log('iframe ' + this.partenaire + 'loaded');
                        clearInterval(tokenInteval.token);
                        var token = _this.readParameter(
                            'token',
                            $('#oidc_' + _this.partenaire)[0].contentWindow.document.location
                            .search
                        );
                        var state = _this.readParameter(
                            'state',
                            $('#oidc_' + _this.partenaire)[0].contentWindow.document.location
                            .search
                        );
                        if (state == _this.state()) _this.accesstoken(token || 'done');
                        callback(true);
                    }
                } catch (e) {
                    /*
                    console.log(
                      'can not load iframe ' + this.partenaire + 'because CORS access'
                    );*/
                    console.log('iframe ' + this.partenaire + ': force leave init');
                    clearInterval(tokenInteval.token);
                    callback(true);
                }
                if (
                    tokenInteval.cpt * tokenInteval.interval > tokenInteval.max &&
                    tokenInteval.token
                ) {
                    console.log('timeout');
                    clearInterval(tokenInteval.token);
                    $('#oidc_' + this.partenaire).remove();
                    if (!_this._noIframe && !_this.parametrage('stop_init')) {
                        _this._noIframe = true;
                        _this.initialize(url, params, callback);
                    } else {
                        _this.accesstoken('Timeout');
                        callback(false);
                    }
                }
            }, tokenInteval.interval);
        });
        if (_this._noIframe) {
            _this.redirect(document.location.href);
            document.location.href = _this.getUrl(url, params);
        } else $('#oidc_' + this.partenaire).attr('src', _this.getUrl(url, params));
    };

    OIDC.prototype.initFullPage = function(url, partenaire) {
        if (this._noInitFullPage) return;
        if (document.location.hash) return;
        this.parametrage('stop_init', true, false, partenaire);
        setTimeout(function() {
            document.location.href = url;
        }, 100);
    };

    window.OIDC = OIDC;
    window.bnpp = window.bnpp || {};
    window.bnpp.oidccontroleur = function(
        partenaire,
        url,
        clientid,
        params,
        callback,
        pathcallback,
        paramnamecallback,
        addstateoncallback
    ) {
        var tmp = new OIDC(partenaire);
        window.tmp = tmp;
        if (clientid) tmp.clientid = clientid;
        if (pathcallback) tmp.pathcallback = pathcallback;
        if (paramnamecallback) tmp.paramnamecallback = paramnamecallback;
        if (addstateoncallback) tmp.addstateoncallback = addstateoncallback;
        tmp.initialize(url, params, function(data) {
            callback(data);
        });
    };
})();
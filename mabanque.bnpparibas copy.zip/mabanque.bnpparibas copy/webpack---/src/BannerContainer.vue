var render = function render(){var _vm=this,_c=_vm._self._c,_setup=_vm._self._setupProxy;return _c('div',{style:({order: _vm.blockOrder}),attrs:{"id":_vm.banner.location,"data-celebrus-type":_vm.banner.location}},[_c(_vm.banner.location,{tag:"component",attrs:{"banner":_vm.banner}})],1)
}
var staticRenderFns = []

export { render, staticRenderFns }
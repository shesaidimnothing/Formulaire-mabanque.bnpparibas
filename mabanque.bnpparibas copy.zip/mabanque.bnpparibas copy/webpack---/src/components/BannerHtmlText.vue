// Imports
var ___CSS_LOADER_API_IMPORT___ = require("../../node_modules/css-loader/dist/runtime/api.js");
exports = ___CSS_LOADER_API_IMPORT___(false);
// Module
exports.push([module.id, ".htmltext__container{padding-left:8%;padding-right:40px}@media screen and (max-width:1023px){.htmltext__container{padding-left:40px}}@media screen and (max-width:767px){.htmltext__container{padding:15px 35px 15px 35px}}", ""]);
// Exports
module.exports = exports;


import { Component, Prop, Vue } from "vue-property-decorator";
import methodList from "@/config/Common";

declare global {
  interface Window {
    _satellite: any;
  }
}
@Component
export default class BannerButton extends Vue {
  @Prop() public banner!: any;
  public methodList = methodList;
  public mounted() {
    this.initOApp();
    this.setURLParameters();
  }

  private initOApp() {
    const webCallbacks = Object.keys(this.banner).filter((entry)=> entry.match(/cta\dWebcallback/));
    webCallbacks
    .forEach((entry)=>{
      if( this.banner[entry] ) {
        const cta = 'cta' + entry.match(/cta(\d)Webcallback/)[1];
        const initializeOApp = setInterval(() => {
          if ((window as any).OApp) {
            (window as any).OApp.runLoading();
            clearInterval(initializeOApp);
            document
              .getElementById(this.getWebcallback(cta))
              .addEventListener("click", () => methodList.onCtaClick(this.banner,cta));
        }
        },200)
      }
    })
  }

  private setURLParameters() {
    const buttonsForm = this.$el.querySelector('#dcrmCTAForm');   
    const paramCTA1 = !!this.banner.cta1URL  ? this.banner.cta1URL?.match(/(\w+[^&]=\w+)/g) || [] : [];
    const paramCTA2 = !!this.banner.cta2URL  ? this.banner.cta2URL?.match(/(\w+[^&]=\w+)/g) || [] : [];

    paramCTA1.concat(paramCTA2)
      .forEach((entry)=>{
        let parameters = entry.split('=');
        let newHiddenInput = document.createElement('input');
        newHiddenInput.type = "hidden";
        newHiddenInput.name = parameters[0];
        newHiddenInput.value = parameters[1];
        buttonsForm.append(newHiddenInput);
    })
  }

  private getWebcallback = (cta) => !!this?.banner[`${cta}Webcallback`] ? `nextcallback_${this?.banner[`${cta}Webcallback`]}` : null;
  private isCookieConsent = (cta) =>  this.banner[cta+'URL'] === "https://cookieconsent" ? "cookiesdisplayparameters" : null;
  private getCtaAriaLabel = (cta) => this?.banner?.[cta+'AriaLabel'] || null;
}

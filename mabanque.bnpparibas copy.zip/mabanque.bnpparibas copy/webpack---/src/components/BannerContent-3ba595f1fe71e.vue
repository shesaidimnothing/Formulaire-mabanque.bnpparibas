var render = function render(){var _vm=this,_c=_vm._self._c,_setup=_vm._self._setupProxy;return _c('div',{staticClass:"banner__content"},[(_vm.banner.teaser)?_c('h3',{staticClass:"banner__teaser",domProps:{"innerHTML":_vm._s(_vm.treatedTeaser)}}):_vm._e(),(_vm.banner.description)?_c('p',{staticClass:"banner__description",domProps:{"innerHTML":_vm._s(_vm.treatedDescription)}}):_vm._e(),(_vm.banner.clickableBanner && _vm.banner.cta1URL && !_vm.banner.cta1Text)?_c('a',{staticClass:"clickableBanner",attrs:{"href":_vm.banner.cta1URL,"target":"_blank"},on:{"click":function($event){_vm.celebrusAccepted; _vm.methodList.trackLaunchCTA(_vm.banner,'zoneClickable')}}}):_vm._e()])
}
var staticRenderFns = []

export { render, staticRenderFns }
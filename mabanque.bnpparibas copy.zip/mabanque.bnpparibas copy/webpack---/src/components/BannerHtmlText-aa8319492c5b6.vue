var render = function render(){var _vm=this,_c=_vm._self._c,_setup=_vm._self._setupProxy;return (_vm.banner.htmlText)?_c('div',{staticClass:"htmltext__container",domProps:{"innerHTML":_vm._s(_vm.treatedhtmlText)}}):_vm._e()
}
var staticRenderFns = []

export { render, staticRenderFns }


import { Component, Prop, Vue } from "vue-property-decorator";
import UdcBannerGeneric from "@/components/UdcBannerGeneric.vue";

@Component({
  name: "confirmation-virement",
  components: {
    UdcBannerGeneric
  }
})

export default class UdcBannerAnimation extends Vue {
@Prop() private banner!: any;
    public data() {
    return  {
                preTitle : this.hasPretitle(),
                backgroundImgCheck: this.getBackgroundImgCheck(),
                backgroundImg: this.getBackgroundImg()
            };
    }

    private hasPretitle() {
        return !(this.banner.template.match(/Gab(07|14)/));
    }

    private getBackgroundImg() {
        if (this.banner.imgBackground) {
            const bckgroundArray = this.banner.imgBackground.split(" ");
            const bckgroundName = bckgroundArray[0];
            const bckgroundParams = bckgroundArray.slice(1).join(" ");
            const urlBackgroundImg = this.banner.celebrusAssetsPathFinder + bckgroundName + ".png";
            return `background: #ffffff url('${urlBackgroundImg}') ${bckgroundParams};`;
        }
    }

    private getBackgroundImgCheck() {
        if (this.banner.imgBackground) {
        return "bckgrdUsed";
        }
    }
}


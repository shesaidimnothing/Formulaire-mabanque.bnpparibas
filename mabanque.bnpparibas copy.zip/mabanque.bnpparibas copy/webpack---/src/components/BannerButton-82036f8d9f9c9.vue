import { render, staticRenderFns } from "./BannerButton.vue?vue&type=template&id=65550cec&scoped=true&lang=pug&"
import script from "./BannerButton.vue?vue&type=script&lang=ts&"
export * from "./BannerButton.vue?vue&type=script&lang=ts&"
import style0 from "./BannerButton.vue?vue&type=style&index=0&id=65550cec&prod&lang=scss&scoped=true&"


/* normalize component */
import normalizer from "!../../node_modules/vue-loader/lib/runtime/componentNormalizer.js"
var component = normalizer(
  script,
  render,
  staticRenderFns,
  false,
  null,
  "65550cec",
  null
  
)

export default component.exports
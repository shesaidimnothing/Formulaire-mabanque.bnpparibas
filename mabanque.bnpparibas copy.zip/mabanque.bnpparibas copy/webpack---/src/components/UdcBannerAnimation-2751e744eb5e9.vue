
import { Component, Prop, Vue } from "vue-property-decorator";
import UdcBannerGeneric from "@/components/UdcBannerGeneric.vue";
import methodList from "@/config/Common";
import "@/styles/main.scss";

@Component({
  name: "udc-banner-animation",
  components: {
    UdcBannerGeneric
  }
})
export default class UdcBannerAnimation extends Vue {
  @Prop() private banner!: any;
  
  public methodList = methodList;
  public data() {
    return {
      backgroundImg: this.getBackgroundImg(),
      backgroundImgCheck: this.getBackgroundImgCheck()
    };
  }

  private getProvenanceName() {
    if (this.banner.message_id) {
      return this.banner.message_id.match(/BAN_SECOURS/)
        ? "emergencyBanner"
        : "rtim";
    } else {
      return "rtim";
    }
  }

  private getBackgroundImg() {
    if (this.banner.imgBackground) {
      const bckgroundArray = this.banner.imgBackground.split(" ");
      const bckgroundName = bckgroundArray[0];
      const bckgroundParams = bckgroundArray.slice(1).join(" ");
      const urlBackgroundImg =
        this.banner.celebrusAssetsPathFinder + bckgroundName + ".png";
      return `background: #ffffff url('${urlBackgroundImg}') ${bckgroundParams};`;
    }
  }

  private getBackgroundImgCheck() {
    if (this.banner.imgBackground) {
      return "bckgrdUsed";
    }
  }
}

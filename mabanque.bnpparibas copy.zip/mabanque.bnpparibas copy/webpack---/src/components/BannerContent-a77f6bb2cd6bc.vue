import { render, staticRenderFns } from "./BannerContent.vue?vue&type=template&id=9a1521fc&lang=pug&"
import script from "./BannerContent.vue?vue&type=script&lang=ts&"
export * from "./BannerContent.vue?vue&type=script&lang=ts&"
import style0 from "./BannerContent.vue?vue&type=style&index=0&id=9a1521fc&prod&lang=scss&"


/* normalize component */
import normalizer from "!../../node_modules/vue-loader/lib/runtime/componentNormalizer.js"
var component = normalizer(
  script,
  render,
  staticRenderFns,
  false,
  null,
  null,
  null
  
)

export default component.exports
import { render, staticRenderFns } from "./UdcBannerAnimation.vue?vue&type=template&id=17d561f3&lang=pug&"
import script from "./UdcBannerAnimation.vue?vue&type=script&lang=ts&"
export * from "./UdcBannerAnimation.vue?vue&type=script&lang=ts&"


/* normalize component */
import normalizer from "!../../node_modules/vue-loader/lib/runtime/componentNormalizer.js"
var component = normalizer(
  script,
  render,
  staticRenderFns,
  false,
  null,
  null,
  null
  
)

export default component.exports
var render = function render(){var _vm=this,_c=_vm._self._c,_setup=_vm._self._setupProxy;return _c('div',[(_vm.preTitle)?_c('span',{staticClass:"preTitle",class:[_vm.banner.mainClass]},[_vm._v("Cela pourrait vous intéresser ...")]):_vm._e(),_c('div',{staticClass:"banner selfcare-banner-celebrus",class:[_vm.banner.mainClass, _vm.banner.category, _vm.backgroundImgCheck],style:(_vm.backgroundImg)},[_c('udc-banner-generic',{attrs:{"banner":_vm.banner}})],1)])
}
var staticRenderFns = []

export { render, staticRenderFns }
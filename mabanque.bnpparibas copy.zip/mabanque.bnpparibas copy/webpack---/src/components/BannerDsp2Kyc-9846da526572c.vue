import { render, staticRenderFns } from "./BannerDsp2Kyc.vue?vue&type=template&id=8bc63f56&"
import script from "./BannerDsp2Kyc.vue?vue&type=script&lang=ts&"
export * from "./BannerDsp2Kyc.vue?vue&type=script&lang=ts&"


/* normalize component */
import normalizer from "!../../node_modules/vue-loader/lib/runtime/componentNormalizer.js"
var component = normalizer(
  script,
  render,
  staticRenderFns,
  false,
  null,
  null,
  null
  
)

export default component.exports
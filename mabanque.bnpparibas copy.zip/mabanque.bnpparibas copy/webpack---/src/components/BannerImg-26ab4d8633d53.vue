var render = function render(){var _vm=this,_c=_vm._self._c,_setup=_vm._self._setupProxy;return (_vm.banner.imgBanner)?_c('div',{staticClass:"imgBanner"},[_c('img',{attrs:{"src":[_vm.assetUrl + _vm.banner.imgBanner +'.png'],"alt":_vm.getImageBannerAlt()}})]):_vm._e()
}
var staticRenderFns = []

export { render, staticRenderFns }

import { Component, Prop, Vue } from "vue-property-decorator";
import methodList from "@/config/Common";

@Component
export default class BannerContent extends Vue {
  @Prop() public banner!: any;
  public teaser: string = this.banner.teaser;
  public description: string = this.banner.description;
  public cta1URL: string = this.banner.cta1URL;
  public gabarit: string = this.banner.template;
  public dynamic1: string = this.banner.dynamic1;
  public dynamic2: string = this.banner.dynamic2;
  public dynamic3: string = this.banner.dynamic3;
  public dynamic4: string = this.banner.dynamic4;
  public dynamic5: string = this.banner.dynamic5;
  public dynamic6: string = this.banner.dynamic6;
  public dynamic7: string = this.banner.dynamic7;
  public dynamic8: string = this.banner.dynamic8;
  public dynamic9: string = this.banner.dynamic9;
  public mPOKA60Month: string;
  public methodList = methodList;

  get treatedTeaser() {
    const mPOKA60Month = this.banner.mPOKA60Month;
    this.teaser = this.teaser.replace(/%(m_poka_60mois)%/, mPOKA60Month);
    return this.teaser.replace(/%(dynamic[0-9])%/gi, (full, group) => {
      return (group = this[group]);
    });
  }

  get treatedDescription() {
    const mPOKA60Month = this.banner.mPOKA60Month;
    this.description = this.description.replace(/%(m_poka_60mois)%/, mPOKA60Month);
    return this.description.replace(/%(dynamic[0-9])%/gi, (full, group) => {
      return (group = this[group]);
    });
  }

  private celebrusAccepted() {
      this.banner.celebrusHelper.accepted();
  }
}


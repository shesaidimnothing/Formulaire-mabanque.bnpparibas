
import { Component, Prop, Vue } from "vue-property-decorator";
import UdcBannerGeneric from "@/components/UdcBannerGeneric.vue";
import methodList from "@/config/Common";

@Component({
  name: "udc-banner-sticky",
  components: {
    UdcBannerGeneric
  }
})
export default class UdcBannerSticky extends Vue {
  @Prop() private banner!: any;
  public methodList = methodList;

  private getProvenanceName() {
    if (this.banner.message_id) {
      return this.banner.message_id.match(/BAN_SECOURS/)
        ? "emergencyBanner"
        : "rtim";
    } else {
      return "rtim";
    }
  }
}


/****** LOADER ******/
.load_chatbot {
    position: absolute;
    background: #fff;
    z-index: 500;
    width: 100%;
    height: 100%;
    top: 0;
    left: 0;
}

.showbox {
    position: absolute;
    left: 50%;
    top: 50%;
    transform: translate(-50%, -50%);
    padding: 5%;
}

.loader-chatbot {
    position: relative;
    margin: 0 auto;
    width: 200px;
}
#nextoutils_service_locator svg {
    overflow: visible !important;
}
.loader-chatbot:before {
    content: "";
    display: block;
    padding-top: 100%;
}

.circular {
    -webkit-animation: rotate 2s linear infinite;
    animation: rotate 2s linear infinite;
    height: 100%;
    -webkit-transform-origin: center center;
    transform-origin: center center;
    width: 100%;
    position: absolute;
    top: 0;
    bottom: 0;
    left: 0;
    right: 0;
    margin: auto;
}

.path {
    stroke-dasharray: 1, 200;
    stroke-dashoffset: 0;
    stroke-linecap: round;
}
.publique {
    .path {
        animation: dash 1.5s ease-in-out infinite, colorHB 6s ease-in-out infinite;
    }
}
.part, .bpf, .pro {
    .path {
        animation: dash 1.5s ease-in-out infinite, colorPART 6s ease-in-out infinite;
    }
}
@-webkit-keyframes rotate {
    100% {
        -webkit-transform: rotate(360deg);
        transform: rotate(360deg);
    }
}

@keyframes rotate {
    100% {
        -webkit-transform: rotate(360deg);
        transform: rotate(360deg);
    }
}
@-webkit-keyframes dash {
    0% {
        stroke-dasharray: 1, 200;
        stroke-dashoffset: 0;
    }
    50% {
        stroke-dasharray: 89, 200;
        stroke-dashoffset: -35px;
    }
    100% {
        stroke-dasharray: 89, 200;
        stroke-dashoffset: -124px;
    }
}
@keyframes dash {
    0% {
        stroke-dasharray: 1, 200;
        stroke-dashoffset: 0;
    }
    50% {
        stroke-dasharray: 89, 200;
        stroke-dashoffset: -35px;
    }
    100% {
        stroke-dasharray: 89, 200;
        stroke-dashoffset: -124px;
    }
}
@keyframes colorHB {
    100%,
    0% {
        stroke: #62d8ea;
    }
    20% {
        stroke: #11bad5;
    }
    40% {
        stroke: #177f8f;
    }
    80%,
    90% {
        stroke: #176d8c;
    }
}
@keyframes colorPART {
    100%,
    0% {
        stroke: #89fdc1;
    }
    20% {
        stroke: #3be68d;
    }
    40% {
        stroke: #1d9758;
    }
    80%,
    90% {
        stroke: #1a7848;
    }
}


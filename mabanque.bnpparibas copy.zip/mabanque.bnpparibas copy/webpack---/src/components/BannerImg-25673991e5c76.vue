// Imports
var ___CSS_LOADER_API_IMPORT___ = require("../../node_modules/css-loader/dist/runtime/api.js");
exports = ___CSS_LOADER_API_IMPORT___(false);
// Module
exports.push([module.id, ".imgBanner[data-v-a1267c34]{margin-top:40px;text-align:center;display:block}.imgBanner img[data-v-a1267c34]{max-height:300px}@media screen and (max-width:768px){.imgBanner[data-v-a1267c34]{margin-top:15px}.imgBanner img[data-v-a1267c34]{height:210px}}", ""]);
// Exports
module.exports = exports;

import { render, staticRenderFns } from "./UdcBannerPopin.vue?vue&type=template&id=2095e2bd&lang=pug&"
import script from "./UdcBannerPopin.vue?vue&type=script&lang=ts&"
export * from "./UdcBannerPopin.vue?vue&type=script&lang=ts&"
import style0 from "./UdcBannerPopin.vue?vue&type=style&index=0&id=2095e2bd&prod&lang=scss&"


/* normalize component */
import normalizer from "!../../node_modules/vue-loader/lib/runtime/componentNormalizer.js"
var component = normalizer(
  script,
  render,
  staticRenderFns,
  false,
  null,
  null,
  null
  
)

export default component.exports
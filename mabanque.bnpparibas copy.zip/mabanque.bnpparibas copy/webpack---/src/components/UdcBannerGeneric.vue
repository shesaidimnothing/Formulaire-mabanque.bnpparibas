var render, staticRenderFns
import script from "./UdcBannerGeneric.vue?vue&type=script&lang=ts&"
export * from "./UdcBannerGeneric.vue?vue&type=script&lang=ts&"


/* normalize component */
import normalizer from "!../../node_modules/vue-loader/lib/runtime/componentNormalizer.js"
var component = normalizer(
  script,
  render,
  staticRenderFns,
  false,
  null,
  "eb155432",
  null
  
)

export default component.exports
import { render, staticRenderFns } from "./BannerImg.vue?vue&type=template&id=a1267c34&scoped=true&lang=pug&"
import script from "./BannerImg.vue?vue&type=script&lang=ts&"
export * from "./BannerImg.vue?vue&type=script&lang=ts&"
import style0 from "./BannerImg.vue?vue&type=style&index=0&id=a1267c34&prod&lang=scss&scoped=true&"


/* normalize component */
import normalizer from "!../../node_modules/vue-loader/lib/runtime/componentNormalizer.js"
var component = normalizer(
  script,
  render,
  staticRenderFns,
  false,
  null,
  "a1267c34",
  null
  
)

export default component.exports
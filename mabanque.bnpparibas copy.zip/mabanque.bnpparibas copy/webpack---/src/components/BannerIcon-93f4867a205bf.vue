import { render, staticRenderFns } from "./BannerIcon.vue?vue&type=template&id=2749bda2&lang=pug&"
import script from "./BannerIcon.vue?vue&type=script&lang=ts&"
export * from "./BannerIcon.vue?vue&type=script&lang=ts&"
import style0 from "./BannerIcon.vue?vue&type=style&index=0&id=2749bda2&prod&lang=scss&"


/* normalize component */
import normalizer from "!../../node_modules/vue-loader/lib/runtime/componentNormalizer.js"
var component = normalizer(
  script,
  render,
  staticRenderFns,
  false,
  null,
  null,
  null
  
)

export default component.exports
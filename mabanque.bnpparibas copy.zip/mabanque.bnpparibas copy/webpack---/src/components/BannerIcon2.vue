var render = function render(){var _vm=this,_c=_vm._self._c,_setup=_vm._self._setupProxy;return (_vm.banner.icon)?_c('div',{staticClass:"icon__container"},[_c('div',{staticClass:"icon__content",class:_vm.banner.icon})]):_vm._e()
}
var staticRenderFns = []

export { render, staticRenderFns }
var render = function render(){var _vm=this,_c=_vm._self._c,_setup=_vm._self._setupProxy;return _c('div',{staticClass:"banner selfcare-banner-celebrus",class:[_vm.banner.mainClass, _vm.banner.category]},[_c('udc-banner-generic',{attrs:{"banner":_vm.banner}}),(_vm.banner.isCross)?_c('div',{staticClass:"close-button-block"},[_c('a',{staticClass:"icon bnpp-icon close-banner",on:{"click":function($event){return _vm.methodList.onCloseClick(_vm.banner)}}})]):_vm._e()],1)
}
var staticRenderFns = []

export { render, staticRenderFns }
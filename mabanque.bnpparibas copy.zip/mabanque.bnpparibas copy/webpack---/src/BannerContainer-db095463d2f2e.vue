

import { Component, Prop, Vue } from "vue-property-decorator";

import UdcBannerRebond from "@/components/UdcBannerRebond.vue";
import UdcBannerPopin from "@/components/UdcBannerPopin.vue";
import UdcBannerAnimation from "@/components/UdcBannerAnimation.vue";
import UdcBannerSticky from "@/components/UdcBannerSticky.vue";
import BannerConfirmationVirement from "@/components/BannerConfirmationVirement.vue";


@Component({
  components: {
    UdcBannerRebond,
    UdcBannerPopin,
    UdcBannerAnimation,
    UdcBannerSticky,
    BannerConfirmationVirement
  }
})
export default class BannerContainer extends Vue {
  @Prop() private banner!: any;
  @Prop() private oldAttribute!: any;
  private observer =  new MutationObserver(() => { setTimeout(this.sendTrackingOnVisible, 100); });

  public mounted() {
    //On récupère les anciens attributs
     (this.oldAttribute).forEach((attribute) => { this.$el[Object.keys(attribute)[0]] = Object.values(attribute)[0] });
    // On écoute les events resize et scroll et la modification du DOM
    document.addEventListener("scroll", this.sendTrackingOnVisible);
    window.addEventListener("resize" , this.sendTrackingOnVisible);

    // On observe la mutation de l'Elément dans lequel est inséré la popin
    document.querySelectorAll("#udc-banner-popin").forEach((target) => { 
      this.observer.observe( target, {childList: true});
    });
    this.sendTrackingOnVisible();
  }

  public data() {
    return {
      blockOrder: this.getOrder()
    };
  }

  private getOrder() {
    if (this.banner.messageWeight) {
      return -this.banner.messageWeight;
    }
  }

  private sendTrackingOnVisible() {
    const targetContainer = this.$el;
    const targetBanner = targetContainer?.querySelector( ".banner" ) || targetContainer?.querySelector( "[role=dialog]" );


    if (targetContainer != null && targetBanner != null ) {
      const targetPosition = targetBanner.getBoundingClientRect();
      // Conditions de visibilité

      const isTargetVisible = (window.innerHeight - targetPosition.top) / targetPosition.height * 100 > 90 &&
                              targetPosition.top + targetPosition.height > targetPosition.height * 0.9 &&
                              targetBanner.getBoundingClientRect().height > 0 &&
                              window.getComputedStyle(targetBanner).visibility !== "hidden" &&
                              window.getComputedStyle(targetBanner).display !== "none" &&
                              (targetContainer as HTMLElement).offsetParent !== null;

      // Test des condition de visibilité
      if (isTargetVisible) {
        this.runBannerTracking();

        // On enleve les évents et l'observateur pour éviter les doublons
        window.removeEventListener("resize", this.sendTrackingOnVisible);
        document.removeEventListener("scroll", this.sendTrackingOnVisible);
        this.observer.disconnect();
      }
    }
  }

  private runBannerTracking() {
    // Acknowledge banner display on Celebrus
    if (this.banner.celebrusHelper) {
      this.banner.celebrusHelper.extended();
    }
    // Acknowledge banner display on Adobe
    this.addAdobeTracking();
  }

  private createDigitalDataEntry() {
    const _entry = {
      Emplacement: this.banner.location,
      Nom: this.banner.messageId,
      Provenance: "rtim",
      url: window.location.pathname
    };

    return _entry;
  }

  private addDigitalDataBannerEntry(banner) {
    try {
      (window as any).digitalData?.modules?.crmd?.banners?.push(banner);
    } catch (e) {
      // console.log(e);
    }
  }

  private addAdobeTracking() {
    this.addDigitalDataBannerEntry(this.createDigitalDataEntry());
  }

  private async onCloseClick() {
    window.dispatchEvent(
      new CustomEvent(`rtim-banner:${this.banner.location}`, {
        detail: {
          content: {},
          placement: {
            id: this.banner.location,
            size: "1260x630",
            zone: "udc-top"
          }
        }
      })
    );
    this.banner.celebrusHelper.refused();
  }
}

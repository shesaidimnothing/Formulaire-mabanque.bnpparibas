export default {
  Gab01: {
    class: "mainContent",
    comp: [
      {
        class: "part1",
        comp: [
          {
            class: "partStart",
            comp: [
              {
                class: "bannerImg",
                comp: "Banner-img"
              }
            ]
          },
          {
            class: "partCenter",
            comp: [
              {
                class: "bannerContent",
                comp: "banner-content"
              },
              {
                class: "bannerButton",
                comp: "banner-button"
              }
            ]
          },
          {
            class: "partMention",
            comp: [
              {
                class: "bannerPolicy",
                comp: "banner-policy"
              }
            ]
          }
        ]
      }
    ]
  },
  Gab02: {
    class: "mainClass",
    comp: [
      {
        class: "banner-container",
        comp: [
          {
            comp: "banner-icon"
          },
          {
            class: "details",
            comp: [
              {
                comp: "banner-content"
              },
              {
                comp: "banner-button"
              }
            ]
          }
        ]
      },
      {
        comp: [
          {
            class: "bannerPolicy",
            comp: "banner-policy"
          }
        ]
      }
    ]
  },
  Gab03: {
    class: "parentclass1",
    comp: [
      {
        class: "bannerImg",
        comp: "Banner-img"
      },
      {
        class: "bannerIcon",
        comp: "Banner-icon"
      },
      {
        class: "parentclass2",
        comp: [
          {
            class: "bannerContent",
            comp: "Banner-content"
          },
          {
            class: "bannerButton",
            comp: "Banner-button"
          }
        ]
      }
    ]
  },
  Gab04: {
    class: "parentclass1",
    comp: [
      {
        class: "parentclass2",
        comp: [
          {
            class: "bannerContent",
            comp: "Banner-content"
          },
          {
            class: "bannerButton",
            comp: "banner-button"
          }
        ]
      }
    ]
  },
  Gab05: {
    class: "parentclass1",
    comp: [
      {
        comp: "banner-dsp2-kyc"
      }
    ]
  },
  Gab07: {
    class: "mainClass",
    comp: [
      {
        class: "banner__container",
        comp: [
          {
            class: "BannerHtmlText",
            comp: "banner-html-text"
          },
          {
            class: "bannerMain",
            comp: [
              {
                class: "bannerIcon",
                comp: "banner-icon"
              },
              {
                class: "banner__wrap banner__caret",
                comp: [
                  {
                    class: "bannerContent",
                    comp: "banner-content"
                  },
                  {
                    class: "bannerButton",
                    comp: "banner-button"
                  }
                ]
              }
            ]
          }
        ]
      },
      {
        comp: [
          {
            class: "bannerPolicy",
            comp: "banner-policy"
          }
        ]
      }
    ]
  },
  Gab10: {
    class: "mainClass",
    comp: [
      {
        class: "banner-container",
        comp: [
          {
            comp: "banner-img"
          },
          {
            class: "details",
            comp: [
              {
                comp: "banner-content"
              },
              {
                comp: "banner-button"
              }
            ]
          }
        ]
      }
    ]
  },
  Gab11: {
    class: "mainClass",
    comp: [
      {
        class: "banner-container",
        comp: [
          {
            comp: "banner-icon"
          },
          {
            class: "details",
            comp: [
              {
                comp: "banner-content"
              },
              {
                comp: "banner-button"
              }
            ]
          }
        ]
      }
    ]
  },
  Gab12: {
    class: "mainClass",
    comp: [
      {
        class: "banner-container",
        comp: [
          {
            comp: "banner-icon"
          },
          {
            class: "details",
            comp: [
              {
                comp: "banner-content"
              },
              {
                comp: "banner-button"
              }
            ]
          }
        ]
      }
    ]
  },
  Gab13: {
    class: "mainContent",
    comp: [
      {
        class: "part1",
        comp: [
          {
            class: "titleContainer",
            comp: [
              {
                class: "BannerHtmlText",
                comp: "banner-content"
              }
            ]
          },
          {
            class: "bannerButton",
            comp: "banner-button"
          }
        ]
      },
      {
        class: "part2",
        comp: [
          {
            class: "bannerPolicy",
            comp: "banner-policy"
          }
        ]
      },
      {
        class: "iconCorner",
        comp: [
          {
            class: "inner",
            comp: [
              {
                class: "bannerIcon",
                comp: "banner-icon"
              }
            ]
          }
        ]
      }
    ]
  },
  Gab14: {
    class: "mainClass",
    comp: [
      {
        class: "banner__container",
        comp: [
          {
            class: "bannerMain",
            comp: [
              {
                class: "bannerIcon",
                comp: "banner-icon"
              },
              {
                class: "banner__wrap banner__caret",
                comp: [{
                    class: "part1",
                    comp: [
                      {
                        class: "bannerContent",
                        comp: "banner-content"
                      },
                      {
                        class: "bannerButton",
                        comp: "banner-button"
                      }
                    ]
                  },
                  {
                    class: "part2",
                    comp: [
                      {
                        class: "bannerPolicy",
                        comp: "banner-policy"
                      }
                    ]
                  }
                ]
              }
            ]
          }
        ]
      }
    ]
  },
  Gab15: {
    class: "mainContent",
    comp: [
      {
        class: "iconCorner",
        comp: [
          {
            class: "inner",
            comp: [
              {
                class: "bannerIcon",
                comp: "banner-icon"
              }
            ]
          }
        ]
      },
      {
        class: "part1",
        comp: [
          {
            class: "titleContainer",
            comp: [
              {
                class: "BannerHtmlText",
                comp: "banner-content"
              }
            ]
          },
          {
            class: "bannerButton",
            comp: "banner-button"
          }
        ]
      },
      {
        class: "part2",
        comp: [
          {
            class: "bannerPolicy",
            comp: "banner-policy"
          }
        ]
      }
    ]
  },
  Gab17: {
    class: "mainContent",
    comp: [
      {
        class: "part1",
        comp: [
          {
            class: "blockLeft",
            comp: [
              {
                class: "block1",
                comp: [
                  {
                    class: "bannerIcon",
                    comp: "banner-icon"
                  },
                  {
                    class: "BannerContent",
                    comp: "banner-content"
                  }
                ]
              },
              {
                class: "block2",
                comp: [
                  {
                    class: "BannerHtmlText",
                    comp: "banner-html-text"
                  }
                ]
              }
            ]
          },
          {
            class: "blockRight",
            comp: [
              {
                class: "bannerButton",
                comp: "banner-button"
              }
            ]
          }
        ]
      },
      {
        class: "part2",
        comp: [
          {
            class: "bannerPolicy",
            comp: "banner-policy"
          }
        ]
      }
    ]
  },
  Gab18: {
    class: "mainContent",
    comp: [
      {
        class: "part1",
        comp: [
          {
            class: "titleContainer",
            comp: [
              {
                class: "bannerIcon",
                comp: "banner-icon"
              },
              {
                class: "BannerHtmlText",
                comp: "banner-html-text"
              }
            ]
          },
          {
            class: "bannerContent",
            comp: "banner-content"
          },
          {
            class: "bannerButton",
            comp: "banner-button"
          }
        ]
      },
      {
        class: "part2",
        comp: [
          {
            class: "bannerPolicy",
            comp: "banner-policy"
          }
        ]
      }
    ]
  },
  Gab19: {
    class: "mainContent",
    comp: [
      {
        class: "part1",
        comp: [
          {
            class: "partStart",
            comp: [
              {
                class: "bannerIcon2",
                comp: "banner-icon-2"
              }
            ]
          },
          {
            class: "partCenter",
            comp: [
              {
                class: "bannerContent",
                comp: "banner-content"
              },
              {
                class: "bannerButton",
                comp: "banner-button"
              }
            ]
          },
          {
            class: "partMention",
            comp: [
              {
                class: "bannerPolicy",
                comp: "banner-policy"
              }
            ]
          }
        ]
      }
    ]
  },
  Gab20: {
    comp: "banner-empty"
  }
};

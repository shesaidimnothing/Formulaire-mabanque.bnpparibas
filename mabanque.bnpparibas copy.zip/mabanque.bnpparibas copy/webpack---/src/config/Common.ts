import { Events } from "vue/types/jsx";

const methodList = {
    trackLaunchCTA : ( banner, cta="" ) => {
      if (!!window.hasOwnProperty("_satellite")) {
        const getHtmlLabel = (labelEntry) => {
          let htmlElem = document.createElement('div');
          htmlElem.innerHTML = labelEntry;
          return htmlElem.innerText.trim();
        }
        (window as any)._satellite.track("DCRMBannerCTA", {   label: !!banner.clickableBanner && cta == "zoneClickable" ? "Zone clickable" : getHtmlLabel(banner[cta+"Text"]),
                                                              placement: banner.location,
                                                              campaign: banner.messageId
                                                          });
      }
    },

    onCtaClick: function (banner,cta) {
      if ( banner[`${cta}URL`] === "https://cookieconsent" ) return;
      if ( banner[`${cta}Webcallback`] ) return;

      if ( !!banner[`${cta}Reponse`] ) {
        if( /(accepted|refused)$/i.test(banner[`${cta}Reponse`])) {
          banner.celebrusHelper[banner[`${cta}Reponse`]]();
        }else{
          banner.celebrusHelper.custom( banner[`${cta}Reponse`] );
        } 
      }

      // Envoi du formulaire
      const target = (event.target as Element).matches('button') ? event.target as HTMLFormElement : (event.target as HTMLFormElement).closest('button');
      const form = (target as Element).closest("form");
      
      form.addEventListener( "submit", () => { if (banner[`${cta}KeepBanner`] !== "true") methodList.getEmptyBanner(banner) } );
      form.setAttribute('target',target.getAttribute('formtarget'));
      form.setAttribute('action',target.getAttribute('formaction'));
      form.setAttribute('method',target.getAttribute('formmethod'));
      form.submit();      
    },

    onCloseClick: function (banner) {
      if ( !!banner.crossAnswer ) {
        if ( /(refused|accepted)$/i.test(banner.crossAnswer) ) {
          banner.celebrusHelper[banner.crossAnswer]();
        }else{
          banner.celebrusHelper.custom(banner.crossAnswer);
        }
      } else {
        banner.celebrusHelper.refused();
      }

      window.dispatchEvent(
        new CustomEvent(`rtim-banner:${banner.location}`, {
          detail: {
            content: {emplacement: "udc-banner-animation", nom_gabarit: "Gab20"},
            placement: {
              id: banner.location,
              size: "1260x630",
              zone: "udc-top"
            }
          }
        })
      );
    },

    getEmptyBanner: (banner) => {
        window.dispatchEvent(
          new CustomEvent(`rtim-banner:${banner.location}`, {
            detail: {
              content: {
                emplacement: banner.location,
                nom_gabarit: "Gab20",
              },
              placement: {
                id: banner.location,
                size: "1260x630",
                zone: "udc-top",
              },
            },
          })
        );
    }
};

export default methodList;

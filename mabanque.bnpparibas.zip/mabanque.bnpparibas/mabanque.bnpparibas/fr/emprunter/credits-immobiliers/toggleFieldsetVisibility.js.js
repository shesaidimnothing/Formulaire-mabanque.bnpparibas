
  let isFirstDisplayed = false;

  function executeFirst() {
    const selecteurRegion = document.querySelector('.form-control');
    selecteurRegion.addEventListener('change', (event) => {
      const topFieldset = document.getElementById('top-fieldset');
      const hiddenElements = topFieldset.querySelectorAll('[style*="display: none;"]');
      if (event.target.value !== '') {
        hiddenElements.forEach((element) => {
          element.style.display = 'block';
        });
        isFirstDisplayed = true;
      } else {
        hiddenElements.forEach((element) => {
          element.style.display = 'none';
        });
        isFirstDisplayed = false;
      }
    });
  }

  function executeSecond() {
    if (!isFirstDisplayed) {
      console.error('Le premier script doit être exécuté (affiché) avant le deuxième.');
      return;
    }

    const showMoreButton = document.getElementById('showMoreOption');
    showMoreButton.addEventListener('click', () => {
      const optionsFieldset = document.getElementById('options');
      optionsFieldset.style.display = 'block';
    });
  }

  function executeThird() {
    if (!isFirstDisplayed) {
      console.error('Le premier script doit être exécuté (affiché) avant le troisième.');
      return;
    }

    document.getElementById('show-resultat').addEventListener('click', function() {
      const selects = document.querySelectorAll('select');
      let allSelected = true;

      selects.forEach(select => {
        if (select.value === '') {
          allSelected = false;
        }
      });

      if (allSelected) {
        document.getElementById('resultats').style.display = 'block';
      } else {
        console.error('Tous les sélecteurs doivent avoir une option sélectionnée.');
      }
    });
  }

  document.addEventListener('DOMContentLoaded', () => {
    executeFirst();

    // écouter pour savoir si on doit faire tourner le 2ème script si les conditions sont remplies
    document.querySelector('.form-control').addEventListener('change', () => {
      if (isFirstDisplayed) {
        executeSecond();
      }
    });

    // écouter pour savoir si on doit faire tourner le 3ème script si les conditions sont remplies
    document.getElementById('showMoreOption').addEventListener('click', () => {
      if (isFirstDisplayed) {
        executeThird();
      }
    });

    // faire marcher le troisième script après l'interaction avec le premier script
    document.querySelector('.form-control').addEventListener('change', () => {
      if (isFirstDisplayed) {
        executeThird();
      }
    });
  });

  document.querySelector('#formSimuLoyer').addEventListener('submit',(event)=> {
    event.preventDefault();
  })
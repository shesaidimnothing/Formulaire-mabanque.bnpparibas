document.addEventListener('DOMContentLoaded', (event) => {
    const optionsList = document.getElementById('u_options');
    const selectedList = document.getElementById('s_options');
    const addButton = document.querySelector('.js-add-to-selected');
    const removeButton = document.querySelector('.js-remove-from-selected');
  
  // Fonction pour ajouter un élément à la liste sélectionnée par ordre alphabétique  
    const addToSelected = (item) => {
      const selectedItemText = item.textContent.trim().toLowerCase();
      const itemsInSelected = Array.from(selectedList.children);
  
  // Trouver la bonne position pour maintenir l'ordre alphabétique
      let insertIndex = itemsInSelected.findIndex(li => {
        const text = li.textContent.trim().toLowerCase();
        return text > selectedItemText;
      });
  
  // Si aucune position n'est trouvée, insérez à la fin
      if (insertIndex === -1) {
        insertIndex = itemsInSelected.length;
      }
  
  // Insère l'élément dans la liste sélectionnée à la position déterminée
      selectedList.insertBefore(item, selectedList.children[insertIndex]);
    };
  
  // Fonction pour supprimer un élément de la liste sélectionnée et maintenir l'ordre alphabétique dans la liste des options
    const removeFromSelected = (item) => {
      const removedItemText = item.textContent.trim().toLowerCase();
      const itemsInOptions = Array.from(optionsList.children);
  
  // Trouver la bonne position pour maintenir l'ordre alphabétique
      let insertIndex = itemsInOptions.findIndex(li => {
        const text = li.textContent.trim().toLowerCase();
        return text > removedItemText;
      });
  
  // Si aucune position n'est trouvée, insérez à la fin
      if (insertIndex === -1) {
        insertIndex = itemsInOptions.length;
      }
  
  // Insère l'élément dans la liste d'options à la position déterminée
      optionsList.insertBefore(item, optionsList.children[insertIndex]);
    };
  
    optionsList.addEventListener('click', (e) => {
      const target = e.target;
      if (target.tagName === 'LI') {
        target.classList.toggle('highlight');
      }
    });
  
    selectedList.addEventListener('click', (e) => {
      const target = e.target;
      if (target.tagName === 'LI') {
        target.classList.toggle('highlight');
      }
    });
  
    addButton.addEventListener('click', () => {
      const highlightedItems = optionsList.querySelectorAll('.highlight');
      highlightedItems.forEach(item => {
        item.classList.remove('highlight');
        addToSelected(item); // Ajouter à la liste sélectionnée par ordre alphabétique
      });
    });
  
    removeButton.addEventListener('click', () => {
      const highlightedItems = selectedList.querySelectorAll('.highlight');
      highlightedItems.forEach(item => {
        item.classList.remove('highlight');
        removeFromSelected(item); // Supprimer de la liste sélectionnée et conserver l'ordre alphabétique dans la liste des options
      });
    });
  });
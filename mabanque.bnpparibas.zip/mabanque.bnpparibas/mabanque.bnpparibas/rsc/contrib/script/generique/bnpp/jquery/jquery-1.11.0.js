! function(e, t, n, r, i, o, a, s) {
    ! function(e, t) {
        "object" == typeof s && "object" == typeof s.exports ? s.exports = e.document ? t(e, !0) : function(e) {
            if (!e.document) throw new Error("jQuery requires a window with a document");
            return t(e)
        } : t(e)
    }("undefined" != typeof e ? e : this, function(e, t) {
        function n(e) {
            var t = e.length,
                n = at.type(e);
            return "function" === n || at.isWindow(e) ? !1 : 1 === e.nodeType && t ? !0 : "array" === n || 0 === t || "number" == typeof t && t > 0 && t - 1 in e
        }

        function r(e, t, n) {
            if (at.isFunction(t)) return at.grep(e, function(e, r) {
                return !!t.call(e, r, e) !== n
            });
            if (t.nodeType) return at.grep(e, function(e) {
                return e === t !== n
            });
            if ("string" == typeof t) {
                if (ht.test(t)) return at.filter(t, e, n);
                t = at.filter(t, e)
            }
            return at.grep(e, function(e) {
                return at.inArray(e, t) >= 0 !== n
            })
        }

        function o(e, t) {
            do e = e[t]; while (e && 1 !== e.nodeType);
            return e
        }

        function a(e) {
            var t = Tt[e] = {};
            return at.each(e.match(wt) || [], function(e, n) {
                t[n] = !0
            }), t
        }

        function s() {
            gt.addEventListener ? (gt.removeEventListener("DOMContentLoaded", l, !1), e.removeEventListener("load", l, !1)) : (gt.detachEvent("onreadystatechange", l), e.detachEvent("onload", l))
        }

        function l() {
            (gt.addEventListener || "load" === event.type || "complete" === gt.readyState) && (s(), at.ready())
        }

        function u(e, t, n) {
            if (void 0 === n && 1 === e.nodeType) {
                var r = "data-" + t.replace(St, "-$1").toLowerCase();
                if (n = e.getAttribute(r), "string" == typeof n) {
                    try {
                        n = "true" === n ? !0 : "false" === n ? !1 : "null" === n ? null : +n + "" === n ? +n : kt.test(n) ? at.parseJSON(n) : n
                    } catch (i) {}
                    at.data(e, t, n)
                } else n = void 0
            }
            return n
        }

        function c(e) {
            var t;
            for (t in e)
                if (("data" !== t || !at.isEmptyObject(e[t])) && "toJSON" !== t) return !1;
            return !0
        }

        function d(e, t, n, r) {
            if (at.acceptData(e)) {
                var i, o, a = at.expando,
                    s = e.nodeType,
                    l = s ? at.cache : e,
                    u = s ? e[a] : e[a] && a;
                if (u && l[u] && (r || l[u].data) || void 0 !== n || "string" != typeof t) return u || (u = s ? e[a] = Y.pop() || at.guid++ : a), l[u] || (l[u] = s ? {} : {
                    toJSON: at.noop
                }), ("object" == typeof t || "function" == typeof t) && (r ? l[u] = at.extend(l[u], t) : l[u].data = at.extend(l[u].data, t)), o = l[u], r || (o.data || (o.data = {}), o = o.data), void 0 !== n && (o[at.camelCase(t)] = n), "string" == typeof t ? (i = o[t], null == i && (i = o[at.camelCase(t)])) : i = o, i
            }
        }

        function f(e, t, n) {
            if (at.acceptData(e)) {
                var r, i, o = e.nodeType,
                    a = o ? at.cache : e,
                    s = o ? e[at.expando] : at.expando;
                if (a[s]) {
                    if (t && (r = n ? a[s] : a[s].data)) {
                        at.isArray(t) ? t = t.concat(at.map(t, at.camelCase)) : t in r ? t = [t] : (t = at.camelCase(t), t = t in r ? [t] : t.split(" ")), i = t.length;
                        for (; i--;) delete r[t[i]];
                        if (n ? !c(r) : !at.isEmptyObject(r)) return
                    }(n || (delete a[s].data, c(a[s]))) && (o ? at.cleanData([e], !0) : it.deleteExpando || a != a.window ? delete a[s] : a[s] = null)
                }
            }
        }

        function p() {
            return !0
        }

        function h() {
            return !1
        }

        function m() {
            try {
                return gt.activeElement
            } catch (e) {}
        }

        function g(e) {
            var t = Bt.split("|"),
                n = e.createDocumentFragment();
            if (n.createElement)
                for (; t.length;) n.createElement(t.pop());
            return n
        }

        function v(e, t) {
            var n, r, i = 0,
                o = typeof e.getElementsByTagName !== Et ? e.getElementsByTagName(t || "*") : typeof e.querySelectorAll !== Et ? e.querySelectorAll(t || "*") : void 0;
            if (!o)
                for (o = [], n = e.childNodes || e; null != (r = n[i]); i++) !t || at.nodeName(r, t) ? o.push(r) : at.merge(o, v(r, t));
            return void 0 === t || t && at.nodeName(e, t) ? at.merge([e], o) : o
        }

        function y(e) {
            Ht.test(e.type) && (e.defaultChecked = e.checked)
        }

        function b(e, t) {
            return at.nodeName(e, "table") && at.nodeName(11 !== t.nodeType ? t : t.firstChild, "tr") ? e.getElementsByTagName("tbody")[0] || e.appendChild(e.ownerDocument.createElement("tbody")) : e
        }

        function x(e) {
            return e.type = (null !== at.find.attr(e, "type")) + "/" + e.type, e
        }

        function w(e) {
            var t = Yt.exec(e.type);
            return t ? e.type = t[1] : e.removeAttribute("type"), e
        }

        function T(e, t) {
            for (var n, r = 0; null != (n = e[r]); r++) at._data(n, "globalEval", !t || at._data(t[r], "globalEval"))
        }

        function C(e, t) {
            if (1 === t.nodeType && at.hasData(e)) {
                var n, r, i, o = at._data(e),
                    a = at._data(t, o),
                    s = o.events;
                if (s) {
                    delete a.handle, a.events = {};
                    for (n in s)
                        for (r = 0, i = s[n].length; i > r; r++) at.event.add(t, n, s[n][r])
                }
                a.data && (a.data = at.extend({}, a.data))
            }
        }

        function N(e, t) {
            var n, r, i;
            if (1 === t.nodeType) {
                if (n = t.nodeName.toLowerCase(), !it.noCloneEvent && t[at.expando]) {
                    i = at._data(t);
                    for (r in i.events) at.removeEvent(t, r, i.handle);
                    t.removeAttribute(at.expando)
                }
                "script" === n && t.text !== e.text ? (x(t).text = e.text, w(t)) : "object" === n ? (t.parentNode && (t.outerHTML = e.outerHTML), it.html5Clone && e.innerHTML && !at.trim(t.innerHTML) && (t.innerHTML = e.innerHTML)) : "input" === n && Ht.test(e.type) ? (t.defaultChecked = t.checked = e.checked, t.value !== e.value && (t.value = e.value)) : "option" === n ? t.defaultSelected = t.selected = e.defaultSelected : ("input" === n || "textarea" === n) && (t.defaultValue = e.defaultValue)
            }
        }

        function E(t, n) {
            var r = at(n.createElement(t)).appendTo(n.body),
                i = e.getDefaultComputedStyle ? e.getDefaultComputedStyle(r[0]).display : at.css(r[0], "display");
            return r.detach(), i
        }

        function k(e) {
            var t = gt,
                n = tn[e];
            return n || (n = E(e, t), "none" !== n && n || (en = (en || at("<iframe frameborder='0' width='0' height='0'/>")).appendTo(t.documentElement), t = (en[0].contentWindow || en[0].contentDocument).document, t.write(), t.close(), n = E(e, t), en.detach()), tn[e] = n), n
        }

        function S(e, t) {
            return {
                get: function() {
                    var n = e();
                    return null != n ? n ? (delete this.get, void 0) : (this.get = t).apply(this, arguments) : void 0
                }
            }
        }

        function A(e, t) {
            if (t in e) return t;
            for (var n = t.charAt(0).toUpperCase() + t.slice(1), r = t, i = mn.length; i--;)
                if (t = mn[i] + n, t in e) return t;
            return r
        }

        function D(e, t) {
            for (var n, r, i, o = [], a = 0, s = e.length; s > a; a++) r = e[a], r.style && (o[a] = at._data(r, "olddisplay"), n = r.style.display, t ? (o[a] || "none" !== n || (r.style.display = ""), "" === r.style.display && jt(r) && (o[a] = at._data(r, "olddisplay", k(r.nodeName)))) : o[a] || (i = jt(r), (n && "none" !== n || !i) && at._data(r, "olddisplay", i ? n : at.css(r, "display"))));
            for (a = 0; s > a; a++) r = e[a], r.style && (t && "none" !== r.style.display && "" !== r.style.display || (r.style.display = t ? o[a] || "" : "none"));
            return e
        }

        function j(e, t, n) {
            var r = dn.exec(t);
            return r ? Math.max(0, r[1] - (n || 0)) + (r[2] || "px") : t
        }

        function L(e, t, n, r, i) {
            for (var o = n === (r ? "border" : "content") ? 4 : "width" === t ? 1 : 0, a = 0; 4 > o; o += 2) "margin" === n && (a += at.css(e, n + Dt[o], !0, i)), r ? ("content" === n && (a -= at.css(e, "padding" + Dt[o], !0, i)), "margin" !== n && (a -= at.css(e, "border" + Dt[o] + "Width", !0, i))) : (a += at.css(e, "padding" + Dt[o], !0, i), "padding" !== n && (a += at.css(e, "border" + Dt[o] + "Width", !0, i)));
            return a
        }

        function H(e, t, n) {
            var r = !0,
                i = "width" === t ? e.offsetWidth : e.offsetHeight,
                o = nn(e),
                a = it.boxSizing() && "border-box" === at.css(e, "boxSizing", !1, o);
            if (0 >= i || null == i) {
                if (i = rn(e, t, o), (0 > i || null == i) && (i = e.style[t]), an.test(i)) return i;
                r = a && (it.boxSizingReliable() || i === e.style[t]), i = parseFloat(i) || 0
            }
            return i + L(e, t, n || (a ? "border" : "content"), r, o) + "px"
        }

        function q(e, t, n, r, i) {
            return new q.prototype.init(e, t, n, r, i)
        }

        function _() {
            return setTimeout(function() {
                gn = void 0
            }), gn = at.now()
        }

        function M(e, t) {
            var n, r = {
                    height: e
                },
                i = 0;
            for (t = t ? 1 : 0; 4 > i; i += 2 - t) n = Dt[i], r["margin" + n] = r["padding" + n] = e;
            return t && (r.opacity = r.width = e), r
        }

        function F(e, t, n) {
            for (var r, i = (Tn[t] || []).concat(Tn["*"]), o = 0, a = i.length; a > o; o++)
                if (r = i[o].call(n, t, e)) return r
        }

        function O(e, t, n) {
            var r, i, o, a, s, l, u, c, d = this,
                f = {},
                p = e.style,
                h = e.nodeType && jt(e),
                m = at._data(e, "fxshow");
            n.queue || (s = at._queueHooks(e, "fx"), null == s.unqueued && (s.unqueued = 0, l = s.empty.fire, s.empty.fire = function() {
                s.unqueued || l()
            }), s.unqueued++, d.always(function() {
                d.always(function() {
                    s.unqueued--, at.queue(e, "fx").length || s.empty.fire()
                })
            })), 1 === e.nodeType && ("height" in t || "width" in t) && (n.overflow = [p.overflow, p.overflowX, p.overflowY], u = at.css(e, "display"), c = k(e.nodeName), "none" === u && (u = c), "inline" === u && "none" === at.css(e, "float") && (it.inlineBlockNeedsLayout && "inline" !== c ? p.zoom = 1 : p.display = "inline-block")), n.overflow && (p.overflow = "hidden", it.shrinkWrapBlocks() || d.always(function() {
                p.overflow = n.overflow[0], p.overflowX = n.overflow[1], p.overflowY = n.overflow[2]
            }));
            for (r in t)
                if (i = t[r], yn.exec(i)) {
                    if (delete t[r], o = o || "toggle" === i, i === (h ? "hide" : "show")) {
                        if ("show" !== i || !m || void 0 === m[r]) continue;
                        h = !0
                    }
                    f[r] = m && m[r] || at.style(e, r)
                }
            if (!at.isEmptyObject(f)) {
                m ? "hidden" in m && (h = m.hidden) : m = at._data(e, "fxshow", {}), o && (m.hidden = !h), h ? at(e).show() : d.done(function() {
                    at(e).hide()
                }), d.done(function() {
                    var t;
                    at._removeData(e, "fxshow");
                    for (t in f) at.style(e, t, f[t])
                });
                for (r in f) a = F(h ? m[r] : 0, r, d), r in m || (m[r] = a.start, h && (a.end = a.start, a.start = "width" === r || "height" === r ? 1 : 0))
            }
        }

        function B(e, t) {
            var n, r, i, o, a;
            for (n in e)
                if (r = at.camelCase(n), i = t[r], o = e[n], at.isArray(o) && (i = o[1], o = e[n] = o[0]), n !== r && (e[r] = o, delete e[n]), a = at.cssHooks[r], a && "expand" in a) {
                    o = a.expand(o), delete e[r];
                    for (n in o) n in e || (e[n] = o[n], t[n] = i)
                } else t[r] = i
        }

        function P(e, t, n) {
            var r, i, o = 0,
                a = wn.length,
                s = at.Deferred().always(function() {
                    delete l.elem
                }),
                l = function() {
                    if (i) return !1;
                    for (var t = gn || _(), n = Math.max(0, u.startTime + u.duration - t), r = n / u.duration || 0, o = 1 - r, a = 0, l = u.tweens.length; l > a; a++) u.tweens[a].run(o);
                    return s.notifyWith(e, [u, o, n]), 1 > o && l ? n : (s.resolveWith(e, [u]), !1)
                },
                u = s.promise({
                    elem: e,
                    props: at.extend({}, t),
                    opts: at.extend(!0, {
                        specialEasing: {}
                    }, n),
                    originalProperties: t,
                    originalOptions: n,
                    startTime: gn || _(),
                    duration: n.duration,
                    tweens: [],
                    createTween: function(t, n) {
                        var r = at.Tween(e, u.opts, t, n, u.opts.specialEasing[t] || u.opts.easing);
                        return u.tweens.push(r), r
                    },
                    stop: function(t) {
                        var n = 0,
                            r = t ? u.tweens.length : 0;
                        if (i) return this;
                        for (i = !0; r > n; n++) u.tweens[n].run(1);
                        return t ? s.resolveWith(e, [u, t]) : s.rejectWith(e, [u, t]), this
                    }
                }),
                c = u.props;
            for (B(c, u.opts.specialEasing); a > o; o++)
                if (r = wn[o].call(u, e, c, u.opts)) return r;
            return at.map(c, F, u), at.isFunction(u.opts.start) && u.opts.start.call(e, u), at.fx.timer(at.extend(l, {
                elem: e,
                anim: u,
                queue: u.opts.queue
            })), u.progress(u.opts.progress).done(u.opts.done, u.opts.complete).fail(u.opts.fail).always(u.opts.always)
        }

        function R(e) {
            return function(t, n) {
                "string" != typeof t && (n = t, t = "*");
                var r, i = 0,
                    o = t.toLowerCase().match(wt) || [];
                if (at.isFunction(n))
                    for (; r = o[i++];) "+" === r.charAt(0) ? (r = r.slice(1) || "*", (e[r] = e[r] || []).unshift(n)) : (e[r] = e[r] || []).push(n)
            }
        }

        function W(e, t, n, r) {
            function i(s) {
                var l;
                return o[s] = !0, at.each(e[s] || [], function(e, s) {
                    var u = s(t, n, r);
                    return "string" != typeof u || a || o[u] ? a ? !(l = u) : void 0 : (t.dataTypes.unshift(u), i(u), !1)
                }), l
            }
            var o = {},
                a = e === Un;
            return i(t.dataTypes[0]) || !o["*"] && i("*")
        }

        function $(e, t) {
            var n, r, i = at.ajaxSettings.flatOptions || {};
            for (r in t) void 0 !== t[r] && ((i[r] ? e : n || (n = {}))[r] = t[r]);
            return n && at.extend(!0, e, n), e
        }

        function z(e, t, n) {
            for (var r, i, o, a, s = e.contents, l = e.dataTypes;
                "*" === l[0];) l.shift(), void 0 === i && (i = e.mimeType || t.getResponseHeader("Content-Type"));
            if (i)
                for (a in s)
                    if (s[a] && s[a].test(i)) {
                        l.unshift(a);
                        break
                    }
            if (l[0] in n) o = l[0];
            else {
                for (a in n) {
                    if (!l[0] || e.converters[a + " " + l[0]]) {
                        o = a;
                        break
                    }
                    r || (r = a)
                }
                o = o || r
            }
            return o ? (o !== l[0] && l.unshift(o), n[o]) : void 0
        }

        function I(e, t, n, r) {
            var i, o, a, s, l, u = {},
                c = e.dataTypes.slice();
            if (c[1])
                for (a in e.converters) u[a.toLowerCase()] = e.converters[a];
            for (o = c.shift(); o;)
                if (e.responseFields[o] && (n[e.responseFields[o]] = t), !l && r && e.dataFilter && (t = e.dataFilter(t, e.dataType)), l = o, o = c.shift())
                    if ("*" === o) o = l;
                    else if ("*" !== l && l !== o) {
                if (a = u[l + " " + o] || u["* " + o], !a)
                    for (i in u)
                        if (s = i.split(" "), s[1] === o && (a = u[l + " " + s[0]] || u["* " + s[0]])) {
                            a === !0 ? a = u[i] : u[i] !== !0 && (o = s[0], c.unshift(s[1]));
                            break
                        }
                if (a !== !0)
                    if (a && e["throws"]) t = a(t);
                    else try {
                        t = a(t)
                    } catch (d) {
                        return {
                            state: "parsererror",
                            error: a ? d : "No conversion from " + l + " to " + o
                        }
                    }
            }
            return {
                state: "success",
                data: t
            }
        }

        function X(e, t, n, r) {
            var i;
            if (at.isArray(t)) at.each(t, function(t, i) {
                n || Gn.test(e) ? r(e, i) : X(e + "[" + ("object" == typeof i ? t : "") + "]", i, n, r)
            });
            else if (n || "object" !== at.type(t)) r(e, t);
            else
                for (i in t) X(e + "[" + i + "]", t[i], n, r)
        }

        function U() {
            try {
                return new e.XMLHttpRequest
            } catch (t) {}
        }

        function V() {
            try {
                return new e.ActiveXObject("Microsoft.XMLHTTP")
            } catch (t) {}
        }

        function J(e) {
            return at.isWindow(e) ? e : 9 === e.nodeType ? e.defaultView || e.parentWindow : !1
        }
        var Y = [],
            G = Y.slice,
            Q = Y.concat,
            K = Y.push,
            Z = Y.indexOf,
            et = {},
            tt = et.toString,
            nt = et.hasOwnProperty,
            rt = "".trim,
            it = {},
            ot = "1.11.0",
            at = function(e, t) {
                return new at.fn.init(e, t)
            },
            st = /^[\s\uFEFF\xA0]+|[\s\uFEFF\xA0]+$/g,
            lt = /^-ms-/,
            ut = /-([\da-z])/gi,
            ct = function(e, t) {
                return t.toUpperCase()
            };
        at.fn = at.prototype = {
            jquery: ot,
            constructor: at,
            selector: "",
            length: 0,
            toArray: function() {
                return G.call(this)
            },
            get: function(e) {
                return null != e ? 0 > e ? this[e + this.length] : this[e] : G.call(this)
            },
            pushStack: function(e) {
                var t = at.merge(this.constructor(), e);
                return t.prevObject = this, t.context = this.context, t
            },
            each: function(e, t) {
                return at.each(this, e, t)
            },
            map: function(e) {
                return this.pushStack(at.map(this, function(t, n) {
                    return e.call(t, n, t)
                }))
            },
            slice: function() {
                return this.pushStack(G.apply(this, arguments))
            },
            first: function() {
                return this.eq(0)
            },
            last: function() {
                return this.eq(-1)
            },
            eq: function(e) {
                var t = this.length,
                    n = +e + (0 > e ? t : 0);
                return this.pushStack(n >= 0 && t > n ? [this[n]] : [])
            },
            end: function() {
                return this.prevObject || this.constructor(null)
            },
            push: K,
            sort: Y.sort,
            splice: Y.splice
        }, at.extend = at.fn.extend = function() {
            var e, t, n, r, i, o, a = arguments[0] || {},
                s = 1,
                l = arguments.length,
                u = !1;
            for ("boolean" == typeof a && (u = a, a = arguments[s] || {}, s++), "object" == typeof a || at.isFunction(a) || (a = {}), s === l && (a = this, s--); l > s; s++)
                if (null != (i = arguments[s]))
                    for (r in i) e = a[r], n = i[r], a !== n && (u && n && (at.isPlainObject(n) || (t = at.isArray(n))) ? (t ? (t = !1, o = e && at.isArray(e) ? e : []) : o = e && at.isPlainObject(e) ? e : {}, a[r] = at.extend(u, o, n)) : void 0 !== n && (a[r] = n));
            return a
        }, at.extend({
            expando: "jQuery" + (ot + Math.random()).replace(/\D/g, ""),
            isReady: !0,
            error: function(e) {
                throw new Error(e)
            },
            noop: function() {},
            isFunction: function(e) {
                return "function" === at.type(e)
            },
            isArray: Array.isArray || function(e) {
                return "array" === at.type(e)
            },
            isWindow: function(e) {
                return null != e && e == e.window
            },
            isNumeric: function(e) {
                return e - parseFloat(e) >= 0
            },
            isEmptyObject: function(e) {
                var t;
                for (t in e) return !1;
                return !0
            },
            isPlainObject: function(e) {
                var t;
                if (!e || "object" !== at.type(e) || e.nodeType || at.isWindow(e)) return !1;
                try {
                    if (e.constructor && !nt.call(e, "constructor") && !nt.call(e.constructor.prototype, "isPrototypeOf")) return !1
                } catch (n) {
                    return !1
                }
                if (it.ownLast)
                    for (t in e) return nt.call(e, t);
                for (t in e);
                return void 0 === t || nt.call(e, t)
            },
            type: function(e) {
                return null == e ? e + "" : "object" == typeof e || "function" == typeof e ? et[tt.call(e)] || "object" : typeof e
            },
            globalEval: function(t) {
                t && at.trim(t) && (e.execScript || function(t) {
                    e.eval.call(e, t)
                })(t)
            },
            camelCase: function(e) {
                return e.replace(lt, "ms-").replace(ut, ct)
            },
            nodeName: function(e, t) {
                return e.nodeName && e.nodeName.toLowerCase() === t.toLowerCase()
            },
            each: function(e, t, r) {
                var i, o = 0,
                    a = e.length,
                    s = n(e);
                if (r) {
                    if (s)
                        for (; a > o && (i = t.apply(e[o], r), i !== !1); o++);
                    else
                        for (o in e)
                            if (i = t.apply(e[o], r), i === !1) break
                } else if (s)
                    for (; a > o && (i = t.call(e[o], o, e[o]), i !== !1); o++);
                else
                    for (o in e)
                        if (i = t.call(e[o], o, e[o]), i === !1) break;
                return e
            },
            trim: rt && !rt.call(" ") ? function(e) {
                return null == e ? "" : rt.call(e)
            } : function(e) {
                return null == e ? "" : (e + "").replace(st, "")
            },
            makeArray: function(e, t) {
                var r = t || [];
                return null != e && (n(Object(e)) ? at.merge(r, "string" == typeof e ? [e] : e) : K.call(r, e)), r
            },
            inArray: function(e, t, n) {
                var r;
                if (t) {
                    if (Z) return Z.call(t, e, n);
                    for (r = t.length, n = n ? 0 > n ? Math.max(0, r + n) : n : 0; r > n; n++)
                        if (n in t && t[n] === e) return n
                }
                return -1
            },
            merge: function(e, t) {
                for (var n = +t.length, r = 0, i = e.length; n > r;) e[i++] = t[r++];
                if (n !== n)
                    for (; void 0 !== t[r];) e[i++] = t[r++];
                return e.length = i, e
            },
            grep: function(e, t, n) {
                for (var r, i = [], o = 0, a = e.length, s = !n; a > o; o++) r = !t(e[o], o), r !== s && i.push(e[o]);
                return i
            },
            map: function(e, t, r) {
                var i, o = 0,
                    a = e.length,
                    s = n(e),
                    l = [];
                if (s)
                    for (; a > o; o++) i = t(e[o], o, r), null != i && l.push(i);
                else
                    for (o in e) i = t(e[o], o, r), null != i && l.push(i);
                return Q.apply([], l)
            },
            guid: 1,
            proxy: function(e, t) {
                var n, r, i;
                return "string" == typeof t && (i = e[t], t = e, e = i), at.isFunction(e) ? (n = G.call(arguments, 2), r = function() {
                    return e.apply(t || this, n.concat(G.call(arguments)))
                }, r.guid = e.guid = e.guid || at.guid++, r) : void 0
            },
            now: function() {
                return +new Date
            },
            support: it
        }), at.each("Boolean Number String Function Array Date RegExp Object Error".split(" "), function(e, t) {
            et["[object " + t + "]"] = t.toLowerCase()
        });
        var dt = function(e) {
            function t(e, t, n, r) {
                var i, o, a, s, l, u, d, h, m, g;
                if ((t ? t.ownerDocument || t : R) !== H && L(t), t = t || H, n = n || [], !e || "string" != typeof e) return n;
                if (1 !== (s = t.nodeType) && 9 !== s) return [];
                if (_ && !r) {
                    if (i = yt.exec(e))
                        if (a = i[1]) {
                            if (9 === s) {
                                if (o = t.getElementById(a), !o || !o.parentNode) return n;
                                if (o.id === a) return n.push(o), n
                            } else if (t.ownerDocument && (o = t.ownerDocument.getElementById(a)) && B(t, o) && o.id === a) return n.push(o), n
                        } else {
                            if (i[2]) return Z.apply(n, t.getElementsByTagName(e)), n;
                            if ((a = i[3]) && C.getElementsByClassName && t.getElementsByClassName) return Z.apply(n, t.getElementsByClassName(a)), n
                        }
                    if (C.qsa && (!M || !M.test(e))) {
                        if (h = d = P, m = t, g = 9 === s && e, 1 === s && "object" !== t.nodeName.toLowerCase()) {
                            for (u = f(e), (d = t.getAttribute("id")) ? h = d.replace(xt, "\\$&") : t.setAttribute("id", h), h = "[id='" + h + "'] ", l = u.length; l--;) u[l] = h + p(u[l]);
                            m = bt.test(e) && c(t.parentNode) || t, g = u.join(",")
                        }
                        if (g) try {
                            return Z.apply(n, m.querySelectorAll(g)), n
                        } catch (v) {} finally {
                            d || t.removeAttribute("id")
                        }
                    }
                }
                return w(e.replace(lt, "$1"), t, n, r)
            }

            function n() {
                function e(n, r) {
                    return t.push(n + " ") > N.cacheLength && delete e[t.shift()], e[n + " "] = r
                }
                var t = [];
                return e
            }

            function r(e) {
                return e[P] = !0, e
            }

            function i(e) {
                var t = H.createElement("div");
                try {
                    return !!e(t)
                } catch (n) {
                    return !1
                } finally {
                    t.parentNode && t.parentNode.removeChild(t), t = null
                }
            }

            function o(e, t) {
                for (var n = e.split("|"), r = e.length; r--;) N.attrHandle[n[r]] = t
            }

            function a(e, t) {
                var n = t && e,
                    r = n && 1 === e.nodeType && 1 === t.nodeType && (~t.sourceIndex || J) - (~e.sourceIndex || J);
                if (r) return r;
                if (n)
                    for (; n = n.nextSibling;)
                        if (n === t) return -1;
                return e ? 1 : -1
            }

            function s(e) {
                return function(t) {
                    var n = t.nodeName.toLowerCase();
                    return "input" === n && t.type === e
                }
            }

            function l(e) {
                return function(t) {
                    var n = t.nodeName.toLowerCase();
                    return ("input" === n || "button" === n) && t.type === e
                }
            }

            function u(e) {
                return r(function(t) {
                    return t = +t, r(function(n, r) {
                        for (var i, o = e([], n.length, t), a = o.length; a--;) n[i = o[a]] && (n[i] = !(r[i] = n[i]))
                    })
                })
            }

            function c(e) {
                return e && typeof e.getElementsByTagName !== V && e
            }

            function d() {}

            function f(e, n) {
                var r, i, o, a, s, l, u, c = I[e + " "];
                if (c) return n ? 0 : c.slice(0);
                for (s = e, l = [], u = N.preFilter; s;) {
                    (!r || (i = ut.exec(s))) && (i && (s = s.slice(i[0].length) || s), l.push(o = [])), r = !1, (i = ct.exec(s)) && (r = i.shift(), o.push({
                        value: r,
                        type: i[0].replace(lt, " ")
                    }), s = s.slice(r.length));
                    for (a in N.filter) !(i = ht[a].exec(s)) || u[a] && !(i = u[a](i)) || (r = i.shift(), o.push({
                        value: r,
                        type: a,
                        matches: i
                    }), s = s.slice(r.length));
                    if (!r) break
                }
                return n ? s.length : s ? t.error(e) : I(e, l).slice(0)
            }

            function p(e) {
                for (var t = 0, n = e.length, r = ""; n > t; t++) r += e[t].value;
                return r
            }

            function h(e, t, n) {
                var r = t.dir,
                    i = n && "parentNode" === r,
                    o = $++;
                return t.first ? function(t, n, o) {
                    for (; t = t[r];)
                        if (1 === t.nodeType || i) return e(t, n, o)
                } : function(t, n, a) {
                    var s, l, u = [W, o];
                    if (a) {
                        for (; t = t[r];)
                            if ((1 === t.nodeType || i) && e(t, n, a)) return !0
                    } else
                        for (; t = t[r];)
                            if (1 === t.nodeType || i) {
                                if (l = t[P] || (t[P] = {}), (s = l[r]) && s[0] === W && s[1] === o) return u[2] = s[2];
                                if (l[r] = u, u[2] = e(t, n, a)) return !0
                            }
                }
            }

            function m(e) {
                return e.length > 1 ? function(t, n, r) {
                    for (var i = e.length; i--;)
                        if (!e[i](t, n, r)) return !1;
                    return !0
                } : e[0]
            }

            function g(e, t, n, r, i) {
                for (var o, a = [], s = 0, l = e.length, u = null != t; l > s; s++)(o = e[s]) && (!n || n(o, r, i)) && (a.push(o), u && t.push(s));
                return a
            }

            function v(e, t, n, i, o, a) {
                return i && !i[P] && (i = v(i)), o && !o[P] && (o = v(o, a)), r(function(r, a, s, l) {
                    var u, c, d, f = [],
                        p = [],
                        h = a.length,
                        m = r || x(t || "*", s.nodeType ? [s] : s, []),
                        v = !e || !r && t ? m : g(m, f, e, s, l),
                        y = n ? o || (r ? e : h || i) ? [] : a : v;
                    if (n && n(v, y, s, l), i)
                        for (u = g(y, p), i(u, [], s, l), c = u.length; c--;)(d = u[c]) && (y[p[c]] = !(v[p[c]] = d));
                    if (r) {
                        if (o || e) {
                            if (o) {
                                for (u = [], c = y.length; c--;)(d = y[c]) && u.push(v[c] = d);
                                o(null, y = [], u, l)
                            }
                            for (c = y.length; c--;)(d = y[c]) && (u = o ? tt.call(r, d) : f[c]) > -1 && (r[u] = !(a[u] = d))
                        }
                    } else y = g(y === a ? y.splice(h, y.length) : y), o ? o(null, a, y, l) : Z.apply(a, y)
                })
            }

            function y(e) {
                for (var t, n, r, i = e.length, o = N.relative[e[0].type], a = o || N.relative[" "], s = o ? 1 : 0, l = h(function(e) {
                        return e === t
                    }, a, !0), u = h(function(e) {
                        return tt.call(t, e) > -1
                    }, a, !0), c = [function(e, n, r) {
                        return !o && (r || n !== A) || ((t = n).nodeType ? l(e, n, r) : u(e, n, r))
                    }]; i > s; s++)
                    if (n = N.relative[e[s].type]) c = [h(m(c), n)];
                    else {
                        if (n = N.filter[e[s].type].apply(null, e[s].matches), n[P]) {
                            for (r = ++s; i > r && !N.relative[e[r].type]; r++);
                            return v(s > 1 && m(c), s > 1 && p(e.slice(0, s - 1).concat({
                                value: " " === e[s - 2].type ? "*" : ""
                            })).replace(lt, "$1"), n, r > s && y(e.slice(s, r)), i > r && y(e = e.slice(r)), i > r && p(e))
                        }
                        c.push(n)
                    }
                return m(c)
            }

            function b(e, n) {
                var i = n.length > 0,
                    o = e.length > 0,
                    a = function(r, a, s, l, u) {
                        var c, d, f, p = 0,
                            h = "0",
                            m = r && [],
                            v = [],
                            y = A,
                            b = r || o && N.find.TAG("*", u),
                            x = W += null == y ? 1 : Math.random() || .1,
                            w = b.length;
                        for (u && (A = a !== H && a); h !== w && null != (c = b[h]); h++) {
                            if (o && c) {
                                for (d = 0; f = e[d++];)
                                    if (f(c, a, s)) {
                                        l.push(c);
                                        break
                                    }
                                u && (W = x)
                            }
                            i && ((c = !f && c) && p--, r && m.push(c))
                        }
                        if (p += h, i && h !== p) {
                            for (d = 0; f = n[d++];) f(m, v, a, s);
                            if (r) {
                                if (p > 0)
                                    for (; h--;) m[h] || v[h] || (v[h] = Q.call(l));
                                v = g(v)
                            }
                            Z.apply(l, v), u && !r && v.length > 0 && p + n.length > 1 && t.uniqueSort(l)
                        }
                        return u && (W = x, A = y), m
                    };
                return i ? r(a) : a
            }

            function x(e, n, r) {
                for (var i = 0, o = n.length; o > i; i++) t(e, n[i], r);
                return r
            }

            function w(e, t, n, r) {
                var i, o, a, s, l, u = f(e);
                if (!r && 1 === u.length) {
                    if (o = u[0] = u[0].slice(0), o.length > 2 && "ID" === (a = o[0]).type && C.getById && 9 === t.nodeType && _ && N.relative[o[1].type]) {
                        if (t = (N.find.ID(a.matches[0].replace(wt, Tt), t) || [])[0], !t) return n;
                        e = e.slice(o.shift().value.length)
                    }
                    for (i = ht.needsContext.test(e) ? 0 : o.length; i-- && (a = o[i], !N.relative[s = a.type]);)
                        if ((l = N.find[s]) && (r = l(a.matches[0].replace(wt, Tt), bt.test(o[0].type) && c(t.parentNode) || t))) {
                            if (o.splice(i, 1), e = r.length && p(o), !e) return Z.apply(n, r), n;
                            break
                        }
                }
                return S(e, u)(r, t, !_, n, bt.test(e) && c(t.parentNode) || t), n
            }
            var T, C, N, E, k, S, A, D, j, L, H, q, _, M, F, O, B, P = "sizzle" + -new Date,
                R = e.document,
                W = 0,
                $ = 0,
                z = n(),
                I = n(),
                X = n(),
                U = function(e, t) {
                    return e === t && (j = !0), 0
                },
                V = "undefined",
                J = 1 << 31,
                Y = {}.hasOwnProperty,
                G = [],
                Q = G.pop,
                K = G.push,
                Z = G.push,
                et = G.slice,
                tt = G.indexOf || function(e) {
                    for (var t = 0, n = this.length; n > t; t++)
                        if (this[t] === e) return t;
                    return -1
                },
                nt = "checked|selected|async|autofocus|autoplay|controls|defer|disabled|hidden|ismap|loop|multiple|open|readonly|required|scoped",
                rt = "[\\x20\\t\\r\\n\\f]",
                it = "(?:\\\\.|[\\w-]|[^\\x00-\\xa0])+",
                ot = it.replace("w", "w#"),
                at = "\\[" + rt + "*(" + it + ")" + rt + "*(?:([*^$|!~]?=)" + rt + "*(?:(['\"])((?:\\\\.|[^\\\\])*?)\\3|(" + ot + ")|)|)" + rt + "*\\]",
                st = ":(" + it + ")(?:\\(((['\"])((?:\\\\.|[^\\\\])*?)\\3|((?:\\\\.|[^\\\\()[\\]]|" + at.replace(3, 8) + ")*)|.*)\\)|)",
                lt = new RegExp("^" + rt + "+|((?:^|[^\\\\])(?:\\\\.)*)" + rt + "+$", "g"),
                ut = new RegExp("^" + rt + "*," + rt + "*"),
                ct = new RegExp("^" + rt + "*([>+~]|" + rt + ")" + rt + "*"),
                dt = new RegExp("=" + rt + "*([^\\]'\"]*?)" + rt + "*\\]", "g"),
                ft = new RegExp(st),
                pt = new RegExp("^" + ot + "$"),
                ht = {
                    ID: new RegExp("^#(" + it + ")"),
                    CLASS: new RegExp("^\\.(" + it + ")"),
                    TAG: new RegExp("^(" + it.replace("w", "w*") + ")"),
                    ATTR: new RegExp("^" + at),
                    PSEUDO: new RegExp("^" + st),
                    CHILD: new RegExp("^:(only|first|last|nth|nth-last)-(child|of-type)(?:\\(" + rt + "*(even|odd|(([+-]|)(\\d*)n|)" + rt + "*(?:([+-]|)" + rt + "*(\\d+)|))" + rt + "*\\)|)", "i"),
                    bool: new RegExp("^(?:" + nt + ")$", "i"),
                    needsContext: new RegExp("^" + rt + "*[>+~]|:(even|odd|eq|gt|lt|nth|first|last)(?:\\(" + rt + "*((?:-\\d)?\\d*)" + rt + "*\\)|)(?=[^-]|$)", "i")
                },
                mt = /^(?:input|select|textarea|button)$/i,
                gt = /^h\d$/i,
                vt = /^[^{]+\{\s*\[native \w/,
                yt = /^(?:#([\w-]+)|(\w+)|\.([\w-]+))$/,
                bt = /[+~]/,
                xt = /'|\\/g,
                wt = new RegExp("\\\\([\\da-f]{1,6}" + rt + "?|(" + rt + ")|.)", "ig"),
                Tt = function(e, t, n) {
                    var r = "0x" + t - 65536;
                    return r !== r || n ? t : 0 > r ? String.fromCharCode(r + 65536) : String.fromCharCode(55296 | r >> 10, 56320 | 1023 & r)
                };
            try {
                Z.apply(G = et.call(R.childNodes), R.childNodes), G[R.childNodes.length].nodeType
            } catch (Ct) {
                Z = {
                    apply: G.length ? function(e, t) {
                        K.apply(e, et.call(t))
                    } : function(e, t) {
                        for (var n = e.length, r = 0; e[n++] = t[r++];);
                        e.length = n - 1
                    }
                }
            }
            C = t.support = {}, k = t.isXML = function(e) {
                var t = e && (e.ownerDocument || e).documentElement;
                return t ? "HTML" !== t.nodeName : !1
            }, L = t.setDocument = function(e) {
                var t, n = e ? e.ownerDocument || e : R,
                    r = n.defaultView;
                return n !== H && 9 === n.nodeType && n.documentElement ? (H = n, q = n.documentElement, _ = !k(n), r && r !== r.top && (r.addEventListener ? r.addEventListener("unload", function() {
                    L()
                }, !1) : r.attachEvent && r.attachEvent("onunload", function() {
                    L()
                })), C.attributes = i(function(e) {
                    return e.className = "i", !e.getAttribute("className")
                }), C.getElementsByTagName = i(function(e) {
                    return e.appendChild(n.createComment("")), !e.getElementsByTagName("*").length
                }), C.getElementsByClassName = vt.test(n.getElementsByClassName) && i(function(e) {
                    return e.innerHTML = "<div class='a'></div><div class='a i'></div>", e.firstChild.className = "i", 2 === e.getElementsByClassName("i").length
                }), C.getById = i(function(e) {
                    return q.appendChild(e).id = P, !n.getElementsByName || !n.getElementsByName(P).length
                }), C.getById ? (N.find.ID = function(e, t) {
                    if (typeof t.getElementById !== V && _) {
                        var n = t.getElementById(e);
                        return n && n.parentNode ? [n] : []
                    }
                }, N.filter.ID = function(e) {
                    var t = e.replace(wt, Tt);
                    return function(e) {
                        return e.getAttribute("id") === t
                    }
                }) : (delete N.find.ID, N.filter.ID = function(e) {
                    var t = e.replace(wt, Tt);
                    return function(e) {
                        var n = typeof e.getAttributeNode !== V && e.getAttributeNode("id");
                        return n && n.value === t
                    }
                }), N.find.TAG = C.getElementsByTagName ? function(e, t) {
                    return typeof t.getElementsByTagName !== V ? t.getElementsByTagName(e) : void 0
                } : function(e, t) {
                    var n, r = [],
                        i = 0,
                        o = t.getElementsByTagName(e);
                    if ("*" === e) {
                        for (; n = o[i++];) 1 === n.nodeType && r.push(n);
                        return r
                    }
                    return o
                }, N.find.CLASS = C.getElementsByClassName && function(e, t) {
                    return typeof t.getElementsByClassName !== V && _ ? t.getElementsByClassName(e) : void 0
                }, F = [], M = [], (C.qsa = vt.test(n.querySelectorAll)) && (i(function(e) {
                    e.innerHTML = "<select t=''><option selected=''></option></select>", e.querySelectorAll("[t^='']").length && M.push("[*^$]=" + rt + "*(?:''|\"\")"), e.querySelectorAll("[selected]").length || M.push("\\[" + rt + "*(?:value|" + nt + ")"), e.querySelectorAll(":checked").length || M.push(":checked")
                }), i(function(e) {
                    var t = n.createElement("input");
                    t.setAttribute("type", "hidden"), e.appendChild(t).setAttribute("name", "D"), e.querySelectorAll("[name=d]").length && M.push("name" + rt + "*[*^$|!~]?="), e.querySelectorAll(":enabled").length || M.push(":enabled", ":disabled"), e.querySelectorAll("*,:x"), M.push(",.*:")
                })), (C.matchesSelector = vt.test(O = q.webkitMatchesSelector || q.mozMatchesSelector || q.oMatchesSelector || q.msMatchesSelector)) && i(function(e) {
                    C.disconnectedMatch = O.call(e, "div"), O.call(e, "[s!='']:x"), F.push("!=", st)
                }), M = M.length && new RegExp(M.join("|")), F = F.length && new RegExp(F.join("|")), t = vt.test(q.compareDocumentPosition), B = t || vt.test(q.contains) ? function(e, t) {
                    var n = 9 === e.nodeType ? e.documentElement : e,
                        r = t && t.parentNode;
                    return e === r || !(!r || 1 !== r.nodeType || !(n.contains ? n.contains(r) : e.compareDocumentPosition && 16 & e.compareDocumentPosition(r)))
                } : function(e, t) {
                    if (t)
                        for (; t = t.parentNode;)
                            if (t === e) return !0;
                    return !1
                }, U = t ? function(e, t) {
                    if (e === t) return j = !0, 0;
                    var r = !e.compareDocumentPosition - !t.compareDocumentPosition;
                    return r ? r : (r = (e.ownerDocument || e) === (t.ownerDocument || t) ? e.compareDocumentPosition(t) : 1, 1 & r || !C.sortDetached && t.compareDocumentPosition(e) === r ? e === n || e.ownerDocument === R && B(R, e) ? -1 : t === n || t.ownerDocument === R && B(R, t) ? 1 : D ? tt.call(D, e) - tt.call(D, t) : 0 : 4 & r ? -1 : 1)
                } : function(e, t) {
                    if (e === t) return j = !0, 0;
                    var r, i = 0,
                        o = e.parentNode,
                        s = t.parentNode,
                        l = [e],
                        u = [t];
                    if (!o || !s) return e === n ? -1 : t === n ? 1 : o ? -1 : s ? 1 : D ? tt.call(D, e) - tt.call(D, t) : 0;
                    if (o === s) return a(e, t);
                    for (r = e; r = r.parentNode;) l.unshift(r);
                    for (r = t; r = r.parentNode;) u.unshift(r);
                    for (; l[i] === u[i];) i++;
                    return i ? a(l[i], u[i]) : l[i] === R ? -1 : u[i] === R ? 1 : 0
                }, n) : H
            }, t.matches = function(e, n) {
                return t(e, null, null, n)
            }, t.matchesSelector = function(e, n) {
                if ((e.ownerDocument || e) !== H && L(e), n = n.replace(dt, "='$1']"), !(!C.matchesSelector || !_ || F && F.test(n) || M && M.test(n))) try {
                    var r = O.call(e, n);
                    if (r || C.disconnectedMatch || e.document && 11 !== e.document.nodeType) return r
                } catch (i) {}
                return t(n, H, null, [e]).length > 0
            }, t.contains = function(e, t) {
                return (e.ownerDocument || e) !== H && L(e), B(e, t)
            }, t.attr = function(e, t) {
                (e.ownerDocument || e) !== H && L(e);
                var n = N.attrHandle[t.toLowerCase()],
                    r = n && Y.call(N.attrHandle, t.toLowerCase()) ? n(e, t, !_) : void 0;
                return void 0 !== r ? r : C.attributes || !_ ? e.getAttribute(t) : (r = e.getAttributeNode(t)) && r.specified ? r.value : null
            }, t.error = function(e) {
                throw new Error("Syntax error, unrecognized expression: " + e)
            }, t.uniqueSort = function(e) {
                var t, n = [],
                    r = 0,
                    i = 0;
                if (j = !C.detectDuplicates, D = !C.sortStable && e.slice(0), e.sort(U), j) {
                    for (; t = e[i++];) t === e[i] && (r = n.push(i));
                    for (; r--;) e.splice(n[r], 1)
                }
                return D = null, e
            }, E = t.getText = function(e) {
                var t, n = "",
                    r = 0,
                    i = e.nodeType;
                if (i) {
                    if (1 === i || 9 === i || 11 === i) {
                        if ("string" == typeof e.textContent) return e.textContent;
                        for (e = e.firstChild; e; e = e.nextSibling) n += E(e)
                    } else if (3 === i || 4 === i) return e.nodeValue
                } else
                    for (; t = e[r++];) n += E(t);
                return n
            }, N = t.selectors = {
                cacheLength: 50,
                createPseudo: r,
                match: ht,
                attrHandle: {},
                find: {},
                relative: {
                    ">": {
                        dir: "parentNode",
                        first: !0
                    },
                    " ": {
                        dir: "parentNode"
                    },
                    "+": {
                        dir: "previousSibling",
                        first: !0
                    },
                    "~": {
                        dir: "previousSibling"
                    }
                },
                preFilter: {
                    ATTR: function(e) {
                        return e[1] = e[1].replace(wt, Tt), e[3] = (e[4] || e[5] || "").replace(wt, Tt), "~=" === e[2] && (e[3] = " " + e[3] + " "), e.slice(0, 4)
                    },
                    CHILD: function(e) {
                        return e[1] = e[1].toLowerCase(), "nth" === e[1].slice(0, 3) ? (e[3] || t.error(e[0]), e[4] = +(e[4] ? e[5] + (e[6] || 1) : 2 * ("even" === e[3] || "odd" === e[3])), e[5] = +(e[7] + e[8] || "odd" === e[3])) : e[3] && t.error(e[0]), e
                    },
                    PSEUDO: function(e) {
                        var t, n = !e[5] && e[2];
                        return ht.CHILD.test(e[0]) ? null : (e[3] && void 0 !== e[4] ? e[2] = e[4] : n && ft.test(n) && (t = f(n, !0)) && (t = n.indexOf(")", n.length - t) - n.length) && (e[0] = e[0].slice(0, t), e[2] = n.slice(0, t)), e.slice(0, 3))
                    }
                },
                filter: {
                    TAG: function(e) {
                        var t = e.replace(wt, Tt).toLowerCase();
                        return "*" === e ? function() {
                            return !0
                        } : function(e) {
                            return e.nodeName && e.nodeName.toLowerCase() === t
                        }
                    },
                    CLASS: function(e) {
                        var t = z[e + " "];
                        return t || (t = new RegExp("(^|" + rt + ")" + e + "(" + rt + "|$)")) && z(e, function(e) {
                            return t.test("string" == typeof e.className && e.className || typeof e.getAttribute !== V && e.getAttribute("class") || "")
                        })
                    },
                    ATTR: function(e, n, r) {
                        return function(i) {
                            var o = t.attr(i, e);
                            return null == o ? "!=" === n : n ? (o += "", "=" === n ? o === r : "!=" === n ? o !== r : "^=" === n ? r && 0 === o.indexOf(r) : "*=" === n ? r && o.indexOf(r) > -1 : "$=" === n ? r && o.slice(-r.length) === r : "~=" === n ? (" " + o + " ").indexOf(r) > -1 : "|=" === n ? o === r || o.slice(0, r.length + 1) === r + "-" : !1) : !0
                        }
                    },
                    CHILD: function(e, t, n, r, i) {
                        var o = "nth" !== e.slice(0, 3),
                            a = "last" !== e.slice(-4),
                            s = "of-type" === t;
                        return 1 === r && 0 === i ? function(e) {
                            return !!e.parentNode
                        } : function(t, n, l) {
                            var u, c, d, f, p, h, m = o !== a ? "nextSibling" : "previousSibling",
                                g = t.parentNode,
                                v = s && t.nodeName.toLowerCase(),
                                y = !l && !s;
                            if (g) {
                                if (o) {
                                    for (; m;) {
                                        for (d = t; d = d[m];)
                                            if (s ? d.nodeName.toLowerCase() === v : 1 === d.nodeType) return !1;
                                        h = m = "only" === e && !h && "nextSibling"
                                    }
                                    return !0
                                }
                                if (h = [a ? g.firstChild : g.lastChild], a && y) {
                                    for (c = g[P] || (g[P] = {}), u = c[e] || [], p = u[0] === W && u[1], f = u[0] === W && u[2], d = p && g.childNodes[p]; d = ++p && d && d[m] || (f = p = 0) || h.pop();)
                                        if (1 === d.nodeType && ++f && d === t) {
                                            c[e] = [W, p, f];
                                            break
                                        }
                                } else if (y && (u = (t[P] || (t[P] = {}))[e]) && u[0] === W) f = u[1];
                                else
                                    for (;
                                        (d = ++p && d && d[m] || (f = p = 0) || h.pop()) && ((s ? d.nodeName.toLowerCase() !== v : 1 !== d.nodeType) || !++f || (y && ((d[P] || (d[P] = {}))[e] = [W, f]), d !== t)););
                                return f -= i, f === r || 0 === f % r && f / r >= 0
                            }
                        }
                    },
                    PSEUDO: function(e, n) {
                        var i, o = N.pseudos[e] || N.setFilters[e.toLowerCase()] || t.error("unsupported pseudo: " + e);
                        return o[P] ? o(n) : o.length > 1 ? (i = [e, e, "", n], N.setFilters.hasOwnProperty(e.toLowerCase()) ? r(function(e, t) {
                            for (var r, i = o(e, n), a = i.length; a--;) r = tt.call(e, i[a]), e[r] = !(t[r] = i[a])
                        }) : function(e) {
                            return o(e, 0, i)
                        }) : o
                    }
                },
                pseudos: {
                    not: r(function(e) {
                        var t = [],
                            n = [],
                            i = S(e.replace(lt, "$1"));
                        return i[P] ? r(function(e, t, n, r) {
                            for (var o, a = i(e, null, r, []), s = e.length; s--;)(o = a[s]) && (e[s] = !(t[s] = o))
                        }) : function(e, r, o) {
                            return t[0] = e, i(t, null, o, n), !n.pop()
                        }
                    }),
                    has: r(function(e) {
                        return function(n) {
                            return t(e, n).length > 0
                        }
                    }),
                    contains: r(function(e) {
                        return function(t) {
                            return (t.textContent || t.innerText || E(t)).indexOf(e) > -1
                        }
                    }),
                    lang: r(function(e) {
                        return pt.test(e || "") || t.error("unsupported lang: " + e), e = e.replace(wt, Tt).toLowerCase(),
                            function(t) {
                                var n;
                                do
                                    if (n = _ ? t.lang : t.getAttribute("xml:lang") || t.getAttribute("lang")) return n = n.toLowerCase(), n === e || 0 === n.indexOf(e + "-"); while ((t = t.parentNode) && 1 === t.nodeType);
                                return !1
                            }
                    }),
                    target: function(t) {
                        var n = e.location && e.location.hash;
                        return n && n.slice(1) === t.id
                    },
                    root: function(e) {
                        return e === q
                    },
                    focus: function(e) {
                        return e === H.activeElement && (!H.hasFocus || H.hasFocus()) && !!(e.type || e.href || ~e.tabIndex)
                    },
                    enabled: function(e) {
                        return e.disabled === !1
                    },
                    disabled: function(e) {
                        return e.disabled === !0
                    },
                    checked: function(e) {
                        var t = e.nodeName.toLowerCase();
                        return "input" === t && !!e.checked || "option" === t && !!e.selected
                    },
                    selected: function(e) {
                        return e.parentNode && e.parentNode.selectedIndex, e.selected === !0
                    },
                    empty: function(e) {
                        for (e = e.firstChild; e; e = e.nextSibling)
                            if (e.nodeType < 6) return !1;
                        return !0
                    },
                    parent: function(e) {
                        return !N.pseudos.empty(e)
                    },
                    header: function(e) {
                        return gt.test(e.nodeName)
                    },
                    input: function(e) {
                        return mt.test(e.nodeName)
                    },
                    button: function(e) {
                        var t = e.nodeName.toLowerCase();
                        return "input" === t && "button" === e.type || "button" === t
                    },
                    text: function(e) {
                        var t;
                        return "input" === e.nodeName.toLowerCase() && "text" === e.type && (null == (t = e.getAttribute("type")) || "text" === t.toLowerCase())
                    },
                    first: u(function() {
                        return [0]
                    }),
                    last: u(function(e, t) {
                        return [t - 1]
                    }),
                    eq: u(function(e, t, n) {
                        return [0 > n ? n + t : n]
                    }),
                    even: u(function(e, t) {
                        for (var n = 0; t > n; n += 2) e.push(n);
                        return e
                    }),
                    odd: u(function(e, t) {
                        for (var n = 1; t > n; n += 2) e.push(n);
                        return e
                    }),
                    lt: u(function(e, t, n) {
                        for (var r = 0 > n ? n + t : n; --r >= 0;) e.push(r);
                        return e
                    }),
                    gt: u(function(e, t, n) {
                        for (var r = 0 > n ? n + t : n; ++r < t;) e.push(r);
                        return e
                    })
                }
            }, N.pseudos.nth = N.pseudos.eq;
            for (T in {
                    radio: !0,
                    checkbox: !0,
                    file: !0,
                    password: !0,
                    image: !0
                }) N.pseudos[T] = s(T);
            for (T in {
                    submit: !0,
                    reset: !0
                }) N.pseudos[T] = l(T);
            return d.prototype = N.filters = N.pseudos, N.setFilters = new d, S = t.compile = function(e, t) {
                var n, r = [],
                    i = [],
                    o = X[e + " "];
                if (!o) {
                    for (t || (t = f(e)), n = t.length; n--;) o = y(t[n]), o[P] ? r.push(o) : i.push(o);
                    o = X(e, b(i, r))
                }
                return o
            }, C.sortStable = P.split("").sort(U).join("") === P, C.detectDuplicates = !!j, L(), C.sortDetached = i(function(e) {
                return 1 & e.compareDocumentPosition(H.createElement("div"))
            }), i(function(e) {
                return e.innerHTML = "<a href='#'></a>", "#" === e.firstChild.getAttribute("href")
            }) || o("type|href|height|width", function(e, t, n) {
                return n ? void 0 : e.getAttribute(t, "type" === t.toLowerCase() ? 1 : 2)
            }), C.attributes && i(function(e) {
                return e.innerHTML = "<input/>", e.firstChild.setAttribute("value", ""), "" === e.firstChild.getAttribute("value")
            }) || o("value", function(e, t, n) {
                return n || "input" !== e.nodeName.toLowerCase() ? void 0 : e.defaultValue
            }), i(function(e) {
                return null == e.getAttribute("disabled")
            }) || o(nt, function(e, t, n) {
                var r;
                return n ? void 0 : e[t] === !0 ? t.toLowerCase() : (r = e.getAttributeNode(t)) && r.specified ? r.value : null
            }), t
        }(e);
        at.find = dt, at.expr = dt.selectors, at.expr[":"] = at.expr.pseudos, at.unique = dt.uniqueSort, at.text = dt.getText, at.isXMLDoc = dt.isXML, at.contains = dt.contains;
        var ft = at.expr.match.needsContext,
            pt = /^<(\w+)\s*\/?>(?:<\/\1>|)$/,
            ht = /^.[^:#\[\.,]*$/;
        at.filter = function(e, t, n) {
            var r = t[0];
            return n && (e = ":not(" + e + ")"), 1 === t.length && 1 === r.nodeType ? at.find.matchesSelector(r, e) ? [r] : [] : at.find.matches(e, at.grep(t, function(e) {
                return 1 === e.nodeType
            }))
        }, at.fn.extend({
            find: function(e) {
                var t, n = [],
                    r = this,
                    i = r.length;
                if ("string" != typeof e) return this.pushStack(at(e).filter(function() {
                    for (t = 0; i > t; t++)
                        if (at.contains(r[t], this)) return !0
                }));
                for (t = 0; i > t; t++) at.find(e, r[t], n);
                return n = this.pushStack(i > 1 ? at.unique(n) : n), n.selector = this.selector ? this.selector + " " + e : e, n
            },
            filter: function(e) {
                return this.pushStack(r(this, e || [], !1))
            },
            not: function(e) {
                return this.pushStack(r(this, e || [], !0))
            },
            is: function(e) {
                return !!r(this, "string" == typeof e && ft.test(e) ? at(e) : e || [], !1).length
            }
        });
        var mt, gt = e.document,
            vt = /^(?:\s*(<[\w\W]+>)[^>]*|#([\w-]*))$/,
            yt = at.fn.init = function(e, t) {
                var n, r;
                if (!e) return this;
                if ("string" == typeof e) {
                    if (n = "<" === e.charAt(0) && ">" === e.charAt(e.length - 1) && e.length >= 3 ? [null, e, null] : vt.exec(e), !n || !n[1] && t) return !t || t.jquery ? (t || mt).find(e) : this.constructor(t).find(e);
                    if (n[1]) {
                        if (t = t instanceof at ? t[0] : t, at.merge(this, at.parseHTML(n[1], t && t.nodeType ? t.ownerDocument || t : gt, !0)), pt.test(n[1]) && at.isPlainObject(t))
                            for (n in t) at.isFunction(this[n]) ? this[n](t[n]) : this.attr(n, t[n]);
                        return this
                    }
                    if (r = gt.getElementById(n[2]), r && r.parentNode) {
                        if (r.id !== n[2]) return mt.find(e);
                        this.length = 1, this[0] = r
                    }
                    return this.context = gt, this.selector = e, this
                }
                return e.nodeType ? (this.context = this[0] = e, this.length = 1, this) : at.isFunction(e) ? "undefined" != typeof mt.ready ? mt.ready(e) : e(at) : (void 0 !== e.selector && (this.selector = e.selector, this.context = e.context), at.makeArray(e, this))
            };
        yt.prototype = at.fn, mt = at(gt);
        var bt = /^(?:parents|prev(?:Until|All))/,
            xt = {
                children: !0,
                contents: !0,
                next: !0,
                prev: !0
            };
        at.extend({
            dir: function(e, t, n) {
                for (var r = [], i = e[t]; i && 9 !== i.nodeType && (void 0 === n || 1 !== i.nodeType || !at(i).is(n));) 1 === i.nodeType && r.push(i), i = i[t];
                return r
            },
            sibling: function(e, t) {
                for (var n = []; e; e = e.nextSibling) 1 === e.nodeType && e !== t && n.push(e);
                return n
            }
        }), at.fn.extend({
            has: function(e) {
                var t, n = at(e, this),
                    r = n.length;
                return this.filter(function() {
                    for (t = 0; r > t; t++)
                        if (at.contains(this, n[t])) return !0
                })
            },
            closest: function(e, t) {
                for (var n, r = 0, i = this.length, o = [], a = ft.test(e) || "string" != typeof e ? at(e, t || this.context) : 0; i > r; r++)
                    for (n = this[r]; n && n !== t; n = n.parentNode)
                        if (n.nodeType < 11 && (a ? a.index(n) > -1 : 1 === n.nodeType && at.find.matchesSelector(n, e))) {
                            o.push(n);
                            break
                        }
                return this.pushStack(o.length > 1 ? at.unique(o) : o)
            },
            index: function(e) {
                return e ? "string" == typeof e ? at.inArray(this[0], at(e)) : at.inArray(e.jquery ? e[0] : e, this) : this[0] && this[0].parentNode ? this.first().prevAll().length : -1
            },
            add: function(e, t) {
                return this.pushStack(at.unique(at.merge(this.get(), at(e, t))))
            },
            addBack: function(e) {
                return this.add(null == e ? this.prevObject : this.prevObject.filter(e))
            }
        }), at.each({
            parent: function(e) {
                var t = e.parentNode;
                return t && 11 !== t.nodeType ? t : null
            },
            parents: function(e) {
                return at.dir(e, "parentNode")
            },
            parentsUntil: function(e, t, n) {
                return at.dir(e, "parentNode", n)
            },
            next: function(e) {
                return o(e, "nextSibling")
            },
            prev: function(e) {
                return o(e, "previousSibling")
            },
            nextAll: function(e) {
                return at.dir(e, "nextSibling")
            },
            prevAll: function(e) {
                return at.dir(e, "previousSibling")
            },
            nextUntil: function(e, t, n) {
                return at.dir(e, "nextSibling", n)
            },
            prevUntil: function(e, t, n) {
                return at.dir(e, "previousSibling", n)
            },
            siblings: function(e) {
                return at.sibling((e.parentNode || {}).firstChild, e)
            },
            children: function(e) {
                return at.sibling(e.firstChild)
            },
            contents: function(e) {
                return at.nodeName(e, "iframe") ? e.contentDocument || e.contentWindow.document : at.merge([], e.childNodes)
            }
        }, function(e, t) {
            at.fn[e] = function(n, r) {
                var i = at.map(this, t, n);
                return "Until" !== e.slice(-5) && (r = n), r && "string" == typeof r && (i = at.filter(r, i)), this.length > 1 && (xt[e] || (i = at.unique(i)), bt.test(e) && (i = i.reverse())), this.pushStack(i)
            }
        });
        var wt = /\S+/g,
            Tt = {};
        at.Callbacks = function(e) {
            e = "string" == typeof e ? Tt[e] || a(e) : at.extend({}, e);
            var t, n, r, i, o, s, l = [],
                u = !e.once && [],
                c = function(a) {
                    for (n = e.memory && a, r = !0, o = s || 0, s = 0, i = l.length, t = !0; l && i > o; o++)
                        if (l[o].apply(a[0], a[1]) === !1 && e.stopOnFalse) {
                            n = !1;
                            break
                        }
                    t = !1, l && (u ? u.length && c(u.shift()) : n ? l = [] : d.disable())
                },
                d = {
                    add: function() {
                        if (l) {
                            var r = l.length;
                            ! function o(t) {
                                at.each(t, function(t, n) {
                                    var r = at.type(n);
                                    "function" === r ? e.unique && d.has(n) || l.push(n) : n && n.length && "string" !== r && o(n)
                                })
                            }(arguments), t ? i = l.length : n && (s = r, c(n))
                        }
                        return this
                    },
                    remove: function() {
                        return l && at.each(arguments, function(e, n) {
                            for (var r;
                                (r = at.inArray(n, l, r)) > -1;) l.splice(r, 1), t && (i >= r && i--, o >= r && o--)
                        }), this
                    },
                    has: function(e) {
                        return e ? at.inArray(e, l) > -1 : !(!l || !l.length)
                    },
                    empty: function() {
                        return l = [], i = 0, this
                    },
                    disable: function() {
                        return l = u = n = void 0, this
                    },
                    disabled: function() {
                        return !l
                    },
                    lock: function() {
                        return u = void 0, n || d.disable(), this
                    },
                    locked: function() {
                        return !u
                    },
                    fireWith: function(e, n) {
                        return !l || r && !u || (n = n || [], n = [e, n.slice ? n.slice() : n], t ? u.push(n) : c(n)), this
                    },
                    fire: function() {
                        return d.fireWith(this, arguments), this
                    },
                    fired: function() {
                        return !!r
                    }
                };
            return d
        }, at.extend({
            Deferred: function(e) {
                var t = [
                        ["resolve", "done", at.Callbacks("once memory"), "resolved"],
                        ["reject", "fail", at.Callbacks("once memory"), "rejected"],
                        ["notify", "progress", at.Callbacks("memory")]
                    ],
                    n = "pending",
                    r = {
                        state: function() {
                            return n
                        },
                        always: function() {
                            return i.done(arguments).fail(arguments), this
                        },
                        then: function() {
                            var e = arguments;
                            return at.Deferred(function(n) {
                                at.each(t, function(t, o) {
                                    var a = at.isFunction(e[t]) && e[t];
                                    i[o[1]](function() {
                                        var e = a && a.apply(this, arguments);
                                        e && at.isFunction(e.promise) ? e.promise().done(n.resolve).fail(n.reject).progress(n.notify) : n[o[0] + "With"](this === r ? n.promise() : this, a ? [e] : arguments)
                                    })
                                }), e = null
                            }).promise()
                        },
                        promise: function(e) {
                            return null != e ? at.extend(e, r) : r
                        }
                    },
                    i = {};
                return r.pipe = r.then, at.each(t, function(e, o) {
                    var a = o[2],
                        s = o[3];
                    r[o[1]] = a.add, s && a.add(function() {
                        n = s
                    }, t[1 ^ e][2].disable, t[2][2].lock), i[o[0]] = function() {
                        return i[o[0] + "With"](this === i ? r : this, arguments), this
                    }, i[o[0] + "With"] = a.fireWith
                }), r.promise(i), e && e.call(i, i), i
            },
            when: function(e) {
                var t, n, r, i = 0,
                    o = G.call(arguments),
                    a = o.length,
                    s = 1 !== a || e && at.isFunction(e.promise) ? a : 0,
                    l = 1 === s ? e : at.Deferred(),
                    u = function(e, n, r) {
                        return function(i) {
                            n[e] = this, r[e] = arguments.length > 1 ? G.call(arguments) : i, r === t ? l.notifyWith(n, r) : --s || l.resolveWith(n, r)
                        }
                    };
                if (a > 1)
                    for (t = new Array(a), n = new Array(a), r = new Array(a); a > i; i++) o[i] && at.isFunction(o[i].promise) ? o[i].promise().done(u(i, r, o)).fail(l.reject).progress(u(i, n, t)) : --s;
                return s || l.resolveWith(r, o), l.promise()
            }
        });
        var Ct;
        at.fn.ready = function(e) {
            return at.ready.promise().done(e), this
        }, at.extend({
            isReady: !1,
            readyWait: 1,
            holdReady: function(e) {
                e ? at.readyWait++ : at.ready(!0)
            },
            ready: function(e) {
                if (e === !0 ? !--at.readyWait : !at.isReady) {
                    if (!gt.body) return setTimeout(at.ready);
                    at.isReady = !0, e !== !0 && --at.readyWait > 0 || (Ct.resolveWith(gt, [at]), at.fn.trigger && at(gt).trigger("ready").off("ready"))
                }
            }
        }), at.ready.promise = function(t) {
            if (!Ct)
                if (Ct = at.Deferred(), "complete" === gt.readyState) setTimeout(at.ready);
                else if (gt.addEventListener) gt.addEventListener("DOMContentLoaded", l, !1), e.addEventListener("load", l, !1);
            else {
                gt.attachEvent("onreadystatechange", l), e.attachEvent("onload", l);
                var n = !1;
                try {
                    n = null == e.frameElement && gt.documentElement
                } catch (r) {}
                n && n.doScroll && ! function i() {
                    if (!at.isReady) {
                        try {
                            n.doScroll("left")
                        } catch (e) {
                            return setTimeout(i, 50)
                        }
                        s(), at.ready()
                    }
                }()
            }
            return Ct.promise(t)
        };
        var Nt, Et = "undefined";
        for (Nt in at(it)) break;
        it.ownLast = "0" !== Nt, it.inlineBlockNeedsLayout = !1, at(function() {
                var e, t, n = gt.getElementsByTagName("body")[0];
                n && (e = gt.createElement("div"), e.style.cssText = "border:0;width:0;height:0;position:absolute;top:0;left:-9999px;margin-top:1px", t = gt.createElement("div"), n.appendChild(e).appendChild(t), typeof t.style.zoom !== Et && (t.style.cssText = "border:0;margin:0;width:1px;padding:1px;display:inline;zoom:1", (it.inlineBlockNeedsLayout = 3 === t.offsetWidth) && (n.style.zoom = 1)), n.removeChild(e), e = t = null)
            }),
            function() {
                var e = gt.createElement("div");
                if (null == it.deleteExpando) {
                    it.deleteExpando = !0;
                    try {
                        delete e.test
                    } catch (t) {
                        it.deleteExpando = !1
                    }
                }
                e = null
            }(), at.acceptData = function(e) {
                var t = at.noData[(e.nodeName + " ").toLowerCase()],
                    n = +e.nodeType || 1;
                return 1 !== n && 9 !== n ? !1 : !t || t !== !0 && e.getAttribute("classid") === t
            };
        var kt = /^(?:\{[\w\W]*\}|\[[\w\W]*\])$/,
            St = /([A-Z])/g;
        at.extend({
            cache: {},
            noData: {
                "applet ": !0,
                "embed ": !0,
                "object ": "clsid:D27CDB6E-AE6D-11cf-96B8-444553540000"
            },
            hasData: function(e) {
                return e = e.nodeType ? at.cache[e[at.expando]] : e[at.expando], !!e && !c(e)
            },
            data: function(e, t, n) {
                return d(e, t, n)
            },
            removeData: function(e, t) {
                return f(e, t)
            },
            _data: function(e, t, n) {
                return d(e, t, n, !0)
            },
            _removeData: function(e, t) {
                return f(e, t, !0)
            }
        }), at.fn.extend({
            data: function(e, t) {
                var n, r, i, o = this[0],
                    a = o && o.attributes;
                if (void 0 === e) {
                    if (this.length && (i = at.data(o), 1 === o.nodeType && !at._data(o, "parsedAttrs"))) {
                        for (n = a.length; n--;) r = a[n].name, 0 === r.indexOf("data-") && (r = at.camelCase(r.slice(5)), u(o, r, i[r]));
                        at._data(o, "parsedAttrs", !0)
                    }
                    return i
                }
                return "object" == typeof e ? this.each(function() {
                    at.data(this, e)
                }) : arguments.length > 1 ? this.each(function() {
                    at.data(this, e, t)
                }) : o ? u(o, e, at.data(o, e)) : void 0
            },
            removeData: function(e) {
                return this.each(function() {
                    at.removeData(this, e)
                })
            }
        }), at.extend({
            queue: function(e, t, n) {
                var r;
                return e ? (t = (t || "fx") + "queue", r = at._data(e, t), n && (!r || at.isArray(n) ? r = at._data(e, t, at.makeArray(n)) : r.push(n)), r || []) : void 0
            },
            dequeue: function(e, t) {
                t = t || "fx";
                var n = at.queue(e, t),
                    r = n.length,
                    i = n.shift(),
                    o = at._queueHooks(e, t),
                    a = function() {
                        at.dequeue(e, t)
                    };
                "inprogress" === i && (i = n.shift(), r--), i && ("fx" === t && n.unshift("inprogress"), delete o.stop, i.call(e, a, o)), !r && o && o.empty.fire()
            },
            _queueHooks: function(e, t) {
                var n = t + "queueHooks";
                return at._data(e, n) || at._data(e, n, {
                    empty: at.Callbacks("once memory").add(function() {
                        at._removeData(e, t + "queue"), at._removeData(e, n)
                    })
                })
            }
        }), at.fn.extend({
            queue: function(e, t) {
                var n = 2;
                return "string" != typeof e && (t = e, e = "fx", n--), arguments.length < n ? at.queue(this[0], e) : void 0 === t ? this : this.each(function() {
                    var n = at.queue(this, e, t);
                    at._queueHooks(this, e), "fx" === e && "inprogress" !== n[0] && at.dequeue(this, e)
                })
            },
            dequeue: function(e) {
                return this.each(function() {
                    at.dequeue(this, e)
                })
            },
            clearQueue: function(e) {
                return this.queue(e || "fx", [])
            },
            promise: function(e, t) {
                var n, r = 1,
                    i = at.Deferred(),
                    o = this,
                    a = this.length,
                    s = function() {
                        --r || i.resolveWith(o, [o])
                    };
                for ("string" != typeof e && (t = e, e = void 0), e = e || "fx"; a--;) n = at._data(o[a], e + "queueHooks"), n && n.empty && (r++, n.empty.add(s));
                return s(), i.promise(t)
            }
        });
        var At = /[+-]?(?:\d*\.|)\d+(?:[eE][+-]?\d+|)/.source,
            Dt = ["Top", "Right", "Bottom", "Left"],
            jt = function(e, t) {
                return e = t || e, "none" === at.css(e, "display") || !at.contains(e.ownerDocument, e)
            },
            Lt = at.access = function(e, t, n, r, i, o, a) {
                var s = 0,
                    l = e.length,
                    u = null == n;
                if ("object" === at.type(n)) {
                    i = !0;
                    for (s in n) at.access(e, t, s, n[s], !0, o, a)
                } else if (void 0 !== r && (i = !0, at.isFunction(r) || (a = !0), u && (a ? (t.call(e, r), t = null) : (u = t, t = function(e, t, n) {
                        return u.call(at(e), n)
                    })), t))
                    for (; l > s; s++) t(e[s], n, a ? r : r.call(e[s], s, t(e[s], n)));
                return i ? e : u ? t.call(e) : l ? t(e[0], n) : o
            },
            Ht = /^(?:checkbox|radio)$/i;
        ! function() {
            var e = gt.createDocumentFragment(),
                t = gt.createElement("div"),
                n = gt.createElement("input");
            if (t.setAttribute("className", "t"), t.innerHTML = "  <link/><table></table><a href='/a'>a</a>", it.leadingWhitespace = 3 === t.firstChild.nodeType, it.tbody = !t.getElementsByTagName("tbody").length, it.htmlSerialize = !!t.getElementsByTagName("link").length, it.html5Clone = "<:nav></:nav>" !== gt.createElement("nav").cloneNode(!0).outerHTML, n.type = "checkbox", n.checked = !0, e.appendChild(n), it.appendChecked = n.checked, t.innerHTML = "<textarea>x</textarea>", it.noCloneChecked = !!t.cloneNode(!0).lastChild.defaultValue, e.appendChild(t), t.innerHTML = "<input type='radio' checked='checked' name='t'/>", it.checkClone = t.cloneNode(!0).cloneNode(!0).lastChild.checked, it.noCloneEvent = !0, t.attachEvent && (t.attachEvent("onclick", function() {
                    it.noCloneEvent = !1
                }), t.cloneNode(!0).click()), null == it.deleteExpando) {
                it.deleteExpando = !0;
                try {
                    delete t.test
                } catch (r) {
                    it.deleteExpando = !1
                }
            }
            e = t = n = null
        }(),
        function() {
            var t, n, r = gt.createElement("div");
            for (t in {
                    submit: !0,
                    change: !0,
                    focusin: !0
                }) n = "on" + t, (it[t + "Bubbles"] = n in e) || (r.setAttribute(n, "t"), it[t + "Bubbles"] = r.attributes[n].expando === !1);
            r = null
        }();
        var qt = /^(?:input|select|textarea)$/i,
            _t = /^key/,
            Mt = /^(?:mouse|contextmenu)|click/,
            Ft = /^(?:focusinfocus|focusoutblur)$/,
            Ot = /^([^.]*)(?:\.(.+)|)$/;
        at.event = {
            global: {},
            add: function(e, t, n, r, i) {
                var o, a, s, l, u, c, d, f, p, h, m, g = at._data(e);
                if (g) {
                    for (n.handler && (l = n, n = l.handler, i = l.selector), n.guid || (n.guid = at.guid++), (a = g.events) || (a = g.events = {}), (c = g.handle) || (c = g.handle = function(e) {
                            return typeof at === Et || e && at.event.triggered === e.type ? void 0 : at.event.dispatch.apply(c.elem, arguments)
                        }, c.elem = e), t = (t || "").match(wt) || [""], s = t.length; s--;) o = Ot.exec(t[s]) || [], p = m = o[1], h = (o[2] || "").split(".").sort(), p && (u = at.event.special[p] || {}, p = (i ? u.delegateType : u.bindType) || p, u = at.event.special[p] || {}, d = at.extend({
                        type: p,
                        origType: m,
                        data: r,
                        handler: n,
                        guid: n.guid,
                        selector: i,
                        needsContext: i && at.expr.match.needsContext.test(i),
                        namespace: h.join(".")
                    }, l), (f = a[p]) || (f = a[p] = [], f.delegateCount = 0, u.setup && u.setup.call(e, r, h, c) !== !1 || (e.addEventListener ? e.addEventListener(p, c, !1) : e.attachEvent && e.attachEvent("on" + p, c))), u.add && (u.add.call(e, d), d.handler.guid || (d.handler.guid = n.guid)), i ? f.splice(f.delegateCount++, 0, d) : f.push(d), at.event.global[p] = !0);
                    e = null
                }
            },
            remove: function(e, t, n, r, i) {
                var o, a, s, l, u, c, d, f, p, h, m, g = at.hasData(e) && at._data(e);
                if (g && (c = g.events)) {
                    for (t = (t || "").match(wt) || [""], u = t.length; u--;)
                        if (s = Ot.exec(t[u]) || [], p = m = s[1], h = (s[2] || "").split(".").sort(), p) {
                            for (d = at.event.special[p] || {}, p = (r ? d.delegateType : d.bindType) || p, f = c[p] || [], s = s[2] && new RegExp("(^|\\.)" + h.join("\\.(?:.*\\.|)") + "(\\.|$)"), l = o = f.length; o--;) a = f[o], !i && m !== a.origType || n && n.guid !== a.guid || s && !s.test(a.namespace) || r && r !== a.selector && ("**" !== r || !a.selector) || (f.splice(o, 1), a.selector && f.delegateCount--, d.remove && d.remove.call(e, a));
                            l && !f.length && (d.teardown && d.teardown.call(e, h, g.handle) !== !1 || at.removeEvent(e, p, g.handle), delete c[p])
                        } else
                            for (p in c) at.event.remove(e, p + t[u], n, r, !0);
                    at.isEmptyObject(c) && (delete g.handle, at._removeData(e, "events"))
                }
            },
            trigger: function(t, n, r, i) {
                var o, a, s, l, u, c, d, f = [r || gt],
                    p = nt.call(t, "type") ? t.type : t,
                    h = nt.call(t, "namespace") ? t.namespace.split(".") : [];
                if (s = c = r = r || gt, 3 !== r.nodeType && 8 !== r.nodeType && !Ft.test(p + at.event.triggered) && (p.indexOf(".") >= 0 && (h = p.split("."), p = h.shift(), h.sort()), a = p.indexOf(":") < 0 && "on" + p, t = t[at.expando] ? t : new at.Event(p, "object" == typeof t && t), t.isTrigger = i ? 2 : 3, t.namespace = h.join("."), t.namespace_re = t.namespace ? new RegExp("(^|\\.)" + h.join("\\.(?:.*\\.|)") + "(\\.|$)") : null, t.result = void 0, t.target || (t.target = r), n = null == n ? [t] : at.makeArray(n, [t]), u = at.event.special[p] || {}, i || !u.trigger || u.trigger.apply(r, n) !== !1)) {
                    if (!i && !u.noBubble && !at.isWindow(r)) {
                        for (l = u.delegateType || p, Ft.test(l + p) || (s = s.parentNode); s; s = s.parentNode) f.push(s), c = s;
                        c === (r.ownerDocument || gt) && f.push(c.defaultView || c.parentWindow || e)
                    }
                    for (d = 0;
                        (s = f[d++]) && !t.isPropagationStopped();) t.type = d > 1 ? l : u.bindType || p, o = (at._data(s, "events") || {})[t.type] && at._data(s, "handle"), o && o.apply(s, n), o = a && s[a], o && o.apply && at.acceptData(s) && (t.result = o.apply(s, n), t.result === !1 && t.preventDefault());
                    if (t.type = p, !i && !t.isDefaultPrevented() && (!u._default || u._default.apply(f.pop(), n) === !1) && at.acceptData(r) && a && r[p] && !at.isWindow(r)) {
                        c = r[a], c && (r[a] = null), at.event.triggered = p;
                        try {
                            r[p]()
                        } catch (m) {}
                        at.event.triggered = void 0, c && (r[a] = c)
                    }
                    return t.result
                }
            },
            dispatch: function(e) {
                e = at.event.fix(e);
                var t, n, r, i, o, a = [],
                    s = G.call(arguments),
                    l = (at._data(this, "events") || {})[e.type] || [],
                    u = at.event.special[e.type] || {};
                if (s[0] = e, e.delegateTarget = this, !u.preDispatch || u.preDispatch.call(this, e) !== !1) {
                    for (a = at.event.handlers.call(this, e, l), t = 0;
                        (i = a[t++]) && !e.isPropagationStopped();)
                        for (e.currentTarget = i.elem, o = 0;
                            (r = i.handlers[o++]) && !e.isImmediatePropagationStopped();)(!e.namespace_re || e.namespace_re.test(r.namespace)) && (e.handleObj = r, e.data = r.data, n = ((at.event.special[r.origType] || {}).handle || r.handler).apply(i.elem, s), void 0 !== n && (e.result = n) === !1 && (e.preventDefault(), e.stopPropagation()));
                    return u.postDispatch && u.postDispatch.call(this, e), e.result
                }
            },
            handlers: function(e, t) {
                var n, r, i, o, a = [],
                    s = t.delegateCount,
                    l = e.target;
                if (s && l.nodeType && (!e.button || "click" !== e.type))
                    for (; l != this; l = l.parentNode || this)
                        if (1 === l.nodeType && (l.disabled !== !0 || "click" !== e.type)) {
                            for (i = [], o = 0; s > o; o++) r = t[o], n = r.selector + " ", void 0 === i[n] && (i[n] = r.needsContext ? at(n, this).index(l) >= 0 : at.find(n, this, null, [l]).length), i[n] && i.push(r);
                            i.length && a.push({
                                elem: l,
                                handlers: i
                            })
                        }
                return s < t.length && a.push({
                    elem: this,
                    handlers: t.slice(s)
                }), a
            },
            fix: function(e) {
                if (e[at.expando]) return e;
                var t, n, r, i = e.type,
                    o = e,
                    a = this.fixHooks[i];
                for (a || (this.fixHooks[i] = a = Mt.test(i) ? this.mouseHooks : _t.test(i) ? this.keyHooks : {}), r = a.props ? this.props.concat(a.props) : this.props, e = new at.Event(o), t = r.length; t--;) n = r[t], e[n] = o[n];
                return e.target || (e.target = o.srcElement || gt), 3 === e.target.nodeType && (e.target = e.target.parentNode), e.metaKey = !!e.metaKey, a.filter ? a.filter(e, o) : e
            },
            props: "altKey bubbles cancelable ctrlKey currentTarget eventPhase metaKey relatedTarget shiftKey target timeStamp view which".split(" "),
            fixHooks: {},
            keyHooks: {
                props: "char charCode key keyCode".split(" "),
                filter: function(e, t) {
                    return null == e.which && (e.which = null != t.charCode ? t.charCode : t.keyCode), e
                }
            },
            mouseHooks: {
                props: "button buttons clientX clientY fromElement offsetX offsetY pageX pageY screenX screenY toElement".split(" "),
                filter: function(e, t) {
                    var n, r, i, o = t.button,
                        a = t.fromElement;
                    return null == e.pageX && null != t.clientX && (r = e.target.ownerDocument || gt, i = r.documentElement, n = r.body, e.pageX = t.clientX + (i && i.scrollLeft || n && n.scrollLeft || 0) - (i && i.clientLeft || n && n.clientLeft || 0), e.pageY = t.clientY + (i && i.scrollTop || n && n.scrollTop || 0) - (i && i.clientTop || n && n.clientTop || 0)), !e.relatedTarget && a && (e.relatedTarget = a === e.target ? t.toElement : a), e.which || void 0 === o || (e.which = 1 & o ? 1 : 2 & o ? 3 : 4 & o ? 2 : 0), e
                }
            },
            special: {
                load: {
                    noBubble: !0
                },
                focus: {
                    trigger: function() {
                        if (this !== m() && this.focus) try {
                            return this.focus(), !1
                        } catch (e) {}
                    },
                    delegateType: "focusin"
                },
                blur: {
                    trigger: function() {
                        return this === m() && this.blur ? (this.blur(), !1) : void 0
                    },
                    delegateType: "focusout"
                },
                click: {
                    trigger: function() {
                        return at.nodeName(this, "input") && "checkbox" === this.type && this.click ? (this.click(), !1) : void 0
                    },
                    _default: function(e) {
                        return at.nodeName(e.target, "a")
                    }
                },
                beforeunload: {
                    postDispatch: function(e) {
                        void 0 !== e.result && (e.originalEvent.returnValue = e.result)
                    }
                }
            },
            simulate: function(e, t, n, r) {
                var i = at.extend(new at.Event, n, {
                    type: e,
                    isSimulated: !0,
                    originalEvent: {}
                });
                r ? at.event.trigger(i, null, t) : at.event.dispatch.call(t, i), i.isDefaultPrevented() && n.preventDefault()
            }
        }, at.removeEvent = gt.removeEventListener ? function(e, t, n) {
            e.removeEventListener && e.removeEventListener(t, n, !1)
        } : function(e, t, n) {
            var r = "on" + t;
            e.detachEvent && (typeof e[r] === Et && (e[r] = null), e.detachEvent(r, n))
        }, at.Event = function(e, t) {
            return this instanceof at.Event ? (e && e.type ? (this.originalEvent = e, this.type = e.type, this.isDefaultPrevented = e.defaultPrevented || void 0 === e.defaultPrevented && (e.returnValue === !1 || e.getPreventDefault && e.getPreventDefault()) ? p : h) : this.type = e, t && at.extend(this, t), this.timeStamp = e && e.timeStamp || at.now(), this[at.expando] = !0, void 0) : new at.Event(e, t)
        }, at.Event.prototype = {
            isDefaultPrevented: h,
            isPropagationStopped: h,
            isImmediatePropagationStopped: h,
            preventDefault: function() {
                var e = this.originalEvent;
                this.isDefaultPrevented = p, e && (e.preventDefault ? e.preventDefault() : e.returnValue = !1)
            },
            stopPropagation: function() {
                var e = this.originalEvent;
                this.isPropagationStopped = p, e && (e.stopPropagation && e.stopPropagation(), e.cancelBubble = !0)
            },
            stopImmediatePropagation: function() {
                this.isImmediatePropagationStopped = p, this.stopPropagation()
            }
        }, at.each({
            mouseenter: "mouseover",
            mouseleave: "mouseout"
        }, function(e, t) {
            at.event.special[e] = {
                delegateType: t,
                bindType: t,
                handle: function(e) {
                    var n, r = this,
                        i = e.relatedTarget,
                        o = e.handleObj;
                    return (!i || i !== r && !at.contains(r, i)) && (e.type = o.origType, n = o.handler.apply(this, arguments), e.type = t), n
                }
            }
        }), it.submitBubbles || (at.event.special.submit = {
            setup: function() {
                return at.nodeName(this, "form") ? !1 : (at.event.add(this, "click._submit keypress._submit", function(e) {
                    var t = e.target,
                        n = at.nodeName(t, "input") || at.nodeName(t, "button") ? t.form : void 0;
                    n && !at._data(n, "submitBubbles") && (at.event.add(n, "submit._submit", function(e) {
                        e._submit_bubble = !0
                    }), at._data(n, "submitBubbles", !0))
                }), void 0)
            },
            postDispatch: function(e) {
                e._submit_bubble && (delete e._submit_bubble, this.parentNode && !e.isTrigger && at.event.simulate("submit", this.parentNode, e, !0))
            },
            teardown: function() {
                return at.nodeName(this, "form") ? !1 : (at.event.remove(this, "._submit"), void 0)
            }
        }), it.changeBubbles || (at.event.special.change = {
            setup: function() {
                return qt.test(this.nodeName) ? (("checkbox" === this.type || "radio" === this.type) && (at.event.add(this, "propertychange._change", function(e) {
                    "checked" === e.originalEvent.propertyName && (this._just_changed = !0)
                }), at.event.add(this, "click._change", function(e) {
                    this._just_changed && !e.isTrigger && (this._just_changed = !1), at.event.simulate("change", this, e, !0)
                })), !1) : (at.event.add(this, "beforeactivate._change", function(e) {
                    var t = e.target;
                    qt.test(t.nodeName) && !at._data(t, "changeBubbles") && (at.event.add(t, "change._change", function(e) {
                        !this.parentNode || e.isSimulated || e.isTrigger || at.event.simulate("change", this.parentNode, e, !0)
                    }), at._data(t, "changeBubbles", !0))
                }), void 0)
            },
            handle: function(e) {
                var t = e.target;
                return this !== t || e.isSimulated || e.isTrigger || "radio" !== t.type && "checkbox" !== t.type ? e.handleObj.handler.apply(this, arguments) : void 0
            },
            teardown: function() {
                return at.event.remove(this, "._change"), !qt.test(this.nodeName)
            }
        }), it.focusinBubbles || at.each({
            focus: "focusin",
            blur: "focusout"
        }, function(e, t) {
            var n = function(e) {
                at.event.simulate(t, e.target, at.event.fix(e), !0)
            };
            at.event.special[t] = {
                setup: function() {
                    var r = this.ownerDocument || this,
                        i = at._data(r, t);
                    i || r.addEventListener(e, n, !0), at._data(r, t, (i || 0) + 1)
                },
                teardown: function() {
                    var r = this.ownerDocument || this,
                        i = at._data(r, t) - 1;
                    i ? at._data(r, t, i) : (r.removeEventListener(e, n, !0), at._removeData(r, t))
                }
            }
        }), at.fn.extend({
            on: function(e, t, n, r, i) {
                var o, a;
                if ("object" == typeof e) {
                    "string" != typeof t && (n = n || t, t = void 0);
                    for (o in e) this.on(o, t, n, e[o], i);
                    return this
                }
                if (null == n && null == r ? (r = t, n = t = void 0) : null == r && ("string" == typeof t ? (r = n, n = void 0) : (r = n, n = t, t = void 0)), r === !1) r = h;
                else if (!r) return this;
                return 1 === i && (a = r, r = function(e) {
                    return at().off(e), a.apply(this, arguments)
                }, r.guid = a.guid || (a.guid = at.guid++)), this.each(function() {
                    at.event.add(this, e, r, n, t)
                })
            },
            one: function(e, t, n, r) {
                return this.on(e, t, n, r, 1)
            },
            off: function(e, t, n) {
                var r, i;
                if (e && e.preventDefault && e.handleObj) return r = e.handleObj, at(e.delegateTarget).off(r.namespace ? r.origType + "." + r.namespace : r.origType, r.selector, r.handler), this;
                if ("object" == typeof e) {
                    for (i in e) this.off(i, t, e[i]);
                    return this
                }
                return (t === !1 || "function" == typeof t) && (n = t, t = void 0), n === !1 && (n = h), this.each(function() {
                    at.event.remove(this, e, n, t)
                })
            },
            trigger: function(e, t) {
                return this.each(function() {
                    at.event.trigger(e, t, this)
                })
            },
            triggerHandler: function(e, t) {
                var n = this[0];
                return n ? at.event.trigger(e, t, n, !0) : void 0
            }
        });
        var Bt = "abbr|article|aside|audio|bdi|canvas|data|datalist|details|figcaption|figure|footer|header|hgroup|mark|meter|nav|output|progress|section|summary|time|video",
            Pt = / jQuery\d+="(?:null|\d+)"/g,
            Rt = new RegExp("<(?:" + Bt + ")[\\s/>]", "i"),
            Wt = /^\s+/,
            $t = /<(?!area|br|col|embed|hr|img|input|link|meta|param)(([\w:]+)[^>]*)\/>/gi,
            zt = /<([\w:]+)/,
            It = /<tbody/i,
            Xt = /<|&#?\w+;/,
            Ut = /<(?:script|style|link)/i,
            Vt = /checked\s*(?:[^=]|=\s*.checked.)/i,
            Jt = /^$|\/(?:java|ecma)script/i,
            Yt = /^true\/(.*)/,
            Gt = /^\s*<!(?:\[CDATA\[|--)|(?:\]\]|--)>\s*$/g,
            Qt = {
                option: [1, "<select multiple='multiple'>", "</select>"],
                legend: [1, "<fieldset>", "</fieldset>"],
                area: [1, "<map>", "</map>"],
                param: [1, "<object>", "</object>"],
                thead: [1, "<table>", "</table>"],
                tr: [2, "<table><tbody>", "</tbody></table>"],
                col: [2, "<table><tbody></tbody><colgroup>", "</colgroup></table>"],
                td: [3, "<table><tbody><tr>", "</tr></tbody></table>"],
                _default: it.htmlSerialize ? [0, "", ""] : [1, "X<div>", "</div>"]
            },
            Kt = g(gt),
            Zt = Kt.appendChild(gt.createElement("div"));
        Qt.optgroup = Qt.option, Qt.tbody = Qt.tfoot = Qt.colgroup = Qt.caption = Qt.thead, Qt.th = Qt.td, at.extend({
            clone: function(e, t, n) {
                var r, i, o, a, s, l = at.contains(e.ownerDocument, e);
                if (it.html5Clone || at.isXMLDoc(e) || !Rt.test("<" + e.nodeName + ">") ? o = e.cloneNode(!0) : (Zt.innerHTML = e.outerHTML, Zt.removeChild(o = Zt.firstChild)), !(it.noCloneEvent && it.noCloneChecked || 1 !== e.nodeType && 11 !== e.nodeType || at.isXMLDoc(e)))
                    for (r = v(o), s = v(e), a = 0; null != (i = s[a]); ++a) r[a] && N(i, r[a]);
                if (t)
                    if (n)
                        for (s = s || v(e), r = r || v(o), a = 0; null != (i = s[a]); a++) C(i, r[a]);
                    else C(e, o);
                return r = v(o, "script"), r.length > 0 && T(r, !l && v(e, "script")), r = s = i = null, o
            },
            buildFragment: function(e, t, n, r) {
                for (var i, o, a, s, l, u, c, d = e.length, f = g(t), p = [], h = 0; d > h; h++)
                    if (o = e[h], o || 0 === o)
                        if ("object" === at.type(o)) at.merge(p, o.nodeType ? [o] : o);
                        else if (Xt.test(o)) {
                    for (s = s || f.appendChild(t.createElement("div")), l = (zt.exec(o) || ["", ""])[1].toLowerCase(), c = Qt[l] || Qt._default, s.innerHTML = c[1] + o.replace($t, "<$1></$2>") + c[2], i = c[0]; i--;) s = s.lastChild;
                    if (!it.leadingWhitespace && Wt.test(o) && p.push(t.createTextNode(Wt.exec(o)[0])), !it.tbody)
                        for (o = "table" !== l || It.test(o) ? "<table>" !== c[1] || It.test(o) ? 0 : s : s.firstChild, i = o && o.childNodes.length; i--;) at.nodeName(u = o.childNodes[i], "tbody") && !u.childNodes.length && o.removeChild(u);
                    for (at.merge(p, s.childNodes), s.textContent = ""; s.firstChild;) s.removeChild(s.firstChild);
                    s = f.lastChild
                } else p.push(t.createTextNode(o));
                for (s && f.removeChild(s), it.appendChecked || at.grep(v(p, "input"), y), h = 0; o = p[h++];)
                    if ((!r || -1 === at.inArray(o, r)) && (a = at.contains(o.ownerDocument, o), s = v(f.appendChild(o), "script"), a && T(s), n))
                        for (i = 0; o = s[i++];) Jt.test(o.type || "") && n.push(o);
                return s = null, f
            },
            cleanData: function(e, t) {
                for (var n, r, i, o, a = 0, s = at.expando, l = at.cache, u = it.deleteExpando, c = at.event.special; null != (n = e[a]); a++)
                    if ((t || at.acceptData(n)) && (i = n[s], o = i && l[i])) {
                        if (o.events)
                            for (r in o.events) c[r] ? at.event.remove(n, r) : at.removeEvent(n, r, o.handle);
                        l[i] && (delete l[i], u ? delete n[s] : typeof n.removeAttribute !== Et ? n.removeAttribute(s) : n[s] = null, Y.push(i))
                    }
            }
        }), at.fn.extend({
            text: function(e) {
                return Lt(this, function(e) {
                    return void 0 === e ? at.text(this) : this.empty().append((this[0] && this[0].ownerDocument || gt).createTextNode(e))
                }, null, e, arguments.length)
            },
            append: function() {
                return this.domManip(arguments, function(e) {
                    if (1 === this.nodeType || 11 === this.nodeType || 9 === this.nodeType) {
                        var t = b(this, e);
                        t.appendChild(e)
                    }
                })
            },
            prepend: function() {
                return this.domManip(arguments, function(e) {
                    if (1 === this.nodeType || 11 === this.nodeType || 9 === this.nodeType) {
                        var t = b(this, e);
                        t.insertBefore(e, t.firstChild)
                    }
                })
            },
            before: function() {
                return this.domManip(arguments, function(e) {
                    this.parentNode && this.parentNode.insertBefore(e, this)
                })
            },
            after: function() {
                return this.domManip(arguments, function(e) {
                    this.parentNode && this.parentNode.insertBefore(e, this.nextSibling)
                })
            },
            remove: function(e, t) {
                for (var n, r = e ? at.filter(e, this) : this, i = 0; null != (n = r[i]); i++) t || 1 !== n.nodeType || at.cleanData(v(n)), n.parentNode && (t && at.contains(n.ownerDocument, n) && T(v(n, "script")), n.parentNode.removeChild(n));
                return this
            },
            empty: function() {
                for (var e, t = 0; null != (e = this[t]); t++) {
                    for (1 === e.nodeType && at.cleanData(v(e, !1)); e.firstChild;) e.removeChild(e.firstChild);
                    e.options && at.nodeName(e, "select") && (e.options.length = 0)
                }
                return this
            },
            clone: function(e, t) {
                return e = null == e ? !1 : e, t = null == t ? e : t, this.map(function() {
                    return at.clone(this, e, t)
                })
            },
            html: function(e) {
                return Lt(this, function(e) {
                    var t = this[0] || {},
                        n = 0,
                        r = this.length;
                    if (void 0 === e) return 1 === t.nodeType ? t.innerHTML.replace(Pt, "") : void 0;
                    if (!("string" != typeof e || Ut.test(e) || !it.htmlSerialize && Rt.test(e) || !it.leadingWhitespace && Wt.test(e) || Qt[(zt.exec(e) || ["", ""])[1].toLowerCase()])) {
                        e = e.replace($t, "<$1></$2>");
                        try {
                            for (; r > n; n++) t = this[n] || {}, 1 === t.nodeType && (at.cleanData(v(t, !1)), t.innerHTML = e);
                            t = 0
                        } catch (i) {}
                    }
                    t && this.empty().append(e)
                }, null, e, arguments.length)
            },
            replaceWith: function() {
                var e = arguments[0];
                return this.domManip(arguments, function(t) {
                    e = this.parentNode, at.cleanData(v(this)), e && e.replaceChild(t, this)
                }), e && (e.length || e.nodeType) ? this : this.remove()
            },
            detach: function(e) {
                return this.remove(e, !0)
            },
            domManip: function(e, t) {
                e = Q.apply([], e);
                var n, r, i, o, a, s, l = 0,
                    u = this.length,
                    c = this,
                    d = u - 1,
                    f = e[0],
                    p = at.isFunction(f);
                if (p || u > 1 && "string" == typeof f && !it.checkClone && Vt.test(f)) return this.each(function(n) {
                    var r = c.eq(n);
                    p && (e[0] = f.call(this, n, r.html())), r.domManip(e, t)
                });
                if (u && (s = at.buildFragment(e, this[0].ownerDocument, !1, this), n = s.firstChild, 1 === s.childNodes.length && (s = n), n)) {
                    for (o = at.map(v(s, "script"), x), i = o.length; u > l; l++) r = s, l !== d && (r = at.clone(r, !0, !0), i && at.merge(o, v(r, "script"))), t.call(this[l], r, l);
                    if (i)
                        for (a = o[o.length - 1].ownerDocument, at.map(o, w), l = 0; i > l; l++) r = o[l], Jt.test(r.type || "") && !at._data(r, "globalEval") && at.contains(a, r) && (r.src ? at._evalUrl && at._evalUrl(r.src) : at.globalEval((r.text || r.textContent || r.innerHTML || "").replace(Gt, "")));
                    s = n = null
                }
                return this
            }
        }), at.each({
            appendTo: "append",
            prependTo: "prepend",
            insertBefore: "before",
            insertAfter: "after",
            replaceAll: "replaceWith"
        }, function(e, t) {
            at.fn[e] = function(e) {
                for (var n, r = 0, i = [], o = at(e), a = o.length - 1; a >= r; r++) n = r === a ? this : this.clone(!0), at(o[r])[t](n), K.apply(i, n.get());
                return this.pushStack(i)
            }
        });
        var en, tn = {};
        ! function() {
            var e, t, n = gt.createElement("div"),
                r = "-webkit-box-sizing:content-box;-moz-box-sizing:content-box;box-sizing:content-box;display:block;padding:0;margin:0;border:0";
            n.innerHTML = "  <link/><table></table><a href='/a'>a</a><input type='checkbox'/>", e = n.getElementsByTagName("a")[0], e.style.cssText = "float:left;opacity:.5", it.opacity = /^0.5/.test(e.style.opacity), it.cssFloat = !!e.style.cssFloat, n.style.backgroundClip = "content-box", n.cloneNode(!0).style.backgroundClip = "", it.clearCloneStyle = "content-box" === n.style.backgroundClip, e = n = null, it.shrinkWrapBlocks = function() {
                var e, n, i, o;
                if (null == t) {
                    if (e = gt.getElementsByTagName("body")[0], !e) return;
                    o = "border:0;width:0;height:0;position:absolute;top:0;left:-9999px", n = gt.createElement("div"), i = gt.createElement("div"), e.appendChild(n).appendChild(i), t = !1, typeof i.style.zoom !== Et && (i.style.cssText = r + ";width:1px;padding:1px;zoom:1", i.innerHTML = "<div></div>", i.firstChild.style.width = "5px", t = 3 !== i.offsetWidth), e.removeChild(n), e = n = i = null
                }
                return t
            }
        }();
        var nn, rn, on = /^margin/,
            an = new RegExp("^(" + At + ")(?!px)[a-z%]+$", "i"),
            sn = /^(top|right|bottom|left)$/;
        e.getComputedStyle ? (nn = function(e) {
                return e.ownerDocument.defaultView.getComputedStyle(e, null)
            }, rn = function(e, t, n) {
                var r, i, o, a, s = e.style;
                return n = n || nn(e), a = n ? n.getPropertyValue(t) || n[t] : void 0, n && ("" !== a || at.contains(e.ownerDocument, e) || (a = at.style(e, t)), an.test(a) && on.test(t) && (r = s.width, i = s.minWidth, o = s.maxWidth, s.minWidth = s.maxWidth = s.width = a, a = n.width, s.width = r, s.minWidth = i, s.maxWidth = o)), void 0 === a ? a : a + ""
            }) : gt.documentElement.currentStyle && (nn = function(e) {
                return e.currentStyle
            }, rn = function(e, t, n) {
                var r, i, o, a, s = e.style;
                return n = n || nn(e), a = n ? n[t] : void 0, null == a && s && s[t] && (a = s[t]), an.test(a) && !sn.test(t) && (r = s.left, i = e.runtimeStyle, o = i && i.left, o && (i.left = e.currentStyle.left), s.left = "fontSize" === t ? "1em" : a, a = s.pixelLeft + "px", s.left = r, o && (i.left = o)), void 0 === a ? a : a + "" || "auto"
            }),
            function() {
                function t() {
                    var t, n, r = gt.getElementsByTagName("body")[0];
                    r && (t = gt.createElement("div"), n = gt.createElement("div"), t.style.cssText = u, r.appendChild(t).appendChild(n), n.style.cssText = "-webkit-box-sizing:border-box;-moz-box-sizing:border-box;box-sizing:border-box;position:absolute;display:block;padding:1px;border:1px;width:4px;margin-top:1%;top:1%", at.swap(r, null != r.style.zoom ? {
                        zoom: 1
                    } : {}, function() {
                        i = 4 === n.offsetWidth
                    }), o = !0, a = !1, s = !0, e.getComputedStyle && (a = "1%" !== (e.getComputedStyle(n, null) || {}).top, o = "4px" === (e.getComputedStyle(n, null) || {
                        width: "4px"
                    }).width), r.removeChild(t), n = r = null)
                }
                var n, r, i, o, a, s, l = gt.createElement("div"),
                    u = "border:0;width:0;height:0;position:absolute;top:0;left:-9999px",
                    c = "-webkit-box-sizing:content-box;-moz-box-sizing:content-box;box-sizing:content-box;display:block;padding:0;margin:0;border:0";
                l.innerHTML = "  <link/><table></table><a href='/a'>a</a><input type='checkbox'/>", n = l.getElementsByTagName("a")[0], n.style.cssText = "float:left;opacity:.5", it.opacity = /^0.5/.test(n.style.opacity), it.cssFloat = !!n.style.cssFloat, l.style.backgroundClip = "content-box", l.cloneNode(!0).style.backgroundClip = "", it.clearCloneStyle = "content-box" === l.style.backgroundClip, n = l = null, at.extend(it, {
                    reliableHiddenOffsets: function() {
                        if (null != r) return r;
                        var e, t, n, i = gt.createElement("div"),
                            o = gt.getElementsByTagName("body")[0];
                        return o ? (i.setAttribute("className", "t"), i.innerHTML = "  <link/><table></table><a href='/a'>a</a><input type='checkbox'/>", e = gt.createElement("div"), e.style.cssText = u, o.appendChild(e).appendChild(i), i.innerHTML = "<table><tr><td></td><td>t</td></tr></table>", t = i.getElementsByTagName("td"), t[0].style.cssText = "padding:0;margin:0;border:0;display:none", n = 0 === t[0].offsetHeight, t[0].style.display = "", t[1].style.display = "none", r = n && 0 === t[0].offsetHeight, o.removeChild(e), i = o = null, r) : void 0
                    },
                    boxSizing: function() {
                        return null == i && t(), i
                    },
                    boxSizingReliable: function() {
                        return null == o && t(), o
                    },
                    pixelPosition: function() {
                        return null == a && t(), a
                    },
                    reliableMarginRight: function() {
                        var t, n, r, i;
                        if (null == s && e.getComputedStyle) {
                            if (t = gt.getElementsByTagName("body")[0], !t) return;
                            n = gt.createElement("div"), r = gt.createElement("div"), n.style.cssText = u, t.appendChild(n).appendChild(r), i = r.appendChild(gt.createElement("div")), i.style.cssText = r.style.cssText = c, i.style.marginRight = i.style.width = "0", r.style.width = "1px", s = !parseFloat((e.getComputedStyle(i, null) || {}).marginRight), t.removeChild(n)
                        }
                        return s
                    }
                })
            }(), at.swap = function(e, t, n, r) {
                var i, o, a = {};
                for (o in t) a[o] = e.style[o], e.style[o] = t[o];
                i = n.apply(e, r || []);
                for (o in t) e.style[o] = a[o];
                return i
            };
        var ln = /alpha\([^)]*\)/i,
            un = /opacity\s*=\s*([^)]*)/,
            cn = /^(none|table(?!-c[ea]).+)/,
            dn = new RegExp("^(" + At + ")(.*)$", "i"),
            fn = new RegExp("^([+-])=(" + At + ")", "i"),
            pn = {
                position: "absolute",
                visibility: "hidden",
                display: "block"
            },
            hn = {
                letterSpacing: 0,
                fontWeight: 400
            },
            mn = ["Webkit", "O", "Moz", "ms"];
        at.extend({
            cssHooks: {
                opacity: {
                    get: function(e, t) {
                        if (t) {
                            var n = rn(e, "opacity");
                            return "" === n ? "1" : n
                        }
                    }
                }
            },
            cssNumber: {
                columnCount: !0,
                fillOpacity: !0,
                fontWeight: !0,
                lineHeight: !0,
                opacity: !0,
                order: !0,
                orphans: !0,
                widows: !0,
                zIndex: !0,
                zoom: !0
            },
            cssProps: {
                "float": it.cssFloat ? "cssFloat" : "styleFloat"
            },
            style: function(e, t, n, r) {
                if (e && 3 !== e.nodeType && 8 !== e.nodeType && e.style) {
                    var i, o, a, s = at.camelCase(t),
                        l = e.style;
                    if (t = at.cssProps[s] || (at.cssProps[s] = A(l, s)), a = at.cssHooks[t] || at.cssHooks[s], void 0 === n) return a && "get" in a && void 0 !== (i = a.get(e, !1, r)) ? i : l[t];
                    if (o = typeof n, "string" === o && (i = fn.exec(n)) && (n = (i[1] + 1) * i[2] + parseFloat(at.css(e, t)), o = "number"), null != n && n === n && ("number" !== o || at.cssNumber[s] || (n += "px"), it.clearCloneStyle || "" !== n || 0 !== t.indexOf("background") || (l[t] = "inherit"), !(a && "set" in a && void 0 === (n = a.set(e, n, r))))) try {
                        l[t] = "", l[t] = n
                    } catch (u) {}
                }
            },
            css: function(e, t, n, r) {
                var i, o, a, s = at.camelCase(t);
                return t = at.cssProps[s] || (at.cssProps[s] = A(e.style, s)), a = at.cssHooks[t] || at.cssHooks[s], a && "get" in a && (o = a.get(e, !0, n)), void 0 === o && (o = rn(e, t, r)), "normal" === o && t in hn && (o = hn[t]), "" === n || n ? (i = parseFloat(o), n === !0 || at.isNumeric(i) ? i || 0 : o) : o
            }
        }), at.each(["height", "width"], function(e, t) {
            at.cssHooks[t] = {
                get: function(e, n, r) {
                    return n ? 0 === e.offsetWidth && cn.test(at.css(e, "display")) ? at.swap(e, pn, function() {
                        return H(e, t, r)
                    }) : H(e, t, r) : void 0
                },
                set: function(e, n, r) {
                    var i = r && nn(e);
                    return j(e, n, r ? L(e, t, r, it.boxSizing() && "border-box" === at.css(e, "boxSizing", !1, i), i) : 0)
                }
            }
        }), it.opacity || (at.cssHooks.opacity = {
            get: function(e, t) {
                return un.test((t && e.currentStyle ? e.currentStyle.filter : e.style.filter) || "") ? .01 * parseFloat(RegExp.$1) + "" : t ? "1" : ""
            },
            set: function(e, t) {
                var n = e.style,
                    r = e.currentStyle,
                    i = at.isNumeric(t) ? "alpha(opacity=" + 100 * t + ")" : "",
                    o = r && r.filter || n.filter || "";
                n.zoom = 1, (t >= 1 || "" === t) && "" === at.trim(o.replace(ln, "")) && n.removeAttribute && (n.removeAttribute("filter"), "" === t || r && !r.filter) || (n.filter = ln.test(o) ? o.replace(ln, i) : o + " " + i)
            }
        }), at.cssHooks.marginRight = S(it.reliableMarginRight, function(e, t) {
            return t ? at.swap(e, {
                display: "inline-block"
            }, rn, [e, "marginRight"]) : void 0
        }), at.each({
            margin: "",
            padding: "",
            border: "Width"
        }, function(e, t) {
            at.cssHooks[e + t] = {
                expand: function(n) {
                    for (var r = 0, i = {}, o = "string" == typeof n ? n.split(" ") : [n]; 4 > r; r++) i[e + Dt[r] + t] = o[r] || o[r - 2] || o[0];
                    return i
                }
            }, on.test(e) || (at.cssHooks[e + t].set = j)
        }), at.fn.extend({
            css: function(e, t) {
                return Lt(this, function(e, t, n) {
                    var r, i, o = {},
                        a = 0;
                    if (at.isArray(t)) {
                        for (r = nn(e), i = t.length; i > a; a++) o[t[a]] = at.css(e, t[a], !1, r);
                        return o
                    }
                    return void 0 !== n ? at.style(e, t, n) : at.css(e, t)
                }, e, t, arguments.length > 1)
            },
            show: function() {
                return D(this, !0)
            },
            hide: function() {
                return D(this)
            },
            toggle: function(e) {
                return "boolean" == typeof e ? e ? this.show() : this.hide() : this.each(function() {
                    jt(this) ? at(this).show() : at(this).hide()
                })
            }
        }), at.Tween = q, q.prototype = {
            constructor: q,
            init: function(e, t, n, r, i, o) {
                this.elem = e, this.prop = n, this.easing = i || "swing", this.options = t, this.start = this.now = this.cur(), this.end = r, this.unit = o || (at.cssNumber[n] ? "" : "px")
            },
            cur: function() {
                var e = q.propHooks[this.prop];
                return e && e.get ? e.get(this) : q.propHooks._default.get(this)
            },
            run: function(e) {
                var t, n = q.propHooks[this.prop];
                return this.pos = t = this.options.duration ? at.easing[this.easing](e, this.options.duration * e, 0, 1, this.options.duration) : e, this.now = (this.end - this.start) * t + this.start, this.options.step && this.options.step.call(this.elem, this.now, this), n && n.set ? n.set(this) : q.propHooks._default.set(this), this
            }
        }, q.prototype.init.prototype = q.prototype, q.propHooks = {
            _default: {
                get: function(e) {
                    var t;
                    return null == e.elem[e.prop] || e.elem.style && null != e.elem.style[e.prop] ? (t = at.css(e.elem, e.prop, ""), t && "auto" !== t ? t : 0) : e.elem[e.prop]
                },
                set: function(e) {
                    at.fx.step[e.prop] ? at.fx.step[e.prop](e) : e.elem.style && (null != e.elem.style[at.cssProps[e.prop]] || at.cssHooks[e.prop]) ? at.style(e.elem, e.prop, e.now + e.unit) : e.elem[e.prop] = e.now
                }
            }
        }, q.propHooks.scrollTop = q.propHooks.scrollLeft = {
            set: function(e) {
                e.elem.nodeType && e.elem.parentNode && (e.elem[e.prop] = e.now)
            }
        }, at.easing = {
            linear: function(e) {
                return e
            },
            swing: function(e) {
                return .5 - Math.cos(e * Math.PI) / 2
            }
        }, at.fx = q.prototype.init, at.fx.step = {};
        var gn, vn, yn = /^(?:toggle|show|hide)$/,
            bn = new RegExp("^(?:([+-])=|)(" + At + ")([a-z%]*)$", "i"),
            xn = /queueHooks$/,
            wn = [O],
            Tn = {
                "*": [function(e, t) {
                    var n = this.createTween(e, t),
                        r = n.cur(),
                        i = bn.exec(t),
                        o = i && i[3] || (at.cssNumber[e] ? "" : "px"),
                        a = (at.cssNumber[e] || "px" !== o && +r) && bn.exec(at.css(n.elem, e)),
                        s = 1,
                        l = 20;
                    if (a && a[3] !== o) {
                        o = o || a[3], i = i || [], a = +r || 1;
                        do s = s || ".5", a /= s, at.style(n.elem, e, a + o); while (s !== (s = n.cur() / r) && 1 !== s && --l)
                    }
                    return i && (a = n.start = +a || +r || 0, n.unit = o, n.end = i[1] ? a + (i[1] + 1) * i[2] : +i[2]), n
                }]
            };
        at.Animation = at.extend(P, {
                tweener: function(e, t) {
                    at.isFunction(e) ? (t = e, e = ["*"]) : e = e.split(" ");
                    for (var n, r = 0, i = e.length; i > r; r++) n = e[r], Tn[n] = Tn[n] || [], Tn[n].unshift(t)
                },
                prefilter: function(e, t) {
                    t ? wn.unshift(e) : wn.push(e)
                }
            }), at.speed = function(e, t, n) {
                var r = e && "object" == typeof e ? at.extend({}, e) : {
                    complete: n || !n && t || at.isFunction(e) && e,
                    duration: e,
                    easing: n && t || t && !at.isFunction(t) && t
                };
                return r.duration = at.fx.off ? 0 : "number" == typeof r.duration ? r.duration : r.duration in at.fx.speeds ? at.fx.speeds[r.duration] : at.fx.speeds._default, (null == r.queue || r.queue === !0) && (r.queue = "fx"), r.old = r.complete, r.complete = function() {
                    at.isFunction(r.old) && r.old.call(this), r.queue && at.dequeue(this, r.queue)
                }, r
            }, at.fn.extend({
                fadeTo: function(e, t, n, r) {
                    return this.filter(jt).css("opacity", 0).show().end().animate({
                        opacity: t
                    }, e, n, r)
                },
                animate: function(e, t, n, r) {
                    var i = at.isEmptyObject(e),
                        o = at.speed(t, n, r),
                        a = function() {
                            var t = P(this, at.extend({}, e), o);
                            (i || at._data(this, "finish")) && t.stop(!0)
                        };
                    return a.finish = a, i || o.queue === !1 ? this.each(a) : this.queue(o.queue, a)
                },
                stop: function(e, t, n) {
                    var r = function(e) {
                        var t = e.stop;
                        delete e.stop, t(n)
                    };
                    return "string" != typeof e && (n = t, t = e, e = void 0), t && e !== !1 && this.queue(e || "fx", []), this.each(function() {
                        var t = !0,
                            i = null != e && e + "queueHooks",
                            o = at.timers,
                            a = at._data(this);
                        if (i) a[i] && a[i].stop && r(a[i]);
                        else
                            for (i in a) a[i] && a[i].stop && xn.test(i) && r(a[i]);
                        for (i = o.length; i--;) o[i].elem !== this || null != e && o[i].queue !== e || (o[i].anim.stop(n), t = !1, o.splice(i, 1));
                        (t || !n) && at.dequeue(this, e)
                    })
                },
                finish: function(e) {
                    return e !== !1 && (e = e || "fx"), this.each(function() {
                        var t, n = at._data(this),
                            r = n[e + "queue"],
                            i = n[e + "queueHooks"],
                            o = at.timers,
                            a = r ? r.length : 0;
                        for (n.finish = !0, at.queue(this, e, []), i && i.stop && i.stop.call(this, !0), t = o.length; t--;) o[t].elem === this && o[t].queue === e && (o[t].anim.stop(!0), o.splice(t, 1));
                        for (t = 0; a > t; t++) r[t] && r[t].finish && r[t].finish.call(this);
                        delete n.finish
                    })
                }
            }), at.each(["toggle", "show", "hide"], function(e, t) {
                var n = at.fn[t];
                at.fn[t] = function(e, r, i) {
                    return null == e || "boolean" == typeof e ? n.apply(this, arguments) : this.animate(M(t, !0), e, r, i)
                }
            }), at.each({
                slideDown: M("show"),
                slideUp: M("hide"),
                slideToggle: M("toggle"),
                fadeIn: {
                    opacity: "show"
                },
                fadeOut: {
                    opacity: "hide"
                },
                fadeToggle: {
                    opacity: "toggle"
                }
            }, function(e, t) {
                at.fn[e] = function(e, n, r) {
                    return this.animate(t, e, n, r)
                }
            }), at.timers = [], at.fx.tick = function() {
                var e, t = at.timers,
                    n = 0;
                for (gn = at.now(); n < t.length; n++) e = t[n], e() || t[n] !== e || t.splice(n--, 1);
                t.length || at.fx.stop(), gn = void 0
            }, at.fx.timer = function(e) {
                at.timers.push(e), e() ? at.fx.start() : at.timers.pop()
            }, at.fx.interval = 13, at.fx.start = function() {
                vn || (vn = setInterval(at.fx.tick, at.fx.interval))
            }, at.fx.stop = function() {
                clearInterval(vn), vn = null
            }, at.fx.speeds = {
                slow: 600,
                fast: 200,
                _default: 400
            }, at.fn.delay = function(e, t) {
                return e = at.fx ? at.fx.speeds[e] || e : e, t = t || "fx", this.queue(t, function(t, n) {
                    var r = setTimeout(t, e);
                    n.stop = function() {
                        clearTimeout(r)
                    }
                })
            },
            function() {
                var e, t, n, r, i = gt.createElement("div");
                i.setAttribute("className", "t"), i.innerHTML = "  <link/><table></table><a href='/a'>a</a><input type='checkbox'/>", e = i.getElementsByTagName("a")[0], n = gt.createElement("select"), r = n.appendChild(gt.createElement("option")), t = i.getElementsByTagName("input")[0], e.style.cssText = "top:1px", it.getSetAttribute = "t" !== i.className, it.style = /top/.test(e.getAttribute("style")), it.hrefNormalized = "/a" === e.getAttribute("href"), it.checkOn = !!t.value, it.optSelected = r.selected, it.enctype = !!gt.createElement("form").enctype, n.disabled = !0, it.optDisabled = !r.disabled, t = gt.createElement("input"), t.setAttribute("value", ""), it.input = "" === t.getAttribute("value"), t.value = "t", t.setAttribute("type", "radio"), it.radioValue = "t" === t.value, e = t = n = r = i = null
            }();
        var Cn = /\r/g;
        at.fn.extend({
            val: function(e) {
                var t, n, r, i = this[0];
                return arguments.length ? (r = at.isFunction(e), this.each(function(n) {
                    var i;
                    1 === this.nodeType && (i = r ? e.call(this, n, at(this).val()) : e, null == i ? i = "" : "number" == typeof i ? i += "" : at.isArray(i) && (i = at.map(i, function(e) {
                        return null == e ? "" : e + ""
                    })), t = at.valHooks[this.type] || at.valHooks[this.nodeName.toLowerCase()], t && "set" in t && void 0 !== t.set(this, i, "value") || (this.value = i))
                })) : i ? (t = at.valHooks[i.type] || at.valHooks[i.nodeName.toLowerCase()], t && "get" in t && void 0 !== (n = t.get(i, "value")) ? n : (n = i.value, "string" == typeof n ? n.replace(Cn, "") : null == n ? "" : n)) : void 0
            }
        }), at.extend({
            valHooks: {
                option: {
                    get: function(e) {
                        var t = at.find.attr(e, "value");
                        return null != t ? t : at.text(e)
                    }
                },
                select: {
                    get: function(e) {
                        for (var t, n, r = e.options, i = e.selectedIndex, o = "select-one" === e.type || 0 > i, a = o ? null : [], s = o ? i + 1 : r.length, l = 0 > i ? s : o ? i : 0; s > l; l++)
                            if (n = r[l], !(!n.selected && l !== i || (it.optDisabled ? n.disabled : null !== n.getAttribute("disabled")) || n.parentNode.disabled && at.nodeName(n.parentNode, "optgroup"))) {
                                if (t = at(n).val(), o) return t;
                                a.push(t)
                            }
                        return a
                    },
                    set: function(e, t) {
                        for (var n, r, i = e.options, o = at.makeArray(t), a = i.length; a--;)
                            if (r = i[a], at.inArray(at.valHooks.option.get(r), o) >= 0) try {
                                r.selected = n = !0
                            } catch (s) {
                                r.scrollHeight
                            } else r.selected = !1;
                        return n || (e.selectedIndex = -1), i
                    }
                }
            }
        }), at.each(["radio", "checkbox"], function() {
            at.valHooks[this] = {
                set: function(e, t) {
                    return at.isArray(t) ? e.checked = at.inArray(at(e).val(), t) >= 0 : void 0
                }
            }, it.checkOn || (at.valHooks[this].get = function(e) {
                return null === e.getAttribute("value") ? "on" : e.value
            })
        });
        var Nn, En, kn = at.expr.attrHandle,
            Sn = /^(?:checked|selected)$/i,
            An = it.getSetAttribute,
            Dn = it.input;
        at.fn.extend({
            attr: function(e, t) {
                return Lt(this, at.attr, e, t, arguments.length > 1)
            },
            removeAttr: function(e) {
                return this.each(function() {
                    at.removeAttr(this, e)
                })
            }
        }), at.extend({
            attr: function(e, t, n) {
                var r, i, o = e.nodeType;
                return e && 3 !== o && 8 !== o && 2 !== o ? typeof e.getAttribute === Et ? at.prop(e, t, n) : (1 === o && at.isXMLDoc(e) || (t = t.toLowerCase(), r = at.attrHooks[t] || (at.expr.match.bool.test(t) ? En : Nn)), void 0 === n ? r && "get" in r && null !== (i = r.get(e, t)) ? i : (i = at.find.attr(e, t), null == i ? void 0 : i) : null !== n ? r && "set" in r && void 0 !== (i = r.set(e, n, t)) ? i : (e.setAttribute(t, n + ""), n) : (at.removeAttr(e, t), void 0)) : void 0
            },
            removeAttr: function(e, t) {
                var n, r, i = 0,
                    o = t && t.match(wt);
                if (o && 1 === e.nodeType)
                    for (; n = o[i++];) r = at.propFix[n] || n, at.expr.match.bool.test(n) ? Dn && An || !Sn.test(n) ? e[r] = !1 : e[at.camelCase("default-" + n)] = e[r] = !1 : at.attr(e, n, ""), e.removeAttribute(An ? n : r)
            },
            attrHooks: {
                type: {
                    set: function(e, t) {
                        if (!it.radioValue && "radio" === t && at.nodeName(e, "input")) {
                            var n = e.value;
                            return e.setAttribute("type", t), n && (e.value = n), t
                        }
                    }
                }
            }
        }), En = {
            set: function(e, t, n) {
                return t === !1 ? at.removeAttr(e, n) : Dn && An || !Sn.test(n) ? e.setAttribute(!An && at.propFix[n] || n, n) : e[at.camelCase("default-" + n)] = e[n] = !0, n
            }
        }, at.each(at.expr.match.bool.source.match(/\w+/g), function(e, t) {
            var n = kn[t] || at.find.attr;
            kn[t] = Dn && An || !Sn.test(t) ? function(e, t, r) {
                var i, o;
                return r || (o = kn[t], kn[t] = i, i = null != n(e, t, r) ? t.toLowerCase() : null, kn[t] = o), i
            } : function(e, t, n) {
                return n ? void 0 : e[at.camelCase("default-" + t)] ? t.toLowerCase() : null
            }
        }), Dn && An || (at.attrHooks.value = {
            set: function(e, t, n) {
                return at.nodeName(e, "input") ? (e.defaultValue = t, void 0) : Nn && Nn.set(e, t, n)
            }
        }), An || (Nn = {
            set: function(e, t, n) {
                var r = e.getAttributeNode(n);
                return r || e.setAttributeNode(r = e.ownerDocument.createAttribute(n)), r.value = t += "", "value" === n || t === e.getAttribute(n) ? t : void 0
            }
        }, kn.id = kn.name = kn.coords = function(e, t, n) {
            var r;
            return n ? void 0 : (r = e.getAttributeNode(t)) && "" !== r.value ? r.value : null
        }, at.valHooks.button = {
            get: function(e, t) {
                var n = e.getAttributeNode(t);
                return n && n.specified ? n.value : void 0
            },
            set: Nn.set
        }, at.attrHooks.contenteditable = {
            set: function(e, t, n) {
                Nn.set(e, "" === t ? !1 : t, n)
            }
        }, at.each(["width", "height"], function(e, t) {
            at.attrHooks[t] = {
                set: function(e, n) {
                    return "" === n ? (e.setAttribute(t, "auto"), n) : void 0
                }
            }
        })), it.style || (at.attrHooks.style = {
            get: function(e) {
                return e.style.cssText || void 0
            },
            set: function(e, t) {
                return e.style.cssText = t + ""
            }
        });
        var jn = /^(?:input|select|textarea|button|object)$/i,
            Ln = /^(?:a|area)$/i;
        at.fn.extend({
            prop: function(e, t) {
                return Lt(this, at.prop, e, t, arguments.length > 1)
            },
            removeProp: function(e) {
                return e = at.propFix[e] || e, this.each(function() {
                    try {
                        this[e] = void 0, delete this[e]
                    } catch (t) {}
                })
            }
        }), at.extend({
            propFix: {
                "for": "htmlFor",
                "class": "className"
            },
            prop: function(e, t, n) {
                var r, i, o, a = e.nodeType;
                return e && 3 !== a && 8 !== a && 2 !== a ? (o = 1 !== a || !at.isXMLDoc(e), o && (t = at.propFix[t] || t, i = at.propHooks[t]), void 0 !== n ? i && "set" in i && void 0 !== (r = i.set(e, n, t)) ? r : e[t] = n : i && "get" in i && null !== (r = i.get(e, t)) ? r : e[t]) : void 0
            },
            propHooks: {
                tabIndex: {
                    get: function(e) {
                        var t = at.find.attr(e, "tabindex");
                        return t ? parseInt(t, 10) : jn.test(e.nodeName) || Ln.test(e.nodeName) && e.href ? 0 : -1
                    }
                }
            }
        }), it.hrefNormalized || at.each(["href", "src"], function(e, t) {
            at.propHooks[t] = {
                get: function(e) {
                    return e.getAttribute(t, 4)
                }
            }
        }), it.optSelected || (at.propHooks.selected = {
            get: function(e) {
                var t = e.parentNode;
                return t && (t.selectedIndex, t.parentNode && t.parentNode.selectedIndex), null
            }
        }), at.each(["tabIndex", "readOnly", "maxLength", "cellSpacing", "cellPadding", "rowSpan", "colSpan", "useMap", "frameBorder", "contentEditable"], function() {
            at.propFix[this.toLowerCase()] = this
        }), it.enctype || (at.propFix.enctype = "encoding");
        var Hn = /[\t\r\n\f]/g;
        at.fn.extend({
            addClass: function(e) {
                var t, n, r, i, o, a, s = 0,
                    l = this.length,
                    u = "string" == typeof e && e;
                if (at.isFunction(e)) return this.each(function(t) {
                    at(this).addClass(e.call(this, t, this.className))
                });
                if (u)
                    for (t = (e || "").match(wt) || []; l > s; s++)
                        if (n = this[s], r = 1 === n.nodeType && (n.className ? (" " + n.className + " ").replace(Hn, " ") : " ")) {
                            for (o = 0; i = t[o++];) r.indexOf(" " + i + " ") < 0 && (r += i + " ");
                            a = at.trim(r), n.className !== a && (n.className = a)
                        }
                return this
            },
            removeClass: function(e) {
                var t, n, r, i, o, a, s = 0,
                    l = this.length,
                    u = 0 === arguments.length || "string" == typeof e && e;
                if (at.isFunction(e)) return this.each(function(t) {
                    at(this).removeClass(e.call(this, t, this.className))
                });
                if (u)
                    for (t = (e || "").match(wt) || []; l > s; s++)
                        if (n = this[s], r = 1 === n.nodeType && (n.className ? (" " + n.className + " ").replace(Hn, " ") : "")) {
                            for (o = 0; i = t[o++];)
                                for (; r.indexOf(" " + i + " ") >= 0;) r = r.replace(" " + i + " ", " ");
                            a = e ? at.trim(r) : "", n.className !== a && (n.className = a)
                        }
                return this
            },
            toggleClass: function(e, t) {
                var n = typeof e;
                return "boolean" == typeof t && "string" === n ? t ? this.addClass(e) : this.removeClass(e) : at.isFunction(e) ? this.each(function(n) {
                    at(this).toggleClass(e.call(this, n, this.className, t), t)
                }) : this.each(function() {
                    if ("string" === n)
                        for (var t, r = 0, i = at(this), o = e.match(wt) || []; t = o[r++];) i.hasClass(t) ? i.removeClass(t) : i.addClass(t);
                    else(n === Et || "boolean" === n) && (this.className && at._data(this, "__className__", this.className), this.className = this.className || e === !1 ? "" : at._data(this, "__className__") || "")
                })
            },
            hasClass: function(e) {
                for (var t = " " + e + " ", n = 0, r = this.length; r > n; n++)
                    if (1 === this[n].nodeType && (" " + this[n].className + " ").replace(Hn, " ").indexOf(t) >= 0) return !0;
                return !1
            }
        }), at.each("blur focus focusin focusout load resize scroll unload click dblclick mousedown mouseup mousemove mouseover mouseout mouseenter mouseleave change select submit keydown keypress keyup error contextmenu".split(" "), function(e, t) {
            at.fn[t] = function(e, n) {
                return arguments.length > 0 ? this.on(t, null, e, n) : this.trigger(t)
            }
        }), at.fn.extend({
            hover: function(e, t) {
                return this.mouseenter(e).mouseleave(t || e)
            },
            bind: function(e, t, n) {
                return this.on(e, null, t, n)
            },
            unbind: function(e, t) {
                return this.off(e, null, t)
            },
            delegate: function(e, t, n, r) {
                return this.on(t, e, n, r)
            },
            undelegate: function(e, t, n) {
                return 1 === arguments.length ? this.off(e, "**") : this.off(t, e || "**", n)
            }
        });
        var qn = at.now(),
            _n = /\?/,
            Mn = /(,)|(\[|{)|(}|])|"(?:[^"\\\r\n]|\\["\\\/bfnrt]|\\u[\da-fA-F]{4})*"\s*:?|true|false|null|-?(?!0\d)\d+(?:\.\d+|)(?:[eE][+-]?\d+|)/g;
        at.parseJSON = function(t) {
            if (e.JSON && e.JSON.parse) return e.JSON.parse(t + "");
            var n, r = null,
                i = at.trim(t + "");
            return i && !at.trim(i.replace(Mn, function(e, t, i, o) {
                return n && t && (r = 0), 0 === r ? e : (n = i || t, r += !o - !i, "")
            })) ? Function("return " + i)() : at.error("Invalid JSON: " + t)
        }, at.parseXML = function(t) {
            var n, r;
            if (!t || "string" != typeof t) return null;
            try {
                e.DOMParser ? (r = new DOMParser, n = r.parseFromString(t, "text/xml")) : (n = new ActiveXObject("Microsoft.XMLDOM"), n.async = "false", n.loadXML(t))
            } catch (i) {
                n = void 0
            }
            return n && n.documentElement && !n.getElementsByTagName("parsererror").length || at.error("Invalid XML: " + t), n
        };
        var Fn, On, Bn = /#.*$/,
            Pn = /([?&])_=[^&]*/,
            Rn = /^(.*?):[ \t]*([^\r\n]*)\r?$/gm,
            Wn = /^(?:about|app|app-storage|.+-extension|file|res|widget):$/,
            $n = /^(?:GET|HEAD)$/,
            zn = /^\/\//,
            In = /^([\w.+-]+:)(?:\/\/(?:[^\/?#]*@|)([^\/?#:]*)(?::(\d+)|)|)/,
            Xn = {},
            Un = {},
            Vn = "*/".concat("*");
        try {
            On = location.href
        } catch (Jn) {
            On = gt.createElement("a"), On.href = "", On = On.href
        }
        Fn = In.exec(On.toLowerCase()) || [], at.extend({
            active: 0,
            lastModified: {},
            etag: {},
            ajaxSettings: {
                url: On,
                type: "GET",
                isLocal: Wn.test(Fn[1]),
                global: !0,
                processData: !0,
                async: !0,
                contentType: "application/x-www-form-urlencoded; charset=UTF-8",
                accepts: {
                    "*": Vn,
                    text: "text/plain",
                    html: "text/html",
                    xml: "application/xml, text/xml",
                    json: "application/json, text/javascript"
                },
                contents: {
                    xml: /xml/,
                    html: /html/,
                    json: /json/
                },
                responseFields: {
                    xml: "responseXML",
                    text: "responseText",
                    json: "responseJSON"
                },
                converters: {
                    "* text": String,
                    "text html": !0,
                    "text json": at.parseJSON,
                    "text xml": at.parseXML
                },
                flatOptions: {
                    url: !0,
                    context: !0
                }
            },
            ajaxSetup: function(e, t) {
                return t ? $($(e, at.ajaxSettings), t) : $(at.ajaxSettings, e)
            },
            ajaxPrefilter: R(Xn),
            ajaxTransport: R(Un),
            ajax: function(e, t) {
                function n(e, t, n, r) {
                    var i, c, v, y, x, T = t;
                    2 !== b && (b = 2, s && clearTimeout(s), u = void 0, a = r || "", w.readyState = e > 0 ? 4 : 0, i = e >= 200 && 300 > e || 304 === e, n && (y = z(d, w, n)), y = I(d, y, w, i), i ? (d.ifModified && (x = w.getResponseHeader("Last-Modified"), x && (at.lastModified[o] = x), x = w.getResponseHeader("etag"), x && (at.etag[o] = x)), 204 === e || "HEAD" === d.type ? T = "nocontent" : 304 === e ? T = "notmodified" : (T = y.state, c = y.data, v = y.error, i = !v)) : (v = T, (e || !T) && (T = "error", 0 > e && (e = 0))), w.status = e, w.statusText = (t || T) + "", i ? h.resolveWith(f, [c, T, w]) : h.rejectWith(f, [w, T, v]), w.statusCode(g), g = void 0, l && p.trigger(i ? "ajaxSuccess" : "ajaxError", [w, d, i ? c : v]), m.fireWith(f, [w, T]), l && (p.trigger("ajaxComplete", [w, d]), --at.active || at.event.trigger("ajaxStop")))
                }
                "object" == typeof e && (t = e, e = void 0), t = t || {};
                var r, i, o, a, s, l, u, c, d = at.ajaxSetup({}, t),
                    f = d.context || d,
                    p = d.context && (f.nodeType || f.jquery) ? at(f) : at.event,
                    h = at.Deferred(),
                    m = at.Callbacks("once memory"),
                    g = d.statusCode || {},
                    v = {},
                    y = {},
                    b = 0,
                    x = "canceled",
                    w = {
                        readyState: 0,
                        getResponseHeader: function(e) {
                            var t;
                            if (2 === b) {
                                if (!c)
                                    for (c = {}; t = Rn.exec(a);) c[t[1].toLowerCase()] = t[2];
                                t = c[e.toLowerCase()]
                            }
                            return null == t ? null : t
                        },
                        getAllResponseHeaders: function() {
                            return 2 === b ? a : null
                        },
                        setRequestHeader: function(e, t) {
                            var n = e.toLowerCase();
                            return b || (e = y[n] = y[n] || e, v[e] = t), this
                        },
                        overrideMimeType: function(e) {
                            return b || (d.mimeType = e), this
                        },
                        statusCode: function(e) {
                            var t;
                            if (e)
                                if (2 > b)
                                    for (t in e) g[t] = [g[t], e[t]];
                                else w.always(e[w.status]);
                            return this
                        },
                        abort: function(e) {
                            var t = e || x;
                            return u && u.abort(t), n(0, t), this
                        }
                    };
                if (h.promise(w).complete = m.add, w.success = w.done, w.error = w.fail, d.url = ((e || d.url || On) + "").replace(Bn, "").replace(zn, Fn[1] + "//"), d.type = t.method || t.type || d.method || d.type, d.dataTypes = at.trim(d.dataType || "*").toLowerCase().match(wt) || [""], null == d.crossDomain && (r = In.exec(d.url.toLowerCase()), d.crossDomain = !(!r || r[1] === Fn[1] && r[2] === Fn[2] && (r[3] || ("http:" === r[1] ? "80" : "443")) === (Fn[3] || ("http:" === Fn[1] ? "80" : "443")))), d.data && d.processData && "string" != typeof d.data && (d.data = at.param(d.data, d.traditional)), W(Xn, d, t, w), 2 === b) return w;
                l = d.global, l && 0 === at.active++ && at.event.trigger("ajaxStart"), d.type = d.type.toUpperCase(), d.hasContent = !$n.test(d.type), o = d.url, d.hasContent || (d.data && (o = d.url += (_n.test(o) ? "&" : "?") + d.data, delete d.data), d.cache === !1 && (d.url = Pn.test(o) ? o.replace(Pn, "$1_=" + qn++) : o + (_n.test(o) ? "&" : "?") + "_=" + qn++)), d.ifModified && (at.lastModified[o] && w.setRequestHeader("If-Modified-Since", at.lastModified[o]), at.etag[o] && w.setRequestHeader("If-None-Match", at.etag[o])), (d.data && d.hasContent && d.contentType !== !1 || t.contentType) && w.setRequestHeader("Content-Type", d.contentType), w.setRequestHeader("Accept", d.dataTypes[0] && d.accepts[d.dataTypes[0]] ? d.accepts[d.dataTypes[0]] + ("*" !== d.dataTypes[0] ? ", " + Vn + "; q=0.01" : "") : d.accepts["*"]);
                for (i in d.headers) w.setRequestHeader(i, d.headers[i]);
                if (d.beforeSend && (d.beforeSend.call(f, w, d) === !1 || 2 === b)) return w.abort();
                x = "abort";
                for (i in {
                        success: 1,
                        error: 1,
                        complete: 1
                    }) w[i](d[i]);
                if (u = W(Un, d, t, w)) {
                    w.readyState = 1, l && p.trigger("ajaxSend", [w, d]), d.async && d.timeout > 0 && (s = setTimeout(function() {
                        w.abort("timeout")
                    }, d.timeout));
                    try {
                        b = 1, u.send(v, n)
                    } catch (T) {
                        if (!(2 > b)) throw T;
                        n(-1, T)
                    }
                } else n(-1, "No Transport");
                return w
            },
            getJSON: function(e, t, n) {
                return at.get(e, t, n, "json")
            },
            getScript: function(e, t) {
                return at.get(e, void 0, t, "script")
            }
        }), at.each(["get", "post"], function(e, t) {
            at[t] = function(e, n, r, i) {
                return at.isFunction(n) && (i = i || r, r = n, n = void 0), at.ajax({
                    url: e,
                    type: t,
                    dataType: i,
                    data: n,
                    success: r
                })
            }
        }), at.each(["ajaxStart", "ajaxStop", "ajaxComplete", "ajaxError", "ajaxSuccess", "ajaxSend"], function(e, t) {
            at.fn[t] = function(e) {
                return this.on(t, e)
            }
        }), at._evalUrl = function(e) {
            return at.ajax({
                url: e,
                type: "GET",
                dataType: "script",
                async: !1,
                global: !1,
                "throws": !0
            })
        }, at.fn.extend({
            wrapAll: function(e) {
                if (at.isFunction(e)) return this.each(function(t) {
                    at(this).wrapAll(e.call(this, t))
                });
                if (this[0]) {
                    var t = at(e, this[0].ownerDocument).eq(0).clone(!0);
                    this[0].parentNode && t.insertBefore(this[0]), t.map(function() {
                        for (var e = this; e.firstChild && 1 === e.firstChild.nodeType;) e = e.firstChild;
                        return e
                    }).append(this)
                }
                return this
            },
            wrapInner: function(e) {
                return at.isFunction(e) ? this.each(function(t) {
                    at(this).wrapInner(e.call(this, t))
                }) : this.each(function() {
                    var t = at(this),
                        n = t.contents();
                    n.length ? n.wrapAll(e) : t.append(e)
                })
            },
            wrap: function(e) {
                var t = at.isFunction(e);
                return this.each(function(n) {
                    at(this).wrapAll(t ? e.call(this, n) : e)
                })
            },
            unwrap: function() {
                return this.parent().each(function() {
                    at.nodeName(this, "body") || at(this).replaceWith(this.childNodes)
                }).end()
            }
        }), at.expr.filters.hidden = function(e) {
            return e.offsetWidth <= 0 && e.offsetHeight <= 0 || !it.reliableHiddenOffsets() && "none" === (e.style && e.style.display || at.css(e, "display"))
        }, at.expr.filters.visible = function(e) {
            return !at.expr.filters.hidden(e)
        };
        var Yn = /%20/g,
            Gn = /\[\]$/,
            Qn = /\r?\n/g,
            Kn = /^(?:submit|button|image|reset|file)$/i,
            Zn = /^(?:input|select|textarea|keygen)/i;
        at.param = function(e, t) {
            var n, r = [],
                i = function(e, t) {
                    t = at.isFunction(t) ? t() : null == t ? "" : t, r[r.length] = encodeURIComponent(e) + "=" + encodeURIComponent(t)
                };
            if (void 0 === t && (t = at.ajaxSettings && at.ajaxSettings.traditional), at.isArray(e) || e.jquery && !at.isPlainObject(e)) at.each(e, function() {
                i(this.name, this.value)
            });
            else
                for (n in e) X(n, e[n], t, i);
            return r.join("&").replace(Yn, "+")
        }, at.fn.extend({
            serialize: function() {
                return at.param(this.serializeArray())
            },
            serializeArray: function() {
                return this.map(function() {
                    var e = at.prop(this, "elements");
                    return e ? at.makeArray(e) : this
                }).filter(function() {
                    var e = this.type;
                    return this.name && !at(this).is(":disabled") && Zn.test(this.nodeName) && !Kn.test(e) && (this.checked || !Ht.test(e))
                }).map(function(e, t) {
                    var n = at(this).val();
                    return null == n ? null : at.isArray(n) ? at.map(n, function(e) {
                        return {
                            name: t.name,
                            value: e.replace(Qn, "\r\n")
                        }
                    }) : {
                        name: t.name,
                        value: n.replace(Qn, "\r\n")
                    }
                }).get()
            }
        }), at.ajaxSettings.xhr = void 0 !== e.ActiveXObject ? function() {
            return !this.isLocal && /^(get|post|head|put|delete|options)$/i.test(this.type) && U() || V()
        } : U;
        var er = 0,
            tr = {},
            nr = at.ajaxSettings.xhr();
        e.ActiveXObject && at(e).on("unload", function() {
            for (var e in tr) tr[e](void 0, !0)
        }), it.cors = !!nr && "withCredentials" in nr, nr = it.ajax = !!nr, nr && at.ajaxTransport(function(e) {
            if (!e.crossDomain || it.cors) {
                var t;
                return {
                    send: function(n, r) {
                        var i, o = e.xhr(),
                            a = ++er;
                        if (o.open(e.type, e.url, e.async, e.username, e.password), e.xhrFields)
                            for (i in e.xhrFields) o[i] = e.xhrFields[i];
                        e.mimeType && o.overrideMimeType && o.overrideMimeType(e.mimeType), e.crossDomain || n["X-Requested-With"] || (n["X-Requested-With"] = "XMLHttpRequest");
                        for (i in n) void 0 !== n[i] && o.setRequestHeader(i, n[i] + "");
                        o.send(e.hasContent && e.data || null), t = function(n, i) {
                            var s, l, u;
                            if (t && (i || 4 === o.readyState))
                                if (delete tr[a], t = void 0, o.onreadystatechange = at.noop, i) 4 !== o.readyState && o.abort();
                                else {
                                    u = {}, s = o.status, "string" == typeof o.responseText && (u.text = o.responseText);
                                    try {
                                        l = o.statusText
                                    } catch (c) {
                                        l = ""
                                    }
                                    s || !e.isLocal || e.crossDomain ? 1223 === s && (s = 204) : s = u.text ? 200 : 404
                                }
                            u && r(s, l, u, o.getAllResponseHeaders())
                        }, e.async ? 4 === o.readyState ? setTimeout(t) : o.onreadystatechange = tr[a] = t : t()
                    },
                    abort: function() {
                        t && t(void 0, !0)
                    }
                }
            }
        }), at.ajaxSetup({
            accepts: {
                script: "text/javascript, application/javascript, application/ecmascript, application/x-ecmascript"
            },
            contents: {
                script: /(?:java|ecma)script/
            },
            converters: {
                "text script": function(e) {
                    return at.globalEval(e), e
                }
            }
        }), at.ajaxPrefilter("script", function(e) {
            void 0 === e.cache && (e.cache = !1), e.crossDomain && (e.type = "GET", e.global = !1)
        }), at.ajaxTransport("script", function(e) {
            if (e.crossDomain) {
                var t, n = gt.head || at("head")[0] || gt.documentElement;
                return {
                    send: function(r, i) {
                        t = gt.createElement("script"), t.async = !0, e.scriptCharset && (t.charset = e.scriptCharset), t.src = e.url, t.onload = t.onreadystatechange = function(e, n) {
                            (n || !t.readyState || /loaded|complete/.test(t.readyState)) && (t.onload = t.onreadystatechange = null, t.parentNode && t.parentNode.removeChild(t), t = null, n || i(200, "success"))
                        }, n.insertBefore(t, n.firstChild)
                    },
                    abort: function() {
                        t && t.onload(void 0, !0)
                    }
                }
            }
        });
        var rr = [],
            ir = /(=)\?(?=&|$)|\?\?/;
        at.ajaxSetup({
            jsonp: "callback",
            jsonpCallback: function() {
                var e = rr.pop() || at.expando + "_" + qn++;
                return this[e] = !0, e
            }
        }), at.ajaxPrefilter("json jsonp", function(t, n, r) {
            var i, o, a, s = t.jsonp !== !1 && (ir.test(t.url) ? "url" : "string" == typeof t.data && !(t.contentType || "").indexOf("application/x-www-form-urlencoded") && ir.test(t.data) && "data");
            return s || "jsonp" === t.dataTypes[0] ? (i = t.jsonpCallback = at.isFunction(t.jsonpCallback) ? t.jsonpCallback() : t.jsonpCallback, s ? t[s] = t[s].replace(ir, "$1" + i) : t.jsonp !== !1 && (t.url += (_n.test(t.url) ? "&" : "?") + t.jsonp + "=" + i), t.converters["script json"] = function() {
                return a || at.error(i + " was not called"), a[0]
            }, t.dataTypes[0] = "json", o = e[i], e[i] = function() {
                a = arguments
            }, r.always(function() {
                e[i] = o, t[i] && (t.jsonpCallback = n.jsonpCallback, rr.push(i)), a && at.isFunction(o) && o(a[0]), a = o = void 0
            }), "script") : void 0
        }), at.parseHTML = function(e, t, n) {
            if (!e || "string" != typeof e) return null;
            "boolean" == typeof t && (n = t, t = !1), t = t || gt;
            var r = pt.exec(e),
                i = !n && [];
            return r ? [t.createElement(r[1])] : (r = at.buildFragment([e], t, i), i && i.length && at(i).remove(), at.merge([], r.childNodes))
        };
        var or = at.fn.load;
        at.fn.load = function(e, t, n) {
            if ("string" != typeof e && or) return or.apply(this, arguments);
            var r, i, o, a = this,
                s = e.indexOf(" ");
            return s >= 0 && (r = e.slice(s, e.length), e = e.slice(0, s)), at.isFunction(t) ? (n = t, t = void 0) : t && "object" == typeof t && (o = "POST"), a.length > 0 && at.ajax({
                url: e,
                type: o,
                dataType: "html",
                data: t
            }).done(function(e) {
                i = arguments, a.html(r ? at("<div>").append(at.parseHTML(e)).find(r) : e)
            }).complete(n && function(e, t) {
                a.each(n, i || [e.responseText, t, e])
            }), this
        }, at.expr.filters.animated = function(e) {
            return at.grep(at.timers, function(t) {
                return e === t.elem
            }).length
        };
        var ar = e.document.documentElement;
        at.offset = {
            setOffset: function(e, t, n) {
                var r, i, o, a, s, l, u, c = at.css(e, "position"),
                    d = at(e),
                    f = {};
                "static" === c && (e.style.position = "relative"), s = d.offset(), o = at.css(e, "top"), l = at.css(e, "left"), u = ("absolute" === c || "fixed" === c) && at.inArray("auto", [o, l]) > -1, u ? (r = d.position(), a = r.top, i = r.left) : (a = parseFloat(o) || 0, i = parseFloat(l) || 0), at.isFunction(t) && (t = t.call(e, n, s)), null != t.top && (f.top = t.top - s.top + a), null != t.left && (f.left = t.left - s.left + i), "using" in t ? t.using.call(e, f) : d.css(f)
            }
        }, at.fn.extend({
            offset: function(e) {
                if (arguments.length) return void 0 === e ? this : this.each(function(t) {
                    at.offset.setOffset(this, e, t)
                });
                var t, n, r = {
                        top: 0,
                        left: 0
                    },
                    i = this[0],
                    o = i && i.ownerDocument;
                return o ? (t = o.documentElement, at.contains(t, i) ? (typeof i.getBoundingClientRect !== Et && (r = i.getBoundingClientRect()), n = J(o), {
                    top: r.top + (n.pageYOffset || t.scrollTop) - (t.clientTop || 0),
                    left: r.left + (n.pageXOffset || t.scrollLeft) - (t.clientLeft || 0)
                }) : r) : void 0
            },
            position: function() {
                if (this[0]) {
                    var e, t, n = {
                            top: 0,
                            left: 0
                        },
                        r = this[0];
                    return "fixed" === at.css(r, "position") ? t = r.getBoundingClientRect() : (e = this.offsetParent(), t = this.offset(), at.nodeName(e[0], "html") || (n = e.offset()), n.top += at.css(e[0], "borderTopWidth", !0), n.left += at.css(e[0], "borderLeftWidth", !0)), {
                        top: t.top - n.top - at.css(r, "marginTop", !0),
                        left: t.left - n.left - at.css(r, "marginLeft", !0)
                    }
                }
            },
            offsetParent: function() {
                return this.map(function() {
                    for (var e = this.offsetParent || ar; e && !at.nodeName(e, "html") && "static" === at.css(e, "position");) e = e.offsetParent;
                    return e || ar
                })
            }
        }), at.each({
            scrollLeft: "pageXOffset",
            scrollTop: "pageYOffset"
        }, function(e, t) {
            var n = /Y/.test(t);
            at.fn[e] = function(r) {
                return Lt(this, function(e, r, i) {
                    var o = J(e);
                    return void 0 === i ? o ? t in o ? o[t] : o.document.documentElement[r] : e[r] : (o ? o.scrollTo(n ? at(o).scrollLeft() : i, n ? i : at(o).scrollTop()) : e[r] = i, void 0)
                }, e, r, arguments.length, null)
            }
        }), at.each(["top", "left"], function(e, t) {
            at.cssHooks[t] = S(it.pixelPosition, function(e, n) {
                return n ? (n = rn(e, t), an.test(n) ? at(e).position()[t] + "px" : n) : void 0
            })
        }), at.each({
            Height: "height",
            Width: "width"
        }, function(e, t) {
            at.each({
                padding: "inner" + e,
                content: t,
                "": "outer" + e
            }, function(n, r) {
                at.fn[r] = function(r, i) {
                    var o = arguments.length && (n || "boolean" != typeof r),
                        a = n || (r === !0 || i === !0 ? "margin" : "border");
                    return Lt(this, function(t, n, r) {
                        var i;
                        return at.isWindow(t) ? t.document.documentElement["client" + e] : 9 === t.nodeType ? (i = t.documentElement, Math.max(t.body["scroll" + e], i["scroll" + e], t.body["offset" + e], i["offset" + e], i["client" + e])) : void 0 === r ? at.css(t, n, a) : at.style(t, n, r, a)
                    }, t, o ? r : void 0, o, null)
                }
            })
        }), at.fn.size = function() {
            return this.length
        }, at.fn.andSelf = at.fn.addBack, "function" == typeof i && i.amd && i("jquery", [], function() {
            return at
        });
        var sr = e.jQuery,
            lr = e.$;
        return at.noConflict = function(t) {
            return e.$ === at && (e.$ = lr), t && e.jQuery === at && (e.jQuery = sr), at
        }, typeof t === Et && (e.jQuery = e.$ = at), at
    })
}(window, document, bnpp.sf31.require, bnpp.sf31.require, bnpp.sf31.define);
//# sourceMappingURL=jquery-1.11.0.js.map
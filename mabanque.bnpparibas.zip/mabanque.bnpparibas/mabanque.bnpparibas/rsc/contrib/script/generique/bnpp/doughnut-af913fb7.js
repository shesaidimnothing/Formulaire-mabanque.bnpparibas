! function(n, t, e, a, i) {
    bnpp.Chart = function(t) {
        function e(n, t, e) {
            o(e), t(1)
        }

        function a(n) {
            return Math.min.apply(Math, n)
        }

        function i(n, t) {
            var e = {};
            for (var a in n) e[a] = n[a];
            for (var a in t) e[a] = t[a];
            return e
        }
        var r = this,
            u = t.canvas.width,
            c = t.canvas.height;
        n.devicePixelRatio && (t.canvas.style.width = u + "px", t.canvas.style.height = c + "px", t.canvas.height = c * n.devicePixelRatio, t.canvas.width = u * n.devicePixelRatio, t.scale(n.devicePixelRatio, n.devicePixelRatio)), this.Doughnut = function(n, e) {
            r.Doughnut.defaults = {
                percentageInnerCutout: 87
            };
            var a = e ? i(r.Doughnut.defaults, e) : r.Doughnut.defaults;
            return new h(n, a, t)
        };
        var o = function(n) {
                n.clearRect(0, 0, u, c)
            },
            h = function(n, t, i) {
                function r() {
                    for (var t = -Math.PI / 2, e = 1, a = 1, r = 0; r < n.length; r++) {
                        var l = 2 * (a * n[r].value / o) * Math.PI;
                        i.beginPath(), i.arc(u / 2, c / 2, e * h, t, t + l, !1), i.arc(u / 2, c / 2, e * f, t + l, t, !0), i.closePath(), i.fillStyle = n[r].color, i.fill(), t += l
                    }
                }
                for (var o = 0, h = a([c / 2, u / 2]) - 5, f = h * (t.percentageInnerCutout / 100), l = 0; l < n.length; l++) o += n[l].value;
                e(t, r, i)
            }
    }, i("donuts", function(n) {
        return function() {
            var t;
            return t || n.bnpp.Chart
        }
    }(this))
}(window, document, bnpp.sf31.requirejs, bnpp.sf31.requirejs, bnpp.sf31.define, bnpp.jquery, bnpp.jquery, bnpp.jquery);
//# sourceMappingURL=doughnut-af913fb7.js.map
! function() {
    var e = ["Jan", "Fév", "Mars", "Avr", "Mai", "Juin", "Juil", "Août", "Sept", "Oct", "Nov", "Déc"],
        i = ["Janvier", "Février", "Mars", "Avril", "Mai", "Juin", "Juillet", "Août", "Septembre", "Octobre", "Novembre", "Décembre"];
    try {
        Handlebars.registerHelper("sum", function(e, i) {
            return e + i;
        }), Handlebars.registerHelper("if_eq", function(e, i, t) {
            return e == i ? t.fn(this) : t.inverse(this);
        }), Handlebars.registerHelper("if_ar_not_empty", function(e, i) {
            return e.length > 0 ? i.fn(this) : i.inverse(this);
        }), Handlebars.registerHelper("if_string_eq", function(e, i, t) {
            return String(e).toLowerCase() == String(i).toLowerCase() ? t.fn(this) : t.inverse(this);
        }), Handlebars.registerHelper("unless_eq", function(e, i, t) {
            return e != i ? t.fn(this) : t.inverse(this);
        }), Handlebars.registerHelper("if_gt", function(e, i, t) {
            return e > i ? t.fn(this) : t.inverse(this);
        }), Handlebars.registerHelper("if_lt", function(e, i, t) {
            return i > e ? t.fn(this) : t.inverse(this);
        }), Handlebars.registerHelper("abs", function(e) {
            return isNaN(e) ? null : Math.abs(e);
        }), Handlebars.registerHelper("formatDate", function(i) {
            var t = DateHelper.formatDateToObject(i),
                a = t.getDate() + "<br><span>" + e[t.getMonth()] + "</span>";
            return a;
        }), Handlebars.registerHelper("formatFullDate", function(e) {
            var t = DateHelper.formatDateToObject(e),
                a = t.getDate() + " " + i[t.getMonth()] + " " + t.getUTCFullYear();
            return a;
        }), Handlebars.registerHelper("formatDateAnnee", function(e) {
            var i = DateHelper.formatDateToObject(e);
            return i.getUTCFullYear();
        }), Handlebars.registerHelper("formatDateMessagerie", function(i) {
            var t = DateHelper.formatDateToObject(i),
                a = t.getDate() + " " + e[t.getMonth()];
            return a;
        }), Handlebars.registerHelper("formatDateUDC", function(e) {
            if (void 0 != e) {
                var i = DateHelper.formatDateToObject(e),
                    t = ("0" + i.getDate()).slice(-2) + "/" + ("0" + (i.getMonth() + 1)).slice(-2) + "/" + i.getFullYear();
                return t;
            }
        }), Handlebars.registerHelper("formatDateUDCShort", function(e) {
            var i = DateHelper.formatDateToObject(e),
                t = ("0" + i.getDate()).slice(-2) + "/" + ("0" + (i.getMonth() + 1)).slice(-2);
            return t;
        }), Handlebars.registerHelper("formatMonthName", function(i) {
            var t = DateHelper.formatDateToObject(i),
                a = e[t.getMonth()];
            return a;
        }), Handlebars.registerHelper("formatMontant", function(e) {
            return addThousandsSep(formatNumber(Number(e).toFixed(2), 2), ".");
        }), Handlebars.registerHelper("formatDayNum", function(e) {
            var i = DateHelper.formatDateToObject(e),
                t = ("0" + i.getDate()).slice(-2);
            return t;
        }), Handlebars.registerHelper("anneeMessagerie", function(e, i, t) {
            var a = "";
            if (void 0 !== e[0]) {
                var r = DateHelper.formatDateToObject(e[0].dateReception);
                if (void 0 === i) a = r.getUTCFullYear();
                else {
                    var o = $(i);
                    "dateReception" == o.find(".active").data("value") && ("up" == o.find(".active").data("direction") ? a = r.getUTCFullYear() + t : "down" == o.find(".active").data("direction") && (a = r.getUTCFullYear() - t));
                }
                return a;
            }
        }), Handlebars.registerHelper("getTypeClass", function(e) {
            if (void 0 !== e) {
                var i = "";
                switch (e) {
                    case 1:
                        i = "flt-conseiller";
                        break;

                    case 2:
                        i = "flt-compte";
                        break;

                    case 3:
                        i = "flt-bp";
                        break;

                    case 4:
                        i = "flt-sd";
                }
                return i;
            }
        }), Handlebars.registerHelper("favoriLength", function(e) {
            for (var i = 0, t = 0, a = e.length; a > t; t++) 1 == e[t].favori && (i += 1);
            return i;
        }), Handlebars.registerHelper("RopLogoType", function(e) {
            return e.search("PAYLIB") > -1 ? "op-paylib" : e.search("P2P-SCTID") > -1 ? "op-transfert" : e.search("MOTIF E2E") > -1 ? "op-facture" : e.search("Remb LuckyMe") > -1 ? "op-luckyme" : void 0;
        }), Handlebars.registerHelper("PfmFormatMontant", function(e, i, t) {
            return ("string" != typeof i || "string" == typeof i && "eur" == i.toLowerCase()) && (i = "€"),
                "abs" == t && (e = Math.abs(e)), addThousandsSep(formatNumber(e, 2)) + " " + i;
        }), Handlebars.registerHelper("getIconTitle", function(e) {
            return getIconTitle(e);
        }), Handlebars.registerHelper("getPourc", function(e, i) {
            return Math.round(100 * (e / i)) + "%";
        }), Handlebars.registerHelper("addOne", function(e) {
            return Number(e) + 1;
        }), Handlebars.registerHelper("Magazine", function(e, i) {
            var t = $(articles.categories).filter(function(i, t) {
                return t.id == e.category;
            });
            if (showAllArticle && i.data.index >= 8 || i.data.index < 8) switch (i.data.index % 8) {
                case 0:
                    return new Handlebars.SafeString('<div id="' + e.idArticle + '" class="index0 col-67" style="border-bottom: 2px solid #' + getColorByCategorie(e.category) + '">' + '<a href="' + articles.params.url + articles.params.accueil + t[0].lienCat + "/" + e.articleLink + '"><div class="image-article-0"><img src="/rsc/contrib/image/webzine/' + getImageArticleByCategorie(e.category) + "/" + e.images.big + '"></img></div></a>' + '<div class="dateArticle">' + formatDate(e.date) + "<img src=" + addFavoriteIcon(e) + "></img></div>" + '<div class="title-article"><h3>' + e.title + '</h3><div style="margin-right:60px;padding: 7px 0;float: right;color: #' + getColorByCategorie(e.category) + ';font-size: 33px"' + 'class="icon ' + getIconArticleByCategorie(e.category) + '"></div></div>' + "</div>");

                case 1:
                    return new Handlebars.SafeString('<div id="' + e.idArticle + '" class="index1 col-30" style="border-bottom: 2px solid #' + getColorByCategorie(e.category) + '">' + '<div class="dateArticle">' + formatDate(e.date) + "<img src=" + addFavoriteIcon(e) + "></img></div>" + "<h3>" + shorten(e.title, 45) + "</h3>" + '<div class="content-article">' + shorten(e.article, 300) + "</div>" + '<div style="margin-right:43px;float: right;font-size: 33px;color: #' + getColorByCategorie(e.category) + '"' + 'class="icon ' + getIconArticleByCategorie(e.category) + '"></div>' + "</div>");

                case 2:
                    return new Handlebars.SafeString('<div id="' + e.idArticle + '" class="index2 col-30" style="border-bottom: 2px solid #' + getColorByCategorie(e.category) + '">' + '<a href="' + articles.params.url + articles.params.accueil + t[0].lienCat + "/" + e.articleLink + '"><div class="image-article-2"><img src="/rsc/contrib/image/webzine/' + getImageArticleByCategorie(e.category) + "/" + e.images.medium + '"></img></div></a>' + '<div class="dateArticle">' + formatDate(e.date) + "<img src=" + addFavoriteIcon(e) + "></img></div>" + "<h3>" + shorten(e.title, 50) + "</h3>" + '<div style="float:right;margin-right: 45px;margin-top: -50px;font-size: 33px;color: #' + getColorByCategorie(e.category) + '"' + 'class="icon ' + getIconArticleByCategorie(e.category) + '"></div>' + "</div>");

                case 3:
                    return new Handlebars.SafeString('<div id="' + e.idArticle + '" class="index3 col-67">' + '<a href="' + articles.params.url + articles.params.accueil + t[0].lienCat + "/" + e.articleLink + '"><div class="image-article-3"><img src="/rsc/contrib/image/webzine/' + getImageArticleByCategorie(e.category) + "/" + e.images.medium + '"></img></div></a>' + '<div class="detail-article-3" style="border-bottom: 2px solid #' + getColorByCategorie(e.category) + '">' + '<div class="dateArticle" style="margin:25px 0px 31px 27px;">' + formatDate(e.date) + "<img src=" + addFavoriteIcon(e) + "></img></div>" + "<h3>" + shorten(e.title, 45) + '</h3><div style="margin: 11px 45px 0 0;float: right;font-size: 33px;color: #' + getColorByCategorie(e.category) + '"' + 'class="icon ' + getIconArticleByCategorie(e.category) + '"></div></div>' + "</div>");

                case 4:
                    return new Handlebars.SafeString('<div id="' + e.idArticle + '" class="index4 col-67" style="border-bottom: 2px solid #' + getColorByCategorie(e.category) + '">' + '<a href="' + articles.params.url + articles.params.accueil + t[0].lienCat + "/" + e.articleLink + '"><div class="image-article-0"><img src="/rsc/contrib/image/webzine/' + getImageArticleByCategorie(e.category) + "/" + e.images.big + '"></img></div></a>' + '<div class="dateArticle">' + formatDate(e.date) + "<img src=" + addFavoriteIcon(e) + "></img></div>" + '<div class="title-article"><h3>' + e.title + '</h3><div style="margin-right:60px;padding: 7px 0;float: right;color: #' + getColorByCategorie(e.category) + ';font-size: 33px"' + 'class="icon ' + getIconArticleByCategorie(e.category) + '"></div></div>' + "</div>");

                case 5:
                    return new Handlebars.SafeString('<div id="' + e.idArticle + '" class="index5 col-30" style="border-bottom: 2px solid #' + getColorByCategorie(e.category) + '">' + '<div class="dateArticle">' + formatDate(e.date) + "<img src=" + addFavoriteIcon(e) + "></img></div>" + "<h3>" + shorten(e.title, 45) + "</h3>" + '<div class="content-article">' + shorten(e.article, 300) + "</div>" + '<div style="margin-right:43px;float: right;font-size: 33px;color: #' + getColorByCategorie(e.category) + '"' + 'class="icon ' + getIconArticleByCategorie(e.category) + '"></div>' + "</div>");

                case 6:
                    return new Handlebars.SafeString('<div id="' + e.idArticle + '" class="index6 col-30" style="border-bottom: 2px solid #' + getColorByCategorie(e.category) + '">' + '<a href="' + articles.params.url + articles.params.accueil + t[0].lienCat + "/" + e.articleLink + '"><div class="image-article-2"><img src="/rsc/contrib/image/webzine/' + getImageArticleByCategorie(e.category) + "/" + e.images.medium + '"></img></div></a>' + '<div class="dateArticle">' + formatDate(e.date) + "<img src=" + addFavoriteIcon(e) + "></img></div>" + "<h3>" + shorten(e.title, 50) + "</h3>" + '<div style="float:right;margin-right: 45px;margin-top: -50px;font-size: 33px;color: #' + getColorByCategorie(e.category) + '"' + 'class="icon ' + getIconArticleByCategorie(e.category) + '"></div>' + "</div>");

                case 7:
                    return new Handlebars.SafeString('<div id="' + e.idArticle + '" class="index7 col-67">' + '<a href="' + articles.params.url + articles.params.accueil + t[0].lienCat + "/" + e.articleLink + '"><div class="image-article-3"><img src="/rsc/contrib/image/webzine/' + getImageArticleByCategorie(e.category) + "/" + e.images.medium + '"></img></div></a>' + '<div class="detail-article-3" style="border-bottom: 2px solid #' + getColorByCategorie(e.category) + '">' + '<div class="dateArticle" style="margin:25px 0px 31px 27px;">' + formatDate(e.date) + "<img src=" + addFavoriteIcon(e) + "></img></div>" + "<h3>" + shorten(e.title, 45) + '</h3><div style="margin: 11px 45px 0 0;float: right;font-size: 33px;color: #' + getColorByCategorie(e.category) + '"' + 'class="icon ' + getIconArticleByCategorie(e.category) + '"></div></div>' + "</div>");
            }
        }), Handlebars.registerHelper("Home", function(e, i) {
            var t = $(articles.categories).filter(function(i, t) {
                return t.id == e.category;
            });
            if (i.data.index < 4) switch (i.data.index % 4) {
                case 0:
                    return new Handlebars.SafeString('<div id="' + e.idArticle + '" class="index0 col-67" style="border-bottom: 2px solid #' + getColorByCategorie(e.category) + '">' + '<a href="' + articles.params.url + articles.params.accueil + t[0].lienCat + "/" + e.articleLink + '"><div class="image-article-0"><img src="/rsc/contrib/image/webzine/' + getImageArticleByCategorie(e.category) + "/" + e.images.big + '"></img></div></a>' + '<div class="dateArticle">' + formatDate(e.date) + "<img src=" + addFavoriteIcon(e) + "></img></div>" + '<div class="title-article"><h3>' + e.title + '</h3><div style="margin-right:60px;padding: 7px 0;float: right;color: #' + getColorByCategorie(e.category) + ';font-size: 33px"' + 'class="icon ' + getIconArticleByCategorie(e.category) + '"></div></div>' + "</div>");

                case 1:
                case 2:
                    return new Handlebars.SafeString('<div id="' + e.idArticle + '" class="index2 col-30" style="border-bottom: 2px solid #' + getColorByCategorie(e.category) + '">' + '<a href="' + articles.params.url + articles.params.accueil + t[0].lienCat + "/" + e.articleLink + '"><div class="image-article-2"><img src="/rsc/contrib/image/webzine/' + getImageArticleByCategorie(e.category) + "/" + e.images.medium + '"></img></div></a>' + '<div class="dateArticle">' + formatDate(e.date) + "<img src=" + addFavoriteIcon(e) + "></img></div>" + "<h3>" + shorten(e.title, 50) + "</h3>" + '<div style="float:right;margin-right: 45px;margin-top: -50px;font-size: 33px;color: #' + getColorByCategorie(e.category) + '"' + 'class="icon ' + getIconArticleByCategorie(e.category) + '"></div>' + "</div>");

                case 3:
                    return new Handlebars.SafeString('<div id="' + e.idArticle + '" class="index3 col-67">' + '<a href="' + articles.params.url + articles.params.accueil + t[0].lienCat + "/" + e.articleLink + '"><div class="image-article-3"><img src="/rsc/contrib/image/webzine/' + getImageArticleByCategorie(e.category) + "/" + e.images.medium + '"></img></div></a>' + '<div class="detail-article-3" style="border-bottom: 2px solid #' + getColorByCategorie(e.category) + '">' + '<div class="dateArticle" style="margin:25px 0px 31px 27px;">' + formatDate(e.date) + "<img src=" + addFavoriteIcon(e) + "></img></div>" + "<h3>" + shorten(e.title, 45) + '</h3><div style="margin: 11px 45px 0 0;float: right;font-size: 33px;color: #' + getColorByCategorie(e.category) + '"' + 'class="icon ' + getIconArticleByCategorie(e.category) + '"></div></div>' + "</div>");
            }
        }), Handlebars.registerHelper("AuthorArticles", function(e, i) {
            var t = $(articles.categories).filter(function(i, t) {
                return t.id == e.category;
            });
            switch (i.data.index % 3) {
                case 0:
                    return new Handlebars.SafeString('<div id="' + e.idArticle + '" class="index2 col-30" style="float:left;border-bottom: 2px solid #' + getColorByCategorie(e.category) + '">' + '<a href="' + articles.params.url + articles.params.accueil + t[0].lienCat + "/" + e.articleLink + '"><div class="image-article-2"><img src="/rsc/contrib/image/webzine/' + getImageArticleByCategorie(e.category) + "/" + e.images.medium + '"></img></div></a>' + '<div class="dateArticle">' + formatDate(e.date) + "<img src=" + addFavoriteIcon(e) + "></img></div>" + "<h3>" + shorten(e.title, 52) + "</h3>" + '<div style="float:right;margin-right: 45px;margin-top: -50px;font-size: 33px;color: #' + getColorByCategorie(e.category) + '"' + 'class="icon ' + getIconArticleByCategorie(e.category) + '"></div>' + "</div>");

                case 1:
                    return new Handlebars.SafeString('<div id="' + e.idArticle + '" class="index2 col-30" style="float:left;margin: 0 5% 24px 5%;border-bottom: 2px solid #' + getColorByCategorie(e.category) + '">' + '<a href="' + articles.params.url + articles.params.accueil + t[0].lienCat + "/" + e.articleLink + '"><div class="image-article-2"><img src="/rsc/contrib/image/webzine/' + getImageArticleByCategorie(e.category) + "/" + e.images.medium + '"></img></div></a>' + '<div class="dateArticle">' + formatDate(e.date) + "<img src=" + addFavoriteIcon(e) + "></img></div>" + "<h3>" + shorten(e.title, 50) + "</h3>" + '<div style="float:right;margin-right: 45px;margin-top: -50px;font-size: 33px;color: #' + getColorByCategorie(e.category) + '"' + 'class="icon ' + getIconArticleByCategorie(e.category) + '"></div>' + "</div>");

                case 2:
                    return new Handlebars.SafeString('<div id="' + e.idArticle + '" class="index2 col-30" style="float:right;border-bottom: 2px solid #' + getColorByCategorie(e.category) + '">' + '<a href="' + articles.params.url + articles.params.accueil + t[0].lienCat + "/" + e.articleLink + '"><div class="image-article-2"><img src="/rsc/contrib/image/webzine/' + getImageArticleByCategorie(e.category) + "/" + e.images.medium + '"></img></div></a>' + '<div class="dateArticle">' + formatDate(e.date) + "<img src=" + addFavoriteIcon(e) + "></img></div>" + "<h3>" + shorten(e.title, 50) + "</h3>" + '<div style="float:right;margin-right: 45px;margin-top: -50px;font-size: 33px;color: #' + getColorByCategorie(e.category) + '"' + 'class="icon ' + getIconArticleByCategorie(e.category) + '"></div>' + "</div>");
            }
        }), Handlebars.registerHelper("Favoris", function(e, i) {
            var t = $(articles.categories).filter(function(i, t) {
                return t.id == e.category;
            });
            switch (i.data.index % 8) {
                case 0:
                case 1:
                case 4:
                case 5:
                case 6:
                case 8:
                    return new Handlebars.SafeString('<div id="' + e.idArticle + '" class="index2 col-30" style="float:left;border-bottom: 2px solid #' + getColorByCategorie(e.category) + '">' + '<a href="' + articles.params.url + articles.params.accueil + t[0].lienCat + "/" + e.articleLink + '"><div class="image-article-2"><img src="/rsc/contrib/image/webzine/' + getImageArticleByCategorie(e.category) + "/" + e.images.medium + '"></img></div></a>' + '<div class="dateArticle">' + formatDate(e.date) + "<img src=" + addFavoriteIcon(e) + "></img></div>" + "<h3>" + shorten(e.title, 50) + "</h3>" + '<div style="float:right;margin-right: 45px;margin-top: -50px;font-size: 33px;color: #' + getColorByCategorie(e.category) + '"' + 'class="icon ' + getIconArticleByCategorie(e.category) + '"></div>' + "</div>");

                case 2:
                case 3:
                case 7:
                    return new Handlebars.SafeString('<div id="' + e.idArticle + '" class="index1 col-30" style="border-bottom: 2px solid #' + getColorByCategorie(e.category) + '">' + '<div class="dateArticle">' + formatDate(e.date) + "<img src=" + addFavoriteIcon(e) + "></img></div>" + "<h3>" + shorten(e.title, 45) + "</h3>" + '<div class="content-article">' + shorten(e.article, 300) + "</div>" + '<div style="margin-right:43px;float: right;font-size: 33px;color: #' + getColorByCategorie(e.category) + '"' + 'class="icon ' + getIconArticleByCategorie(e.category) + '"></div>' + "</div>");
            }
        }), Handlebars.registerHelper("FavorisHome", function(e, i) {
            if (i.data.index < 3) {
                var t = $(articles.categories).filter(function(i, t) {
                    return t.id == e.category;
                });
                if (2 == favoris.length && 1 == i.data.index % 3) return new Handlebars.SafeString('<div id="' + e.idArticle + '" class="index2 col-30" style="float:left;margin: 0 5% 24px 5%;border-bottom: 2px solid #' + getColorByCategorie(e.category) + '">' + '<a href="' + articles.params.url + articles.params.accueil + t[0].lienCat + "/" + e.articleLink + '"><div class="image-article-2"><img src="/rsc/contrib/image/webzine/' + getImageArticleByCategorie(e.category) + "/" + e.images.medium + '"></img></div></a>' + '<div class="dateArticle">' + formatDate(e.date) + "<img src=" + addFavoriteIcon(e) + "></img></div>" + "<h3>" + shorten(e.title, 50) + "</h3>" + '<div style="float:right;margin-right: 45px;margin-top: -50px;font-size: 33px;color: #' + getColorByCategorie(e.category) + '"' + 'class="icon ' + getIconArticleByCategorie(e.category) + '"></div>' + "</div>" + '<div class="col-30 col-hidden"></div></div>');
                if (1 == favoris.length && 0 == i.data.index % 3) return new Handlebars.SafeString('<div id="' + e.idArticle + '" class="index2 col-30" style="float:left;border-bottom: 2px solid #' + getColorByCategorie(e.category) + '">' + '<a href="' + articles.params.url + articles.params.accueil + t[0].lienCat + "/" + e.articleLink + '"><div class="image-article-2"><img src="/rsc/contrib/image/webzine/' + getImageArticleByCategorie(e.category) + "/" + e.images.medium + '"></img></div></a>' + '<div class="dateArticle">' + formatDate(e.date) + "<img src=" + addFavoriteIcon(e) + "></img></div>" + "<h3>" + shorten(e.title, 50) + "</h3>" + '<div style="float:right;margin-right: 45px;margin-top: -50px;font-size: 33px;color: #' + getColorByCategorie(e.category) + '"' + 'class="icon ' + getIconArticleByCategorie(e.category) + '"></div></div>' + '<div class="col-30 col-hidden"></div><div class="col-30 col-hidden"></div></div>');
                switch (i.data.index % 3) {
                    case 0:
                        return new Handlebars.SafeString('<div id="' + e.idArticle + '" class="index2 col-30" style="float:left;border-bottom: 2px solid #' + getColorByCategorie(e.category) + '">' + '<a href="' + articles.params.url + articles.params.accueil + t[0].lienCat + "/" + e.articleLink + '"><div class="image-article-2"><img src="/rsc/contrib/image/webzine/' + getImageArticleByCategorie(e.category) + "/" + e.images.medium + '"></img></div></a>' + '<div class="dateArticle">' + formatDate(e.date) + "<img src=" + addFavoriteIcon(e) + "></img></div>" + "<h3>" + shorten(e.title, 50) + "</h3>" + '<div style="float:right;margin-right: 45px;margin-top: -50px;font-size: 33px;color: #' + getColorByCategorie(e.category) + '"' + 'class="icon ' + getIconArticleByCategorie(e.category) + '"></div>' + "</div>");

                    case 1:
                        return new Handlebars.SafeString('<div id="' + e.idArticle + '" class="index2 col-30" style="float:left;margin: 0 5% 24px 5%;border-bottom: 2px solid #' + getColorByCategorie(e.category) + '">' + '<a href="' + articles.params.url + articles.params.accueil + t[0].lienCat + "/" + e.articleLink + '"><div class="image-article-2"><img src="/rsc/contrib/image/webzine/' + getImageArticleByCategorie(e.category) + "/" + e.images.medium + '"></img></div></a>' + '<div class="dateArticle">' + formatDate(e.date) + "<img src=" + addFavoriteIcon(e) + "></img></div>" + "<h3>" + shorten(e.title, 50) + "</h3>" + '<div style="float:right;margin-right: 45px;margin-top: -50px;font-size: 33px;color: #' + getColorByCategorie(e.category) + '"' + 'class="icon ' + getIconArticleByCategorie(e.category) + '"></div>' + "</div>");

                    case 2:
                        return new Handlebars.SafeString('<div id="' + e.idArticle + '" class="index2 col-30" style="float:right;border-bottom: 2px solid #' + getColorByCategorie(e.category) + '">' + '<a href="' + articles.params.url + articles.params.accueil + t[0].lienCat + "/" + e.articleLink + '"><div class="image-article-2"><img src="/rsc/contrib/image/webzine/' + getImageArticleByCategorie(e.category) + "/" + e.images.medium + '"></img></div></a>' + '<div class="dateArticle">' + formatDate(e.date) + "<img src=" + addFavoriteIcon(e) + "></img></div>" + "<h3>" + shorten(e.title, 50) + "</h3>" + '<div style="float:right;margin-right: 45px;margin-top: -50px;font-size: 33px;color: #' + getColorByCategorie(e.category) + '"' + 'class="icon ' + getIconArticleByCategorie(e.category) + '"></div>' + "</div>");
                }
            }
        }), Handlebars.registerHelper("Actualite", function(e, i) {
            return showAllActualite && i.data.index >= 5 || i.data.index < 5 ? new Handlebars.SafeString("<a href=" + actualites.params.url + actualites.params.accueil + e.url + '><div class="col-100 border-actualite actualite-item ' + addColorByCategory(e.categoryId) + '">' + '<div class="date"><div class="day-actu">' + getDayFromDate(e.date) + '</div><div class="month-actu">' + getMonthFromDate(e.date) + '</div></div><div class="titre-actu">' + e.title + '</div><div class="img-actu icon ' + updateItemDisplay(e.categoryId) + '" ></div><div class="icon icon-fright detail-actu"></div>' + "</div></a>") : void 0;
        }), Handlebars.registerHelper("MobileHome", function(e, i) {
            var t = $(articles.categories).filter(function(i, t) {
                return t.id == e.category;
            });
            return i.data.index < 4 ? new Handlebars.SafeString('<div id="' + e.idArticle + '" class="index2 col-100" style="border-bottom: 2px solid #' + getColorByCategorie(e.category) + '">' + '<a href="' + articles.params.url + articles.params.accueil + t[0].lienCat + "/" + e.articleLink + '"><div class="image-article-2"><img src="/rsc/contrib/image/webzine/' + getImageArticleByCategorie(e.category) + "/" + e.images.medium + '"></img></div></a>' + '<div class="dateArticle">' + formatDate(e.date) + "<img src=" + addFavoriteIcon(e) + "></img></div>" + "<h3>" + shorten(e.title, 50) + "</h3>" + '<div style="float:right;margin-right: 45px;margin-top: -50px;font-size: 33px;color: #' + getColorByCategorie(e.category) + '"' + 'class="icon ' + getIconArticleByCategorie(e.category) + '"></div>' + "</div>") : void 0;
        }), Handlebars.registerHelper("MobileFavoris", function(e) {
            var i = $(articles.categories).filter(function(i, t) {
                return t.id == e.category;
            });
            return new Handlebars.SafeString('<div id="' + e.idArticle + '" class="index2 col-100" style="border-bottom: 2px solid #' + getColorByCategorie(e.category) + '">' + '<a href="' + articles.params.url + articles.params.accueil + i[0].lienCat + "/" + e.articleLink + '"><div class="image-article-2"><img src="/rsc/contrib/image/webzine/' + getImageArticleByCategorie(e.category) + "/" + e.images.medium + '"></img></div></a>' + '<div class="dateArticle">' + formatDate(e.date) + "<img src=" + addFavoriteIcon(e) + "></img></div>" + "<h3>" + shorten(e.title, 50) + "</h3>" + '<div style="float:right;margin-right: 45px;margin-top: -50px;font-size: 33px;color: #' + getColorByCategorie(e.category) + '"' + 'class="icon ' + getIconArticleByCategorie(e.category) + '"></div>' + "</div>");
        }), Handlebars.registerHelper("MobileMagazine", function(e, i) {
            var t = $(articles.categories).filter(function(i, t) {
                return t.id == e.category;
            });
            return showAllArticle && i.data.index >= 8 || i.data.index < 8 ? new Handlebars.SafeString('<div id="' + e.idArticle + '" class="index2 col-100" style="border-bottom: 2px solid #' + getColorByCategorie(e.category) + '">' + '<a href="' + articles.params.url + articles.params.accueil + t[0].lienCat + "/" + e.articleLink + '"><div class="image-article-2"><img src="/rsc/contrib/image/webzine/' + getImageArticleByCategorie(e.category) + "/" + e.images.medium + '"></img></div></a>' + '<div class="dateArticle">' + formatDate(e.date) + "<img src=" + addFavoriteIcon(e) + "></img></div>" + "<h3>" + shorten(e.title, 50) + "</h3>" + '<div style="float:right;margin-right: 45px;margin-top: -50px;font-size: 33px;color: #' + getColorByCategorie(e.category) + '"' + 'class="icon ' + getIconArticleByCategorie(e.category) + '"></div>' + "</div>") : void 0;
        }), Handlebars.registerHelper("RelArticles", function(e, i) {
            var t = $(articles.categories).filter(function(i, t) {
                return t.id == e.category;
            });
            if (i.data.index < 3) switch (i.data.index % 3) {
                case 0:
                    return new Handlebars.SafeString('<div class="favoris-container"><div id="' + e.idArticle + '" class="index2 col-30" style="float:left;border-bottom: 2px solid #' + getColorByCategorie(e.category) + '">' + '<a href="' + articles.params.url + articles.params.accueil + t[0].lienCat + "/" + e.articleLink + '"><div class="image-article-2"><img src="/rsc/contrib/image/webzine/' + getImageArticleByCategorie(e.category) + "/" + e.images.medium + '"></img></div></a>' + '<div class="dateArticle">' + formatDate(e.date) + "<img src=" + addFavoriteIcon(e) + "></img></div>" + "<h3>" + shorten(e.title, 50) + "</h3>" + '<div style="float:right;margin-right: 45px;margin-top: -50px;font-size: 33px;color: #' + getColorByCategorie(e.category) + '"' + 'class="icon ' + getIconArticleByCategorie(e.category) + '"></div>' + "</div>");

                case 1:
                    return new Handlebars.SafeString('<div id="' + e.idArticle + '" class="index2 col-30" style="float:left;margin: 0 5% 24px 5%;border-bottom: 2px solid #' + getColorByCategorie(e.category) + '">' + '<a href="' + articles.params.url + articles.params.accueil + t[0].lienCat + "/" + e.articleLink + '"><div class="image-article-2"><img src="/rsc/contrib/image/webzine/' + getImageArticleByCategorie(e.category) + "/" + e.images.medium + '"></img></div></a>' + '<div class="dateArticle">' + formatDate(e.date) + "<img src=" + addFavoriteIcon(e) + "></img></div>" + "<h3>" + shorten(e.title, 50) + "</h3>" + '<div style="float:right;margin-right: 45px;margin-top: -50px;font-size: 33px;color: #' + getColorByCategorie(e.category) + '"' + 'class="icon ' + getIconArticleByCategorie(e.category) + '"></div>' + "</div>");

                case 2:
                    return new Handlebars.SafeString('<div id="' + e.idArticle + '" class="index2 col-30" style="float:right;border-bottom: 2px solid #' + getColorByCategorie(e.category) + '">' + '<a href="' + articles.params.url + articles.params.accueil + t[0].lienCat + "/" + e.articleLink + '"><div class="image-article-2"><img src="/rsc/contrib/image/webzine/' + getImageArticleByCategorie(e.category) + "/" + e.images.medium + '"></img></div></a>' + '<div class="dateArticle">' + formatDate(e.date) + "<img src=" + addFavoriteIcon(e) + "></img></div>" + "<h3>" + shorten(e.title, 50) + "</h3>" + '<div style="float:right;margin-right: 45px;margin-top: -50px;font-size: 33px;color: #' + getColorByCategorie(e.category) + '"' + 'class="icon ' + getIconArticleByCategorie(e.category) + '"></div>' + "</div></div>");
            }
        }), Handlebars.registerHelper("list", function(e) {
            var i = "<div id='" + e[0].date + "' class='container-items'>";
            i += '<div class="day-container"><div class="day">' + getDay(e[0].date) + "</div>",
                i += '<div class="dayNumber">' + getDate(e[0].date).getDate() + "</div></div>";
            for (var t, a = 0, r = e.length; r > a; a++) t = "1" == e[a].category ? "/rsc/contrib/image/webzine/puce-eve.png" : "/rsc/contrib/image/webzine/puce-fisc.png",
                i += e.length - 1 == a ? "<div id=" + e[a].id + " class='item-list last-item'><span class='puce-agenda'><img src=" + t + "></span><p><span>" + e[a].title + "</span></p></div>" : "<div id=" + e[a].id + " class='item-list'><span class='puce-agenda'><img src=" + t + "></span><p><span>" + e[a].title + "</span></p></div>";
            return i + "</div>";
        }), Handlebars.registerHelper("NoteOrentationStrat", function() {});
    } catch (t) {}
}();
define("handlebars.helpers", ["jquery", "handlebars"], function() {});
bnpp.sf31.define(["jquery"], function(p) {
    return bnpp.jquery = p.noConflict(!0), bnpp.jQuery = bnpp.jquery, bnpp.$ = bnpp.jquery,
        bnpp.jquery;
});
// Rivets.js
// version: 0.6.5
// author: Michael Richards
// license: MIT

(function() {
    var t, e = function(t, e) {
            return function() {
                return t.apply(e, arguments);
            };
        },
        i = [].indexOf || function(t) {
            for (var e = 0, i = this.length; i > e; e++)
                if (e in this && this[e] === t) return e;
            return -1;
        },
        n = [].slice,
        s = {}.hasOwnProperty,
        r = function(t, e) {
            function i() {
                this.constructor = t;
            }
            for (var n in e) s.call(e, n) && (t[n] = e[n]);
            return i.prototype = e.prototype, t.prototype = new i(), t.__super__ = e.prototype,
                t;
        };
    t = {
        binders: {},
        components: {},
        formatters: {},
        adapters: {},
        config: {
            prefix: "rv",
            templateDelimiters: ["{", "}"],
            rootInterface: ".",
            preloadData: !0,
            handler: function(t, e, i) {
                return this.call(t, e, i.view.models);
            }
        }
    }, t.Util = {
        bindEvent: function(t, e, i) {
            return null != window.jQuery ? (t = jQuery(t), null != t.on ? t.on(e, i) : t.bind(e, i)) : null != window.addEventListener ? t.addEventListener(e, i, !1) : (e = "on" + e,
                t.attachEvent(e, i));
        },
        unbindEvent: function(t, e, i) {
            return null != window.jQuery ? (t = jQuery(t), null != t.off ? t.off(e, i) : t.unbind(e, i)) : null != window.removeEventListener ? t.removeEventListener(e, i, !1) : (e = "on" + e,
                t.detachEvent(e, i));
        },
        getInputValue: function(t) {
            var e, i, n, s;
            if (null != window.jQuery) switch (t = jQuery(t), t[0].type) {
                case "checkbox":
                    return t.is(":checked");

                default:
                    return t.val();
            } else switch (t.type) {
                case "checkbox":
                    return t.checked;

                case "select-multiple":
                    for (s = [], i = 0, n = t.length; n > i; i++) e = t[i], e.selected && s.push(e.value);
                    return s;

                default:
                    return t.value;
            }
        }
    }, t.View = function() {
        function n(i, n, s) {
            var r, h, o, u, a, l, p, d, c;
            for (this.els = i, this.models = n, this.options = null != s ? s : {}, this.update = e(this.update, this),
                this.publish = e(this.publish, this), this.sync = e(this.sync, this), this.unbind = e(this.unbind, this),
                this.bind = e(this.bind, this), this.select = e(this.select, this), this.build = e(this.build, this),
                this.componentRegExp = e(this.componentRegExp, this), this.bindingRegExp = e(this.bindingRegExp, this),
                this.els.jquery || this.els instanceof Array || (this.els = [this.els]), p = ["config", "binders", "formatters", "adapters"],
                a = 0, l = p.length; l > a; a++) {
                if (h = p[a], this[h] = {}, this.options[h]) {
                    d = this.options[h];
                    for (r in d) o = d[r], this[h][r] = o;
                }
                c = t[h];
                for (r in c) o = c[r], null == (u = this[h])[r] && (u[r] = o);
            }
            this.build();
        }
        return n.prototype.bindingRegExp = function() {
            return new RegExp("^" + this.config.prefix + "-");
        }, n.prototype.componentRegExp = function() {
            return new RegExp("^" + this.config.prefix.toUpperCase() + "-");
        }, n.prototype.build = function() {
            var e, n, s, r, h, o, u, a, l, p = this;
            for (this.bindings = [], o = [], e = this.bindingRegExp(), s = this.componentRegExp(),
                n = function(e, i, n, s) {
                    var r, h, o, u, a, l, d;
                    return a = {}, d = function() {
                            var t, e, i, n;
                            for (i = s.split("|"), n = [], t = 0, e = i.length; e > t; t++) l = i[t], n.push(l.trim());
                            return n;
                        }(), r = function() {
                            var t, e, i, n;
                            for (i = d.shift().split("<"), n = [], t = 0, e = i.length; e > t; t++) h = i[t],
                                n.push(h.trim());
                            return n;
                        }(), u = r.shift(), a.formatters = d, (o = r.shift()) && (a.dependencies = o.split(/\s+/)),
                        p.bindings.push(new t[e](p, i, n, u, a));
                }, h = function(r) {
                    var u, a, l, d, c, f, b, v, y, g, m, w, k, x, E, N, O, j, R, B, V, C, P, U, A, T, S, _, Q, F;
                    if (i.call(o, r) < 0) {
                        if (3 === r.nodeType) {
                            if (v = t.TextTemplateParser, (c = p.config.templateDelimiters) && (w = v.parse(r.data, c)).length && (1 !== w.length || w[0].type !== v.types.text)) {
                                for (E = 0, R = w.length; R > E; E++) m = w[E], g = document.createTextNode(m.value),
                                    r.parentNode.insertBefore(g, r), 1 === m.type && n("TextBinding", g, null, m.value);
                                r.parentNode.removeChild(r);
                            }
                        } else if (s.test(r.tagName)) k = r.tagName.replace(s, "").toLowerCase(), p.bindings.push(new t.ComponentBinding(p, r, k));
                        else if (null != r.attributes) {
                            for (A = r.attributes, N = 0, B = A.length; B > N; N++)
                                if (u = A[N], e.test(u.name)) {
                                    if (k = u.name.replace(e, ""), !(l = p.binders[k])) {
                                        T = p.binders;
                                        for (f in T) x = T[f], "*" !== f && -1 !== f.indexOf("*") && (y = new RegExp("^" + f.replace("*", ".+") + "$"),
                                            y.test(k) && (l = x));
                                    }
                                    if (l || (l = p.binders["*"]), l.block) {
                                        for (S = r.childNodes, O = 0, V = S.length; V > O; O++) b = S[O], o.push(b);
                                        a = [u];
                                    }
                                }
                            for (_ = a || r.attributes, j = 0, C = _.length; C > j; j++) u = _[j], e.test(u.name) && (k = u.name.replace(e, ""),
                                n("Binding", r, k, u.value));
                        }
                        for (Q = function() {
                                var t, e, i, n;
                                for (i = r.childNodes, n = [], e = 0, t = i.length; t > e; e++) b = i[e], n.push(b);
                                return n;
                            }(), F = [], U = 0, P = Q.length; P > U; U++) d = Q[U], F.push(h(d));
                        return F;
                    }
                }, l = this.els, u = 0, a = l.length; a > u; u++) r = l[u], h(r);
        }, n.prototype.select = function(t) {
            var e, i, n, s, r;
            for (s = this.bindings, r = [], i = 0, n = s.length; n > i; i++) e = s[i], t(e) && r.push(e);
            return r;
        }, n.prototype.bind = function() {
            var t, e, i, n, s;
            for (n = this.bindings, s = [], e = 0, i = n.length; i > e; e++) t = n[e], s.push(t.bind());
            return s;
        }, n.prototype.unbind = function() {
            var t, e, i, n, s;
            for (n = this.bindings, s = [], e = 0, i = n.length; i > e; e++) t = n[e], s.push(t.unbind());
            return s;
        }, n.prototype.sync = function() {
            var t, e, i, n, s;
            for (n = this.bindings, s = [], e = 0, i = n.length; i > e; e++) t = n[e], s.push(t.sync());
            return s;
        }, n.prototype.publish = function() {
            var t, e, i, n, s;
            for (n = this.select(function(t) {
                    return t.binder.publishes;
                }), s = [], e = 0, i = n.length; i > e; e++) t = n[e], s.push(t.publish());
            return s;
        }, n.prototype.update = function(t) {
            var e, i, n, s, r, h, o;
            null == t && (t = {});
            for (i in t) n = t[i], this.models[i] = n;
            for (h = this.bindings, o = [], s = 0, r = h.length; r > s; s++) e = h[s], o.push(e.update(t));
            return o;
        }, n;
    }(), t.Binding = function() {
        function i(t, i, n, s, r) {
            this.view = t, this.el = i, this.type = n, this.keypath = s, this.options = null != r ? r : {},
                this.update = e(this.update, this), this.unbind = e(this.unbind, this), this.bind = e(this.bind, this),
                this.publish = e(this.publish, this), this.sync = e(this.sync, this), this.set = e(this.set, this),
                this.eventHandler = e(this.eventHandler, this), this.formattedValue = e(this.formattedValue, this),
                this.setObserver = e(this.setObserver, this), this.setBinder = e(this.setBinder, this),
                this.formatters = this.options.formatters || [], this.dependencies = [], this.setBinder(),
                this.setObserver();
        }
        return i.prototype.setBinder = function() {
            var t, e, i, n;
            if (!(this.binder = this.view.binders[this.type])) {
                n = this.view.binders;
                for (t in n) i = n[t], "*" !== t && -1 !== t.indexOf("*") && (e = new RegExp("^" + t.replace("*", ".+") + "$"),
                    e.test(this.type) && (this.binder = i, this.args = new RegExp("^" + t.replace("*", "(.+)") + "$").exec(this.type),
                        this.args.shift()));
            }
            return this.binder || (this.binder = this.view.binders["*"]), this.binder instanceof Function ? this.binder = {
                routine: this.binder
            } : void 0;
        }, i.prototype.setObserver = function() {
            var e = this;
            return this.observer = new t.KeypathObserver(this.view, this.view.models, this.keypath, function(t) {
                return e.key && e.unbind(!0), e.model = t.target, e.key && e.bind(!0), e.sync();
            }), this.key = this.observer.key, this.model = this.observer.target;
        }, i.prototype.formattedValue = function(t) {
            var e, i, s, r, h, o;
            for (o = this.formatters, r = 0, h = o.length; h > r; r++) i = o[r], e = i.split(/\s+/),
                s = e.shift(), i = this.view.formatters[s], (null != i ? i.read : void 0) instanceof Function ? t = i.read.apply(i, [t].concat(n.call(e))) : i instanceof Function && (t = i.apply(null, [t].concat(n.call(e))));
            return t;
        }, i.prototype.eventHandler = function(t) {
            var e, i;
            return i = (e = this).view.config.handler,
                function(n) {
                    return i.call(t, this, n, e);
                };
        }, i.prototype.set = function(t) {
            var e;
            return t = t instanceof Function && !this.binder["function"] ? this.formattedValue(t.call(this.model)) : this.formattedValue(t),
                null != (e = this.binder.routine) ? e.call(this, this.el, t) : void 0;
        }, i.prototype.sync = function() {
            return this.set(this.key ? this.view.adapters[this.key["interface"]].read(this.model, this.key.path) : this.model);
        }, i.prototype.publish = function() {
            var e, i, s, r, h, o, u, a, l;
            for (r = t.Util.getInputValue(this.el), u = this.formatters.slice(0).reverse(),
                h = 0, o = u.length; o > h; h++) i = u[h], e = i.split(/\s+/), s = e.shift(), (null != (a = this.view.formatters[s]) ? a.publish : void 0) && (r = (l = this.view.formatters[s]).publish.apply(l, [r].concat(n.call(e))));
            return this.view.adapters[this.key["interface"]].publish(this.model, this.key.path, r);
        }, i.prototype.bind = function(e) {
            var i, n, s, r, h, o, u, a, l, p = this;
            if (null == e && (e = !1), e || null != (o = this.binder.bind) && o.call(this, this.el),
                this.key && this.view.adapters[this.key["interface"]].subscribe(this.model, this.key.path, this.sync),
                (e ? void 0 : this.view.config.preloadData) && this.sync(), null != (u = this.options.dependencies) ? u.length : void 0) {
                for (a = this.options.dependencies, l = [], r = 0, h = a.length; h > r; r++) i = a[r],
                    s = new t.KeypathObserver(this.view, this.model, i, function(t, e) {
                        var i;
                        return i = t.key, p.view.adapters[i["interface"]].unsubscribe(e, i.path, p.sync),
                            p.view.adapters[i["interface"]].subscribe(t.target, i.path, p.sync), p.sync();
                    }), n = s.key, this.view.adapters[n["interface"]].subscribe(s.target, n.path, this.sync),
                    l.push(this.dependencies.push(s));
                return l;
            }
        }, i.prototype.unbind = function(t) {
            var e, i, n, s, r, h;
            if (null == t && (t = !1), t || (null != (r = this.binder.unbind) && r.call(this, this.el),
                    this.observer.unobserve()), this.key && this.view.adapters[this.key["interface"]].unsubscribe(this.model, this.key.path, this.sync),
                this.dependencies.length) {
                for (h = this.dependencies, n = 0, s = h.length; s > n; n++) i = h[n], e = i.key,
                    this.view.adapters[e["interface"]].unsubscribe(i.target, e.path, this.sync);
                return this.dependencies = [];
            }
        }, i.prototype.update = function(t) {
            var e;
            return null == t && (t = {}), null != (e = this.binder.update) ? e.call(this, t) : void 0;
        }, i;
    }(), t.ComponentBinding = function(n) {
        function s(n, s, r) {
            var h, o, u, a, l;
            for (this.view = n, this.el = s, this.type = r, this.unbind = e(this.unbind, this),
                this.bind = e(this.bind, this), this.update = e(this.update, this), this.locals = e(this.locals, this),
                this.component = t.components[this.type], this.attributes = {}, this.inflections = {},
                a = this.el.attributes || [], o = 0, u = a.length; u > o; o++) h = a[o], l = h.name,
                i.call(this.component.attributes, l) >= 0 ? this.attributes[h.name] = h.value : this.inflections[h.name] = h.value;
        }
        return r(s, n), s.prototype.sync = function() {}, s.prototype.locals = function(t) {
            var e, i, n, s, r, h, o, u, a;
            null == t && (t = this.view.models), r = {}, u = this.inflections;
            for (i in u)
                for (e = u[i], a = e.split("."), h = 0, o = a.length; o > h; h++) s = a[h],
                    r[i] = (r[i] || t)[s];
            for (i in t) n = t[i], null == r[i] && (r[i] = n);
            return r;
        }, s.prototype.update = function(t) {
            var e;
            return null != (e = this.componentView) ? e.update(this.locals(t)) : void 0;
        }, s.prototype.bind = function() {
            var e, i;
            return null != this.componentView ? null != (i = this.componentView) ? i.bind() : void 0 : (e = this.component.build.call(this.attributes),
                (this.componentView = new t.View(e, this.locals(), this.view.options)).bind(), this.el.parentNode.replaceChild(e, this.el));
        }, s.prototype.unbind = function() {
            var t;
            return null != (t = this.componentView) ? t.unbind() : void 0;
        }, s;
    }(t.Binding), t.TextBinding = function(t) {
        function i(t, i, n, s, r) {
            this.view = t, this.el = i, this.type = n, this.keypath = s, this.options = null != r ? r : {},
                this.sync = e(this.sync, this), this.formatters = this.options.formatters || [],
                this.dependencies = [], this.setObserver();
        }
        return r(i, t), i.prototype.binder = {
            routine: function(t, e) {
                return t.data = null != e ? e : "";
            }
        }, i.prototype.sync = function() {
            return i.__super__.sync.apply(this, arguments);
        }, i;
    }(t.Binding), t.KeypathParser = function() {
        function t() {}
        return t.parse = function(t, e, n) {
            var s, r, h, o, u;
            for (h = [], r = {
                    "interface": n,
                    path: ""
                }, o = 0, u = t.length; u > o; o++) s = t[o], i.call(e, s) >= 0 ? (h.push(r), r = {
                "interface": s,
                path: ""
            }) : r.path += s;
            return h.push(r), h;
        }, t;
    }(), t.TextTemplateParser = function() {
        function t() {}
        return t.types = {
            text: 0,
            binding: 1
        }, t.parse = function(t, e) {
            var i, n, s, r, h, o, u;
            for (o = [], r = t.length, i = 0, n = 0; r > n;) {
                if (i = t.indexOf(e[0], n), 0 > i) {
                    o.push({
                        type: this.types.text,
                        value: t.slice(n)
                    });
                    break;
                }
                if (i > 0 && i > n && o.push({
                        type: this.types.text,
                        value: t.slice(n, i)
                    }), n = i + e[0].length, i = t.indexOf(e[1], n), 0 > i) {
                    h = t.slice(n - e[1].length), s = o[o.length - 1], (null != s ? s.type : void 0) === this.types.text ? s.value += h : o.push({
                        type: this.types.text,
                        value: h
                    });
                    break;
                }
                u = t.slice(n, i).trim(), o.push({
                    type: this.types.binding,
                    value: u
                }), n = i + e[1].length;
            }
            return o;
        }, t;
    }(), t.KeypathObserver = function() {
        function n(t, i, n, s) {
            this.view = t, this.model = i, this.keypath = n, this.callback = s, this.unobserve = e(this.unobserve, this),
                this.realize = e(this.realize, this), this.update = e(this.update, this), this.parse = e(this.parse, this),
                this.parse(), this.objectPath = [], this.target = this.realize();
        }
        return n.prototype.parse = function() {
            var e, n, s, r, h, o;
            return e = function() {
                var t, e;
                t = this.view.adapters, e = [];
                for (n in t) h = t[n], e.push(n);
                return e;
            }.call(this), o = this.keypath[0], i.call(e, o) >= 0 ? (r = this.keypath[0], s = this.keypath.substr(1)) : (r = this.view.config.rootInterface,
                s = this.keypath), this.tokens = t.KeypathParser.parse(s, e, r), this.key = this.tokens.pop();
        }, n.prototype.update = function() {
            var t, e;
            return (t = this.realize()) !== this.target ? (e = this.target, this.target = t,
                this.callback(this, e)) : void 0;
        }, n.prototype.realize = function() {
            var t, e, i, n, s, r, h;
            for (t = this.model, h = this.tokens, e = s = 0, r = h.length; r > s; e = ++s) n = h[e],
                null != this.objectPath[e] ? t !== (i = this.objectPath[e]) && (this.view.adapters[n["interface"]].unsubscribe(i, n.path, this.update),
                    this.view.adapters[n["interface"]].subscribe(t, n.path, this.update), this.objectPath[e] = t) : (this.view.adapters[n["interface"]].subscribe(t, n.path, this.update),
                    this.objectPath[e] = t), t = this.view.adapters[n["interface"]].read(t, n.path);
            return t;
        }, n.prototype.unobserve = function() {
            var t, e, i, n, s, r, h;
            for (r = this.tokens, h = [], t = n = 0, s = r.length; s > n; t = ++n) i = r[t],
                (e = this.objectPath[t]) ? h.push(this.view.adapters[i["interface"]].unsubscribe(e, i.path, this.update)) : h.push(void 0);
            return h;
        }, n;
    }(), t.binders.text = function(t, e) {
        return null != t.textContent ? t.textContent = null != e ? e : "" : t.innerText = null != e ? e : "";
    }, t.binders.html = function(t, e) {
        return t.innerHTML = null != e ? e : "";
    }, t.binders.show = function(t, e) {
        return t.style.display = e ? "" : "none";
    }, t.binders.hide = function(t, e) {
        return t.style.display = e ? "none" : "";
    }, t.binders.enabled = function(t, e) {
        return t.disabled = !e;
    }, t.binders.disabled = function(t, e) {
        return t.disabled = !!e;
    }, t.binders.checked = {
        publishes: !0,
        bind: function(e) {
            return t.Util.bindEvent(e, "change", this.publish);
        },
        unbind: function(e) {
            return t.Util.unbindEvent(e, "change", this.publish);
        },
        routine: function(t, e) {
            var i;
            return t.checked = "radio" === t.type ? (null != (i = t.value) ? i.toString() : void 0) === (null != e ? e.toString() : void 0) : !!e;
        }
    }, t.binders.unchecked = {
        publishes: !0,
        bind: function(e) {
            return t.Util.bindEvent(e, "change", this.publish);
        },
        unbind: function(e) {
            return t.Util.unbindEvent(e, "change", this.publish);
        },
        routine: function(t, e) {
            var i;
            return t.checked = "radio" === t.type ? (null != (i = t.value) ? i.toString() : void 0) !== (null != e ? e.toString() : void 0) : !e;
        }
    }, t.binders.value = {
        publishes: !0,
        bind: function(e) {
            return t.Util.bindEvent(e, "change", this.publish);
        },
        unbind: function(e) {
            return t.Util.unbindEvent(e, "change", this.publish);
        },
        routine: function(t, e) {
            var n, s, r, h, o, u, a;
            if (null != window.jQuery) {
                if (t = jQuery(t), (null != e ? e.toString() : void 0) !== (null != (h = t.val()) ? h.toString() : void 0)) return t.val(null != e ? e : "");
            } else if ("select-multiple" === t.type) {
                if (null != e) {
                    for (a = [], s = 0, r = t.length; r > s; s++) n = t[s], a.push(n.selected = (o = n.value,
                        i.call(e, o) >= 0));
                    return a;
                }
            } else if ((null != e ? e.toString() : void 0) !== (null != (u = t.value) ? u.toString() : void 0)) return t.value = null != e ? e : "";
        }
    }, t.binders["if"] = {
        block: !0,
        bind: function(t) {
            var e, i;
            return null == this.marker ? (e = [this.view.config.prefix, this.type].join("-").replace("--", "-"),
                i = t.getAttribute(e), this.marker = document.createComment(" rivets: " + this.type + " " + i + " "),
                t.removeAttribute(e), t.parentNode.insertBefore(this.marker, t), t.parentNode.removeChild(t)) : void 0;
        },
        unbind: function() {
            var t;
            return null != (t = this.nested) ? t.unbind() : void 0;
        },
        routine: function(e, i) {
            var n, s, r, h, o;
            if (!!i == (null == this.nested)) {
                if (i) {
                    r = {}, o = this.view.models;
                    for (n in o) s = o[n], r[n] = s;
                    return h = {
                        binders: this.view.options.binders,
                        formatters: this.view.options.formatters,
                        adapters: this.view.options.adapters,
                        config: this.view.options.config
                    }, (this.nested = new t.View(e, r, h)).bind(), this.marker.parentNode.insertBefore(e, this.marker.nextSibling);
                }
                return e.parentNode.removeChild(e), this.nested.unbind(), delete this.nested;
            }
        },
        update: function(t) {
            var e;
            return null != (e = this.nested) ? e.update(t) : void 0;
        }
    }, t.binders.unless = {
        block: !0,
        bind: function(e) {
            return t.binders["if"].bind.call(this, e);
        },
        unbind: function() {
            return t.binders["if"].unbind.call(this);
        },
        routine: function(e, i) {
            return t.binders["if"].routine.call(this, e, !i);
        },
        update: function(e) {
            return t.binders["if"].update.call(this, e);
        }
    }, t.binders["on-*"] = {
        "function": !0,
        unbind: function(e) {
            return this.handler ? t.Util.unbindEvent(e, this.args[0], this.handler) : void 0;
        },
        routine: function(e, i) {
            return this.handler && t.Util.unbindEvent(e, this.args[0], this.handler), t.Util.bindEvent(e, this.args[0], this.handler = this.eventHandler(i));
        }
    }, t.binders["each-*"] = {
        block: !0,
        bind: function(t) {
            var e;
            return null == this.marker ? (e = [this.view.config.prefix, this.type].join("-").replace("--", "-"),
                this.marker = document.createComment(" rivets: " + this.type + " "), this.iterated = [],
                t.removeAttribute(e), t.parentNode.insertBefore(this.marker, t), t.parentNode.removeChild(t)) : void 0;
        },
        unbind: function() {
            var t, e, i, n, s;
            if (null != this.iterated) {
                for (n = this.iterated, s = [], e = 0, i = n.length; i > e; e++) t = n[e], s.push(t.unbind());
                return s;
            }
        },
        routine: function(e, i) {
            var n, s, r, h, o, u, a, l, p, d, c, f, b, v, y, g, m, w, k, x, E, N, O, j;
            if (l = this.args[0], i = i || [], this.iterated.length > i.length)
                for (x = Array(this.iterated.length - i.length),
                    v = 0, m = x.length; m > v; v++) r = x[v], b = this.iterated.pop(), b.unbind(),
                    this.marker.parentNode.removeChild(b.els[0]);
            for (h = y = 0, w = i.length; w > y; h = ++y)
                if (a = i[h], s = {}, s[l] = a, null == this.iterated[h]) {
                    E = this.view.models;
                    for (u in E) a = E[u], null == s[u] && (s[u] = a);
                    d = this.iterated.length ? this.iterated[this.iterated.length - 1].els[0] : this.marker,
                        p = {
                            binders: this.view.options.binders,
                            formatters: this.view.options.formatters,
                            adapters: this.view.options.adapters,
                            config: {}
                        }, N = this.view.options.config;
                    for (o in N) f = N[o], p.config[o] = f;
                    p.config.preloadData = !0, c = e.cloneNode(!0), b = new t.View(c, s, p), b.bind(),
                        this.iterated.push(b), this.marker.parentNode.insertBefore(c, d.nextSibling);
                } else this.iterated[h].models[l] !== a && this.iterated[h].update(s);
            if ("OPTION" === e.nodeName) {
                for (O = this.view.bindings, j = [], g = 0, k = O.length; k > g; g++) n = O[g],
                    n.el === this.marker.parentNode && "value" === n.type ? j.push(n.sync()) : j.push(void 0);
                return j;
            }
        },
        update: function(t) {
            var e, i, n, s, r, h, o, u;
            e = {};
            for (i in t) n = t[i], i !== this.args[0] && (e[i] = n);
            for (o = this.iterated, u = [], r = 0, h = o.length; h > r; r++) s = o[r], u.push(s.update(e));
            return u;
        }
    }, t.binders["class-*"] = function(t, e) {
        var i;
        return i = " " + t.className + " ", !e == (-1 !== i.indexOf(" " + this.args[0] + " ")) ? t.className = e ? "" + t.className + " " + this.args[0] : i.replace(" " + this.args[0] + " ", " ").trim() : void 0;
    }, t.binders["*"] = function(t, e) {
        return e ? t.setAttribute(this.type, e) : t.removeAttribute(this.type);
    }, t.adapters["."] = {
        id: "_rv",
        counter: 0,
        weakmap: {},
        weakReference: function(t) {
            var e;
            return null == t[this.id] && (e = this.counter++, this.weakmap[e] = {
                callbacks: {}
            }, Object.defineProperty(t, this.id, {
                value: e
            })), this.weakmap[t[this.id]];
        },
        stubFunction: function(t, e) {
            var i, n, s;
            return n = t[e], i = this.weakReference(t), s = this.weakmap, t[e] = function() {
                var e, r, h, o, u, a, l, p, d, c;
                o = n.apply(t, arguments), l = i.pointers;
                for (h in l)
                    for (r = l[h], c = null != (p = null != (d = s[h]) ? d.callbacks[r] : void 0) ? p : [],
                        u = 0, a = c.length; a > u; u++) e = c[u], e();
                return o;
            };
        },
        observeMutations: function(t, e, n) {
            var s, r, h, o, u, a;
            if (Array.isArray(t)) {
                if (h = this.weakReference(t), null == h.pointers)
                    for (h.pointers = {}, r = ["push", "pop", "shift", "unshift", "sort", "reverse", "splice"],
                        u = 0, a = r.length; a > u; u++) s = r[u], this.stubFunction(t, s);
                if (null == (o = h.pointers)[e] && (o[e] = []), i.call(h.pointers[e], n) < 0) return h.pointers[e].push(n);
            }
        },
        unobserveMutations: function(t, e, i) {
            var n, s;
            return Array.isArray(t && null != t[this.id]) && (n = null != (s = this.weakReference(t).pointers) ? s[e] : void 0) ? n.splice(n.indexOf(i), 1) : void 0;
        },
        subscribe: function(t, e, n) {
            var s, r, h = this;
            return s = this.weakReference(t).callbacks, null == s[e] && (s[e] = [], r = t[e],
                Object.defineProperty(t, e, {
                    get: function() {
                        return r;
                    },
                    set: function(i) {
                        var o, u, a;
                        if (i !== r) {
                            for (r = i, a = s[e], o = 0, u = a.length; u > o; o++) n = a[o], n();
                            return h.observeMutations(i, t[h.id], e);
                        }
                    }
                })), i.call(s[e], n) < 0 && s[e].push(n), this.observeMutations(t[e], t[this.id], e);
        },
        unsubscribe: function(t, e, i) {
            var n;
            return n = this.weakmap[t[this.id]].callbacks[e], n.splice(n.indexOf(i), 1), this.unobserveMutations(t[e], t[this.id], e);
        },
        read: function(t, e) {
            return t[e];
        },
        publish: function(t, e, i) {
            return t[e] = i;
        }
    }, t.factory = function(e) {
        return e._ = t, e.binders = t.binders, e.components = t.components, e.formatters = t.formatters,
            e.adapters = t.adapters, e.config = t.config, e.configure = function(e) {
                var i, n;
                null == e && (e = {});
                for (i in e) n = e[i], t.config[i] = n;
            }, e.bind = function(e, i, n) {
                var s;
                return null == i && (i = {}), null == n && (n = {}), s = new t.View(e, i, n), s.bind(),
                    s;
            };
    }, "object" == typeof exports ? t.factory(exports) : "function" == typeof define && define.amd ? define('rivets-src', ["exports"], function(e) {
        return t.factory(this.rivets = e), e;
    }) : t.factory(this.rivets = {});
}).call(this);
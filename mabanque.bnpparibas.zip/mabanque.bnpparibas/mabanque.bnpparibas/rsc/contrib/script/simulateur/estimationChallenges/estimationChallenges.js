function initsimuLoyer(item, Obj) {
    //initalisation du nanoscroller
    document.getElementById(item).scrollIntoView({
        behavior: "smooth",
        block: "center",
        inline: "nearest"
    })
    $('#showMoreOption').click(function(event) {
        //$('.select-box .nano').nanoScroller();
        setTimeout(
            function() {
                document.getElementById('options').scrollIntoView({
                    behavior: "smooth",
                    block: "center",
                    inline: "nearest"
                })
            },
            300
        )
        $('#options').removeClass('hidden');
    });

    // ------------------------- Boite de selection --------------------

    $('.select-box').on('click', 'li', function(event) {
        $(this).toggleClass('active');
    });

    //selectionner des options
    $('.js-add-to-selected').click(function(event) {
        var optionSelected = $('.list-select-options li.active:not(.hidden)').clone();
        $('.list-select-options li.active').removeClass('active').addClass('hidden');

        //on les copies dans la liste des options sélectionnées
        $.each(optionSelected, function(i, val) {
            $(this).removeClass('active');
            $('.list-selected-options').append(val);
        });

        //$('.select-box .nano').nanoScroller();

    });

    //déselectionner des options
    $('.js-remove-from-selected').click(function(event) {

        var OptionToDeselect = $('.list-selected-options li.active');
        $.each(OptionToDeselect, function(i, val) {
            var option = $(this).data('option');
            $('.list-select-options li[data-option="' + option + '"]').removeClass('hidden');
            $(this).remove();
        });

    });

    // ----------------------------------------------------------------

    // validation du formulaire
    $("form").submit(function(e) {
        e.preventDefault();

        // controle des champs si valide on check sinon return
        if (!$(this).valid()) {
            return;
        }
        /* 
        // Mosaic Off 
        // sinon pas de possibilité de rajouter des options apres 1ere simul sans option et sans tout resaisir
        if($('#showMoreOption:visible')){
            $('#showMoreOption').addClass('hidden');
        }
        */
        $('#resultats').removeClass('hidden');
        loyerImmo.getParamUser("result");
        return false;
    })

    //nouvelle simulation
    $('.wrap').on('click', '#reset-form', function(event) {
        event.preventDefault();

        $('#showMoreOption').removeClass('hidden');
        $('#resultats').addClass('hidden');

        //on vide les options
        $('.select-box li').removeClass();
        $('.list-selected-options').html("");
        $('#options').addClass('hidden');

        $("#formSimuLoyer .form-control").removeClass('valid');
        $("#formSimuLoyer")[0].reset();
    });


    // ------------------------ Simul Challenge add Mosaic
    var loyerImmo = {
        module: '',
        wsurl: '',
        idfields: {
            'ville': '',
            'situ': '',
            'taille': '',
            'etage': '',
            'u_options': '',
            'superficie': ''
        },
        uparam: {},
        ubien_region: '',
        nb_options: 0,

        Init: function(simul, wsurl) { // init Simul
            this.wsurl = wsurl;
            this.module = (simul != 'immo') ? 'loyer' : simul;
            this.title = (simul != 'immo') ? "Etape 2 - Loyer estime" : "Etape 2 - Valeur estimee";

            var sloyer = (this.module == 'loyer'),
                ismobile = ((/ipad|iphone/i.test(navigator.platform)) || (/linux/i.test(navigator.platform) && /android/i.test(navigator.userAgent)));
            $('input[name="typebien"]').change(function() {
                loyerImmo.getParamUser();
            });
            $('#region').change(function() {
                loyerImmo.getParamUser();
            });
            if (ismobile) {
                $('#superficie').attr("type", "number");
            }

            for (var field in this.idfields) {
                if (field != 'u_options') {
                    $('#div-' + field).hide();
                    $('#' + field).change(function() {
                        if ($(this).is("select")) {
                            var id = $(this).attr('id');
                            loyerImmo.idfields[id] = $('#' + id + ' option:selected').text();
                        } // car value <> selon bien / region
                        loyerImmo.resultatOnOff(false);
                    });
                }
            }
            $('#s_options').bind("DOMSubtreeModified", function() { // sur changement options selectionnees
                setTimeout(function() {
                    if ($('#s_options li').length != loyerImmo.nb_options) {
                        loyerImmo.nb_options = $('#s_options li').length;
                        loyerImmo.resultatOnOff(false);
                    }
                }, 10);
            });

            $('#showMoreOption').hide();
            // MOA voir ajout id
            $('#libtitre').html((sloyer) ? 'ESTIMER LE MONTANT DE MON LOYER' : 'ESTIMER LA VALEUR DE MON BIEN IMMOBILIER');
            $('#libsstitre').html((sloyer) ? 'MON LOGEMENT' : 'MON BIEN IMMOBILIER');
            $('#show-resultat').html((sloyer) ? 'Estimer mon loyer' : 'Estimer mon bien');
            $('#libresult').html((sloyer) ? 'LOYER MENSUEL ESTIMÉ' : 'VALEUR ESTIMÉE DU BIEN');

        },


        getParamUser: function(query) { // query WS
            if (!query) {
                query = 'param';
            }
            var dataform = "mode=" + query + '&module=' + this.module + '&' + $('#formSimuLoyer').serialize(),
                bien = $('input[name="typebien"]:checked').val(),
                region = $('#region').val(),
                options = '';

            if ((query != 'param' && query != 'result') || bien == "" || region == "") {
                return false;
            }

            this.resultatOnOff(false);

            if (query == 'result') {
                if (parseFloat($('#superficie').val()) < 1) {
                    $('#superficie').val('').focus();
                    return false;
                }
                $.each($('#s_options li'), function(key, val) {
                    options += ";" + $(this).data('option');
                });
                if (options != "") {
                    dataform += "&options=" + options.substring(1);
                }

                if (this.uparam[query] && this.uparam[query] == dataform) {
                    return this.resultatOnOff(true);
                }
                this.uparam[query] = dataform;
            } else {
                this.ubien_region = bien + '_' + region;
                if (this.uparam[this.ubien_region]) {
                    return this.setSimul(this.uparam[this.ubien_region]);
                }
            }


            $.ajax({
                url: this.wsurl,
                dataType: "jsonp",
                data: dataform,
                success: function(data) {
                    loyerImmo.setSimul(data);
                }
            });

        },

        setSimul: function(data) { // reponse WS et peuplement

            var idfields = this.idfields,
                eachfirst, uservalue;

            if (!data || data.error.status != "0") {
                this.resultatOnOff(true, "Temporairement indisponible."); // mode user 
                if (window.console) {
                    console.log((data && data.error) ? data.error.status + " - " + data.error.label : "Incident Serveur !");
                } // mode dev
                this.uparam = {};
                return false;
            }

            if (data.result) {
                var tmp = JSON.parse(JSON.stringify(Obj.webtrends));
                tmp.title = this.title;
                OApp.webtrends(tmp, 2);
                return this.resultatOnOff(true, data.result);
            }

            for (var field in idfields) {
                $select = $('#' + field);
                if (data[field]) {
                    $select.html($select.is("select") ? '<option value="">Précisez</option>' : ''); // first choix defaut 
                    eachfirst = true;
                    uservalue = '';
                    $.each(data[field], function(key, val) {
                        if (field == "u_options") {
                            if (eachfirst) {
                                $('#s_options').html('');
                                $('#showMoreOption').show();
                                eachfirst = false;
                            } // clean old select option / bt option                             
                            $select.append('<li data-option="' + val.value + '">' + val.label + '</li>');
                        } else {
                            if (eachfirst) {
                                $('#div-' + field).show();
                                eachfirst = false;
                            } // MOA voir new id div-xxxx
                            $select.append('<option value="' + val.value + '">' + val.label + '</option>');
                            if (uservalue == '' && idfields[field] == val.label) {
                                uservalue = val.value;
                            }
                        }
                    });
                    if (uservalue != '') {
                        $select.val(uservalue);
                    }
                } else
                if ($select.is("select")) {
                    $select.html('<option value=" "></option>');
                    $('#div-' + field).hide(); // hide &  by pass les required
                } else {
                    $('#div-' + field).show(); // superficie 
                }
            }
            this.uparam[this.ubien_region] = data;

            return true;

        },

        resultatOnOff: function(show, result) { // affichage resultat
            $('#resultats').css('visibility', (show) ? 'visible' : 'hidden');
            if (result) {
                $('#result').html(result);
            } // aff montant
            if (show) {
                $('#reset-form').focus();
            }
            return show;
        }

    }
    // fin loyerImmo

    // MOA lancement simul 
    // 2 parametres : type de simulation , url unique du web service  
    var wsurl = 'https://animation.bnpparibas.net/simulateur-loyer-immo/ws/'; // url webservice PROD
    var typeSimul = (Obj.type == 'immo') ? "immo" : "loyer";
    loyerImmo.Init(typeSimul, wsurl);

    // ------------------------ fin Simul Challenge Mosaic

}
(function() {
    function ABTESTING() {
        this._local = true;
        var env = this.env();
        var client = /\/secure\//.test(document.location.pathname);
        if (!client) {
            if (document.querySelectorAll("#nextoutils_abtesting_json_secure, #nextoutilsinstant_abtesting_json_secure").length)
                client = true;
            if (document.querySelectorAll("#nextoutils_abtesting, #nextoutils_abtesting_json, #nextoutilsinstant_abtesting, #nextoutilsinstant_abtesting_json").length)
                client = false;
        }

        if (env == "hb") {
            if (client) {
                this._file = "b78359e529c33e2fbc1155f54c0dfc54.js";
                this._local = true;
            } else {
                this._file = "4c62a028a6d0778a110f8d627e378bdf.js";
                this._local = false;
            }
        } else if (env == "hbpro" || env == "hbpro-acqui") {
            if (client)
                return;
            else {
                this._file = "11271a16fa667c6e9427b01c96fb1284.js";
                this._local = false;
            }
        } else if (env == "part") {
            if (client) {
                this._file = "e746b158c9dbb421637f2ff3c0fd9865.js";
                this._local = true;
            } else {
                this._file = "807d0874b7fd2c300e36f6368f3c7dce.js";
                this._local = false;
            }
        } else if (env == "pro") {
            let pageAcquis = ['/fr/notre-offre-pro/comptes-cartes-et-services/devenir-client-ouvrir-un-compte/ouvrir-un-compte-bancaire',
                '/fr/notre-offre-pro/credits/projet-de-creation',
                '/fr/notre-offre-pro/comptes-cartes-et-services/devenir-client-ouvrir-un-compte/ouvrir-un-compte-personnel-en-ligne',
                '/rsc/contrib/minisite/landing/pros.html',
                '/rsc/contrib/minisite/landing/pros2.html',
                '/rsc/contrib/minisite/landing/pros3.html',
                '/rsc/contrib/minisite/landing/solutions-digitales.html',
                '/rsc/contrib/minisite/landing/monbusinessassistant.html',
                '/fr/vos-besoins-pro/votre-activite/createurs-repreneurs-d-entreprise/accompagnement-creation-entreprise/lancezvous',
                '/fr/mon-business-assistant',
                '/rsc/contrib/minisite/landing/filrougepro.html',
                '/fr/notre-offre-pro/devenir-client/ouverture-compte-pro'
            ];

            // Acquisitions
            if (pageAcquis.includes(window.location.pathname)) {
                this._file = "c8b3310b2880f750d52b5078fadc5c98.js";
                this._local = true;
            }

            // Remote Sales Clients
            else {
                this._file = "8e9049bb2c2034a84547fdf9024334df.js";
                this._local = true;
            }
        } else
            return;
        if (localStorage.abtestingTest)
            this._local = false;
        this._url = (this._local ? "/rsc/contrib/script/simulateur/abtesting/try/" : "https://try.abtasty.com/") + this._file;

        if (!window.bnpp || !bnpp.gestioncookies || !bnpp.gestioncookies.audience())
            return;

        function addScript(src, mod, dataDomain, onload) {
            if (mod) {
                var d = new Date();
                var t = d - (d % mod);
                src += "?" + t;
            }
            var s = document.createElement('script');
            s.setAttribute('src', src);
            onload ? s.setAttribute('onload', onload) : null;
            dataDomain ? s.setAttribute('data-domain-script', dataDomain) : null;
            document.head.appendChild(s);
        }
        var cache = this._local ? 0.5 * 60 * 60 * 1000 : 0;
        if (document.querySelectorAll("script[src*='try.abtasty.com']").length == 0 && document.querySelectorAll("script[src*='/abtesting/try']").length == 0)
            addScript(this._url, cache);
    }

    ABTESTING.prototype.env = function() {
        if (/hellobank-pro-qual1-acqui|hellobankpro/.test(document.location.hostname))
            return "hbpro-acqui";
        if (/hellobank-pro-|pro\.hellobank/.test(document.location.hostname))
            return "hbpro";
        if (/canalnet-pro|mabanquepro|pro\./.test(document.location.hostname))
            return "pro";
        if (/canalnet-bpf|mabanqueprivee|privee\./.test(document.location.hostname))
            return "bpf";
        if (/hellobank/.test(document.location.hostname))
            return "hb";
        return "part";
    }
    ABTESTING.prototype.readParameter = function(key, paramsString) {
        var result = paramsString.match(
            new RegExp("(\\?|\\#|&)" + key + "(\\[\\])?=([^&]*)")
        );

        return result ? decodeURIComponent(result[3]) : undefined;
    }

    if (!window.bnpp)
        window.bnpp = {};
    window.bnpp.abtesting = new ABTESTING();
})();
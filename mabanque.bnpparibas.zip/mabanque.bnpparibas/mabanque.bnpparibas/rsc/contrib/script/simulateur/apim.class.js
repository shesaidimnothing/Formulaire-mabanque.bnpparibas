function APIM(forceApigee, forceBroadcom) {
    if (!window.ENVIRONNEMENT ||
        ENVIRONNEMENT == 'PROD' ||
        ENVIRONNEMENT == 'PREVIEW' ||
        ENVIRONNEMENT == 'MACHINE' ||
        ENVIRONNEMENT == 'MOBILE' ||
        document.location.hostname == 'pro.hellobank.fr' ||
        /prev-(.)*.hellobank-(part|pro|bpf).hellobank.fr/.test(window.location.host)
    ) {
        this._apiserver = '//api-nav.bddf.bnpparibas';
        this._apiserverIOGA = '//w-services.bnpparibas.net';
    } else if (ENVIRONNEMENT == 'LOCAL') {
        this._apiserver = '/APIM';
        this._apiserverIOGA = '//staging-bnp.synten.com';
    } else {
        this._apiserver = '//api-nav.bddf.staging.bnpparibas';
        this._apiserverIOGA = '//staging-bnp.synten.com';
    }

    this._api = {
        /* aol questionnaires */
        questionnairesDisplayEligibility: {
            pathApigee: '/rgg/aol/v1/questionnaires/display/eligibility',
            method: 'POST',
            stringify: true,
        },
        questionnairesSave: {
            pathApigee: '/rgg/aol/v1/questionnaires/save',
            method: 'POST',
            stringify: true,
        },
        questionnairesPause: {
            pathApigee: '/rgg/aol/v1/questionnaires/pause',
            method: 'POST',
            stringify: true,
        },
        /* commando-demat */
        cancelElectronicStatements: {
            path: '/preferences/V1.0/electronic-statements/cancel',
            pathApigee: '/rgg/preferences/v1/electronic-statements/cancel',
            method: 'PUT',
        },
        /* agregation */
        flagAgregation: {
            path: '/preferences/v2/aggregation',
            pathApigee: '/rgg/preferences/v2/aggregation',
            method: 'POST',
            stringify: true,
        },
        messageBMM: {
            path: '/bmm/v2/messages',
            pathApigee: '/rgg/bmm/v1/messages',
            method: 'POST',
            stringify: true,
        },
        /* hub-epargne */
        clientEvaluation: {
            path: '/financial-profile/retail/V1.1/client-evaluations',
            pathApigee: '/rgg/financial-profiles/retails/v1/client-evaluations',
            method: 'POST',
            stringify: true,
        },
        lifeInsurances: {
            path: '/patrimonial-saving/V1.0/life-insurances',
            pathApigee: '/rgg/patrimonial-saving/v1/life-insurances',
            method: 'POST',
            stringify: true,
        },
        savingAccounts: {
            path: '/saving/V1.0/saving-accounts',
            pathApigee: '/rgg/savings/v1/saving-accounts',
            method: 'GET',
        },
        /* indicateurEmail */
        emails: {
            path: '/persons/email-reliability/v1/customers/me/emails',
            pathApigee: '/rgg/persons/email-reliability/v1/customers/me/emails',
            method: 'GET',
        },
        email: {
            path: '/persons/email-reliability/v1/customers/me/email',
            pathApigee: '/rgg/persons/email-reliability/v1/customers/me/email',
            method: 'GET',
        },
        emailUpdate: {
            path: '/persons/email-reliability/v1/customers/me/emails',
            pathApigee: '/rgg/persons/email-reliability/v1/customers/me/emails',
            method: 'PUT',
            stringify: true,
        },
        /* 1up4hb */
        bfmauthorizations: {
            path: '/finances-mgt/v1/bfm/me/authorizations',
            pathApigee: '/rgg/finances-mgt/v1/bfm/me/authorizations',
            method: 'GET',
        },
        bfmenrollment: {
            pathApigee: '/rgg/finances-mgt/v1/bfm/me/bb/enrollment/initialization',
            method: 'POST',
            stringify: true,
        },
        /* consentement */
        getconsent: {
            path: '/consent/v1/consents/collectionpoints/SCC',
            pathApigee: '/rgg/baseconsent/v1/consents/collectionpoints/SCC',
            method: 'GET',
            replaceUrlParam: true,
        },
        setconsent: {
            path: '/consent/v1/consents/collectionpoints/SCC?brandCode=BRANDCODE&scopeCode=SCOPECODE',
            pathApigee: '/rgg/baseconsent/v1/consents/collectionpoints/SCC?brandCode=BRANDCODE&scopeCode=SCOPECODE',
            method: 'PUT',
            stringify: true,
            replaceUrlParam: true,
        },
        /* cj-mecontent */
        claims: {
            path: '/claims/V2.0/claims',
            pathApigee: '/rgg/claims/v1/claims',
            method: 'POST',
            stringify: true,
        },
        claimBranches: {
            path: '/claims/V2.0/branches',
            pathApigee: '/rgg/claims/v1/branches',
            method: 'GET',
        },
        claimThemes: {
            path: '/claims/V2.0/themes',
            pathApigee: '/rgg/claims/v1/themes',
            method: 'GET',
        },
        claimSubthemes: {
            path: '/claims/V2.0/themes/themeCode/subthemes',
            pathApigee: '/rgg/claims/v1/themes/themeCode/subthemes',
            method: 'GET',
            replaceUrlParam: true,
        },
        claimCauses: {
            path: '/claims/V2.0/themes/themeCode/subthemes/subthemeCode/causes',
            pathApigee: '/rgg/claims/v1/themes/themeCode/subthemes/subthemeCode/causes',
            method: 'GET',
            replaceUrlParam: true,
        },

        msEligibilite: {
            path: '/sm/V1.0/service-models/msEligibilite',
            pathApigee: '/rgg/sm/v1/service-models/msEligibilite',
            method: 'GET',
            replaceUrlParam: false,
        },
        principal: {
            path: '/sm/V1.0/service-models/principal',
            pathApigee: '/rgg/sm/v1/service-models/principal',
            method: 'GET',
            replaceUrlParam: false,
        },
        proximityAdvisers: {
            path: '/sm/V1.0/service-models/proximityAdvisers',
            pathApigee: '/rgg/sm/v1/service-models/proximityAdvisers',
            method: 'GET',
            replaceUrlParam: false,
        },
        msDetail: {
            path: '/sm/V1.0/service-models/msDetail',
            pathApigee: '/rgg/sm/v1/service-models/msDetail',
            method: 'GET',
            replaceUrlParam: false,
        },
        msAutonomePreparation: {
            path: '/sm/V1.0/service-models/msAutonomePreparation',
            pathApigee: '/rgg/sm/v1/service-models/msAutonomePreparation',
            method: 'GET',
            replaceUrlParam: false,
        },
        msAutonomeValidation: {
            path: '/sm/V1.0/service-models/msAutonomeValidation',
            pathApigee: '/rgg/sm/v1/service-models/msAutonomeValidation',
            method: 'POST',
            stringify: true,
        },
        /* VCD contrat - declarer sinistre */
        vcdContrats: {
            pathApigee: '/rgg/protection-vcd/v1/me/contracts',
            method: 'GET',
        },
        vcdContratsDetail: {
            pathApigee: '/rgg/protection-vcd/v1/me/contracts/IDCONTRAT',
            method: 'GET',
            replaceUrlParam: true,
        },
        /* APIGEE */
        tokenAPIGEE: {
            path: '/pgg/as-front/v2/token',
            method: 'POST'
        },
        /* IOGA */
        IOGALogin: {
            url: this._apiserverIOGA + '/services/ioga/v1/login',
            method: 'GET',
            wservice: true,
        },
        IOGAMarques: {
            url: this._apiserverIOGA + '/services/ioga/v1/brands',
            method: 'GET',
            wservice: true,
        },
        IOGAModeles: {
            url: this._apiserverIOGA + '/services/ioga/v1/models',
            method: 'GET',
            wservice: true,
        },
        IOGADisponibilite: {
            url: this._apiserverIOGA + '/services/ioga/v1/availability/date',
            method: 'GET',
            replaceUrlParam: true,
            wservice: true,
        },
        IOGAProjet: {
            url: this._apiserverIOGA + '/services/ioga/v1/projectPrescription',
            method: 'POST',
            stringify: true,
            wservice: true,
        },
        tradingcentral: {
            url: this._apiserverIOGA + '/services/ioga/v1/tradingcentral',
            method: 'POST',
            stringify: true,
            wservice: true,
        },
        ikpitoken: {
            url: this._apiserverIOGA + '/services/ioga/v1/token',
            method: 'POST',
            stringify: true,
            wservice: true,
        },
        /* authorize */
        authorizeclientEvaluation: {
            path: '/as/retail/V2.0/authorize',
            method: 'GET',
            type: 'html',
        },
        authorizeAPIGEE: {
            path: '/pgg/as-front/v2/retail/authorize',
            method: 'GET',
            type: 'html',
        },

        authorizeBNPAPI: {
            url: '/oidc/authorize',
            method: 'GET',
            type: 'html'
        },
        getAuthorize: {
            url: '/rsc/contrib/script/simulateur/authorize.html',
            method: 'GET',
            type: 'html',
        },
        /* webCallback */
        setAppointementConnected: {
            pathApigee: '/rgg/webcallback/v1/campaigns/appointments',
            method: 'POST',
            stringify: true,
            auth: true,
        },
        getTimeSlotsConnected: {
            pathApigee: '/rgg/webcallback/v1/campaigns/',
            method: 'GET',
            auth: true,
        },
        setAppointement: {
            pathApigee: '/rgg/webcallback-nc/v1/campaigns/appointments',
            method: 'POST',
            stringify: true,
            auth: false,
        },
        getTimeSlots: {
            pathApigee: '/rgg/webcallback-nc/v1/campaigns/',
            method: 'GET',
            auth: false,
        },
    };
    this._expireToken = 9 * 60;
    this._oidc = {
        APIGEE: {
            interval: {
                interval: 500,
                max: 10000
            },
            client_id: ''
        },
        APIM: {
            interval: {
                interval: 500,
                max: 10000
            },
            client_id: ''
        },
        APIMEX1: {
            interval: {
                interval: 500,
                max: 30000
            },
            client_id: ''
        },
        APIMV2: {
            interval: {
                interval: 500,
                max: 30000
            },
            client_id: ''
        },
    };
    if (!window.ENVIRONNEMENT ||
        ENVIRONNEMENT == 'PROD' ||
        ENVIRONNEMENT == 'PREVIEW' ||
        ENVIRONNEMENT == 'MACHINE' ||
        ENVIRONNEMENT == 'MOBILE' ||
        document.location.hostname == 'pro.hellobank.fr' ||
        /prev-(.)*.hellobank-(part|pro|bpf).hellobank.fr/.test(window.location.host)
    ) {
        this._oidc.APIGEE.client_id = '30e572f8-a1c7-42f1-af7d-cf9799afda06';
        this._oidc.APIM.client_id = 'eee05137-6edb-43be-a675-5c697d848742';
        this._oidc.APIMEX1.client_id = '93c2b620-74c2-4768-972a-204e2bba23a5';
        var _prodHOST = false;
        if (sessionStorage.APIMProdHost) _prodHOST = true;
        switch (this.env()) {
            case 'part':
                if (_prodHOST) this._apiserver = '//api-nav.mabanque.bnpparibas';
                this._oidc.APIMV2.authorize = '/fr/secure/mes-outils/profil';
                this._oidc.APIMV2.client_id = 'f4e41e6e-160b-40f7-b22c-068155df2f39';
                break;
            case 'pro':
                if (_prodHOST) this._apiserver = '//api-nav.mabanquepro.bnpparibas';
                this._oidc.APIMV2.authorize = '/fr/secure/mes-outils/profil';
                this._oidc.APIMV2.client_id = '52529561-ea56-43c8-9f0a-8aacf65e0dae';
                break;
            case 'bpf':
                if (_prodHOST) this._apiserver = '//api-nav.mabanqueprivee.bnpparibas';
                this._oidc.APIMV2.authorize = '/fr/secure/mes-outils/profil';
                this._oidc.APIMV2.client_id = '619c9d24-1c3b-42ee-8d35-9095a7c8f592';
                break;
            case 'hb':
                if (_prodHOST) this._apiserver = '//api-nav.hellobank.fr';
                this._oidc.APIMV2.authorize =
                    '/fr/secure/mon-profil/kyc-informations-personnelles';
                this._oidc.APIMV2.client_id = '9f0ec854-2c9a-4c61-9123-9a617a2d39d1';
                this._api.authorizeclientEvaluation.path =
                    '/as/hellobank/V2.0/authorize';
                this._api.authorizeAPIGEE.path = '/pgg/as-front/v2/hellobank/authorize';
                break;
            case 'hbpro':
                if (_prodHOST) this._apiserver = '//api-nav.hellobank.fr';
                this._oidc.APIMV2.authorize =
                    '/fr/secure/mon-profil/kyc-informations-personnelles';
                this._oidc.APIMV2.client_id = '9f0ec854-2c9a-4c61-9123-9a617a2d39d1';
                this._api.authorizeclientEvaluation.path =
                    '/as/hellobank/V2.0/authorize';
                this._api.authorizeAPIGEE.path = '/pgg/as-front/v2/hellobank/authorize';
                break;
        }
    } else {
        this._oidc.APIGEE.client_id = '9fc81919-69e7-4d89-b96b-af5536a4e07c';
        this._oidc.APIM.client_id = 'eed5b0bb-147d-4640-8fc9-1036d31a4857';
        this._oidc.APIMEX1.client_id = '72b64edb-8dc6-4db4-b3df-bbca93737d73';
        switch (this.env()) {
            case 'part':
                this._apiserver = '//api-nav.staging.bnpparibas.net';
                this._oidc.APIMV2.authorize = '/fr/secure/mes-outils/profil';
                this._oidc.APIMV2.client_id = '40ce341e301a474180090b7ab9d2baf5';
                break;
            case 'pro':
                this._apiserver = '//api-nav.staging.bnpparibas.net';
                this._oidc.APIMV2.authorize = '/fr/secure/mes-outils/profil';
                this._oidc.APIMV2.client_id = '511761a4-4dff-4f1c-888a-3d504c9879e7';
                break;
            case 'bpf':
                this._apiserver = '//api-nav.staging.bnpparibas.net';
                this._oidc.APIMV2.authorize = '/fr/secure/mes-outils/profil';
                this._oidc.APIMV2.client_id = '3539ef4e-edd9-43cc-ba18-42f8e884df7d';
                break;
            case 'hb':
                this._apiserver = '//api-nav.staging.hellobank.fr';
                this._oidc.APIMV2.authorize =
                    '/fr/secure/mon-profil/kyc-informations-personnelles';
                this._oidc.APIMV2.client_id = '8ded094708194a28a3c9ba26ae418522';
                this._api.authorizeclientEvaluation.path =
                    '/as/hellobank/V2.0/authorize';
                this._api.authorizeAPIGEE.path = '/pgg/as-front/v2/hellobank/authorize';
                break;
            case 'hbpro':
                this._apiserver = '//api-nav.staging.hellobank.fr';
                this._oidc.APIMV2.authorize =
                    '/fr/secure/mon-profil/kyc-informations-personnelles';
                this._oidc.APIMV2.client_id = '8ded094708194a28a3c9ba26ae418522';
                this._api.authorizeclientEvaluation.path =
                    '/as/hellobank/V2.0/authorize';
                this._api.authorizeAPIGEE.path = '/pgg/as-front/v2/hellobank/authorize';
                break;
        }
    }
    if (window.ENVIRONNEMENT && ENVIRONNEMENT == 'LOCAL')
        this._apiserver = '/APIM';
    switch (this.env()) {
        case 'part':
        case 'bpf':
            this.consentDashboardSollicitationCommerciale =
                'dashboard_sc_mb_part_web';
            this.consentDashboardEmprunteCarbone = 'dashboard_ec_mb_part_web';
            this.consentDashboardPF = 'parcoursmetier_mp_pf_mb_part_web';
            this.consentDashboardArval = 'parcoursmetier_mp_arval_mb_part_web';
            this.consentFormulairePEA = 'parcoursmetier_fpea_mb_part_web';
            this.consentDashboardCategorisationOperation = 'dashboard_co_mb_part_web';
            break;
        case 'pro':
            this.consentDashboardSollicitationCommerciale = 'dashboard_sc_mb_pro_web';
            break;
        case 'hb':
            this.consentDashboardSollicitationCommerciale =
                'dashboard_sc_hb_part_web';
            this.consentDashboardEmprunteCarbone = 'dashboard_ec_hb_part_web';
            this.consentDashboardCategorisationOperation = 'dashboard_co_hb_part_web';
            break;
        case 'hbpro':
            this.consentDashboardSollicitationCommerciale = 'dashboard_sc_hb_pro_web';
            break;
    }
    if (sessionStorage.APIGEE) {
        try {
            this.APIGEE = JSON.parse(sessionStorage.APIGEE);
        } catch (e) {}
    } else this.APIGEE = {};
    if (sessionStorage.APIM) {
        try {
            this.APIM = JSON.parse(sessionStorage.APIM);
        } catch (e) {}
    } else this.APIM = {};
    if (sessionStorage.APIMEX1) {
        try {
            this.APIMEX1 = JSON.parse(sessionStorage.APIMEX1);
        } catch (e) {}
    } else this.APIMEX1 = {};
    if (sessionStorage.APIMV2) {
        try {
            this.APIMV2 = JSON.parse(sessionStorage.APIMV2);
        } catch (e) {}
    } else this.APIMV2 = {};
    this._sgi;
    try {
        var infoClt = JSON.parse(sessionStorage.info_client);
        var compte = infoClt.data.contrat.comptePrincipal;
        if (!compte) compte = infoClt.data.contrat.comptes[0];
        this._sgi = compte.identifiantSGIRattache;
    } catch (e) {}
    this.parametrage('sgi', this._sgi, true);
    if (Object.keys(this.APIGEE).length)
        this.parametrage('sgi', this._sgi, true, 'APIGEE');
    if (Object.keys(this.APIMEX1).length)
        this.parametrage('sgi', this._sgi, true, 'APIMEX1');
    if (Object.keys(this.APIMV2).length)
        this.parametrage('sgi', this._sgi, true, 'APIMV2');

    var access_token;
    var state = this.readParameter('state', document.location.hash);
    if (state)
        access_token = this.readParameter('access_token', document.location.hash);
    else {
        state = this.readParameter('state', document.location.search);
        if (state)
            access_token = this.readParameter(
                'access_token',
                document.location.search
            );
    }
    if (
        Object.keys(this.APIGEE).length &&
        state == this.state(undefined, 'APIGEE')
    ) {
        if (!access_token)
            access_token = this.readParameter('code', document.location.search);
        if (access_token) this.accesstoken(access_token, 'APIGEE');
        else if (this.readParameter('error', document.location.search))
            this.accesstoken('error', 'APIGEE');
    }
    if (
        Object.keys(this.APIMV2).length &&
        state == this.state(undefined, 'APIMV2')
    ) {
        if (access_token) this.accesstoken(access_token, 'APIMV2');
        else if (this.readParameter('error', document.location.search))
            this.accesstoken('error', 'APIMV2');
    } else if (
        Object.keys(this.APIM).length &&
        state == this.state(undefined, 'APIM')
    ) {
        if (access_token) this.accesstoken(access_token, 'APIM');
        else if (this.readParameter('error', document.location.search))
            this.accesstoken('error', 'APIM');
    }
    this._ieVersion = (function() {
        var rv = false;
        if (navigator.appName == 'Microsoft Internet Explorer') {
            var ua = navigator.userAgent;
            var re = new RegExp('MSIE ([0-9]{1,}[.0-9]{0,})');
            if (re.exec(ua) != null) rv = parseFloat(RegExp.$1);
        } else if (navigator.appName == 'Netscape') {
            var ua = navigator.userAgent;
            var re = new RegExp('Trident/.*rv:([0-9]{1,}[.0-9]{0,})');
            if (re.exec(ua) != null) rv = parseFloat(RegExp.$1);
        }
        return rv;
    })();

    try {
        if (window.GlobalSite && !GlobalSite.getBrowser) {
            GlobalSite.getBrowser = function() {
                var ua = navigator.userAgent,
                    tem,
                    M =
                    ua.match(
                        /(opera|chrome|safari|firefox|msie|trident(?=\/))\/?\s*(\d+)/i
                    ) || [];
                if (/trident/i.test(M[1])) {
                    tem = /\brv[ :]+(\d+)/g.exec(ua) || [];
                    return 'IE ' + (tem[1] || '');
                }
                if (M[1] === 'Chrome') {
                    tem = ua.match(/\bOPR\/(\d+)/);
                    if (tem != null) return 'Opera ' + tem[1];
                }
                M = M[2] ?
                    [M[1], M[2]] :
                    [navigator.appName, navigator.appVersion, '-?'];
                if ((tem = ua.match(/version\/(\d+)/i)) != null) M.splice(1, 1, tem[1]);
                return M.join(' ');
            };
        }
        this._isSafari = /Safari/.test(GlobalSite.getBrowser());
    } catch (e) {}
    this._noIframe = false;
    this._noInitFullPage = false;
    if (this._isSafari && !sessionStorage.noOIDCIframe) this._noIframe = true;
    if (/\/webview\//.test(document.location.pathname)) this._noIframe = true;
    this._noIframe =
        sessionStorage.noOIDCIframe == 'true' ? true : this._noIframe;
    this._noInitFullPage =
        sessionStorage.noOIDCFullPage == 'true' ? true : this._noInitFullPage;

    /*if (sessionStorage.apigee)
          this.apigee = true;
      if (/-qual-we(5|3|1)-ap(5|3|1)./.test(document.location.host))
          this.apigee = true;
      if (!this.apigee && forceApigee)
          this.apigee = true;*/
    this.apigee = true;
    if (sessionStorage.broadcom) this.apigee = false;
    if (forceBroadcom) this.apigee = false;
}
APIM.prototype.env = function() {
    if (/localhost/.test(document.location.hostname))
        return /part/.test(document.body.className) ?
            'part' :
            /hb/.test(document.body.className) ?
            'hb' :
            'pro';
    if (/hellobank-pro-qual1-acqui|hellobankpro/.test(document.location.hostname))
        return 'hbpro-acqui';
    if (/hellobank-pro-|pro\.hellobank/.test(document.location.hostname))
        return 'hbpro';
    if (/canalnet-pro|mabanquepro|pro\./.test(document.location.hostname))
        return 'pro';
    if (/canalnet-bpf|mabanqueprivee|privee\./.test(document.location.hostname))
        return 'bpf';
    if (/hellobank/.test(document.location.hostname)) return 'hb';
    return 'part';
};

APIM.prototype.readParameter = function(key, paramsString) {
    var result = paramsString.match(
        new RegExp('(\\?|\\#|&)' + key + '(\\[\\])?=([^&]*)')
    );

    return result ? decodeURIComponent(result[3]) : undefined;
};
APIM.prototype.parametrage = function(key, value, reset, env) {
    if (!env) env = 'APIM';
    if (value === undefined) return this[env][key];
    else {
        var save = this[env][key] != value;
        this[env][key] = value;
        if (save || key == 'cache') {
            if (reset) {
                for (key in this[env]) {
                    if (key != 'sgi') delete this[env][key];
                }
            }
            sessionStorage[env] = JSON.stringify(this[env]);
        }
    }
};
APIM.prototype.cache = function(name, value) {
    var cache = this.parametrage('cache') || {};
    if (value === undefined) return cache[name];
    else {
        if (value == null) console.log('empty cache');
        if (this.parametrage('nocache')) return;
        cache[name] = value;
        this.parametrage('cache', cache);
    }
};
APIM.prototype.state = function(value, env) {
    if (value === false) this.parametrage('state', null, undefined, env);
    if (value) {
        return this.parametrage('state', undefined, undefined, env) == value;
    } else {
        if (!this.parametrage('state', undefined, undefined, env))
            this.parametrage('state', btoa(this.randomString(21)), undefined, env);
        return this.parametrage('state', undefined, undefined, env);
    }
};
APIM.prototype.redirect = function(value, env) {
    if (value === undefined)
        return this.parametrage('redirect', undefined, undefined, env);
    else {
        this.parametrage('redirect', value, undefined, env);
    }
};

APIM.prototype.nonce = function(value, env) {
    if (value === false) this.parametrage('nonce', null, undefined, env);
    if (value) {
        return this.parametrage('nonce', undefined, undefined, env) == value;
    } else {
        if (!this.parametrage('nonce', undefined, undefined, env))
            this.parametrage('nonce', btoa(this.randomString(21)), undefined, env);
        return this.parametrage('nonce', undefined, undefined, env);
    }
};

APIM.prototype.accesstoken = function(value, env) {
    if (value === undefined) {
        if (
            this.parametrage('access_token', undefined, undefined, env) &&
            this.parametrage('expire', undefined, undefined, env) <
            new Date().getTime() / 1000
        )
            this.parametrage('access_token', null, undefined, env);
        return this.parametrage('access_token', undefined, undefined, env);
    } else {
        this.parametrage('access_token', value, undefined, env);
        this.parametrage(
            'expire',
            new Date().getTime() / 1000 + this._expireToken,
            undefined,
            env
        );
    }
};

APIM.prototype.media = function() {
    switch (this.env()) {
        case 'part':
            return '004';
            break;
        case 'pro':
            return '086';
            break;
        case 'bpf':
            return '078';
            break;
        case 'hb':
            return '082';
            break;
        case 'hbpro':
            return '117';
            break;
    }
};

APIM.prototype.brand = function() {
    switch (this.env()) {
        case 'part':
            return '01';
            break;
        case 'pro':
            return '01';
            break;
        case 'bpf':
            return '01';
            break;
        case 'hb':
            return '02';
            break;
        case 'hbpro':
            return '02';
            break;
    }
};

APIM.prototype.scope = function() {
    switch (this.env()) {
        case 'part':
            return '01';
            break;
        case 'pro':
            return '02';
            break;
        case 'bpf':
            return '01';
            break;
        case 'hb':
            return '01';
            break;
        case 'hbpro':
            return '02';
            break;
    }
};

APIM.prototype.randomString = function(length) {
    var text = '';
    var possible =
        'ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789';
    for (var i = 0; i < length; i++) {
        text += possible.charAt(Math.floor(Math.random() * possible.length));
    }
    return text;
};

APIM.prototype.getUrl = function(api, params, apigee) {
    var url = api.url ?
        api.url :
        apigee ?
        api.pathApigee :
        this._apiserver + api.path;
    if (params) {
        var tmpUrl = url;
        for (var param in params) {
            var tmp = url;
            if (typeof params[param] !== 'object') {
                url = url.replace(param, params[param]);
                if (tmp != url) delete params[param];
            }
        }
        if (tmpUrl == url) {
            var bEt = url.indexOf('?') >= 0;
            for (var param in params) {
                if (typeof params[param] !== 'object') {
                    url += (bEt ? '&' : '?') + param + '=' + params[param];
                    bEt = true;
                }
            }
        }
    }

    return url;
};

APIM.prototype.callapiPromise = function(
    api,
    data,
    auth,
    header,
    env,
    apigee
) {
    env = env || 'APIM';
    var settings = {
        url: this.getUrl(api, api.replaceUrlParam ? data : null, apigee),
        type: api.method
            /*,
                   cache: api.cache || false*/
            ,
    };
    if (data) settings.data = api.stringify ? JSON.stringify(data) : data;
    if (auth && !apigee)
        settings.headers = {
            Authorization: 'Bearer ' +
                (api.wservice === true && this.apigee ?
                    this.accesstoken(undefined, 'APIGEE') :
                    this.accesstoken(undefined, env)),
        };
    if (header) {
        if (!settings.headers) settings.headers = [];
        for (var key in header) settings.headers[key] = header[key];
    }
    settings.dataType = api.type || 'json';
    settings.contentType = 'application/json;charset=UTF-8';

    return $.ajax(settings);
};

APIM.prototype.callapi = function(
    api,
    data,
    auth,
    header,
    callback,
    env,
    apigee
) {
    this.callapiPromise(api, data, auth, header, env, apigee)
        .done(callback)
        .fail(function(jqXHR, textStatus) {
            callback(null, textStatus, jqXHR);
        });
};

APIM.prototype.initAPIM = function(callback, env, service) {
    if (env && !Object.keys(this[env]).length)
        this.parametrage('sgi', this._sgi, true, env);
    var apigee = false;
    if (
        service &&
        (service.pathApigee || service.url) &&
        (this.apigee || service.forceApigee)
    )
        apigee = true;
    if (
        this.accesstoken(undefined, env) ||
        apigee === true ||
        window.ENVIRONNEMENT == 'LOCAL'
    )
        callback(apigee);
    else {
        var _this = this;
        var param = {};
        param.state = _this.state(false, env);
        param.redirect_uri = encodeURI(
            'https://' + document.location.host + _this._api.getAuthorize.url
        );
        param.response_type = 'id_token token';
        param.scope = 'openid';
        param.nonce = _this.nonce(false, env);
        param.prompt = 'none';
        param.client_id = this._oidc.APIM.client_id;

        if ($('#oidc_apim').length > 0) {
            setTimeout(function() {
                if (sessionStorage.APIM) {
                    try {
                        _this.APIM = JSON.parse(sessionStorage.APIM);
                    } catch (e) {}
                } else _this.APIM = {};
                _this.initAPIM(callback, env, service);
            }, 1000);
            return;
        }
        if ($('#oidc_apim').length == 0)
            $('body').append($("<iframe id='oidc_apim' class='hidden'>"));
        $('#oidc_apim').on('load', function() {
            var tokenInteval = JSON.parse(JSON.stringify(_this._oidc.APIM.interval));
            tokenInteval.cpt = 0;
            tokenInteval.token = setInterval(function() {
                tokenInteval.cpt++;
                try {
                    if ($('#oidc_apim')[0].contentWindow.document.location.hash) {
                        clearInterval(tokenInteval.token);
                        var params = $('#oidc_apim')[0]
                            .contentWindow.document.location.hash.substring(1)
                            .split('&');
                        var access_token =
                            'null ' + $('#oidc_apim')[0].contentWindow.document.location;
                        var state;
                        for (var cptI = 0; cptI < params.length; cptI++) {
                            var param = params[cptI].split('=');
                            if (param[0] == 'access_token')
                                access_token = decodeURIComponent(param[1]);
                            if (param[0] == 'state') state = param[1];
                        }
                        if (state == _this.state(undefined, env))
                            _this.accesstoken(access_token, env);
                        $('#oidc_apim').remove();
                        callback(apigee);
                    }
                } catch (e) {}
                if (
                    tokenInteval.cpt * tokenInteval.interval > tokenInteval.max &&
                    tokenInteval.token
                ) {
                    clearInterval(tokenInteval.token);
                    _this.accesstoken('Timeout', env);
                    $('#oidc_apim').remove();
                    callback(apigee);
                }
            }, tokenInteval.interval);
        });
        $('#oidc_apim').attr(
            'src',
            _this.getUrl(_this._api.authorizeBNPAPI, param)
        );
    }
};
APIM.prototype.initFullPage = function(url, env) {
    if (this._noInitFullPage) return;
    if (document.location.hash) return;
    this.parametrage('stop_init', true, false, env);
    setTimeout(function() {
        document.location.href = url;
    }, 100);
};

APIM.prototype.token = function(callback) {
    var _this = this;
    this.initAPIM(function(apigee) {
        callback(_this.accesstoken());
    }, 'APIM');
};

APIM.prototype.initExternalApigee = function(
    callback,
    env,
    service,
    noIframe
) {
    env = env || 'APIGEE';
    if (env && !Object.keys(this[env]).length)
        this.parametrage('sgi', this._sgi, true, env);
    if (window.ENVIRONNEMENT == 'LOCAL') callback(true);
    if (this.accesstoken(undefined, env)) {
        callback(false);
        return;
    }
    var _this = this;
    var param = {};
    param.state = _this.state(false, env);
    param.redirect_uri = encodeURI(
        'https://' + document.location.host + _this._api.getAuthorize.url
    );
    param.response_type = 'code';
    param.scope = 'chatlive';
    param.client_id = this._oidc.APIGEE.client_id;
    param.code_challenge_method = 'S256';

    function digestMessage(message, callback) {
        var msgUint8 = new TextEncoder().encode(message);
        crypto.subtle.digest('SHA-256', msgUint8).then(callback);
    }

    function base64urlencode(a) {
        return btoa(String.fromCharCode.apply(null, new Uint8Array(a)))
            .replace(/\+/g, '-')
            .replace(/\//g, '_')
            .replace(/=+$/, '');
    }
    digestMessage(this.nonce(false, env), function(data) {
        param.code_challenge = base64urlencode(data);
        if ($('#token_apigee').length > 0) $('#token_apigee').remove();

        if ($('#token_apigee').length == 0)
            $('body').append($("<iframe id='token_apigee' class='hidden'>"));
        $('#token_apigee').on('load', function() {
            var tokenInteval = JSON.parse(JSON.stringify(_this._oidc.APIM.interval));
            tokenInteval.cpt = 0;
            tokenInteval.token = setInterval(function() {
                tokenInteval.cpt++;
                try {
                    if ($('#token_apigee')[0].contentWindow.document.location) {
                        clearInterval(tokenInteval.token);
                        var code = _this.readParameter(
                            'code',
                            $('#token_apigee')[0].contentWindow.document.location.search
                        );
                        var state = _this.readParameter(
                            'state',
                            $('#token_apigee')[0].contentWindow.document.location.search
                        );
                        if (state == _this.state(undefined, env))
                            _this.accesstoken(code, env);
                        callback(false);
                    }
                } catch (e) {}
                if (
                    tokenInteval.cpt * tokenInteval.interval > tokenInteval.max &&
                    tokenInteval.token
                ) {
                    clearInterval(tokenInteval.token);
                    $('#token_apigee').remove();
                    if (!_this._noIframe &&
                        !_this.parametrage('stop_init', undefined, false, env)
                    ) {
                        _this.parametrage('stop_init', true, false, env);
                        _this._noIframe = true;
                        _this.initExternalApigee(callback, env, service, true);
                    } else {
                        _this.accesstoken('Timeout', env);
                        callback(false);
                    }
                }
            }, tokenInteval.interval);
        });

        if (
            (_this._noIframe || noIframe) &&
            window.location.host.indexOf('-benc-we') === -1
        ) {
            _this.redirect(document.location.href, env);
            document.location.href = _this.getUrl(_this._api.authorizeAPIGEE, param);
        } else $('#token_apigee').attr('src', _this.getUrl(_this._api.authorizeAPIGEE, param));
    });
};

APIM.prototype.tokenApigee = function(callback) {
    if (!this.accesstoken(undefined, 'APIGEE'))
        this.cache(this._api.tokenAPIGEE.path, null);
    if (this.cache(this._api.tokenAPIGEE.path)) {
        if (callback) callback(this.cache(this._api.tokenAPIGEE.path));
        return;
    }
    if (!this.apigee) {
        if (callback) callback(null);
        return;
    }
    var _this = this;
    this.initExternalApigee(
        function(apigee) {
            var data = {
                grant_type: 'authorization_code',
                redirect_uri: encodeURI(
                    'https://' + document.location.host + _this._api.getAuthorize.url
                ),
                code: _this.accesstoken(undefined, 'APIGEE'),
                client_id: _this._oidc.APIGEE.client_id,
                code_verifier: _this.nonce(undefined, 'APIGEE'),
            };
            _this.callapi(
                _this._api.tokenAPIGEE,
                data,
                false, {
                    'content-Type': 'application/x-www-form-urlencoded'
                },
                function(data) {
                    if (data && data.access_token) data = data.access_token;
                    else data = null;
                    _this.cache(_this._api.tokenAPIGEE.path, data);
                    if (callback) callback(data);
                },
                'APIGEE',
                apigee
            );
        },
        'APIGEE',
        _this._api.tokenAPIGEE
    );
};

APIM.prototype.flagAgregation = function(value, callback) {
    var _this = this;
    this.initAPIM(
        function(apigee) {
            var data = {
                aggregationStatus: value ? 1 : 0
            };
            _this.callapi(
                _this._api.flagAgregation,
                data,
                true, {
                    Media: _this.media()
                },
                function(data, textStatus, jqXHR) {
                    if (callback) callback(_this._ieVersion || jqXHR.status == 200);
                },
                'APIM',
                apigee
            );
        },
        'APIM',
        _this._api.flagAgregation,
        _this._noIframe
    );
};

APIM.prototype.messageBMM = function(data, callback) {
    var _this = this;
    this.initAPIM(
        function(apigee) {
            _this.callapi(
                _this._api.messageBMM,
                data,
                true, {
                    Channel: 'web'
                },
                function(data) {
                    if (callback) callback(data);
                },
                'APIM',
                apigee
            );
        },
        'APIM',
        _this._api.messageBMM,
        _this._noIframe
    );
};

APIM.prototype.cancelElectronicStatements = function(caller, callback) {
    var _this = this;
    this.initAPIM(
        function(apigee) {
            var header = {
                Channel: 'web',
                Caller: caller
            };
            if (apigee) header.Media = _this.media();
            _this.callapi(
                _this._api.cancelElectronicStatements,
                null,
                true,
                header,
                function(data) {
                    if (callback) callback(data);
                },
                'APIM',
                apigee
            );
        },
        'APIM',
        _this._api.cancelElectronicStatements
    );
};

APIM.prototype.getSCC = function(typeDashboard) {
    try {
        typeDashboard = parseInt(typeDashboard);
    } catch (e) {}
    var SCC = this.consentDashboardSollicitationCommerciale;
    switch (typeDashboard) {
        case 2:
            SCC = this.consentDashboardEmprunteCarbone;
            break;
        case 3:
            SCC = this.consentDashboardPF;
            break;
        case 4:
            SCC = this.consentDashboardArval;
            break;
        case 5:
            SCC = this.consentFormulairePEA;
            break;
        case 6:
            SCC = this.consentDashboardCategorisationOperation;
            break;
    }
    return SCC;
};

APIM.prototype.getconsent = function(typeDashboard, callback) {
    var _this = this;
    this.initAPIM(
        function(apigee) {
            var data = {
                SCC: _this.getSCC(typeDashboard),
                brandCode: _this.brand(),
                scopeCode: _this.scope(),
            };
            _this.callapi(
                _this._api.getconsent,
                data,
                true, {
                    Channel: '007',
                    media: _this.media()
                },
                function(data) {
                    if (callback) callback(data);
                },
                'APIM',
                apigee
            );
        },
        'APIM',
        _this._api.getconsent
    );
};

APIM.prototype.setconsent = function(typeDashboard, value, callback) {
    var _this = this;
    this.initAPIM(
        function(apigee) {
            var data = {
                SCC: _this.getSCC(typeDashboard),
                BRANDCODE: _this.brand(),
                SCOPECODE: _this.scope(),
                consentUpdate: value,
                customPayload: {
                    interactionAuthor: 'TestUUID',
                    interactionCanal: '007',
                    interactionMedia: _this.media(),
                    originCommercialResume: '',
                    partnerCode: 'BCEF',
                },
            };
            _this.callapi(
                _this._api.setconsent,
                data,
                true, {
                    Channel: '007',
                    media: _this.media()
                },
                function(data) {
                    if (callback) callback(data);
                },
                'APIM',
                apigee
            );
        },
        'APIM',
        _this._api.setconsent
    );
};
APIM.prototype.bfmauthorizations = function(callback) {
    if (this.cache(this._api.bfmauthorizations.path)) {
        if (callback) callback(this.cache(this._api.bfmauthorizations.path));
        return;
    }
    var _this = this;
    this.initAPIM(
        function(apigee) {
            _this.callapi(
                _this._api.bfmauthorizations,
                null,
                true,
                null,
                function(data) {
                    _this.cache(_this._api.bfmauthorizations.path, data);
                    if (callback) callback(data);
                },
                'APIM',
                apigee
            );
        },
        'APIM',
        _this._api.bfmauthorizations
    );
};

APIM.prototype.bfmenrollment = function(clients, callback) {
    var _this = this;
    var data = {
        bannerStatus: 0,
        incrementNumber: 1,
        enterprises: []
    };
    for (var cptI = 0; cptI < clients.length; cptI++)
        data.enterprises.push({
            idkpi: clients[cptI].ikpi
        });
    this.callapi(
        _this._api.bfmenrollment,
        data,
        true, {
            Media: this.media()
        },
        function(data, textStatus, jqXHR) {
            if (data == null && jqXHR.status) {
                data = {
                    status: jqXHR.status
                };
            }
            if (callback) callback(data);
        },
        'APIM',
        true
    );
};

APIM.prototype.IOGALogin = function(callback) {
    if (this.cache(this._api.IOGALogin.url)) {
        if (callback) callback(this.cache(this._api.IOGALogin.url));
        return;
    }
    var _this = this;

    if (this.apigee) {
        this.resetCacheAPIGEE();
        this.resetCacheAPIM();
        this.initExternalApigee(
            function(apigee) {
                _this._api.IOGALogin.method = 'POST';
                _this._api.IOGALogin.stringify = true;
                var data = {
                    grant_type: 'authorization_code',
                    redirect_uri: encodeURI(
                        'https://' + document.location.host + _this._api.getAuthorize.url
                    ),
                    code: _this.accesstoken(undefined, 'APIGEE'),
                    client_id: _this._oidc.APIGEE.client_id,
                    code_verifier: _this.nonce(undefined, 'APIGEE'),
                };
                _this.callapi(
                    _this._api.IOGALogin,
                    data,
                    true,
                    null,
                    function(data) {
                        _this.cache(_this._api.IOGALogin.url, data);
                        if (callback) callback(data);
                    },
                    'APIM',
                    apigee
                );
            },
            'APIGEE',
            _this._api.tokenAPIGEE
        );
    } else {
        _this._api.IOGALogin.wservice = false;
        this.initAPIM(
            function() {
                _this.callapi(_this._api.IOGALogin, null, true, null, function(data) {
                    _this.cache(_this._api.IOGALogin.url, data);
                    if (callback) callback(data);
                });
            },
            'APIM',
            _this._api.IOGALogin
        );
    }
};

APIM.prototype.IOGAMarques = function(callback) {
    if (this.cache(this._api.IOGAMarques.url)) {
        if (callback) callback(this.cache(this._api.IOGAMarques.url));
        return;
    }
    var _this = this;
    this._api.IOGAMarques.wservice = this.apigee;

    this.initAPIM(
        function(apigee) {
            apigee = false;
            _this.callapi(
                _this._api.IOGAMarques,
                null,
                true,
                null,
                function(data) {
                    try {
                        data = data.filter(function(item) {
                            return item.isActive;
                        });
                        data.sort(function(a, b) {
                            if (a.name.toLowerCase() < b.name.toLowerCase()) return -1;
                            if (a.name.toLowerCase() > b.name.toLowerCase()) return 1;
                            return 0;
                        });
                    } catch (e) {}
                    _this.cache(_this._api.IOGAMarques.url, data);
                    if (callback) callback(data);
                },
                'APIM',
                apigee
            );
        },
        'APIM',
        _this._api.IOGAMarques
    );
};

APIM.prototype.IOGAModeles = function(callback) {
    if (this.cache(this._api.IOGAModeles.url)) {
        if (callback) callback(this.cache(this._api.IOGAModeles.url));
        return;
    }
    var _this = this;
    this._api.IOGAModeles.wservice = this.apigee;
    this.initAPIM(
        function(apigee) {
            apigee = false;
            _this.callapi(
                _this._api.IOGAModeles,
                null,
                true,
                null,
                function(data) {
                    try {
                        data = data.filter(function(item) {
                            return item.isActive;
                        });
                        data.sort(function(a, b) {
                            if (a.label.toLowerCase() < b.label.toLowerCase()) return -1;
                            if (a.label.toLowerCase() > b.label.toLowerCase()) return 1;
                            return 0;
                        });
                    } catch (e) {}
                    _this.cache(_this._api.IOGAModeles.url, data);
                    if (callback) callback(data);
                },
                'APIM',
                apigee
            );
        },
        'APIM',
        _this._api.IOGAModeles
    );
};
APIM.prototype.IOGADisponibilite = function(value, callback) {
    var _this = this;
    this._api.IOGADisponibilite.wservice = this.apigee;
    this.initAPIM(
        function() {
            apigee = false;
            _this.callapi(
                _this._api.IOGADisponibilite, {
                    date: value
                },
                true,
                null,
                function(data) {
                    if (callback) callback(data);
                },
                'APIM',
                apigee
            );
        },
        'APIM',
        _this._api.IOGADisponibilite
    );
};
APIM.prototype.IOGAProjet = function(value, callback) {
    var _this = this;
    this._api.IOGAProjet.wservice = this.apigee;
    this.initAPIM(
        function(apigee) {
            apigee = false;
            _this.callapi(
                _this._api.IOGAProjet,
                value,
                true,
                null,
                function(data) {
                    _this.cache(_this._api.IOGAProjet.path, data);
                    if (callback) callback(data);
                },
                'APIM',
                apigee
            );
        },
        'APIM',
        _this._api.IOGAProjet
    );
};

APIM.prototype.tradingcentral = function(data, callback) {
    var _this = this;
    if (this.apigee) {
        this.resetCacheAPIGEE();
        this.initExternalApigee(
            function(apigee) {
                data = data || {};
                data.grant_type = 'authorization_code';
                data.redirect_uri = encodeURI(
                    'https://' + document.location.host + _this._api.getAuthorize.url
                );
                data.code = _this.accesstoken(undefined, 'APIGEE');
                data.client_id = _this._oidc.APIGEE.client_id;
                data.code_verifier = _this.nonce(undefined, 'APIGEE');

                _this.callapi(
                    _this._api.tradingcentral,
                    data,
                    true,
                    null,
                    function(data) {
                        if (callback) callback(data);
                    },
                    'APIM',
                    apigee
                );
            },
            'APIGEE',
            _this._api.tokenAPIGEE
        );
    } else {
        this.initAPIM(
            function() {
                _this.callapi(
                    _this._api.tradingcentral,
                    data,
                    true,
                    null,
                    function(data) {
                        if (callback) callback(data);
                    }
                );
            },
            'APIM',
            _this._api.IOGALogin
        );
    }
};

APIM.prototype.resetCacheAPIGEE = function() {
    try {
        var tmp = new URL(document.referrer);
        if (this._noIframe && tmp && /authorize.html/.test(tmp.pathname)) return;
    } catch (e) {}
    this.APIGEE = {};
    this.parametrage('sgi', this._sgi, true, 'APIGEE');
};
APIM.prototype.resetCacheAPIM = function() {
    try {
        var tmp = new URL(document.referrer);
        if (this._noIframe && tmp && /authorize.html/.test(tmp.pathname)) return;
    } catch (e) {}
    this.APIM = {};
    this.parametrage('sgi', this._sgi, true, 'APIM');
};

APIM.prototype.ikpitoken = function(ikpi, callback) {
    var _this = this;
    var data = {
        ikpi: ikpi
    };
    if (this.apigee) {
        this.resetCacheAPIGEE();
        this.initExternalApigee(
            function(apigee) {
                data.grant_type = 'authorization_code';
                data.redirect_uri = encodeURI(
                    'https://' + document.location.host + _this._api.getAuthorize.url
                );
                data.code = _this.accesstoken(undefined, 'APIGEE');
                data.client_id = _this._oidc.APIGEE.client_id;
                data.code_verifier = _this.nonce(undefined, 'APIGEE');

                _this.callapi(
                    _this._api.ikpitoken,
                    data,
                    true,
                    null,
                    function(data) {
                        _this.resetCacheAPIGEE();
                        if (callback) callback(data);
                    },
                    'APIM',
                    apigee
                );
            },
            'APIGEE',
            _this._api.tokenAPIGEE
        );
    } else {
        this.initAPIM(
            function() {
                _this.callapi(_this._api.ikpitoken, data, true, null, function(data) {
                    if (callback) callback(data);
                });
            },
            'APIM',
            _this._api.ikpitoken
        );
    }
};

APIM.prototype.emails = function(callback) {
    var _this = this;
    this.initAPIM(
        function(apigee) {
            _this.callapi(
                _this._api.emails,
                'identityType=PE',
                true, {
                    Media: _this.media(),
                    caller: 'MABANQUE'
                },
                function() {
                    if (callback) callback.apply(null, arguments);
                },
                'APIM',
                apigee
            );
        },
        'APIM',
        _this._api.emails,
        _this._noIframe
    );
};
APIM.prototype.email = function(callback) {
    var _this = this;
    this.initAPIM(
        function(apigee) {
            _this.callapi(
                _this._api.email,
                null,
                true, {
                    Media: _this.media(),
                    caller: 'MABANQUE'
                },
                function() {
                    if (callback) callback.apply(null, arguments);
                },
                'APIM',
                apigee
            );
        },
        'APIM',
        _this._api.email,
        _this._noIframe
    );
};
APIM.prototype.emailUpdate = function(email, callback) {
    var _this = this;
    this.initAPIM(
        function(apigee) {
            _this.callapi(
                _this._api.emailUpdate,
                email,
                true, {
                    Media: _this.media(),
                    caller: 'MABANQUE'
                },
                function(data) {
                    if (callback) callback.apply(null, arguments);
                },
                'APIM',
                apigee
            );
        },
        'APIM',
        _this._api.emailUpdate,
        _this._noIframe
    );
};

APIM.prototype.initAPIMV2 = function(callback, env, noIframe) {
    env = env || 'APIMV2';
    if (env && !Object.keys(this[env]).length)
        this.parametrage('sgi', this._sgi, true, env);

    if (this.accesstoken(undefined, env) || window.ENVIRONNEMENT == 'LOCAL')
        callback();
    else {
        if (noIframe && this.parametrage('stop_init', undefined, false, env))
            return;

        var _this = this;
        var param = {
            redirect_uri: encodeURI(
                'https://' + document.location.host + this._oidc[env].authorize
            ),
            state: this.state(false, env),
            response_type: 'token',
            scope: 'retail-banking:*:*',
            client_id: this._oidc[env].client_id,
        };

        if ($('#oidc_apimV2').length > 0) $('#oidc_apimV2').remove();

        if ($('#oidc_apimV2').length == 0)
            $('body').append($("<iframe id='oidc_apimV2' class='hidden'>"));

        $('#oidc_apimV2').on('load', function() {
            var tokenInteval = JSON.parse(JSON.stringify(_this._oidc[env].interval));
            tokenInteval.cpt = 0;
            tokenInteval.token = setInterval(function() {
                tokenInteval.cpt++;
                try {
                    if ($('#oidc_apimV2')[0].contentWindow.document.location.hash) {
                        clearInterval(tokenInteval.token);
                        var params = $('#oidc_apimV2')[0]
                            .contentWindow.document.location.hash.substring(1)
                            .split('&');
                        var access_token;
                        var state;
                        for (var cptI = 0; cptI < params.length; cptI++) {
                            var param = params[cptI].split('=');
                            if (param[0] == 'access_token')
                                access_token = decodeURIComponent(param[1]);
                            if (param[0] == 'state') state = param[1];
                        }
                        if (state == _this.state(undefined, env))
                            _this.accesstoken(access_token, env);
                        callback();
                    }
                } catch (e) {}
                if (
                    tokenInteval.cpt * tokenInteval.interval > tokenInteval.max &&
                    tokenInteval.token
                ) {
                    clearInterval(tokenInteval.token);
                    callback();
                }
            }, tokenInteval.interval);
        });
        if (noIframe)
            _this.initFullPage(
                _this.getUrl(_this._api.authorizeclientEvaluation, param),
                env
            );
        else
            $('#oidc_apimV2').attr(
                'src',
                _this.getUrl(_this._api.authorizeclientEvaluation, param)
            );
    }
};

APIM.prototype.lifeInsurances = function(callback) {
    var _this = this;
    this.initAPIM(
        function(apigee) {
            _this.callapi(
                _this._api.lifeInsurances, {
                    fields: ['lifeInsuranceDatas']
                },
                true, {
                    Media: '004',
                    Channel: '007'
                },
                function(data) {
                    if (callback) callback(data);
                },
                'APIM',
                apigee
            );
        },
        'APIM',
        _this._api.lifeInsurances
    );
};

APIM.prototype.savingAccounts = function(params, callback) {
    var _this = this;
    this.initAPIM(
        function(apigee) {
            _this._api.savingAccounts.path += '/' + params.id;
            _this._api.savingAccounts.pathApigee += '/' + params.id;

            delete params['id'];

            var data = Object.assign({}, params, {
                caller: _this.env() === 'hb' ? 'HELOBANK' : 'MABANQUE',
                brand: _this.env() === 'hb' ? '002' : '001',
                familyNumber: '9',
                familyList: '010203040506070809',
            });
            var header = {
                Media: '004',
                Channel: '007',
                'X-B3-TraceId': 'X-B3-TraceId',
                'X-B3-SpanId': 'X-B3-SpanId',
            };
            _this.callapi(
                _this._api.savingAccounts,
                data,
                true,
                header,
                function(response) {
                    if (callback) callback(response);
                },
                'APIM',
                apigee
            );
        },
        'APIM',
        _this._api.savingAccounts
    );
};

APIM.prototype.clientEvaluation = function(callback) {
    var _this = this;
    this.initAPIM(
        function(apigee) {
            _this.callapi(
                _this._api.clientEvaluation, {
                    returnQuestionnaireInd: 'O',
                    returnSubmittedDocsInd: 'N',
                    restitutionPreconizationsInd: 'O',
                    productId: ' ',
                    actionCode: ' ',
                    questionAskedNumber: 0,
                    requestedQuestionsData: [{
                            questionId: ' ',
                        },
                        {
                            questionId: ' ',
                        },
                    ],
                    requestedObjectivesNumber: 0,
                    requestedObjectiveData: [{
                            objectiveIdToRestor: ' ',
                        },
                        {
                            objectiveIdToRestor: ' ',
                        },
                    ],
                    indicGua: ' ',
                    recoveryKey: ' ',
                },
                true, {
                    Channel: 'web',
                    'Content-Type': 'application/json;charset=UTF-8'
                },
                function(data) {
                    if (callback) callback(data);
                },
                'APIM',
                apigee
            );
        },
        'APIM',
        _this._api.clientEvaluation
    );
};

APIM.prototype.claimBranches = function(data) {
    var _this = this;
    return new Promise(function(resolve, reject) {
        _this.initAPIM(
            function(apigee) {
                _this.callapi(
                    _this._api.claimBranches,
                    data,
                    true, {
                        Media: '004'
                    },
                    function(data) {
                        resolve(data);
                    },
                    'APIM',
                    apigee
                );
            },
            'APIM',
            _this._api.claimBranches
        );
    });
};

APIM.prototype.claimThemes = function(datanotused, customerType) {
    var _this = this;
    var data = {
        customerMarket: customerType
    };
    return new Promise(function(resolve, reject) {
        _this.initAPIM(
            function(apigee) {
                _this.callapi(
                    _this._api.claimThemes,
                    data,
                    true, {
                        Media: '004'
                    },
                    function(data) {
                        resolve(data);
                    },
                    'APIM',
                    apigee
                );
            },
            'APIM',
            _this._api.claimThemes
        );
    });
};

APIM.prototype.claimSubthemes = function(data, customerType) {
    var _this = this;
    data.customerMarket = customerType;
    return new Promise(function(resolve, reject) {
        _this.initAPIM(
            function(apigee) {
                _this.callapi(
                    _this._api.claimSubthemes,
                    data,
                    true, {
                        Media: '004'
                    },
                    function(data) {
                        resolve(data);
                    },
                    'APIM',
                    apigee
                );
            },
            'APIM',
            _this._api.claimSubthemes
        );
    });
};
APIM.prototype.claimCauses = function(data, customerType) {
    var _this = this;
    data.customerMarket = customerType;
    return new Promise(function(resolve, reject) {
        _this.initAPIM(
            function(apigee) {
                _this.callapi(
                    _this._api.claimCauses,
                    data,
                    true, {
                        Media: '004'
                    },
                    function(data) {
                        resolve(data);
                    },
                    'APIM',
                    apigee
                );
            },
            'APIM',
            _this._api.claimCauses
        );
    });
};
APIM.prototype.claims = function(data) {
    var _this = this;
    return new Promise(function(resolve, reject) {
        _this.initAPIM(
            function(apigee) {
                _this.callapi(
                    _this._api.claims,
                    data,
                    true, {
                        Media: '004'
                    },
                    function(data) {
                        resolve(data);
                    },
                    'APIM',
                    apigee
                );
            },
            'APIM',
            _this._api.claims
        );
    });
};

/*APIM.prototype.MSAPI = function(endpoint, callback, data, method){
    data = data || '';
    method = method || 'GET';
    var _this = this;
	this.initAPIM(function(){
        var settings = {
            url: _this._apiserver + "/sm/V1.0/service-models/"+endpoint,
            type: method,
            cache: false
        };
        if (method == 'POST') {
            settings.data = JSON.stringify(data)
        } else {
            settings.url+= data
        }
        settings.headers= {Authorization: "Bearer " + _this.accesstoken(), media : "004"};
        settings.dataType = "json";
        settings.contentType = "application/json;charset=UTF-8";
        $.ajax(settings).always(function(data){
            callback(data);
        });
    })
}

APIM.prototype.msEligibilite = function(callback){ this.MSAPI('msEligibilite', callback) }
APIM.prototype.principal = function(callback){ this.MSAPI('principal', callback) }
APIM.prototype.msDetail = function(callback){ this.MSAPI('msDetail', callback, '?billing=O&member=O&loyalty=O&documents=O') }
APIM.prototype.msAutonomePreparation = function(callback){ this.MSAPI('msAutonomePreparation', callback) }
APIM.prototype.msAutonomeValidation = function(callback, data){ this.MSAPI('msAutonomeValidation', callback, data, 'POST') }
APIM.prototype.proximityAdvisers = function(callback, data){ this.MSAPI('proximityAdvisers', callback, data) }*/

APIM.prototype.msEligibilite = function(callback) {
    var _this = this;
    promise = new Promise(function(resolve, reject) {
        _this.initAPIM(
            function(apigee) {
                _this.callapi(
                    _this._api.msEligibilite,
                    null,
                    true, {
                        Media: '004'
                    },
                    function(data) {
                        resolve(data);
                    },
                    'APIM',
                    apigee
                );
            },
            'APIM',
            _this._api.msEligibilite
        );
    });
    if (callback) promise.then(callback);
    else return promise;
};
APIM.prototype.principal = function(callback) {
    var _this = this;
    promise = new Promise(function(resolve, reject) {
        _this.initAPIM(
            function(apigee) {
                _this.callapi(
                    _this._api.principal,
                    null,
                    true, {
                        Media: '004'
                    },
                    function(data) {
                        resolve(data);
                    },
                    'APIM',
                    apigee
                );
            },
            'APIM',
            _this._api.principal
        );
    });
    if (callback) promise.then(callback);
    else return promise;
};
APIM.prototype.msDetail = function(callback) {
    var _this = this;
    promise = new Promise(function(resolve, reject) {
        _this.initAPIM(
            function(apigee) {
                _this.callapi(
                    _this._api.msDetail, {
                        billing: 'O',
                        member: 'O',
                        loyalty: 'O',
                        documents: 'O'
                    },
                    true, {
                        Media: '004'
                    },
                    function(data) {
                        resolve(data);
                    },
                    'APIM',
                    apigee
                );
            },
            'APIM',
            _this._api.principal
        );
    });
    if (callback) promise.then(callback);
    else return promise;
};
APIM.prototype.msAutonomePreparation = function(callback) {
    var _this = this;
    promise = new Promise(function(resolve, reject) {
        _this.initAPIM(
            function(apigee) {
                _this.callapi(
                    _this._api.msAutonomePreparation,
                    null,
                    true, {
                        Media: '004'
                    },
                    function(data) {
                        resolve(data);
                    },
                    'APIM',
                    apigee
                );
            },
            'APIM',
            _this._api.principal
        );
    });
    if (callback) promise.then(callback);
    else return promise;
};
APIM.prototype.msAutonomeValidation = function(callback, data) {
    var _this = this;
    promise = new Promise(function(resolve, reject) {
        _this.initAPIM(
            function(apigee) {
                _this.callapi(
                    _this._api.msAutonomeValidation,
                    data,
                    true, {
                        Media: '004'
                    },
                    function(data) {
                        resolve(data);
                    },
                    'APIM',
                    apigee
                );
            },
            'APIM',
            _this._api.principal
        );
    });
    if (callback) promise.then(callback);
    else return promise;
};

APIM.prototype.proximityAdvisers = function(callback, data) {
    var _this = this;
    if ((typeof data === 'string' || data instanceof String) && data[0] == '?')
        data = data.substring(1);
    promise = new Promise(function(resolve, reject) {
        _this.initAPIM(
            function(apigee) {
                _this.callapi(
                    _this._api.proximityAdvisers,
                    data,
                    true, {
                        Media: '004'
                    },
                    function(data) {
                        resolve(data);
                    },
                    'APIM',
                    apigee
                );
            },
            'APIM',
            _this._api.proximityAdvisers
        );
    });
    if (callback) promise.then(callback);
    else return promise;
};

APIM.prototype.vcdContrats = function(productCode, serviceCode, callback) {
    var _this = this;
    promise = new Promise(function(resolve, reject) {
        _this.initAPIM(
            function(apigee) {
                _this.callapi(
                    _this._api.vcdContrats, {
                        productCode: productCode,
                        serviceCode: serviceCode
                    },
                    true, {
                        Media: _this.media()
                    },
                    function(data) {
                        resolve(data);
                    },
                    'APIM',
                    apigee
                );
            },
            'APIM',
            _this._api.vcdContrats
        );
    });
    if (callback) promise.then(callback);
    else return promise;
};

APIM.prototype.vcdContratsDetail = function(ID, callback) {
    var _this = this;
    promise = new Promise(function(resolve, reject) {
        _this.initAPIM(
            function(apigee) {
                _this.callapi(
                    _this._api.vcdContratsDetail, {
                        IDCONTRAT: ID
                    },
                    true, {
                        Media: _this.media()
                    },
                    function(data) {
                        resolve(data);
                    },
                    'APIM',
                    apigee
                );
            },
            'APIM',
            _this._api.vcdContratsDetail
        );
    });
    if (callback) promise.then(callback);
    else return promise;
};

APIM.prototype.getTimeSlotsConnected = function(
    queryParam,
    campaignId,
    callback
) {
    var _this = this;
    var conf = _this._api.getTimeSlotsConnected;

    var promise = new Promise(function(resolve) {
        _this.initAPIM(
            function(apigee) {
                var searchParam = new URLSearchParams(queryParam || {});

                conf.pathApigee += `${campaignId}/timeslots?${searchParam}`;

                _this.callapi(
                    conf,
                    undefined,
                    conf.auth, {
                        Media: _this.media()
                    },
                    function(response) {
                        resolve(response);
                    },
                    'APIM',
                    apigee
                );
            },
            'APIM',
            conf
        );
    });

    if (callback) {
        promise.then(callback);
    } else {
        return promise;
    }
};

APIM.prototype.setAppointementConnected = function(requestBody, callback) {
    var _this = this;
    var conf = _this._api.setAppointementConnected;
    var promise = new Promise(function(resolve) {
        _this.initAPIM(
            function(apigee) {
                _this.callapi(
                    conf,
                    requestBody,
                    conf.auth, {
                        Media: _this.media()
                    },
                    function(response) {
                        resolve(response);
                    },
                    'APIM',
                    apigee
                );
            },
            'APIM',
            conf
        );
    });

    if (callback) {
        promise.then(callback);
    } else {
        return promise;
    }
};

APIM.prototype.getTimeSlots = function(queryParam, campaignId, callback) {
    var _this = this;
    var conf = _this._api.getTimeSlots;
    var promise = new Promise(function(resolve) {
        _this.initAPIM(
            function(apigee) {
                var searchParam = new URLSearchParams(queryParam || {});

                conf.pathApigee += `${campaignId}/timeslots?${searchParam}`;

                _this.callapi(
                    conf,
                    undefined,
                    conf.auth, {
                        Media: _this.media()
                    },
                    function(response) {
                        resolve(response);
                    },
                    'APIM',
                    apigee
                );
            },
            'APIM',
            conf
        );
    });

    if (callback) {
        promise.then(callback);
    } else {
        return promise;
    }
};

APIM.prototype.setAppointement = function(requestBody, callback) {
    var _this = this;
    var conf = _this._api.setAppointement;
    var promise = new Promise(function(resolve) {
        _this.initAPIM(
            function(apigee) {
                _this.callapi(
                    conf,
                    requestBody,
                    conf.auth, {
                        Media: _this.media()
                    },
                    function(response) {
                        resolve(response);
                    },
                    'APIM',
                    apigee
                );
            },
            'APIM',
            conf
        );
    });

    if (callback) {
        promise.then(callback);
    } else {
        return promise;
    }
};

APIM.prototype.questionnairesDisplayEligibility = function(data, callback) {
    var _this = this;
    this.initAPIM(
        function(apigee) {
            _this.callapi(
                _this._api.questionnairesDisplayEligibility,
                data,
                true, {
                    Media: _this.media()
                },
                function(data, textStatus, jqXHR) {
                    callback(data);
                },
                'APIM',
                apigee
            );
        },
        'APIM',
        _this._api.questionnairesDisplayEligibility,
        _this._noIframe
    );
};

APIM.prototype.questionnairesSave = function(data, callback) {
    var _this = this;
    this.initAPIM(
        function(apigee) {
            _this.callapi(
                _this._api.questionnairesSave,
                data,
                true, {
                    Media: _this.media()
                },
                function(data, textStatus, jqXHR) {
                    callback(data);
                },
                'APIM',
                apigee
            );
        },
        'APIM',
        _this._api.questionnairesSave,
        _this._noIframe
    );
};

APIM.prototype.questionnairesPause = function(data, callback) {
    var _this = this;
    this.initAPIM(
        function(apigee) {
            _this.callapi(
                _this._api.questionnairesPause,
                data,
                true, {
                    Media: _this.media()
                },
                function(data, textStatus, jqXHR) {
                    callback(data);
                },
                'APIM',
                apigee
            );
        },
        'APIM',
        _this._api.questionnairesPause,
        _this._noIframe
    );
};
function loadChat(cb) {
    $.get("/rsc/contrib/script/simulateur/pointDeContact/html/loader.html", function(res) {
        $("body").append(res);
        cb();
    });
}

var btn = '<div class="content-bt-chat init-chat"><div class="bouton-chat-s"><div class="bloc-text"><p>Chatter</p></div><div class="bloc-bulle"><span class="icon icon-bulle"></span></div></div></div>';

function initContact(item, Obj) {
    if (!$('[data-target="#modalContact"]').length) $('[data-target="#modalContact"]').addClass('iadvize-launcher')
    if ($("#secret-nbr-keyboard")[0] || /(100-connexions|mot-de-passe-expire|authentification-forte-anr-maj|authentification-forte-anr|authentification-forte)(|\/)$/gim.test(location.pathname)) return;

    if (!window.MyObjContact) window.MyObjContact = new Contact();

    if (MyObjContact.Step() > 0) {
        var nameBtnChatbot = MyObjContact.parametrage('nameBtnChatbot') + ', .content-bt-chat'
        $(nameBtnChatbot).hide()
    }

    if (/(chat-externe)/gi.test(location.href)) {
        MyObjContact.Step(2);
        MyObjContact.init();
    }

    MyObjContact.init()
}
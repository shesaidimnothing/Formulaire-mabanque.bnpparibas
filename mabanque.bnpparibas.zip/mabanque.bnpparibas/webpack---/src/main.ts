import Vue from "vue";
import BannerContainer from "@/BannerContainer.vue";
import { MainEvent } from "@/classes/MainEvent";
import { gabs } from "./config/exclusionList";
import "@/styles/main.scss";

const getPlacement =  ( selecteur:string ) => {
  return new Promise ((resolve, reject ) =>{
    let waitForPlacement = setInterval(()=>{
      let placement = (window as any).dcrm.GetAnyElement(`${selecteur}`);
      if ( !!placement ){
        clearInterval( waitForPlacement );
        resolve( placement );
      }
    })
  })
}

var logDebug = ( string:any ) => console.log(`%c DCRM `,'color: #fff; font-weight: bold; background: #08b; border-radius:3px', string);
Vue.config.productionTip = false;
function bannerLauncher(payload) {
  const banner = new MainEvent(payload);
  getPlacement(`#${banner.placement.id}`)
    .then(( placement:any )=>{
      let attributesTab = [];
      ( placement.getAttributeNames() ).forEach( (attrName:string) => { attributesTab.push( { [attrName] : placement.getAttribute(attrName)}) } )
      new Vue({
        render: (createElement) =>
          createElement(BannerContainer, { props: { banner, oldAttribute:attributesTab } })
      }).$mount(placement);
    })
}

const emplacements = ["rebond", "animation", "popin", "sticky", "confirmation-virement"];
emplacements.forEach((emplacement) => {
  const eventName = emplacement === "confirmation-virement" ? `rtim-banner:${emplacement}` : `rtim-banner:udc-banner-${emplacement}`;
  window.addEventListener(
    eventName,
    (event: any) => {
      const params = event.detail;
      logDebug(`Event pushed on banner-${emplacement}`);
      // Only if not from exclusion list
      const isABTest = params.content.hasOwnProperty("ab_test");
      if (!gabs.includes(params.content.nom_gabarit) && !isABTest) {
        bannerLauncher(params);
      }
      if (!!gabs.includes(params.content.nom_gabarit)) {
        logDebug(`le Gabarit ${params.content.nom_gabarit} fourni est décomissioné, la bannière ne s\'affichera pas`);
      }
    },
    false
  );
});

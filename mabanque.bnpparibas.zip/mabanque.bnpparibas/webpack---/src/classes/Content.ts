import { Payload } from "@/interfaces/Payload";
import isNull from "lodash/isNull";
import isUndefined from "lodash/isUndefined";
import kebabCase from "lodash/kebabCase";
import { oc } from "ts-optchain";

function setValue(value: string) {
  return !isUndefined(value) ? value : null;
}

export class Content {
  public location: string;
  public template: string;
  public messageId: string | boolean;
  public htmlText: string | boolean;
  public description: string;
  public teaser: string;
  public icon: string | boolean;
  public imgBanner: string | boolean;
  public imgBannerAlt: string | boolean;
  public category: string | boolean;
  public contentRefWeb: string | boolean;
  public cross: string | boolean;
  public textWarning: string | boolean;
  public messageWeight: string | boolean;
  public mPOKA60Month: string | boolean;
  public text: string | boolean;
  public timer: string | boolean;
  public templatePopin: string | boolean;
  public assetPopin: string | boolean;
  public teaserPopin: string | boolean;
  public titlePopin: string | boolean;
  public descriptionPopin: string | boolean;
  public textOption01: string | boolean;
  public textOption02: string | boolean;
  public textOption03: string | boolean;
  public textOption04: string | boolean;
  public textOption05: string | boolean;
  public ctaTextPopin: string | boolean;
  public ctaText2Popin: string | boolean;
  public textRDV: string | boolean;
  public webCallbackType: string | boolean;
  public dynamic1: string | boolean;
  public dynamic2: string | boolean;
  public dynamic3: string | boolean;
  public dynamic4: string | boolean;
  public dynamic5: string | boolean;
  public dynamic6: string | boolean;
  public dynamic7: string | boolean;
  public dynamic8: string | boolean;
  public dynamic9: string | boolean;
  public cta1Reponse: string | boolean;
  public cta1Text: string | boolean;
  public cta1URL: string | boolean;
  public cta1Webcallback: string | boolean;
  public cta1Target: string | boolean;
  public cta1KeepBanner: string | boolean;
  public cta1AriaLabel: string | boolean;
  public cta2Text: string | boolean;
  public cta2URL: string | boolean;
  public cta2Webcallback: string | boolean;
  public cta2Reponse: string | boolean;
  public cta2Target: string | boolean;
  public cta2KeepBanner: string | boolean;
  public cta2AriaLabel: string | boolean;
  public clickableBanner: string | boolean;
  public crossAnswer: string | boolean;
  public policyText: string | boolean;
  public imgBackground: string | boolean;
  public celebrusAssetsPath: string;
  public bannerSize: string | boolean;
  public abTest: string | boolean;

  private _payload: Payload;

  constructor(payload: Payload) {
    this._payload = payload;

    this.location = oc(payload).content.emplacement();
    this.template = oc(payload).content.nom_gabarit();
    this.messageId = oc(payload).content.message_id();
    // Main content
    this.htmlText = oc(payload).content.texte_titre(false);
    this.description = oc(payload).content.texte_description();
    this.teaser = oc(payload).content.texte_accroche();
    this.icon = oc(payload).content.picto_banner(false);
    this.imgBanner = oc(payload).content.img_banner(false);
    this.imgBannerAlt = oc(payload).content.img_banner_alt(false);
    this.category = oc(payload).content.univers_campagne(false);
    this.contentRefWeb = oc(payload).content.content_ref_web(false);

    this.cross = oc(payload).content.croix_presence(false);
    this.crossAnswer = oc(payload).content.croix_reponse(false);

    this.textWarning = oc(payload).content.texte_avertissement(false);

    // Alternative content options
    this.messageWeight = oc(payload).content.messageweight(false);

    this.mPOKA60Month = oc(payload).content.m_poka_60mois(false);

    this.text = oc(payload).content.text(false);

    this.timer = oc(payload).content.timer(false);
    this.templatePopin = oc(payload).content.nom_gabarit_popin(false);
    this.assetPopin = oc(payload).content.picto_popin(false);
    this.teaserPopin = oc(payload).content.texte_accroche_popin(false);
    this.titlePopin = oc(payload).content.texte_titre_popin(false);
    this.descriptionPopin = oc(payload).content.texte_description_popin(false);
    this.cta1Text = oc(payload).content.cta_1_texte(false);
    this.cta1URL = oc(payload).content.cta_1_url(false);
    this.cta1Webcallback = oc(payload).content.cta_1_webcallback(false);
    this.cta1Reponse = oc(payload).content.cta_1_reponse(false);
    this.cta1Target = oc(payload).content.cta_1_target(false);
    this.cta1KeepBanner = oc(payload).content.cta_1_keep_banner(false);
    this.cta1AriaLabel = oc(payload).content.cta_1_aria_label(false);
    this.cta2Text = oc(payload).content.cta_2_texte(false);
    this.cta2URL = oc(payload).content.cta_2_url(false);
    this.cta2Webcallback = oc(payload).content.cta_2_webcallback(false);
    this.cta2Reponse = oc(payload).content.cta_2_reponse(false);
    this.cta2Target = oc(payload).content.cta_2_target(false);
    this.cta2KeepBanner = oc(payload).content.cta_2_keep_banner(false);
    this.cta2AriaLabel = oc(payload).content.cta_2_aria_label(false);
    this.clickableBanner = oc(payload).content.clickable_banner(false);
    this.dynamic1 = oc(payload).content.dynamic1(false);
    this.dynamic2 = oc(payload).content.dynamic2(false);
    this.dynamic3 = oc(payload).content.dynamic3(false);
    this.dynamic4 = oc(payload).content.dynamic4(false);
    this.dynamic5 = oc(payload).content.dynamic5(false);
    this.dynamic6 = oc(payload).content.dynamic6(false);
    this.dynamic7 = oc(payload).content.dynamic7(false);
    this.dynamic8 = oc(payload).content.dynamic8(false);
    this.dynamic9 = oc(payload).content.dynamic9(false);
    this.policyText = oc(this._payload).content.texte_mentions_legales(false);
    this.imgBackground = oc(payload).content.img_background(false);
    this.bannerSize = oc(payload).content.banner_size(false);
    this.abTest = oc(payload).content.AB_test(false);
  }

  public get mainClass(): string {
    return !isNull(this.template) ? kebabCase(this.template) : null;
  }

  public get isCross(): string | boolean {
    const isTrueSet = this.cross === "true";
    return isTrueSet;
  }

   // compatibility  aem/offline
   public get celebrusAssetsPathFinder(): string {
    if ((window as any).celebrusPath === "/rsc/contrib/script/aem/celebrus/") {
      this.celebrusAssetsPath = "/content/dam/mabanque/rsc/contrib/image/celebrus/";
    } else if ((window as any).celebrusPath === "/local/") {
      this.celebrusAssetsPath = "./forLocal/img/";
    }
    return this.celebrusAssetsPath;
  }

}

import { Placement } from "@/interfaces/Placement";
import { CelebrusHelper } from "@/interfaces/CelebrusHelper";
import { Content } from "./Content";
import { Payload } from "@/interfaces/Payload";

export class MainEvent extends Content {
  public placement: Placement;
  public celebrusHelper: CelebrusHelper;
  constructor(payload: Payload) {
    super(payload);
    this.placement = payload.placement;
    this.celebrusHelper = payload.celebrusHelper;
  }
}

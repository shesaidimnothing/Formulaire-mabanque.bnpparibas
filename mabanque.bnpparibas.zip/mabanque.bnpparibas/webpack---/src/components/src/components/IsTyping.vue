<template>
    <div class="isTyping">
        <div class="chargement">
            <div class="load-wrapp">
                <div class="load">
                    <div class="line"></div>
                    <div class="line"></div>
                    <div class="line"></div>
                </div>
            </div>
        </div>
    </div>
</template>

<style>
    .chargement {
        content: "";
        display: block;
        clear: both;
    }
    .popin_chatbot .isTyping .load-wrapp {
        float: right;
    }
    .popin_chatbot .chargement {
        position: absolute;
        bottom: 55px;
        left: 15px;
    }
    .popin_chatbot .chargement,
    .load-3 {
        height: 10px;
    }
    .popin_chatbot .line {
        background-color: rgb(223, 223, 223);
        width: 10px;
        height: 10px;
    }
    .popin_chatbot .load .line {
        float: left;
        margin: 0 3px;
        border-radius: 50%;
    }
    .popin_chatbot .load .line:nth-last-child(1) {
        animation: bounceAnim 0.8s 0.3s linear infinite;
    }
    .popin_chatbot .load .line:nth-last-child(2) {
        animation: bounceAnim 0.8s 0.2s linear infinite;
    }
    .popin_chatbot .load .line:nth-last-child(3) {
        animation: bounceAnim 0.8s 0.1s linear infinite;
    }
    @keyframes bounceAnim {
        0% {
            transform: scale(0.5);
        }
        50% {
            transform: scale(1);
        }
        100% {
            transform: scale(0.5);
        }
    }

</style>

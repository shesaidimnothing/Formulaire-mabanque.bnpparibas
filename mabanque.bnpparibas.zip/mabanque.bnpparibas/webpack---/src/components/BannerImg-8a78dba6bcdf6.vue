
import { Component, Prop, Vue } from "vue-property-decorator";

@Component
export default class BannerImg extends Vue {
  @Prop() private banner!: any;

  get assetUrl() {
    const url =
      this.banner.celebrusAssetsPathFinder || "";

    return url;
  }

  private getImageBannerAlt() {
    if (this.banner.imgBannerAlt) {
      return  this.banner.imgBannerAlt;
    } else {
      return "";
    }
  }
}

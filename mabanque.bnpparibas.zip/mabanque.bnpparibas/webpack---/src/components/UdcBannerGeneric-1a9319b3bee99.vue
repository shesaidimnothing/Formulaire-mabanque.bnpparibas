
import { Component, Prop, Vue } from "vue-property-decorator";

import BannerIcon from "./BannerIcon.vue";
import BannerIcon2 from "./BannerIcon2.vue";
import BannerImg from "./BannerImg.vue";
import BannerHtmlText from "./BannerHtmlText.vue";
import BannerContent from "./BannerContent.vue";
import BannerButton from "./BannerButton.vue";
import BannerPolicy from "./BannerPolicy.vue";
import BannerDsp2Kyc from "./BannerDsp2Kyc.vue";
import BannerEmpty from "./BannerEmpty.vue";
import isString from "lodash/isString";
import templates from "../templates/templates";

@Component({
  name: `banner.location`,
  components: {
    BannerIcon,
    BannerIcon2,
    BannerImg,
    BannerHtmlText,
    BannerContent,
    BannerButton,
    BannerPolicy,
    BannerEmpty,
    BannerDsp2Kyc
  }
})
export default class UdcBannerGeneric extends Vue {
  @Prop() private banner!: any;

  get structure(): object {
    // Select template structure matching with templates.json
    return templates[this.banner.template];
  }
  public render(ce) {
    const a = this.drawTemplate(this.structure);

    return Vue.compile(a).render.call(this, ce);
  }
  private drawTemplate(obj) {
    obj = obj || this.structure;
    if (isString(obj.comp)) {
      return "<" + obj.comp + " :banner='banner'></" + obj.comp + ">";
    } else {
      return (
        "<div class='" + obj.class + "'>" + this.drawArray(obj.comp) + "</div>"
      );
    }
  }
  private drawArray(tableauElements) {
    let ret = "";
    tableauElements.forEach((element) => {
      ret += this.drawTemplate(element);
    });
    return ret;
  }
  private async onCloseClick() {
    window.dispatchEvent(
      new CustomEvent(`rtim-banner:${this.banner.location}`, {
        detail: {
          content: {},
          placement: {
            id: this.banner.location,
            size: "1260x630",
            zone: "udc-top"
          }
        }
      })
    );
    this.banner.celebrusHelper.refused();
  }
}



import { Component, Prop, Vue } from "vue-property-decorator";
import VModal from "vue-js-modal";

import UdcBannerGeneric from "@/components/UdcBannerGeneric.vue";
import methodList from "@/config/Common";

Vue.use(VModal);

@Component({
  name: "udc-banner-popin",
  components: {
    UdcBannerGeneric
  }
})
export default class UdcBannerPopin extends Vue {
  @Prop() private banner!: any;
  public methodList = methodList;
  public data() {
    return {
      popinHeight: "auto"
    };
  }

  public mounted() {
    this.$modal.show("generic-popin");
  }

  private getImgBanner() {
    return this.banner.imgBanner;
  }
}

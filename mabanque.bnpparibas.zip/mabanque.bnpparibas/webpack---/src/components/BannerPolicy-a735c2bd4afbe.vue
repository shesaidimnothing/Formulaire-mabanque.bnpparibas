var render = function render(){var _vm=this,_c=_vm._self._c,_setup=_vm._self._setupProxy;return (_vm.banner.policyText)?_c('div',{staticClass:"policy__container",domProps:{"innerHTML":_vm._s(_vm.banner.policyText)}}):_vm._e()
}
var staticRenderFns = []

export { render, staticRenderFns }
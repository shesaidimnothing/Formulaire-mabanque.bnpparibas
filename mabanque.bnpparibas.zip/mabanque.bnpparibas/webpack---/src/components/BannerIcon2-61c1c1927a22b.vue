
import { Component, Prop, Vue } from "vue-property-decorator";

@Component
export default class BannerIcon2 extends Vue {
  @Prop() private banner!: any;
}

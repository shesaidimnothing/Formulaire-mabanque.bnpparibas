
import { Component, Prop, Vue } from "vue-property-decorator";

@Component
export default class BannerDsp2Kyc extends Vue {
  @Prop() private banner!: any;

  public mounted() {
    const wind = window as any;
    if (wind.GlobalSite && wind.GlobalSite.KycSollicitationHelper) {
      wind.GlobalSite.KycSollicitationHelper.init(true);
    }
    if (wind.testKYCService) {
      wind.testKYCService(true);
    }
  }
}

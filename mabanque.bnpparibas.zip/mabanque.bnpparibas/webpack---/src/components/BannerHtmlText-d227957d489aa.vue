
import { Component, Prop, Vue } from "vue-property-decorator";

@Component
export default class BannerHtmlText extends Vue {
  @Prop() public banner!: any;
  public htmlText: string = this.banner.htmlText;
  public dynamic1: string = this.banner.dynamic1;
  public dynamic2: string = this.banner.dynamic2;
  public dynamic3: string = this.banner.dynamic3;
  public dynamic4: string = this.banner.dynamic4;
  public dynamic5: string = this.banner.dynamic5;
  public dynamic6: string = this.banner.dynamic6;
  public dynamic7: string = this.banner.dynamic7;
  public dynamic8: string = this.banner.dynamic8;
  public dynamic9: string = this.banner.dynamic9;
  public mPOKA60Month: string;

  get treatedhtmlText() {
    const mPOKA60Month = this.banner.mPOKA60Month;
    this.htmlText = this.htmlText.replace(/%(m_poka_60mois)%/, mPOKA60Month);
    return this.htmlText.replace(/%(dynamic[0-9])%/gi, (full, group) => {
      return (group = this[group]);
    });
  }
}

import { render, staticRenderFns } from "./BannerContainer.vue?vue&type=template&id=b98c0ad8&lang=pug&"
import script from "./BannerContainer.vue?vue&type=script&lang=ts&"
export * from "./BannerContainer.vue?vue&type=script&lang=ts&"


/* normalize component */
import normalizer from "!../node_modules/vue-loader/lib/runtime/componentNormalizer.js"
var component = normalizer(
  script,
  render,
  staticRenderFns,
  false,
  null,
  null,
  null
  
)

export default component.exports
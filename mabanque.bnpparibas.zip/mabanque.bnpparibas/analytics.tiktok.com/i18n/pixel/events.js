window[window["TiktokAnalyticsObject"]]._env = {
    "env": "external",
    "key": ""
};
window[window["TiktokAnalyticsObject"]]._variation_id = 'test_2_single_track';
window[window["TiktokAnalyticsObject"]]._cc = 'FR';;
if (!window[window["TiktokAnalyticsObject"]]._server_unique_id) window[window["TiktokAnalyticsObject"]]._server_unique_id = '783405dd-2409-11ef-930e-1070fd68b908';
window[window["TiktokAnalyticsObject"]]._plugins = {
    "AdvancedMatching": true,
    "AutoAdvancedMatching": true,
    "AutoConfig": true,
    "Callback": true,
    "DiagnosticsConsole": true,
    "EnrichIpv6": true,
    "EventBuilder": true,
    "Identify": true,
    "Monitor": false,
    "PageData": false,
    "PangleCookieMatching": true,
    "PerformanceInteraction": false,
    "Shopify": true,
    "WebFL": false
};
window[window["TiktokAnalyticsObject"]]._auto_config = {
    "open_graph": ["audience"],
    "microdata": ["audience"],
    "json_ld": ["audience"],
    "meta": null
};
var SIGNAL_TYPE;
! function(i) {
    i[i.OFFSITE = 0] = "OFFSITE", i[i.ONSITE = 1] = "ONSITE"
}(SIGNAL_TYPE = SIGNAL_TYPE || {}),
function() {
    var n = [{
            id: "MTRiM2JhOTViMA",
            map: {
                AutoAdvancedMatching: !1,
                Shopify: !1,
                Monitor: !1,
                CompetitorInsight: !1
            }
        }, {
            id: "MTRiM2JhOTViMQ",
            map: {
                AutoAdvancedMatching: !0,
                Shopify: !1,
                Monitor: !1,
                CompetitorInsight: !1
            }
        }, {
            id: "MTRiM2JhOTViMg",
            map: {
                AutoAdvancedMatching: !1,
                Shopify: !0,
                Monitor: !1,
                CompetitorInsight: !1
            }
        }, {
            id: "MTRiM2JhOTViMw",
            map: {
                AutoAdvancedMatching: !0,
                Shopify: !0,
                Monitor: !1,
                CompetitorInsight: !1
            }
        }, {
            id: "MTRiM2JhOTViNA",
            map: {
                AutoAdvancedMatching: !1,
                Shopify: !1,
                Monitor: !0,
                CompetitorInsight: !1
            }
        }, {
            id: "MTRiM2JhOTViNQ",
            map: {
                AutoAdvancedMatching: !0,
                Shopify: !1,
                Monitor: !0,
                CompetitorInsight: !1
            }
        }, {
            id: "MTRiM2JhOTViNg",
            map: {
                AutoAdvancedMatching: !1,
                Shopify: !0,
                Monitor: !0,
                CompetitorInsight: !1
            }
        }, {
            id: "MTRiM2JhOTViNw",
            map: {
                AutoAdvancedMatching: !0,
                Shopify: !0,
                Monitor: !0,
                CompetitorInsight: !1
            }
        }, {
            id: "MTRiM2JhOTViOA",
            map: {
                AutoAdvancedMatching: !1,
                Shopify: !1,
                Monitor: !1,
                CompetitorInsight: !0
            }
        }, {
            id: "MTRiM2JhOTViOQ",
            map: {
                AutoAdvancedMatching: !0,
                Shopify: !1,
                Monitor: !1,
                CompetitorInsight: !0
            }
        }, {
            id: "MTRiM2JhOTViMTA",
            map: {
                AutoAdvancedMatching: !1,
                Shopify: !0,
                Monitor: !1,
                CompetitorInsight: !0
            }
        }, {
            id: "MTRiM2JhOTViMTE",
            map: {
                AutoAdvancedMatching: !0,
                Shopify: !0,
                Monitor: !1,
                CompetitorInsight: !0
            }
        }, {
            id: "MTRiM2JhOTViMTI",
            map: {
                AutoAdvancedMatching: !1,
                Shopify: !1,
                Monitor: !0,
                CompetitorInsight: !0
            }
        }, {
            id: "MTRiM2JhOTViMTM",
            map: {
                AutoAdvancedMatching: !0,
                Shopify: !1,
                Monitor: !0,
                CompetitorInsight: !0
            }
        }, {
            id: "MTRiM2JhOTViMTQ",
            map: {
                AutoAdvancedMatching: !1,
                Shopify: !0,
                Monitor: !0,
                CompetitorInsight: !0
            }
        }, {
            id: "MTRiM2JhOTViMTU",
            map: {
                AutoAdvancedMatching: !0,
                Shopify: !0,
                Monitor: !0,
                CompetitorInsight: !0
            }
        }],
        i = {
            "info": {
                "pixelCode": "CKNQS8BC77UC0DSE7RLG",
                "name": "Pixel BNP - JFFR",
                "status": 0,
                "setupMode": 0,
                "partner": "",
                "advertiserID": "7272771539752386561",
                "is_onsite": false,
                "firstPartyCookieEnabled": true
            },
            "plugins": {
                "Shopify": false,
                "AdvancedMatching": {
                    "email": true,
                    "phone_number": true,
                    "first_name": true,
                    "last_name": true,
                    "city": true,
                    "state": true,
                    "country": true,
                    "zip_code": true
                },
                "AutoAdvancedMatching": null,
                "Callback": true,
                "Identify": true,
                "Monitor": true,
                "PerformanceInteraction": true,
                "WebFL": true,
                "AutoConfig": null,
                "DiagnosticsConsole": true,
                "PangleCookieMatching": false,
                "CompetitorInsight": true,
                "EventBuilder": true,
                "EnrichIpv6": true
            },
            "rules": []
        },
        t = "https://analytics.tiktok.com/i18n/pixel/static/";

    function o() {
        return window && window.TiktokAnalyticsObject || "ttq"
    }

    function e() {
        return window && window[o()]
    }

    function a(i, t) {
        t = e()[t];
        return t && t[i] || {}
    }
    var d, r, c = e();
    c || (c = [], window && (window[o()] = c)), Object.assign(i, {
        options: a(i.info.pixelCode, "_o")
    }), d = i, c._i || (c._i = {}), (r = d.info.pixelCode) && (c._i[r] || (c._i[r] = []), Object.assign(c._i[r], d), c._i[r]._load = +new Date), Object.assign(i.info, {
        loadStart: a(i.info.pixelCode, "_t"),
        loadEnd: a(i.info.pixelCode, "_i")._load
    }), d = function(i, t, o) {
        var a = 0 < arguments.length && void 0 !== i ? i : {},
            d = 1 < arguments.length ? t : void 0,
            i = 2 < arguments.length ? o : void 0,
            t = function(i, t) {
                for (var o = 0; o < i.length; o++)
                    if (t.call(null, i[o], o)) return i[o]
            }(n, function(i) {
                for (var t = i.map, o = Object.keys(t), n = function(i) {
                        return !(!a[i] || !d[i]) === t[i]
                    }, e = 0; e < o.length; e++)
                    if (!n.call(null, o[e], e)) return !1;
                return !0
            });
        return t ? "".concat(i, "main.").concat(t.id, ".js") : "".concat(i, "main.").concat(n[0].id, ".js")
    }(c._plugins, i.plugins, t), r = i.info.pixelCode, (void 0 !== self.DedicatedWorkerGlobalScope ? self instanceof self.DedicatedWorkerGlobalScope : "DedicatedWorkerGlobalScope" === self.constructor.name) ? self.importScripts && self.importScripts(d) : ((c = document.createElement("script")).type = "text/javascript", c.async = !0, c.src = d, c.setAttribute("data-id", r), (d = document.getElementsByTagName("script")[0]) && d.parentNode && d.parentNode.insertBefore(c, d))
}();
! function() {
    "use strict";

    function t() {
        t = function() {
            return e
        };
        var e = {},
            r = Object.prototype,
            n = r.hasOwnProperty,
            o = "function" == typeof Symbol ? Symbol : {},
            i = o.iterator || "@@iterator",
            a = o.asyncIterator || "@@asyncIterator",
            c = o.toStringTag || "@@toStringTag";

        function u(t, e, r) {
            return Object.defineProperty(t, e, {
                value: r,
                enumerable: !0,
                configurable: !0,
                writable: !0
            }), t[e]
        }
        try {
            u({}, "")
        } catch (t) {
            u = function(t, e, r) {
                return t[e] = r
            }
        }

        function f(t, e, r, n) {
            var o = e && e.prototype instanceof p ? e : p,
                i = Object.create(o.prototype),
                a = new S(n || []);
            return i._invoke = function(t, e, r) {
                var n = "suspendedStart";
                return function(o, i) {
                    if ("executing" === n) throw new Error("Generator is already running");
                    if ("completed" === n) {
                        if ("throw" === o) throw i;
                        return j()
                    }
                    for (r.method = o, r.arg = i;;) {
                        var a = r.delegate;
                        if (a) {
                            var c = g(a, r);
                            if (c) {
                                if (c === l) continue;
                                return c
                            }
                        }
                        if ("next" === r.method) r.sent = r._sent = r.arg;
                        else if ("throw" === r.method) {
                            if ("suspendedStart" === n) throw n = "completed", r.arg;
                            r.dispatchException(r.arg)
                        } else "return" === r.method && r.abrupt("return", r.arg);
                        n = "executing";
                        var u = s(t, e, r);
                        if ("normal" === u.type) {
                            if (n = r.done ? "completed" : "suspendedYield", u.arg === l) continue;
                            return {
                                value: u.arg,
                                done: r.done
                            }
                        }
                        "throw" === u.type && (n = "completed", r.method = "throw", r.arg = u.arg)
                    }
                }
            }(t, r, a), i
        }

        function s(t, e, r) {
            try {
                return {
                    type: "normal",
                    arg: t.call(e, r)
                }
            } catch (t) {
                return {
                    type: "throw",
                    arg: t
                }
            }
        }
        e.wrap = f;
        var l = {};

        function p() {}

        function h() {}

        function y() {}
        var d = {};
        u(d, i, (function() {
            return this
        }));
        var _ = Object.getPrototypeOf,
            v = _ && _(_(I([])));
        v && v !== r && n.call(v, i) && (d = v);
        var m = y.prototype = p.prototype = Object.create(d);

        function w(t) {
            ["next", "throw", "return"].forEach((function(e) {
                u(t, e, (function(t) {
                    return this._invoke(e, t)
                }))
            }))
        }

        function b(t, e) {
            function r(o, i, a, c) {
                var u = s(t[o], t, i);
                if ("throw" !== u.type) {
                    var f = u.arg,
                        l = f.value;
                    return l && "object" == typeof l && n.call(l, "__await") ? e.resolve(l.__await).then((function(t) {
                        r("next", t, a, c)
                    }), (function(t) {
                        r("throw", t, a, c)
                    })) : e.resolve(l).then((function(t) {
                        f.value = t, a(f)
                    }), (function(t) {
                        return r("throw", t, a, c)
                    }))
                }
                c(u.arg)
            }
            var o;
            this._invoke = function(t, n) {
                function i() {
                    return new e((function(e, o) {
                        r(t, n, e, o)
                    }))
                }
                return o = o ? o.then(i, i) : i()
            }
        }

        function g(t, e) {
            var r = t.iterator[e.method];
            if (void 0 === r) {
                if (e.delegate = null, "throw" === e.method) {
                    if (t.iterator.return && (e.method = "return", e.arg = void 0, g(t, e), "throw" === e.method)) return l;
                    e.method = "throw", e.arg = new TypeError("The iterator does not provide a 'throw' method")
                }
                return l
            }
            var n = s(r, t.iterator, e.arg);
            if ("throw" === n.type) return e.method = "throw", e.arg = n.arg, e.delegate = null, l;
            var o = n.arg;
            return o ? o.done ? (e[t.resultName] = o.value, e.next = t.nextLoc, "return" !== e.method && (e.method = "next", e.arg = void 0), e.delegate = null, l) : o : (e.method = "throw", e.arg = new TypeError("iterator result is not an object"), e.delegate = null, l)
        }

        function O(t) {
            var e = {
                tryLoc: t[0]
            };
            1 in t && (e.catchLoc = t[1]), 2 in t && (e.finallyLoc = t[2], e.afterLoc = t[3]), this.tryEntries.push(e)
        }

        function E(t) {
            var e = t.completion || {};
            e.type = "normal", delete e.arg, t.completion = e
        }

        function S(t) {
            this.tryEntries = [{
                tryLoc: "root"
            }], t.forEach(O, this), this.reset(!0)
        }

        function I(t) {
            if (t) {
                var e = t[i];
                if (e) return e.call(t);
                if ("function" == typeof t.next) return t;
                if (!isNaN(t.length)) {
                    var r = -1,
                        o = function e() {
                            for (; ++r < t.length;)
                                if (n.call(t, r)) return e.value = t[r], e.done = !1, e;
                            return e.value = void 0, e.done = !0, e
                        };
                    return o.next = o
                }
            }
            return {
                next: j
            }
        }

        function j() {
            return {
                value: void 0,
                done: !0
            }
        }
        return h.prototype = y, u(m, "constructor", y), u(y, "constructor", h), h.displayName = u(y, c, "GeneratorFunction"), e.isGeneratorFunction = function(t) {
            var e = "function" == typeof t && t.constructor;
            return !!e && (e === h || "GeneratorFunction" === (e.displayName || e.name))
        }, e.mark = function(t) {
            return Object.setPrototypeOf ? Object.setPrototypeOf(t, y) : (t.__proto__ = y, u(t, c, "GeneratorFunction")), t.prototype = Object.create(m), t
        }, e.awrap = function(t) {
            return {
                __await: t
            }
        }, w(b.prototype), u(b.prototype, a, (function() {
            return this
        })), e.AsyncIterator = b, e.async = function(t, r, n, o, i) {
            void 0 === i && (i = Promise);
            var a = new b(f(t, r, n, o), i);
            return e.isGeneratorFunction(r) ? a : a.next().then((function(t) {
                return t.done ? t.value : a.next()
            }))
        }, w(m), u(m, c, "Generator"), u(m, i, (function() {
            return this
        })), u(m, "toString", (function() {
            return "[object Generator]"
        })), e.keys = function(t) {
            var e = [];
            for (var r in t) e.push(r);
            return e.reverse(),
                function r() {
                    for (; e.length;) {
                        var n = e.pop();
                        if (n in t) return r.value = n, r.done = !1, r
                    }
                    return r.done = !0, r
                }
        }, e.values = I, S.prototype = {
            constructor: S,
            reset: function(t) {
                if (this.prev = 0, this.next = 0, this.sent = this._sent = void 0, this.done = !1, this.delegate = null, this.method = "next", this.arg = void 0, this.tryEntries.forEach(E), !t)
                    for (var e in this) "t" === e.charAt(0) && n.call(this, e) && !isNaN(+e.slice(1)) && (this[e] = void 0)
            },
            stop: function() {
                this.done = !0;
                var t = this.tryEntries[0].completion;
                if ("throw" === t.type) throw t.arg;
                return this.rval
            },
            dispatchException: function(t) {
                if (this.done) throw t;
                var e = this;

                function r(r, n) {
                    return a.type = "throw", a.arg = t, e.next = r, n && (e.method = "next", e.arg = void 0), !!n
                }
                for (var o = this.tryEntries.length - 1; o >= 0; --o) {
                    var i = this.tryEntries[o],
                        a = i.completion;
                    if ("root" === i.tryLoc) return r("end");
                    if (i.tryLoc <= this.prev) {
                        var c = n.call(i, "catchLoc"),
                            u = n.call(i, "finallyLoc");
                        if (c && u) {
                            if (this.prev < i.catchLoc) return r(i.catchLoc, !0);
                            if (this.prev < i.finallyLoc) return r(i.finallyLoc)
                        } else if (c) {
                            if (this.prev < i.catchLoc) return r(i.catchLoc, !0)
                        } else {
                            if (!u) throw new Error("try statement without catch or finally");
                            if (this.prev < i.finallyLoc) return r(i.finallyLoc)
                        }
                    }
                }
            },
            abrupt: function(t, e) {
                for (var r = this.tryEntries.length - 1; r >= 0; --r) {
                    var o = this.tryEntries[r];
                    if (o.tryLoc <= this.prev && n.call(o, "finallyLoc") && this.prev < o.finallyLoc) {
                        var i = o;
                        break
                    }
                }
                i && ("break" === t || "continue" === t) && i.tryLoc <= e && e <= i.finallyLoc && (i = null);
                var a = i ? i.completion : {};
                return a.type = t, a.arg = e, i ? (this.method = "next", this.next = i.finallyLoc, l) : this.complete(a)
            },
            complete: function(t, e) {
                if ("throw" === t.type) throw t.arg;
                return "break" === t.type || "continue" === t.type ? this.next = t.arg : "return" === t.type ? (this.rval = this.arg = t.arg, this.method = "return", this.next = "end") : "normal" === t.type && e && (this.next = e), l
            },
            finish: function(t) {
                for (var e = this.tryEntries.length - 1; e >= 0; --e) {
                    var r = this.tryEntries[e];
                    if (r.finallyLoc === t) return this.complete(r.completion, r.afterLoc), E(r), l
                }
            },
            catch: function(t) {
                for (var e = this.tryEntries.length - 1; e >= 0; --e) {
                    var r = this.tryEntries[e];
                    if (r.tryLoc === t) {
                        var n = r.completion;
                        if ("throw" === n.type) {
                            var o = n.arg;
                            E(r)
                        }
                        return o
                    }
                }
                throw new Error("illegal catch attempt")
            },
            delegateYield: function(t, e, r) {
                return this.delegate = {
                    iterator: I(t),
                    resultName: e,
                    nextLoc: r
                }, "next" === this.method && (this.arg = void 0), l
            }
        }, e
    }

    function e(t) {
        return e = "function" == typeof Symbol && "symbol" == typeof Symbol.iterator ? function(t) {
            return typeof t
        } : function(t) {
            return t && "function" == typeof Symbol && t.constructor === Symbol && t !== Symbol.prototype ? "symbol" : typeof t
        }, e(t)
    }

    function r(t, e) {
        return r = Object.setPrototypeOf ? Object.setPrototypeOf.bind() : function(t, e) {
            return t.__proto__ = e, t
        }, r(t, e)
    }

    function n() {
        if ("undefined" == typeof Reflect || !Reflect.construct) return !1;
        if (Reflect.construct.sham) return !1;
        if ("function" == typeof Proxy) return !0;
        try {
            return Boolean.prototype.valueOf.call(Reflect.construct(Boolean, [], (function() {}))), !0
        } catch (t) {
            return !1
        }
    }

    function o(t, e, i) {
        return o = n() ? Reflect.construct.bind() : function(t, e, n) {
            var o = [null];
            o.push.apply(o, e);
            var i = new(Function.bind.apply(t, o));
            return n && r(i, n.prototype), i
        }, o.apply(null, arguments)
    }

    function i(t) {
        return function(t) {
            if (Array.isArray(t)) return a(t)
        }(t) || function(t) {
            if ("undefined" != typeof Symbol && null != t[Symbol.iterator] || null != t["@@iterator"]) return Array.from(t)
        }(t) || function(t, e) {
            if (!t) return;
            if ("string" == typeof t) return a(t, e);
            var r = Object.prototype.toString.call(t).slice(8, -1);
            "Object" === r && t.constructor && (r = t.constructor.name);
            if ("Map" === r || "Set" === r) return Array.from(t);
            if ("Arguments" === r || /^(?:Ui|I)nt(?:8|16|32)(?:Clamped)?Array$/.test(r)) return a(t, e)
        }(t) || function() {
            throw new TypeError("Invalid attempt to spread non-iterable instance.\nIn order to be iterable, non-array objects must have a [Symbol.iterator]() method.")
        }()
    }

    function a(t, e) {
        (null == e || e > t.length) && (e = t.length);
        for (var r = 0, n = new Array(e); r < e; r++) n[r] = t[r];
        return n
    }
    var c;
    ! function(t) {
        t.LOAD_START = "load_start", t.LOAD_END = "load_end", t.BEFORE_INIT = "before_init", t.INIT_START = "init_start", t.INIT_END = "init_end", t.JSB_INIT_START = "jsb_init_start", t.JSB_INIT_END = "jsb_init_end", t.BEFORE_AD_INFO_INIT_START = "before_ad_info_init_start", t.AD_INFO_INIT_START = "ad_info_init_start", t.AD_INFO_INIT_END = "ad_info_init_end", t.IDENTIFY_INIT_START = "identify_init_start", t.IDENTIFY_INIT_END = "identify_init_end", t.PLUGIN_INIT_START = "_init_start", t.PLUGIN_INIT_END = "_init_end", t.PIXEL_SEND = "pixel_send", t.PIXEL_SEND_PCM = "pixel_send_PCM", t.JSB_SEND = "jsb_send", t.HTTP_SEND = "http_send", t.HANDLE_CACHE = "handle_cache", t.INIT_ERROR = "init_error", t.PIXEL_EMPTY = "pixel_empty", t.JSB_ERROR = "jsb_error", t.API_ERROR = "api_error", t.PLUGIN_ERROR = "plugin_error", t.CUSTOM_INFO = "custom_info", t.CUSTOM_ERROR = "custom_error", t.CUSTOM_TIMER = "custom_timer"
    }(c || (c = {}));
    var u = function() {
            return "object" === ("undefined" == typeof window ? "undefined" : e(window)) && window.TiktokAnalyticsObject || "ttq"
        },
        f = function() {
            return "object" === ("undefined" == typeof window ? "undefined" : e(window)) && window[u()]
        },
        s = function(t) {
            try {
                var e = f()._plugins || {};
                return null == e[t] || !!e[t]
            } catch (t) {
                return !0
            }
        },
        l = {
            info: [],
            error: []
        };
    try {
        ! function() {
            if (/function bind\(\) \{[\s\S]*\[native code\][\s\S]*\}/.test(Function.prototype.bind.toString())) return !0;

            function t() {}
            return new(t.bind.apply(t, [void 0, 1])) instanceof t
        }() || Function.prototype._ttq_bind ? Function.prototype._ttq_bind || Object.defineProperty(Function.prototype, "_ttq_bind", {
                value: function(t) {
                    if ("function" != typeof this) throw new TypeError("What is being called by bind is not a function.");
                    var e = t || window,
                        r = Array.prototype.slice.call(arguments).slice(1),
                        n = Symbol("key");
                    return e[n] = this,
                        function t() {
                            return this instanceof t ? o(e[n], i(r).concat(Array.prototype.slice.call(arguments))) : e[n].apply(e, i(r).concat(Array.prototype.slice.call(arguments)))
                        }
                },
                enumerable: !1,
                writable: !1,
                configurable: !1
            }) : Object.defineProperty(Function.prototype, "_ttq_bind", {
                value: Function.prototype.bind,
                enumerable: !1,
                writable: !1,
                configurable: !1
            }), Object._ttq_keys || (Object._ttq_keys = function(t) {
                try {
                    return Array.isArray(t) ? Object.keys(t).filter((function(t) {
                        return -1 === ["each", "eachSlice", "all", "any", "collect", "detect", "findAll", "grep", "include", "inGroupsOf", "inject", "invoke", "max", "min", "partition", "pluck", "reject", "sortBy", "toArray", "zip", "size", "inspect", "select", "member", "_reverse", "_each", "clear", "first", "last", "compact", "flatten", "without", "uniq", "intersect", "clone", "toJSON", "remove", "swap", "putAll"].indexOf(t)
                    })) : Object.keys(t)
                } catch (e) {
                    return Object.keys(t)
                }
            }),
            function() {
                var e = u();

                function r(t) {
                    return null === t ? "NULL" : void 0 === t ? "UNDEFINED" : "[object Object]" === Object.prototype.toString.call(t) || "[object Array]" === Object.prototype.toString.call(t) ? JSON.stringify(t) : t.toString()
                }
                /function Map\(\) \{[\s\S]*\[native code\][\s\S]*\}/.test(Map.toString()) ? window[e]._ttq_map = Map : window[e]._ttq_map || (window[e]._ttq_map = function() {
                    this.items = {}, this.size = 0
                }, window[e]._ttq_map.prototype.set = function(t, e) {
                    return this.has(t) || (this.items[r(t)] = e, this.size++), this
                }, window[e]._ttq_map.prototype.get = function(t) {
                    return this.items[r(t)]
                }, window[e]._ttq_map.prototype.has = function(t) {
                    return void 0 !== this.items[r(t)]
                }, window[e]._ttq_map.prototype.delete = function(t) {
                    return this.has(t) && (delete this.items[r(t)], this.size--), this
                }, window[e]._ttq_map.prototype.clear = function() {
                    this.items = {}, this.size = 0
                }, window[e]._ttq_map.prototype.keys = function() {
                    var e = t().mark(o),
                        r = [];
                    for (var n in this.items) this.has(n) && r.push(n);

                    function o() {
                        return t().wrap((function(t) {
                            for (;;) switch (t.prev = t.next) {
                                case 0:
                                    return t.delegateYield(r, "t0", 1);
                                case 1:
                                case "end":
                                    return t.stop()
                            }
                        }), e)
                    }
                    return o()
                }, window[e]._ttq_map.prototype.values = function() {
                    var e = t().mark(o),
                        r = [];
                    for (var n in this.items) this.has(n) && r.push(this.items[n]);

                    function o() {
                        return t().wrap((function(t) {
                            for (;;) switch (t.prev = t.next) {
                                case 0:
                                    return t.delegateYield(r, "t0", 1);
                                case 1:
                                case "end":
                                    return t.stop()
                            }
                        }), e)
                    }
                    return o()
                })
            }(), /function create\(\) \{[\s\S]*\[native code\][\s\S]*\}/.test(Map.toString()) ? Object._ttq_create = Object.create : Object._ttq_create = function() {
                function t() {}
                var r = Object.prototype.hasOwnProperty;
                return function(n, o) {
                    if ("object" !== e(n) && "function" != typeof n) throw new TypeError("Object prototype may only be an Object or null");
                    t.prototype = n;
                    var i = new t;
                    return t.prototype = null, null != o && Object.keys(o).forEach((function(t) {
                        var n = o[t];
                        if ("object" !== e(n) || null === n) throw new TypeError("Property description must be an object: " + n);
                        r.call(n, "value") ? i[t] = n.value : "function" != typeof n.get && "function" != typeof n.set || Object.defineProperty(i, t, n)
                    })), i
                }
            }()
    } catch (t) {
        ! function(t, e) {
            var r = arguments.length > 2 && void 0 !== arguments[2] ? arguments[2] : {},
                n = arguments.length > 3 && void 0 !== arguments[3] && arguments[3];
            try {
                var o = f(),
                    i = o.getPlugin && o.getPlugin("Monitor") || null;
                i && i.error && "function" == typeof i.error ? i.error.call(i, t, e, r, n) : s("Monitor") && l.error.push({
                    event: t,
                    err: e,
                    detail: r,
                    withoutJSB: n
                })
            } catch (t) {}
        }(c.INIT_ERROR, t)
    }
}();
! function() {
    "use strict";

    function e() {
        e = function() {
            return t
        };
        var t = {},
            n = Object.prototype,
            r = n.hasOwnProperty,
            i = "function" == typeof Symbol ? Symbol : {},
            o = i.iterator || "@@iterator",
            a = i.asyncIterator || "@@asyncIterator",
            c = i.toStringTag || "@@toStringTag";

        function s(e, t, n) {
            return Object.defineProperty(e, t, {
                value: n,
                enumerable: !0,
                configurable: !0,
                writable: !0
            }), e[t]
        }
        try {
            s({}, "")
        } catch (e) {
            s = function(e, t, n) {
                return e[t] = n
            }
        }

        function u(e, t, n, r) {
            var i = t && t.prototype instanceof d ? t : d,
                o = Object._ttq_create(i.prototype),
                a = new O(r || []);
            return o._invoke = function(e, t, n) {
                var r = "suspendedStart";
                return function(i, o) {
                    if ("executing" === r) throw new Error("Generator is already running");
                    if ("completed" === r) {
                        if ("throw" === i) throw o;
                        return N()
                    }
                    for (n.method = i, n.arg = o;;) {
                        var a = n.delegate;
                        if (a) {
                            var c = b(a, n);
                            if (c) {
                                if (c === f) continue;
                                return c
                            }
                        }
                        if ("next" === n.method) n.sent = n._sent = n.arg;
                        else if ("throw" === n.method) {
                            if ("suspendedStart" === r) throw r = "completed", n.arg;
                            n.dispatchException(n.arg)
                        } else "return" === n.method && n.abrupt("return", n.arg);
                        r = "executing";
                        var s = l(e, t, n);
                        if ("normal" === s.type) {
                            if (r = n.done ? "completed" : "suspendedYield", s.arg === f) continue;
                            return {
                                value: s.arg,
                                done: n.done
                            }
                        }
                        "throw" === s.type && (r = "completed", n.method = "throw", n.arg = s.arg)
                    }
                }
            }(e, n, a), o
        }

        function l(e, t, n) {
            try {
                return {
                    type: "normal",
                    arg: e.call(t, n)
                }
            } catch (e) {
                return {
                    type: "throw",
                    arg: e
                }
            }
        }
        t.wrap = u;
        var f = {};

        function d() {}

        function h() {}

        function p() {}
        var v = {};
        s(v, o, (function() {
            return this
        }));
        var _ = Object.getPrototypeOf,
            g = _ && _(_(S([])));
        g && g !== n && r.call(g, o) && (v = g);
        var y = p.prototype = d.prototype = Object._ttq_create(v);

        function m(e) {
            ["next", "throw", "return"].forEach((function(t) {
                s(e, t, (function(e) {
                    return this._invoke(t, e)
                }))
            }))
        }

        function E(e, t) {
            function n(i, o, a, c) {
                var s = l(e[i], e, o);
                if ("throw" !== s.type) {
                    var u = s.arg,
                        f = u.value;
                    return f && "object" == typeof f && r.call(f, "__await") ? t.resolve(f.__await).then((function(e) {
                        n("next", e, a, c)
                    }), (function(e) {
                        n("throw", e, a, c)
                    })) : t.resolve(f).then((function(e) {
                        u.value = e, a(u)
                    }), (function(e) {
                        return n("throw", e, a, c)
                    }))
                }
                c(s.arg)
            }
            var i;
            this._invoke = function(e, r) {
                function o() {
                    return new t((function(t, i) {
                        n(e, r, t, i)
                    }))
                }
                return i = i ? i.then(o, o) : o()
            }
        }

        function b(e, t) {
            var n = e.iterator[t.method];
            if (void 0 === n) {
                if (t.delegate = null, "throw" === t.method) {
                    if (e.iterator.return && (t.method = "return", t.arg = void 0, b(e, t), "throw" === t.method)) return f;
                    t.method = "throw", t.arg = new TypeError("The iterator does not provide a 'throw' method")
                }
                return f
            }
            var r = l(n, e.iterator, t.arg);
            if ("throw" === r.type) return t.method = "throw", t.arg = r.arg, t.delegate = null, f;
            var i = r.arg;
            return i ? i.done ? (t[e.resultName] = i.value, t.next = e.nextLoc, "return" !== t.method && (t.method = "next", t.arg = void 0), t.delegate = null, f) : i : (t.method = "throw", t.arg = new TypeError("iterator result is not an object"), t.delegate = null, f)
        }

        function T(e) {
            var t = {
                tryLoc: e[0]
            };
            1 in e && (t.catchLoc = e[1]), 2 in e && (t.finallyLoc = e[2], t.afterLoc = e[3]), this.tryEntries.push(t)
        }

        function I(e) {
            var t = e.completion || {};
            t.type = "normal", delete t.arg, e.completion = t
        }

        function O(e) {
            this.tryEntries = [{
                tryLoc: "root"
            }], e.forEach(T, this), this.reset(!0)
        }

        function S(e) {
            if (e) {
                var t = e[o];
                if (t) return t.call(e);
                if ("function" == typeof e.next) return e;
                if (!isNaN(e.length)) {
                    var n = -1,
                        i = function t() {
                            for (; ++n < e.length;)
                                if (r.call(e, n)) return t.value = e[n], t.done = !1, t;
                            return t.value = void 0, t.done = !0, t
                        };
                    return i.next = i
                }
            }
            return {
                next: N
            }
        }

        function N() {
            return {
                value: void 0,
                done: !0
            }
        }
        return h.prototype = p, s(y, "constructor", p), s(p, "constructor", h), h.displayName = s(p, c, "GeneratorFunction"), t.isGeneratorFunction = function(e) {
            var t = "function" == typeof e && e.constructor;
            return !!t && (t === h || "GeneratorFunction" === (t.displayName || t.name))
        }, t.mark = function(e) {
            return Object.setPrototypeOf ? Object.setPrototypeOf(e, p) : (e.__proto__ = p, s(e, c, "GeneratorFunction")), e.prototype = Object._ttq_create(y), e
        }, t.awrap = function(e) {
            return {
                __await: e
            }
        }, m(E.prototype), s(E.prototype, a, (function() {
            return this
        })), t.AsyncIterator = E, t.async = function(e, n, r, i, o) {
            void 0 === o && (o = Promise);
            var a = new E(u(e, n, r, i), o);
            return t.isGeneratorFunction(n) ? a : a.next().then((function(e) {
                return e.done ? e.value : a.next()
            }))
        }, m(y), s(y, c, "Generator"), s(y, o, (function() {
            return this
        })), s(y, "toString", (function() {
            return "[object Generator]"
        })), t.keys = function(e) {
            var t = [];
            for (var n in e) t.push(n);
            return t.reverse(),
                function n() {
                    for (; t.length;) {
                        var r = t.pop();
                        if (r in e) return n.value = r, n.done = !1, n
                    }
                    return n.done = !0, n
                }
        }, t.values = S, O.prototype = {
            constructor: O,
            reset: function(e) {
                if (this.prev = 0, this.next = 0, this.sent = this._sent = void 0, this.done = !1, this.delegate = null, this.method = "next", this.arg = void 0, this.tryEntries.forEach(I), !e)
                    for (var t in this) "t" === t.charAt(0) && r.call(this, t) && !isNaN(+t.slice(1)) && (this[t] = void 0)
            },
            stop: function() {
                this.done = !0;
                var e = this.tryEntries[0].completion;
                if ("throw" === e.type) throw e.arg;
                return this.rval
            },
            dispatchException: function(e) {
                if (this.done) throw e;
                var t = this;

                function n(n, r) {
                    return a.type = "throw", a.arg = e, t.next = n, r && (t.method = "next", t.arg = void 0), !!r
                }
                for (var i = this.tryEntries.length - 1; i >= 0; --i) {
                    var o = this.tryEntries[i],
                        a = o.completion;
                    if ("root" === o.tryLoc) return n("end");
                    if (o.tryLoc <= this.prev) {
                        var c = r.call(o, "catchLoc"),
                            s = r.call(o, "finallyLoc");
                        if (c && s) {
                            if (this.prev < o.catchLoc) return n(o.catchLoc, !0);
                            if (this.prev < o.finallyLoc) return n(o.finallyLoc)
                        } else if (c) {
                            if (this.prev < o.catchLoc) return n(o.catchLoc, !0)
                        } else {
                            if (!s) throw new Error("try statement without catch or finally");
                            if (this.prev < o.finallyLoc) return n(o.finallyLoc)
                        }
                    }
                }
            },
            abrupt: function(e, t) {
                for (var n = this.tryEntries.length - 1; n >= 0; --n) {
                    var i = this.tryEntries[n];
                    if (i.tryLoc <= this.prev && r.call(i, "finallyLoc") && this.prev < i.finallyLoc) {
                        var o = i;
                        break
                    }
                }
                o && ("break" === e || "continue" === e) && o.tryLoc <= t && t <= o.finallyLoc && (o = null);
                var a = o ? o.completion : {};
                return a.type = e, a.arg = t, o ? (this.method = "next", this.next = o.finallyLoc, f) : this.complete(a)
            },
            complete: function(e, t) {
                if ("throw" === e.type) throw e.arg;
                return "break" === e.type || "continue" === e.type ? this.next = e.arg : "return" === e.type ? (this.rval = this.arg = e.arg, this.method = "return", this.next = "end") : "normal" === e.type && t && (this.next = t), f
            },
            finish: function(e) {
                for (var t = this.tryEntries.length - 1; t >= 0; --t) {
                    var n = this.tryEntries[t];
                    if (n.finallyLoc === e) return this.complete(n.completion, n.afterLoc), I(n), f
                }
            },
            catch: function(e) {
                for (var t = this.tryEntries.length - 1; t >= 0; --t) {
                    var n = this.tryEntries[t];
                    if (n.tryLoc === e) {
                        var r = n.completion;
                        if ("throw" === r.type) {
                            var i = r.arg;
                            I(n)
                        }
                        return i
                    }
                }
                throw new Error("illegal catch attempt")
            },
            delegateYield: function(e, t, n) {
                return this.delegate = {
                    iterator: S(e),
                    resultName: t,
                    nextLoc: n
                }, "next" === this.method && (this.arg = void 0), f
            }
        }, t
    }

    function t(e) {
        return t = "function" == typeof Symbol && "symbol" == typeof Symbol.iterator ? function(e) {
            return typeof e
        } : function(e) {
            return e && "function" == typeof Symbol && e.constructor === Symbol && e !== Symbol.prototype ? "symbol" : typeof e
        }, t(e)
    }

    function n(e, t, n, r, i, o, a) {
        try {
            var c = e[o](a),
                s = c.value
        } catch (e) {
            return void n(e)
        }
        c.done ? t(s) : Promise.resolve(s).then(r, i)
    }

    function r(e) {
        return function() {
            var t = this,
                r = arguments;
            return new Promise((function(i, o) {
                var a = e.apply(t, r);

                function c(e) {
                    n(a, i, o, c, s, "next", e)
                }

                function s(e) {
                    n(a, i, o, c, s, "throw", e)
                }
                c(void 0)
            }))
        }
    }

    function i(e, t) {
        if (!(e instanceof t)) throw new TypeError("Cannot call a class as a function")
    }

    function o(e, t) {
        for (var n = 0; n < t.length; n++) {
            var r = t[n];
            r.enumerable = r.enumerable || !1, r.configurable = !0, "value" in r && (r.writable = !0), Object.defineProperty(e, r.key, r)
        }
    }

    function a(e, t, n) {
        return t && o(e.prototype, t), n && o(e, n), Object.defineProperty(e, "prototype", {
            writable: !1
        }), e
    }

    function c(e, t, n) {
        return t in e ? Object.defineProperty(e, t, {
            value: n,
            enumerable: !0,
            configurable: !0,
            writable: !0
        }) : e[t] = n, e
    }

    function s(e, t) {
        if ("function" != typeof t && null !== t) throw new TypeError("Super expression must either be null or a function");
        e.prototype = Object._ttq_create(t && t.prototype, {
            constructor: {
                value: e,
                writable: !0,
                configurable: !0
            }
        }), Object.defineProperty(e, "prototype", {
            writable: !1
        }), t && l(e, t)
    }

    function u(e) {
        return u = Object.setPrototypeOf ? Object.getPrototypeOf.bind() : function(e) {
            return e.__proto__ || Object.getPrototypeOf(e)
        }, u(e)
    }

    function l(e, t) {
        return l = Object.setPrototypeOf ? Object.setPrototypeOf.bind() : function(e, t) {
            return e.__proto__ = t, e
        }, l(e, t)
    }

    function f(e) {
        if (void 0 === e) throw new ReferenceError("this hasn't been initialised - super() hasn't been called");
        return e
    }

    function d(e, t) {
        if (t && ("object" == typeof t || "function" == typeof t)) return t;
        if (void 0 !== t) throw new TypeError("Derived constructors may only return object or undefined");
        return f(e)
    }

    function h(e) {
        var t = function() {
            if ("undefined" == typeof Reflect || !Reflect.construct) return !1;
            if (Reflect.construct.sham) return !1;
            if ("function" == typeof Proxy) return !0;
            try {
                return Boolean.prototype.valueOf.call(Reflect.construct(Boolean, [], (function() {}))), !0
            } catch (e) {
                return !1
            }
        }();
        return function() {
            var n, r = u(e);
            if (t) {
                var i = u(this).constructor;
                n = Reflect.construct(r, arguments, i)
            } else n = r.apply(this, arguments);
            return d(this, n)
        }
    }

    function p(e, t) {
        for (; !Object.prototype.hasOwnProperty.call(e, t) && null !== (e = u(e)););
        return e
    }

    function v() {
        return v = "undefined" != typeof Reflect && Reflect.get ? Reflect.get.bind() : function(e, t, n) {
            var r = p(e, t);
            if (r) {
                var i = Object.getOwnPropertyDescriptor(r, t);
                return i.get ? i.get.call(arguments.length < 3 ? e : n) : i.value
            }
        }, v.apply(this, arguments)
    }

    function _(e, t) {
        return m(e) || function(e, t) {
            var n = null == e ? null : "undefined" != typeof Symbol && e[Symbol.iterator] || e["@@iterator"];
            if (null == n) return;
            var r, i, o = [],
                a = !0,
                c = !1;
            try {
                for (n = n.call(e); !(a = (r = n.next()).done) && (o.push(r.value), !t || o.length !== t); a = !0);
            } catch (e) {
                c = !0, i = e
            } finally {
                try {
                    a || null == n.return || n.return()
                } finally {
                    if (c) throw i
                }
            }
            return o
        }(e, t) || b(e, t) || I()
    }

    function g(e) {
        return m(e) || E(e) || b(e) || I()
    }

    function y(e) {
        return function(e) {
            if (Array.isArray(e)) return T(e)
        }(e) || E(e) || b(e) || function() {
            throw new TypeError("Invalid attempt to spread non-iterable instance.\nIn order to be iterable, non-array objects must have a [Symbol.iterator]() method.")
        }()
    }

    function m(e) {
        if (Array.isArray(e)) return e
    }

    function E(e) {
        if ("undefined" != typeof Symbol && null != e[Symbol.iterator] || null != e["@@iterator"]) return Array.from(e)
    }

    function b(e, t) {
        if (e) {
            if ("string" == typeof e) return T(e, t);
            var n = Object.prototype.toString.call(e).slice(8, -1);
            return "Object" === n && e.constructor && (n = e.constructor.name), "Map" === n || "Set" === n ? Array.from(e) : "Arguments" === n || /^(?:Ui|I)nt(?:8|16|32)(?:Clamped)?Array$/.test(n) ? T(e, t) : void 0
        }
    }

    function T(e, t) {
        (null == t || t > e.length) && (t = e.length);
        for (var n = 0, r = new Array(t); n < t; n++) r[n] = e[n];
        return r
    }

    function I() {
        throw new TypeError("Invalid attempt to destructure non-iterable instance.\nIn order to be iterable, non-array objects must have a [Symbol.iterator]() method.")
    }

    function O(e, t) {
        var n = "undefined" != typeof Symbol && e[Symbol.iterator] || e["@@iterator"];
        if (!n) {
            if (Array.isArray(e) || (n = b(e)) || t && e && "number" == typeof e.length) {
                n && (e = n);
                var r = 0,
                    i = function() {};
                return {
                    s: i,
                    n: function() {
                        return r >= e.length ? {
                            done: !0
                        } : {
                            done: !1,
                            value: e[r++]
                        }
                    },
                    e: function(e) {
                        throw e
                    },
                    f: i
                }
            }
            throw new TypeError("Invalid attempt to iterate non-iterable instance.\nIn order to be iterable, non-array objects must have a [Symbol.iterator]() method.")
        }
        var o, a = !0,
            c = !1;
        return {
            s: function() {
                n = n.call(e)
            },
            n: function() {
                var e = n.next();
                return a = e.done, e
            },
            e: function(e) {
                c = !0, o = e
            },
            f: function() {
                try {
                    a || null == n.return || n.return()
                } finally {
                    if (c) throw o
                }
            }
        }
    }
    var S, N = "undefined" != typeof globalThis ? globalThis : "undefined" != typeof window ? window : "undefined" != typeof global ? global : "undefined" != typeof self ? self : {};
    ! function(e) {
        ! function(t) {
            var n = "object" == typeof N ? N : "object" == typeof self ? self : "object" == typeof this ? this : Function("return this;")(),
                r = i(e);

            function i(e, t) {
                return function(n, r) {
                    "function" != typeof e[n] && Object.defineProperty(e, n, {
                        configurable: !0,
                        writable: !0,
                        value: r
                    }), t && t(n, r)
                }
            }
            void 0 === n.Reflect ? n.Reflect = e : r = i(n.Reflect, r),
                function(e) {
                    var t = Object.prototype.hasOwnProperty,
                        n = "function" == typeof Symbol,
                        r = n && void 0 !== Symbol.toPrimitive ? Symbol.toPrimitive : "@@toPrimitive",
                        i = n && void 0 !== Symbol.iterator ? Symbol.iterator : "@@iterator",
                        o = "function" == typeof Object.create,
                        a = {
                            __proto__: []
                        }
                    instanceof Array, c = !o && !a, s = {
                        create: o ? function() {
                            return re(Object._ttq_create(null))
                        } : a ? function() {
                            return re({
                                __proto__: null
                            })
                        } : function() {
                            return re({})
                        },
                        has: c ? function(e, n) {
                            return t.call(e, n)
                        } : function(e, t) {
                            return t in e
                        },
                        get: c ? function(e, n) {
                            return t.call(e, n) ? e[n] : void 0
                        } : function(e, t) {
                            return e[t]
                        }
                    }, u = Object.getPrototypeOf(Function), l = "object" == typeof process && process.env && "true" === process.env.REFLECT_METADATA_USE_MAP_POLYFILL, f = l || "function" != typeof Map || "function" != typeof Map.prototype.entries ? ee() : Map, d = l || "function" != typeof Set || "function" != typeof Set.prototype.entries ? te() : Set, h = new(l || "function" != typeof WeakMap ? ne() : WeakMap);

                    function p(e, t, n, r) {
                        if (D(n)) {
                            if (!J(e)) throw new TypeError;
                            if (!W(t)) throw new TypeError;
                            return O(e, t)
                        }
                        if (!J(e)) throw new TypeError;
                        if (!U(t)) throw new TypeError;
                        if (!U(r) && !D(r) && !x(r)) throw new TypeError;
                        return x(r) && (r = void 0), S(e, t, n = V(n), r)
                    }

                    function v(e, t) {
                        function n(n, r) {
                            if (!U(n)) throw new TypeError;
                            if (!D(r) && !Y(r)) throw new TypeError;
                            w(e, t, n, r)
                        }
                        return n
                    }

                    function _(e, t, n, r) {
                        if (!U(n)) throw new TypeError;
                        return D(r) || (r = V(r)), w(e, t, n, r)
                    }

                    function g(e, t, n) {
                        if (!U(t)) throw new TypeError;
                        return D(n) || (n = V(n)), R(e, t, n)
                    }

                    function y(e, t, n) {
                        if (!U(t)) throw new TypeError;
                        return D(n) || (n = V(n)), A(e, t, n)
                    }

                    function m(e, t, n) {
                        if (!U(t)) throw new TypeError;
                        return D(n) || (n = V(n)), C(e, t, n)
                    }

                    function E(e, t, n) {
                        if (!U(t)) throw new TypeError;
                        return D(n) || (n = V(n)), P(e, t, n)
                    }

                    function b(e, t) {
                        if (!U(e)) throw new TypeError;
                        return D(t) || (t = V(t)), k(e, t)
                    }

                    function T(e, t) {
                        if (!U(e)) throw new TypeError;
                        return D(t) || (t = V(t)), M(e, t)
                    }

                    function I(e, t, n) {
                        if (!U(t)) throw new TypeError;
                        D(n) || (n = V(n));
                        var r = N(t, n, !1);
                        if (D(r)) return !1;
                        if (!r.delete(e)) return !1;
                        if (r.size > 0) return !0;
                        var i = h.get(t);
                        return i.delete(n), i.size > 0 || h.delete(t), !0
                    }

                    function O(e, t) {
                        for (var n = e.length - 1; n >= 0; --n) {
                            var r = (0, e[n])(t);
                            if (!D(r) && !x(r)) {
                                if (!W(r)) throw new TypeError;
                                t = r
                            }
                        }
                        return t
                    }

                    function S(e, t, n, r) {
                        for (var i = e.length - 1; i >= 0; --i) {
                            var o = (0, e[i])(t, n, r);
                            if (!D(o) && !x(o)) {
                                if (!U(o)) throw new TypeError;
                                r = o
                            }
                        }
                        return r
                    }

                    function N(e, t, n) {
                        var r = h.get(e);
                        if (D(r)) {
                            if (!n) return;
                            r = new f, h.set(e, r)
                        }
                        var i = r.get(t);
                        if (D(i)) {
                            if (!n) return;
                            i = new f, r.set(t, i)
                        }
                        return i
                    }

                    function R(e, t, n) {
                        if (A(e, t, n)) return !0;
                        var r = $(t);
                        return !x(r) && R(e, r, n)
                    }

                    function A(e, t, n) {
                        var r = N(t, n, !1);
                        return !D(r) && G(r.has(e))
                    }

                    function C(e, t, n) {
                        if (A(e, t, n)) return P(e, t, n);
                        var r = $(t);
                        return x(r) ? void 0 : C(e, r, n)
                    }

                    function P(e, t, n) {
                        var r = N(t, n, !1);
                        if (!D(r)) return r.get(e)
                    }

                    function w(e, t, n, r) {
                        N(n, r, !0).set(e, t)
                    }

                    function k(e, t) {
                        var n = M(e, t),
                            r = $(e);
                        if (null === r) return n;
                        var i = k(r, t);
                        if (i.length <= 0) return n;
                        if (n.length <= 0) return i;
                        for (var o = new d, a = [], c = 0, s = n; c < s.length; c++) {
                            var u = s[c];
                            o.has(u) || (o.add(u), a.push(u))
                        }
                        for (var l = 0, f = i; l < f.length; l++) {
                            u = f[l];
                            o.has(u) || (o.add(u), a.push(u))
                        }
                        return a
                    }

                    function M(e, t) {
                        var n = [],
                            r = N(e, t, !1);
                        if (D(r)) return n;
                        for (var i = X(r.keys()), o = 0;;) {
                            var a = Q(i);
                            if (!a) return n.length = o, n;
                            var c = z(a);
                            try {
                                n[o] = c
                            } catch (e) {
                                try {
                                    Z(i)
                                } finally {
                                    throw e
                                }
                            }
                            o++
                        }
                    }

                    function L(e) {
                        if (null === e) return 1;
                        switch (typeof e) {
                            case "undefined":
                                return 0;
                            case "boolean":
                                return 2;
                            case "string":
                                return 3;
                            case "symbol":
                                return 4;
                            case "number":
                                return 5;
                            case "object":
                                return null === e ? 1 : 6;
                            default:
                                return 6
                        }
                    }

                    function D(e) {
                        return void 0 === e
                    }

                    function x(e) {
                        return null === e
                    }

                    function j(e) {
                        return "symbol" == typeof e
                    }

                    function U(e) {
                        return "object" == typeof e ? null !== e : "function" == typeof e
                    }

                    function F(e, t) {
                        switch (L(e)) {
                            case 0:
                            case 1:
                            case 2:
                            case 3:
                            case 4:
                            case 5:
                                return e
                        }
                        var n = 3 === t ? "string" : 5 === t ? "number" : "default",
                            i = q(e, r);
                        if (void 0 !== i) {
                            var o = i.call(e, n);
                            if (U(o)) throw new TypeError;
                            return o
                        }
                        return B(e, "default" === n ? "number" : n)
                    }

                    function B(e, t) {
                        if ("string" === t) {
                            var n = e.toString;
                            if (K(n))
                                if (!U(i = n.call(e))) return i;
                            if (K(r = e.valueOf))
                                if (!U(i = r.call(e))) return i
                        } else {
                            var r;
                            if (K(r = e.valueOf))
                                if (!U(i = r.call(e))) return i;
                            var i, o = e.toString;
                            if (K(o))
                                if (!U(i = o.call(e))) return i
                        }
                        throw new TypeError
                    }

                    function G(e) {
                        return !!e
                    }

                    function H(e) {
                        return "" + e
                    }

                    function V(e) {
                        var t = F(e, 3);
                        return j(t) ? t : H(t)
                    }

                    function J(e) {
                        return Array.isArray ? Array.isArray(e) : e instanceof Object ? e instanceof Array : "[object Array]" === Object.prototype.toString.call(e)
                    }

                    function K(e) {
                        return "function" == typeof e
                    }

                    function W(e) {
                        return "function" == typeof e
                    }

                    function Y(e) {
                        switch (L(e)) {
                            case 3:
                            case 4:
                                return !0;
                            default:
                                return !1
                        }
                    }

                    function q(e, t) {
                        var n = e[t];
                        if (null != n) {
                            if (!K(n)) throw new TypeError;
                            return n
                        }
                    }

                    function X(e) {
                        var t = q(e, i);
                        if (!K(t)) throw new TypeError;
                        var n = t.call(e);
                        if (!U(n)) throw new TypeError;
                        return n
                    }

                    function z(e) {
                        return e.value
                    }

                    function Q(e) {
                        var t = e.next();
                        return !t.done && t
                    }

                    function Z(e) {
                        var t = e.return;
                        t && t.call(e)
                    }

                    function $(e) {
                        var t = Object.getPrototypeOf(e);
                        if ("function" != typeof e || e === u) return t;
                        if (t !== u) return t;
                        var n = e.prototype,
                            r = n && Object.getPrototypeOf(n);
                        if (null == r || r === Object.prototype) return t;
                        var i = r.constructor;
                        return "function" != typeof i || i === e ? t : i
                    }

                    function ee() {
                        var e = {},
                            t = [],
                            n = function() {
                                function e(e, t, n) {
                                    this._index = 0, this._keys = e, this._values = t, this._selector = n
                                }
                                return e.prototype["@@iterator"] = function() {
                                    return this
                                }, e.prototype[i] = function() {
                                    return this
                                }, e.prototype.next = function() {
                                    var e = this._index;
                                    if (e >= 0 && e < this._keys.length) {
                                        var n = this._selector(this._keys[e], this._values[e]);
                                        return e + 1 >= this._keys.length ? (this._index = -1, this._keys = t, this._values = t) : this._index++, {
                                            value: n,
                                            done: !1
                                        }
                                    }
                                    return {
                                        value: void 0,
                                        done: !0
                                    }
                                }, e.prototype.throw = function(e) {
                                    throw this._index >= 0 && (this._index = -1, this._keys = t, this._values = t), e
                                }, e.prototype.return = function(e) {
                                    return this._index >= 0 && (this._index = -1, this._keys = t, this._values = t), {
                                        value: e,
                                        done: !0
                                    }
                                }, e
                            }();
                        return function() {
                            function t() {
                                this._keys = [], this._values = [], this._cacheKey = e, this._cacheIndex = -2
                            }
                            return Object.defineProperty(t.prototype, "size", {
                                get: function() {
                                    return this._keys.length
                                },
                                enumerable: !0,
                                configurable: !0
                            }), t.prototype.has = function(e) {
                                return this._find(e, !1) >= 0
                            }, t.prototype.get = function(e) {
                                var t = this._find(e, !1);
                                return t >= 0 ? this._values[t] : void 0
                            }, t.prototype.set = function(e, t) {
                                var n = this._find(e, !0);
                                return this._values[n] = t, this
                            }, t.prototype.delete = function(t) {
                                var n = this._find(t, !1);
                                if (n >= 0) {
                                    for (var r = this._keys.length, i = n + 1; i < r; i++) this._keys[i - 1] = this._keys[i], this._values[i - 1] = this._values[i];
                                    return this._keys.length--, this._values.length--, t === this._cacheKey && (this._cacheKey = e, this._cacheIndex = -2), !0
                                }
                                return !1
                            }, t.prototype.clear = function() {
                                this._keys.length = 0, this._values.length = 0, this._cacheKey = e, this._cacheIndex = -2
                            }, t.prototype.keys = function() {
                                return new n(this._keys, this._values, r)
                            }, t.prototype.values = function() {
                                return new n(this._keys, this._values, o)
                            }, t.prototype.entries = function() {
                                return new n(this._keys, this._values, a)
                            }, t.prototype["@@iterator"] = function() {
                                return this.entries()
                            }, t.prototype[i] = function() {
                                return this.entries()
                            }, t.prototype._find = function(e, t) {
                                return this._cacheKey !== e && (this._cacheIndex = this._keys.indexOf(this._cacheKey = e)), this._cacheIndex < 0 && t && (this._cacheIndex = this._keys.length, this._keys.push(e), this._values.push(void 0)), this._cacheIndex
                            }, t
                        }();

                        function r(e, t) {
                            return e
                        }

                        function o(e, t) {
                            return t
                        }

                        function a(e, t) {
                            return [e, t]
                        }
                    }

                    function te() {
                        return function() {
                            function e() {
                                this._map = new f
                            }
                            return Object.defineProperty(e.prototype, "size", {
                                get: function() {
                                    return this._map.size
                                },
                                enumerable: !0,
                                configurable: !0
                            }), e.prototype.has = function(e) {
                                return this._map.has(e)
                            }, e.prototype.add = function(e) {
                                return this._map.set(e, e), this
                            }, e.prototype.delete = function(e) {
                                return this._map.delete(e)
                            }, e.prototype.clear = function() {
                                this._map.clear()
                            }, e.prototype.keys = function() {
                                return this._map.keys()
                            }, e.prototype.values = function() {
                                return this._map.values()
                            }, e.prototype.entries = function() {
                                return this._map.entries()
                            }, e.prototype["@@iterator"] = function() {
                                return this.keys()
                            }, e.prototype[i] = function() {
                                return this.keys()
                            }, e
                        }()
                    }

                    function ne() {
                        var e = 16,
                            n = s.create(),
                            r = i();
                        return function() {
                            function e() {
                                this._key = i()
                            }
                            return e.prototype.has = function(e) {
                                var t = o(e, !1);
                                return void 0 !== t && s.has(t, this._key)
                            }, e.prototype.get = function(e) {
                                var t = o(e, !1);
                                return void 0 !== t ? s.get(t, this._key) : void 0
                            }, e.prototype.set = function(e, t) {
                                return o(e, !0)[this._key] = t, this
                            }, e.prototype.delete = function(e) {
                                var t = o(e, !1);
                                return void 0 !== t && delete t[this._key]
                            }, e.prototype.clear = function() {
                                this._key = i()
                            }, e
                        }();

                        function i() {
                            var e;
                            do {
                                e = "@@WeakMap@@" + u()
                            } while (s.has(n, e));
                            return n[e] = !0, e
                        }

                        function o(e, n) {
                            if (!t.call(e, r)) {
                                if (!n) return;
                                Object.defineProperty(e, r, {
                                    value: s.create()
                                })
                            }
                            return e[r]
                        }

                        function a(e, t) {
                            for (var n = 0; n < t; ++n) e[n] = 255 * Math.random() | 0;
                            return e
                        }

                        function c(e) {
                            return "function" == typeof Uint8Array ? "undefined" != typeof crypto ? crypto.getRandomValues(new Uint8Array(e)) : "undefined" != typeof msCrypto ? msCrypto.getRandomValues(new Uint8Array(e)) : a(new Uint8Array(e), e) : a(new Array(e), e)
                        }

                        function u() {
                            var t = c(e);
                            t[6] = 79 & t[6] | 64, t[8] = 191 & t[8] | 128;
                            for (var n = "", r = 0; r < e; ++r) {
                                var i = t[r];
                                4 !== r && 6 !== r && 8 !== r || (n += "-"), i < 16 && (n += "0"), n += i.toString(16).toLowerCase()
                            }
                            return n
                        }
                    }

                    function re(e) {
                        return e.__ = void 0, delete e.__, e
                    }
                    e("decorate", p), e("metadata", v), e("ttq_defineMetadata", _), e("ttq_hasMetadata", g), e("ttq_hasOwnMetadata", y), e("ttq_getMetadata", m), e("getOwnMetadata", E), e("getMetadataKeys", b), e("getOwnMetadataKeys", T), e("deleteMetadata", I)
                }(r)
        }()
    }(S || (S = {}));
    var R, A = {},
        C = {};
    R = C, Object.defineProperty(R, "__esModule", {
        value: !0
    }), R.NON_CUSTOM_TAG_KEYS = R.POST_CONSTRUCT = R.DESIGN_PARAM_TYPES = R.PARAM_TYPES = R.TAGGED_PROP = R.TAGGED = R.MULTI_INJECT_TAG = R.INJECT_TAG = R.OPTIONAL_TAG = R.UNMANAGED_TAG = R.NAME_TAG = R.NAMED_TAG = void 0, R.NAMED_TAG = "named", R.NAME_TAG = "name", R.UNMANAGED_TAG = "unmanaged", R.OPTIONAL_TAG = "optional", R.INJECT_TAG = "inject", R.MULTI_INJECT_TAG = "multi_inject", R.TAGGED = "inversify:tagged", R.TAGGED_PROP = "inversify:tagged_props", R.PARAM_TYPES = "inversify:paramtypes", R.DESIGN_PARAM_TYPES = "design:paramtypes", R.POST_CONSTRUCT = "post_construct", R.NON_CUSTOM_TAG_KEYS = [R.INJECT_TAG, R.MULTI_INJECT_TAG, R.NAME_TAG, R.UNMANAGED_TAG, R.NAMED_TAG, R.OPTIONAL_TAG];
    var P = {},
        w = {},
        k = {};
    Object.defineProperty(k, "__esModule", {
        value: !0
    }), k.TargetTypeEnum = k.BindingTypeEnum = k.BindingScopeEnum = void 0;
    k.BindingScopeEnum = {
        Request: "Request",
        Singleton: "Singleton",
        Transient: "Transient"
    };
    k.BindingTypeEnum = {
        ConstantValue: "ConstantValue",
        Constructor: "Constructor",
        DynamicValue: "DynamicValue",
        Factory: "Factory",
        Function: "Function",
        Instance: "Instance",
        Invalid: "Invalid",
        Provider: "Provider"
    };
    k.TargetTypeEnum = {
        ClassProperty: "ClassProperty",
        ConstructorArgument: "ConstructorArgument",
        Variable: "Variable"
    };
    var M = {};
    Object.defineProperty(M, "__esModule", {
        value: !0
    }), M.id = void 0;
    var L = 0;
    M.id = function() {
        return L++
    }, Object.defineProperty(w, "__esModule", {
        value: !0
    }), w.Binding = void 0;
    var D = k,
        x = M,
        j = function() {
            function e(e, t) {
                this.id = x.id(), this.activated = !1, this.serviceIdentifier = e, this.scope = t, this.type = D.BindingTypeEnum.Invalid, this.constraint = function(e) {
                    return !0
                }, this.implementationType = null, this.cache = null, this.factory = null, this.provider = null, this.onActivation = null, this.dynamicValue = null
            }
            return e.prototype.clone = function() {
                var t = new e(this.serviceIdentifier, this.scope);
                return t.activated = t.scope === D.BindingScopeEnum.Singleton && this.activated, t.implementationType = this.implementationType, t.dynamicValue = this.dynamicValue, t.scope = this.scope, t.type = this.type, t.factory = this.factory, t.provider = this.provider, t.constraint = this.constraint, t.onActivation = this.onActivation, t.cache = this.cache, t
            }, e
        }();
    w.Binding = j;
    var U = {};
    Object.defineProperty(U, "__esModule", {
        value: !0
    }), U.STACK_OVERFLOW = U.CIRCULAR_DEPENDENCY_IN_FACTORY = U.POST_CONSTRUCT_ERROR = U.MULTIPLE_POST_CONSTRUCT_METHODS = U.CONTAINER_OPTIONS_INVALID_SKIP_BASE_CHECK = U.CONTAINER_OPTIONS_INVALID_AUTO_BIND_INJECTABLE = U.CONTAINER_OPTIONS_INVALID_DEFAULT_SCOPE = U.CONTAINER_OPTIONS_MUST_BE_AN_OBJECT = U.ARGUMENTS_LENGTH_MISMATCH = U.INVALID_DECORATOR_OPERATION = U.INVALID_TO_SELF_VALUE = U.INVALID_FUNCTION_BINDING = U.INVALID_MIDDLEWARE_RETURN = U.NO_MORE_SNAPSHOTS_AVAILABLE = U.INVALID_BINDING_TYPE = U.NOT_IMPLEMENTED = U.CIRCULAR_DEPENDENCY = U.UNDEFINED_INJECT_ANNOTATION = U.MISSING_INJECT_ANNOTATION = U.MISSING_INJECTABLE_ANNOTATION = U.NOT_REGISTERED = U.CANNOT_UNBIND = U.AMBIGUOUS_MATCH = U.KEY_NOT_FOUND = U.NULL_ARGUMENT = U.DUPLICATED_METADATA = U.DUPLICATED_INJECTABLE_DECORATOR = void 0, U.DUPLICATED_INJECTABLE_DECORATOR = "Cannot apply @injectable decorator multiple times.", U.DUPLICATED_METADATA = "Metadata key was used more than once in a parameter:", U.NULL_ARGUMENT = "NULL argument", U.KEY_NOT_FOUND = "Key Not Found", U.AMBIGUOUS_MATCH = "Ambiguous match found for serviceIdentifier:", U.CANNOT_UNBIND = "Could not unbind serviceIdentifier:", U.NOT_REGISTERED = "No matching bindings found for serviceIdentifier:", U.MISSING_INJECTABLE_ANNOTATION = "Missing required @injectable annotation in:", U.MISSING_INJECT_ANNOTATION = "Missing required @inject or @multiInject annotation in:";
    U.UNDEFINED_INJECT_ANNOTATION = function(e) {
        return "@inject called with undefined this could mean that the class " + e + " has a circular dependency problem. You can use a LazyServiceIdentifer to  overcome this limitation."
    }, U.CIRCULAR_DEPENDENCY = "Circular dependency found:", U.NOT_IMPLEMENTED = "Sorry, this feature is not fully implemented yet.", U.INVALID_BINDING_TYPE = "Invalid binding type:", U.NO_MORE_SNAPSHOTS_AVAILABLE = "No snapshot available to restore.", U.INVALID_MIDDLEWARE_RETURN = "Invalid return type in middleware. Middleware must return!", U.INVALID_FUNCTION_BINDING = "Value provided to function binding must be a function!", U.INVALID_TO_SELF_VALUE = "The toSelf function can only be applied when a constructor is used as service identifier", U.INVALID_DECORATOR_OPERATION = "The @inject @multiInject @tagged and @named decorators must be applied to the parameters of a class constructor or a class property.";
    U.ARGUMENTS_LENGTH_MISMATCH = function() {
        for (var e = [], t = 0; t < arguments.length; t++) e[t] = arguments[t];
        return "The number of constructor arguments in the derived class " + e[0] + " must be >= than the number of constructor arguments of its base class."
    }, U.CONTAINER_OPTIONS_MUST_BE_AN_OBJECT = "Invalid Container constructor argument. Container options must be an object.", U.CONTAINER_OPTIONS_INVALID_DEFAULT_SCOPE = "Invalid Container option. Default scope must be a string ('singleton' or 'transient').", U.CONTAINER_OPTIONS_INVALID_AUTO_BIND_INJECTABLE = "Invalid Container option. Auto bind injectable must be a boolean", U.CONTAINER_OPTIONS_INVALID_SKIP_BASE_CHECK = "Invalid Container option. Skip base check must be a boolean", U.MULTIPLE_POST_CONSTRUCT_METHODS = "Cannot apply @postConstruct decorator multiple times in the same class";
    U.POST_CONSTRUCT_ERROR = function() {
        for (var e = [], t = 0; t < arguments.length; t++) e[t] = arguments[t];
        return "@postConstruct error in class " + e[0] + ": " + e[1]
    };
    U.CIRCULAR_DEPENDENCY_IN_FACTORY = function() {
        for (var e = [], t = 0; t < arguments.length; t++) e[t] = arguments[t];
        return "It looks like there is a circular dependency in one of the '" + e[0] + "' bindings. Please investigate bindings withservice identifier '" + e[1] + "'."
    }, U.STACK_OVERFLOW = "Maximum call stack size exceeded";
    var F = {};
    Object.defineProperty(F, "__esModule", {
        value: !0
    }), F.MetadataReader = void 0;
    var B = C,
        G = function() {
            function e() {}
            return e.prototype.getConstructorMetadata = function(e) {
                return {
                    compilerGeneratedMetadata: Reflect.ttq_getMetadata(B.PARAM_TYPES, e),
                    userGeneratedMetadata: Reflect.ttq_getMetadata(B.TAGGED, e) || {}
                }
            }, e.prototype.getPropertiesMetadata = function(e) {
                return Reflect.ttq_getMetadata(B.TAGGED_PROP, e) || []
            }, e
        }();
    F.MetadataReader = G;
    var H = {},
        V = {};
    Object.defineProperty(V, "__esModule", {
        value: !0
    }), V.BindingCount = void 0;
    V.BindingCount = {
        MultipleBindingsAvailable: 2,
        NoBindingsAvailable: 0,
        OnlyOneBindingAvailable: 1
    };
    var J = {};
    Object.defineProperty(J, "__esModule", {
        value: !0
    }), J.isStackOverflowExeption = void 0;
    var K = U;
    J.isStackOverflowExeption = function(e) {
        return e instanceof RangeError || e.message === K.STACK_OVERFLOW
    };
    var W = {};
    Object.defineProperty(W, "__esModule", {
        value: !0
    }), W.circularDependencyToException = W.listMetadataForTarget = W.listRegisteredBindingsForServiceIdentifier = W.getServiceIdentifierAsString = W.getFunctionName = void 0;
    var Y = U;

    function q(e) {
        return "function" == typeof e ? e.name : "symbol" == typeof e ? e.toString() : e
    }

    function X(e, t) {
        return null !== e.parentRequest && (e.parentRequest.serviceIdentifier === t || X(e.parentRequest, t))
    }

    function z(e) {
        if (e.name) return e.name;
        var t = e.toString(),
            n = t.match(/^function\s*([^\s(]+)/);
        return n ? n[1] : "Anonymous function: " + t
    }
    W.getServiceIdentifierAsString = q, W.listRegisteredBindingsForServiceIdentifier = function(e, t, n) {
        var r = "",
            i = n(e, t);
        return 0 !== i.length && (r = "\nRegistered bindings:", i.forEach((function(e) {
            var t = "Object";
            null !== e.implementationType && (t = z(e.implementationType)), r = r + "\n " + t, e.constraint.metaData && (r = r + " - " + e.constraint.metaData)
        }))), r
    }, W.circularDependencyToException = function e(t) {
        t.childRequests.forEach((function(t) {
            if (X(t, t.serviceIdentifier)) {
                var n = function(e) {
                    return function e(t, n) {
                        void 0 === n && (n = []);
                        var r = q(t.serviceIdentifier);
                        return n.push(r), null !== t.parentRequest ? e(t.parentRequest, n) : n
                    }(e).reverse().join(" --\x3e ")
                }(t);
                throw new Error(Y.CIRCULAR_DEPENDENCY + " " + n)
            }
            e(t)
        }))
    }, W.listMetadataForTarget = function(e, t) {
        if (t.isTagged() || t.isNamed()) {
            var n = "",
                r = t.getNamedTag(),
                i = t.getCustomTags();
            return null !== r && (n += r.toString() + "\n"), null !== i && i.forEach((function(e) {
                n += e.toString() + "\n"
            })), " " + e + "\n " + e + " - " + n
        }
        return " " + e
    }, W.getFunctionName = z;
    var Q = {};
    Object.defineProperty(Q, "__esModule", {
        value: !0
    }), Q.Context = void 0;
    var Z = M,
        $ = function() {
            function e(e) {
                this.id = Z.id(), this.container = e
            }
            return e.prototype.addPlan = function(e) {
                this.plan = e
            }, e.prototype.setCurrentRequest = function(e) {
                this.currentRequest = e
            }, e
        }();
    Q.Context = $;
    var ee = {};
    Object.defineProperty(ee, "__esModule", {
        value: !0
    }), ee.Metadata = void 0;
    var te = C,
        ne = function() {
            function e(e, t) {
                this.key = e, this.value = t
            }
            return e.prototype.toString = function() {
                return this.key === te.NAMED_TAG ? "named: " + this.value.toString() + " " : "tagged: { key:" + this.key.toString() + ", value: " + this.value + " }"
            }, e
        }();
    ee.Metadata = ne;
    var re = {};
    Object.defineProperty(re, "__esModule", {
        value: !0
    }), re.Plan = void 0;
    var ie = function(e, t) {
        this.parentContext = e, this.rootRequest = t
    };
    re.Plan = ie;
    var oe = {},
        ae = {},
        ce = {};
    Object.defineProperty(ce, "__esModule", {
        value: !0
    }), ce.tagProperty = ce.tagParameter = ce.decorate = void 0;
    var se = U,
        ue = C;

    function le(e, t, n, r, i) {
        var o = {},
            a = "number" == typeof i,
            c = void 0 !== i && a ? i.toString() : n;
        if (a && void 0 !== n) throw new Error(se.INVALID_DECORATOR_OPERATION);
        Reflect.ttq_hasOwnMetadata(e, t) && (o = Reflect.ttq_getMetadata(e, t));
        var s = o[c];
        if (Array.isArray(s))
            for (var u = 0, l = s; u < l.length; u++) {
                var f = l[u];
                if (f.key === r.key) throw new Error(se.DUPLICATED_METADATA + " " + f.key.toString())
            } else s = [];
        s.push(r), o[c] = s, Reflect.ttq_defineMetadata(e, o, t)
    }

    function fe(e, t) {
        Reflect.decorate(e, t)
    }

    function de(e, t) {
        return function(n, r) {
            t(n, r, e)
        }
    }
    ce.tagParameter = function(e, t, n, r) {
        le(ue.TAGGED, e, t, r, n)
    }, ce.tagProperty = function(e, t, n) {
        le(ue.TAGGED_PROP, e.constructor, t, n)
    }, ce.decorate = function(e, t, n) {
        "number" == typeof n ? fe([de(n, e)], t) : "string" == typeof n ? Reflect.decorate([e], t, n) : fe([e], t)
    }, Object.defineProperty(ae, "__esModule", {
        value: !0
    }), ae.inject = ae.LazyServiceIdentifer = void 0;
    var he = U,
        pe = C,
        ve = ee,
        _e = ce,
        ge = function() {
            function e(e) {
                this._cb = e
            }
            return e.prototype.unwrap = function() {
                return this._cb()
            }, e
        }();
    ae.LazyServiceIdentifer = ge, ae.inject = function(e) {
        return function(t, n, r) {
            if (void 0 === e) throw new Error(he.UNDEFINED_INJECT_ANNOTATION(t.name));
            var i = new ve.Metadata(pe.INJECT_TAG, e);
            "number" == typeof r ? _e.tagParameter(t, n, r, i) : _e.tagProperty(t, n, i)
        }
    };
    var ye = {},
        me = {};
    Object.defineProperty(me, "__esModule", {
        value: !0
    }), me.QueryableString = void 0;
    var Ee = function() {
        function e(e) {
            this.str = e
        }
        return e.prototype.startsWith = function(e) {
            return 0 === this.str.indexOf(e)
        }, e.prototype.endsWith = function(e) {
            var t, n = e.split("").reverse().join("");
            return t = this.str.split("").reverse().join(""), this.startsWith.call({
                str: t
            }, n)
        }, e.prototype.contains = function(e) {
            return -1 !== this.str.indexOf(e)
        }, e.prototype.equals = function(e) {
            return this.str === e
        }, e.prototype.value = function() {
            return this.str
        }, e
    }();
    me.QueryableString = Ee, Object.defineProperty(ye, "__esModule", {
        value: !0
    }), ye.Target = void 0;
    var be = C,
        Te = M,
        Ie = ee,
        Oe = me,
        Se = function() {
            function e(e, t, n, r) {
                this.id = Te.id(), this.type = e, this.serviceIdentifier = n, this.name = new Oe.QueryableString(t || ""), this.metadata = new Array;
                var i = null;
                "string" == typeof r ? i = new Ie.Metadata(be.NAMED_TAG, r) : r instanceof Ie.Metadata && (i = r), null !== i && this.metadata.push(i)
            }
            return e.prototype.hasTag = function(e) {
                for (var t = 0, n = this.metadata; t < n.length; t++) {
                    if (n[t].key === e) return !0
                }
                return !1
            }, e.prototype.isArray = function() {
                return this.hasTag(be.MULTI_INJECT_TAG)
            }, e.prototype.matchesArray = function(e) {
                return this.matchesTag(be.MULTI_INJECT_TAG)(e)
            }, e.prototype.isNamed = function() {
                return this.hasTag(be.NAMED_TAG)
            }, e.prototype.isTagged = function() {
                return this.metadata.some((function(e) {
                    return be.NON_CUSTOM_TAG_KEYS.every((function(t) {
                        return e.key !== t
                    }))
                }))
            }, e.prototype.isOptional = function() {
                return this.matchesTag(be.OPTIONAL_TAG)(!0)
            }, e.prototype.getNamedTag = function() {
                return this.isNamed() ? this.metadata.filter((function(e) {
                    return e.key === be.NAMED_TAG
                }))[0] : null
            }, e.prototype.getCustomTags = function() {
                return this.isTagged() ? this.metadata.filter((function(e) {
                    return be.NON_CUSTOM_TAG_KEYS.every((function(t) {
                        return e.key !== t
                    }))
                })) : null
            }, e.prototype.matchesNamedTag = function(e) {
                return this.matchesTag(be.NAMED_TAG)(e)
            }, e.prototype.matchesTag = function(e) {
                var t = this;
                return function(n) {
                    for (var r = 0, i = t.metadata; r < i.length; r++) {
                        var o = i[r];
                        if (o.key === e && o.value === n) return !0
                    }
                    return !1
                }
            }, e
        }();
    ye.Target = Se,
        function(e) {
            var t = N && N.__spreadArray || function(e, t) {
                for (var n = 0, r = t.length, i = e.length; n < r; n++, i++) e[i] = t[n];
                return e
            };
            Object.defineProperty(e, "__esModule", {
                value: !0
            }), e.getFunctionName = e.getBaseClassDependencyCount = e.getDependencies = void 0;
            var n = ae,
                r = U,
                i = k,
                o = C,
                a = W;
            Object.defineProperty(e, "getFunctionName", {
                enumerable: !0,
                get: function() {
                    return a.getFunctionName
                }
            });
            var c = ye;

            function s(e, n, i, o) {
                var a = e.getConstructorMetadata(i),
                    c = a.compilerGeneratedMetadata;
                if (void 0 === c) {
                    var s = r.MISSING_INJECTABLE_ANNOTATION + " " + n + ".";
                    throw new Error(s)
                }
                var f = a.userGeneratedMetadata,
                    d = Object.keys(f),
                    h = 0 === i.length && d.length > 0,
                    p = d.length > i.length,
                    v = function(e, t, n, r, i) {
                        for (var o = [], a = 0; a < i; a++) {
                            var c = u(a, e, t, n, r);
                            null !== c && o.push(c)
                        }
                        return o
                    }(o, n, c, f, h || p ? d.length : i.length),
                    _ = l(e, i);
                return t(t([], v), _)
            }

            function u(e, t, o, a, s) {
                var u = s[e.toString()] || [],
                    l = f(u),
                    d = !0 !== l.unmanaged,
                    h = a[e],
                    p = l.inject || l.multiInject;
                if ((h = p || h) instanceof n.LazyServiceIdentifer && (h = h.unwrap()), d) {
                    if (!t && (h === Object || h === Function || void 0 === h)) {
                        var v = r.MISSING_INJECT_ANNOTATION + " argument " + e + " in class " + o + ".";
                        throw new Error(v)
                    }
                    var _ = new c.Target(i.TargetTypeEnum.ConstructorArgument, l.targetName, h);
                    return _.metadata = u, _
                }
                return null
            }

            function l(e, n) {
                for (var r = e.getPropertiesMetadata(n), o = [], a = 0, s = Object._ttq_keys(r); a < s.length; a++) {
                    var u = s[a],
                        d = r[u],
                        h = f(r[u]),
                        p = h.targetName || u,
                        v = h.inject || h.multiInject,
                        _ = new c.Target(i.TargetTypeEnum.ClassProperty, p, v);
                    _.metadata = d, o.push(_)
                }
                var g = Object.getPrototypeOf(n.prototype).constructor;
                if (g !== Object) {
                    var y = l(e, g);
                    o = t(t([], o), y)
                }
                return o
            }

            function f(e) {
                var t = {};
                return e.forEach((function(e) {
                    t[e.key.toString()] = e.value
                })), {
                    inject: t[o.INJECT_TAG],
                    multiInject: t[o.MULTI_INJECT_TAG],
                    targetName: t[o.NAME_TAG],
                    unmanaged: t[o.UNMANAGED_TAG]
                }
            }
            e.getDependencies = function(e, t) {
                return s(e, a.getFunctionName(t), t, !1)
            }, e.getBaseClassDependencyCount = function e(t, n) {
                var r = Object.getPrototypeOf(n.prototype).constructor;
                if (r !== Object) {
                    var i = s(t, a.getFunctionName(r), r, !0),
                        c = i.map((function(e) {
                            return e.metadata.filter((function(e) {
                                return e.key === o.UNMANAGED_TAG
                            }))
                        })),
                        u = [].concat.apply([], c).length,
                        l = i.length - u;
                    return l > 0 ? l : e(t, r)
                }
                return 0
            }
        }(oe);
    var Ne = {};
    Object.defineProperty(Ne, "__esModule", {
        value: !0
    }), Ne.Request = void 0;
    var Re = M,
        Ae = function() {
            function e(e, t, n, r, i) {
                this.id = Re.id(), this.serviceIdentifier = e, this.parentContext = t, this.parentRequest = n, this.target = i, this.childRequests = [], this.bindings = Array.isArray(r) ? r : [r], this.requestScope = null === n ? new window[window.TiktokAnalyticsObject || "ttq"]._ttq_map : null
            }
            return e.prototype.addChildRequest = function(t, n, r) {
                var i = new e(t, this.parentContext, this, n, r);
                return this.childRequests.push(i), i
            }, e
        }();
    Ne.Request = Ae, Object.defineProperty(H, "__esModule", {
        value: !0
    }), H.getBindingDictionary = H.createMockRequest = H.plan = void 0;
    var Ce = V,
        Pe = U,
        we = k,
        ke = C,
        Me = J,
        Le = W,
        De = Q,
        xe = ee,
        je = re,
        Ue = oe,
        Fe = Ne,
        Be = ye;

    function Ge(e) {
        return e._bindingDictionary
    }

    function He(e, t, n, r, i) {
        var o = Je(n.container, i.serviceIdentifier),
            a = [];
        return o.length === Ce.BindingCount.NoBindingsAvailable && n.container.options.autoBindInjectable && "function" == typeof i.serviceIdentifier && e.getConstructorMetadata(i.serviceIdentifier).compilerGeneratedMetadata && (n.container.bind(i.serviceIdentifier).toSelf(), o = Je(n.container, i.serviceIdentifier)), a = t ? o : o.filter((function(e) {
                var t = new Fe.Request(e.serviceIdentifier, n, r, e, i);
                return e.constraint(t)
            })),
            function(e, t, n, r) {
                switch (t.length) {
                    case Ce.BindingCount.NoBindingsAvailable:
                        if (n.isOptional()) return t;
                        var i = Le.getServiceIdentifierAsString(e),
                            o = Pe.NOT_REGISTERED;
                        throw o += Le.listMetadataForTarget(i, n), o += Le.listRegisteredBindingsForServiceIdentifier(r, i, Je), new Error(o);
                    case Ce.BindingCount.OnlyOneBindingAvailable:
                        if (!n.isArray()) return t;
                    case Ce.BindingCount.MultipleBindingsAvailable:
                    default:
                        if (n.isArray()) return t;
                        i = Le.getServiceIdentifierAsString(e), o = Pe.AMBIGUOUS_MATCH + " " + i;
                        throw o += Le.listRegisteredBindingsForServiceIdentifier(r, i, Je), new Error(o)
                }
            }(i.serviceIdentifier, a, i, n.container), a
    }

    function Ve(e, t, n, r, i, o) {
        var a, c;
        if (null === i) {
            a = He(e, t, r, null, o), c = new Fe.Request(n, r, null, a, o);
            var s = new je.Plan(r, c);
            r.addPlan(s)
        } else a = He(e, t, r, i, o), c = i.addChildRequest(o.serviceIdentifier, a, o);
        a.forEach((function(t) {
            var n = null;
            if (o.isArray()) n = c.addChildRequest(t.serviceIdentifier, t, o);
            else {
                if (t.cache) return;
                n = c
            }
            if (t.type === we.BindingTypeEnum.Instance && null !== t.implementationType) {
                var i = Ue.getDependencies(e, t.implementationType);
                if (!r.container.options.skipBaseClassChecks) {
                    var a = Ue.getBaseClassDependencyCount(e, t.implementationType);
                    if (i.length < a) {
                        var s = Pe.ARGUMENTS_LENGTH_MISMATCH(Ue.getFunctionName(t.implementationType));
                        throw new Error(s)
                    }
                }
                i.forEach((function(t) {
                    Ve(e, !1, t.serviceIdentifier, r, n, t)
                }))
            }
        }))
    }

    function Je(e, t) {
        var n = [],
            r = Ge(e);
        return r.hasKey(t) ? n = r.get(t) : null !== e.parent && (n = Je(e.parent, t)), n
    }
    H.getBindingDictionary = Ge, H.plan = function(e, t, n, r, i, o, a, c) {
        void 0 === c && (c = !1);
        var s = new De.Context(t),
            u = function(e, t, n, r, i, o) {
                var a = e ? ke.MULTI_INJECT_TAG : ke.INJECT_TAG,
                    c = new xe.Metadata(a, n),
                    s = new Be.Target(t, r, n, c);
                if (void 0 !== i) {
                    var u = new xe.Metadata(i, o);
                    s.metadata.push(u)
                }
                return s
            }(n, r, i, "", o, a);
        try {
            return Ve(e, c, i, s, null, u), s
        } catch (e) {
            throw Me.isStackOverflowExeption(e) && s.plan && Le.circularDependencyToException(s.plan.rootRequest), e
        }
    }, H.createMockRequest = function(e, t, n, r) {
        var i = new Be.Target(we.TargetTypeEnum.Variable, "", t, new xe.Metadata(n, r)),
            o = new De.Context(e);
        return new Fe.Request(t, o, null, [], i)
    };
    var Ke = {},
        We = {},
        Ye = N && N.__spreadArray || function(e, t) {
            for (var n = 0, r = t.length, i = e.length; n < r; n++, i++) e[i] = t[n];
            return e
        };
    Object.defineProperty(We, "__esModule", {
        value: !0
    }), We.resolveInstance = void 0;
    var qe = U,
        Xe = k,
        ze = C;
    We.resolveInstance = function(e, t, n) {
        var r, i, o = null;
        if (t.length > 0) {
            var a = t.filter((function(e) {
                return null !== e.target && e.target.type === Xe.TargetTypeEnum.ConstructorArgument
            })).map(n);
            i = a, o = function(e, t, n) {
                var r = t.filter((function(e) {
                        return null !== e.target && e.target.type === Xe.TargetTypeEnum.ClassProperty
                    })),
                    i = r.map(n);
                return r.forEach((function(t, n) {
                    var r;
                    r = t.target.name.value();
                    var o = i[n];
                    e[r] = o
                })), e
            }(o = new((r = e)._ttq_bind.apply(r, Ye([void 0], i))), t, n)
        } else o = new e;
        return function(e, t) {
            if (Reflect.ttq_hasMetadata(ze.POST_CONSTRUCT, e)) {
                var n = Reflect.ttq_getMetadata(ze.POST_CONSTRUCT, e);
                try {
                    t[n.value]()
                } catch (t) {
                    throw new Error(qe.POST_CONSTRUCT_ERROR(e.name, t.message))
                }
            }
        }(e, o), o
    }, Object.defineProperty(Ke, "__esModule", {
        value: !0
    }), Ke.resolve = void 0;
    var Qe = U,
        Ze = k,
        $e = J,
        et = W,
        tt = We,
        nt = function(e, t, n) {
            try {
                return n()
            } catch (n) {
                throw $e.isStackOverflowExeption(n) ? new Error(Qe.CIRCULAR_DEPENDENCY_IN_FACTORY(e, t.toString())) : n
            }
        },
        rt = function(e) {
            return function(t) {
                t.parentContext.setCurrentRequest(t);
                var n = t.bindings,
                    r = t.childRequests,
                    i = t.target && t.target.isArray(),
                    o = !(t.parentRequest && t.parentRequest.target && t.target && t.parentRequest.target.matchesArray(t.target.serviceIdentifier));
                if (i && o) return r.map((function(t) {
                    return rt(e)(t)
                }));
                var a = null;
                if (!t.target.isOptional() || 0 !== n.length) {
                    var c = n[0],
                        s = c.scope === Ze.BindingScopeEnum.Singleton,
                        u = c.scope === Ze.BindingScopeEnum.Request;
                    if (s && c.activated) return c.cache;
                    if (u && null !== e && e.has(c.id)) return e.get(c.id);
                    if (c.type === Ze.BindingTypeEnum.ConstantValue) a = c.cache, c.activated = !0;
                    else if (c.type === Ze.BindingTypeEnum.Function) a = c.cache, c.activated = !0;
                    else if (c.type === Ze.BindingTypeEnum.Constructor) a = c.implementationType;
                    else if (c.type === Ze.BindingTypeEnum.DynamicValue && null !== c.dynamicValue) a = nt("toDynamicValue", c.serviceIdentifier, (function() {
                        return c.dynamicValue(t.parentContext)
                    }));
                    else if (c.type === Ze.BindingTypeEnum.Factory && null !== c.factory) a = nt("toFactory", c.serviceIdentifier, (function() {
                        return c.factory(t.parentContext)
                    }));
                    else if (c.type === Ze.BindingTypeEnum.Provider && null !== c.provider) a = nt("toProvider", c.serviceIdentifier, (function() {
                        return c.provider(t.parentContext)
                    }));
                    else {
                        if (c.type !== Ze.BindingTypeEnum.Instance || null === c.implementationType) {
                            var l = et.getServiceIdentifierAsString(t.serviceIdentifier);
                            throw new Error(Qe.INVALID_BINDING_TYPE + " " + l)
                        }
                        a = tt.resolveInstance(c.implementationType, r, rt(e))
                    }
                    return "function" == typeof c.onActivation && (a = c.onActivation(t.parentContext, a)), s && (c.cache = a, c.activated = !0), u && null !== e && !e.has(c.id) && e.set(c.id, a), a
                }
            }
        };
    Ke.resolve = function(e) {
        return rt(e.plan.rootRequest.requestScope)(e.plan.rootRequest)
    };
    var it = {},
        ot = {},
        at = {},
        ct = {},
        st = {},
        ut = {},
        lt = {};
    Object.defineProperty(lt, "__esModule", {
        value: !0
    }), lt.typeConstraint = lt.namedConstraint = lt.taggedConstraint = lt.traverseAncerstors = void 0;
    var ft = C,
        dt = ee,
        ht = function(e, t) {
            var n = e.parentRequest;
            return null !== n && (!!t(n) || ht(n, t))
        };
    lt.traverseAncerstors = ht;
    var pt = function(e) {
        return function(t) {
            var n = function(n) {
                return null !== n && null !== n.target && n.target.matchesTag(e)(t)
            };
            return n.metaData = new dt.Metadata(e, t), n
        }
    };
    lt.taggedConstraint = pt;
    var vt = pt(ft.NAMED_TAG);
    lt.namedConstraint = vt;
    lt.typeConstraint = function(e) {
        return function(t) {
            var n = null;
            if (null !== t) {
                if (n = t.bindings[0], "string" == typeof e) return n.serviceIdentifier === e;
                var r = t.bindings[0].implementationType;
                return e === r
            }
            return !1
        }
    }, Object.defineProperty(ut, "__esModule", {
        value: !0
    }), ut.BindingWhenSyntax = void 0;
    var _t = st,
        gt = lt,
        yt = function() {
            function e(e) {
                this._binding = e
            }
            return e.prototype.when = function(e) {
                return this._binding.constraint = e, new _t.BindingOnSyntax(this._binding)
            }, e.prototype.whenTargetNamed = function(e) {
                return this._binding.constraint = gt.namedConstraint(e), new _t.BindingOnSyntax(this._binding)
            }, e.prototype.whenTargetIsDefault = function() {
                return this._binding.constraint = function(e) {
                    return null !== e.target && !e.target.isNamed() && !e.target.isTagged()
                }, new _t.BindingOnSyntax(this._binding)
            }, e.prototype.whenTargetTagged = function(e, t) {
                return this._binding.constraint = gt.taggedConstraint(e)(t), new _t.BindingOnSyntax(this._binding)
            }, e.prototype.whenInjectedInto = function(e) {
                return this._binding.constraint = function(t) {
                    return gt.typeConstraint(e)(t.parentRequest)
                }, new _t.BindingOnSyntax(this._binding)
            }, e.prototype.whenParentNamed = function(e) {
                return this._binding.constraint = function(t) {
                    return gt.namedConstraint(e)(t.parentRequest)
                }, new _t.BindingOnSyntax(this._binding)
            }, e.prototype.whenParentTagged = function(e, t) {
                return this._binding.constraint = function(n) {
                    return gt.taggedConstraint(e)(t)(n.parentRequest)
                }, new _t.BindingOnSyntax(this._binding)
            }, e.prototype.whenAnyAncestorIs = function(e) {
                return this._binding.constraint = function(t) {
                    return gt.traverseAncerstors(t, gt.typeConstraint(e))
                }, new _t.BindingOnSyntax(this._binding)
            }, e.prototype.whenNoAncestorIs = function(e) {
                return this._binding.constraint = function(t) {
                    return !gt.traverseAncerstors(t, gt.typeConstraint(e))
                }, new _t.BindingOnSyntax(this._binding)
            }, e.prototype.whenAnyAncestorNamed = function(e) {
                return this._binding.constraint = function(t) {
                    return gt.traverseAncerstors(t, gt.namedConstraint(e))
                }, new _t.BindingOnSyntax(this._binding)
            }, e.prototype.whenNoAncestorNamed = function(e) {
                return this._binding.constraint = function(t) {
                    return !gt.traverseAncerstors(t, gt.namedConstraint(e))
                }, new _t.BindingOnSyntax(this._binding)
            }, e.prototype.whenAnyAncestorTagged = function(e, t) {
                return this._binding.constraint = function(n) {
                    return gt.traverseAncerstors(n, gt.taggedConstraint(e)(t))
                }, new _t.BindingOnSyntax(this._binding)
            }, e.prototype.whenNoAncestorTagged = function(e, t) {
                return this._binding.constraint = function(n) {
                    return !gt.traverseAncerstors(n, gt.taggedConstraint(e)(t))
                }, new _t.BindingOnSyntax(this._binding)
            }, e.prototype.whenAnyAncestorMatches = function(e) {
                return this._binding.constraint = function(t) {
                    return gt.traverseAncerstors(t, e)
                }, new _t.BindingOnSyntax(this._binding)
            }, e.prototype.whenNoAncestorMatches = function(e) {
                return this._binding.constraint = function(t) {
                    return !gt.traverseAncerstors(t, e)
                }, new _t.BindingOnSyntax(this._binding)
            }, e
        }();
    ut.BindingWhenSyntax = yt, Object.defineProperty(st, "__esModule", {
        value: !0
    }), st.BindingOnSyntax = void 0;
    var mt = ut,
        Et = function() {
            function e(e) {
                this._binding = e
            }
            return e.prototype.onActivation = function(e) {
                return this._binding.onActivation = e, new mt.BindingWhenSyntax(this._binding)
            }, e
        }();
    st.BindingOnSyntax = Et, Object.defineProperty(ct, "__esModule", {
        value: !0
    }), ct.BindingWhenOnSyntax = void 0;
    var bt = st,
        Tt = ut,
        It = function() {
            function e(e) {
                this._binding = e, this._bindingWhenSyntax = new Tt.BindingWhenSyntax(this._binding), this._bindingOnSyntax = new bt.BindingOnSyntax(this._binding)
            }
            return e.prototype.when = function(e) {
                return this._bindingWhenSyntax.when(e)
            }, e.prototype.whenTargetNamed = function(e) {
                return this._bindingWhenSyntax.whenTargetNamed(e)
            }, e.prototype.whenTargetIsDefault = function() {
                return this._bindingWhenSyntax.whenTargetIsDefault()
            }, e.prototype.whenTargetTagged = function(e, t) {
                return this._bindingWhenSyntax.whenTargetTagged(e, t)
            }, e.prototype.whenInjectedInto = function(e) {
                return this._bindingWhenSyntax.whenInjectedInto(e)
            }, e.prototype.whenParentNamed = function(e) {
                return this._bindingWhenSyntax.whenParentNamed(e)
            }, e.prototype.whenParentTagged = function(e, t) {
                return this._bindingWhenSyntax.whenParentTagged(e, t)
            }, e.prototype.whenAnyAncestorIs = function(e) {
                return this._bindingWhenSyntax.whenAnyAncestorIs(e)
            }, e.prototype.whenNoAncestorIs = function(e) {
                return this._bindingWhenSyntax.whenNoAncestorIs(e)
            }, e.prototype.whenAnyAncestorNamed = function(e) {
                return this._bindingWhenSyntax.whenAnyAncestorNamed(e)
            }, e.prototype.whenAnyAncestorTagged = function(e, t) {
                return this._bindingWhenSyntax.whenAnyAncestorTagged(e, t)
            }, e.prototype.whenNoAncestorNamed = function(e) {
                return this._bindingWhenSyntax.whenNoAncestorNamed(e)
            }, e.prototype.whenNoAncestorTagged = function(e, t) {
                return this._bindingWhenSyntax.whenNoAncestorTagged(e, t)
            }, e.prototype.whenAnyAncestorMatches = function(e) {
                return this._bindingWhenSyntax.whenAnyAncestorMatches(e)
            }, e.prototype.whenNoAncestorMatches = function(e) {
                return this._bindingWhenSyntax.whenNoAncestorMatches(e)
            }, e.prototype.onActivation = function(e) {
                return this._bindingOnSyntax.onActivation(e)
            }, e
        }();
    ct.BindingWhenOnSyntax = It, Object.defineProperty(at, "__esModule", {
        value: !0
    }), at.BindingInSyntax = void 0;
    var Ot = k,
        St = ct,
        Nt = function() {
            function e(e) {
                this._binding = e
            }
            return e.prototype.inRequestScope = function() {
                return this._binding.scope = Ot.BindingScopeEnum.Request, new St.BindingWhenOnSyntax(this._binding)
            }, e.prototype.inSingletonScope = function() {
                return this._binding.scope = Ot.BindingScopeEnum.Singleton, new St.BindingWhenOnSyntax(this._binding)
            }, e.prototype.inTransientScope = function() {
                return this._binding.scope = Ot.BindingScopeEnum.Transient, new St.BindingWhenOnSyntax(this._binding)
            }, e
        }();
    at.BindingInSyntax = Nt, Object.defineProperty(ot, "__esModule", {
        value: !0
    }), ot.BindingInWhenOnSyntax = void 0;
    var Rt = at,
        At = st,
        Ct = ut,
        Pt = function() {
            function e(e) {
                this._binding = e, this._bindingWhenSyntax = new Ct.BindingWhenSyntax(this._binding), this._bindingOnSyntax = new At.BindingOnSyntax(this._binding), this._bindingInSyntax = new Rt.BindingInSyntax(e)
            }
            return e.prototype.inRequestScope = function() {
                return this._bindingInSyntax.inRequestScope()
            }, e.prototype.inSingletonScope = function() {
                return this._bindingInSyntax.inSingletonScope()
            }, e.prototype.inTransientScope = function() {
                return this._bindingInSyntax.inTransientScope()
            }, e.prototype.when = function(e) {
                return this._bindingWhenSyntax.when(e)
            }, e.prototype.whenTargetNamed = function(e) {
                return this._bindingWhenSyntax.whenTargetNamed(e)
            }, e.prototype.whenTargetIsDefault = function() {
                return this._bindingWhenSyntax.whenTargetIsDefault()
            }, e.prototype.whenTargetTagged = function(e, t) {
                return this._bindingWhenSyntax.whenTargetTagged(e, t)
            }, e.prototype.whenInjectedInto = function(e) {
                return this._bindingWhenSyntax.whenInjectedInto(e)
            }, e.prototype.whenParentNamed = function(e) {
                return this._bindingWhenSyntax.whenParentNamed(e)
            }, e.prototype.whenParentTagged = function(e, t) {
                return this._bindingWhenSyntax.whenParentTagged(e, t)
            }, e.prototype.whenAnyAncestorIs = function(e) {
                return this._bindingWhenSyntax.whenAnyAncestorIs(e)
            }, e.prototype.whenNoAncestorIs = function(e) {
                return this._bindingWhenSyntax.whenNoAncestorIs(e)
            }, e.prototype.whenAnyAncestorNamed = function(e) {
                return this._bindingWhenSyntax.whenAnyAncestorNamed(e)
            }, e.prototype.whenAnyAncestorTagged = function(e, t) {
                return this._bindingWhenSyntax.whenAnyAncestorTagged(e, t)
            }, e.prototype.whenNoAncestorNamed = function(e) {
                return this._bindingWhenSyntax.whenNoAncestorNamed(e)
            }, e.prototype.whenNoAncestorTagged = function(e, t) {
                return this._bindingWhenSyntax.whenNoAncestorTagged(e, t)
            }, e.prototype.whenAnyAncestorMatches = function(e) {
                return this._bindingWhenSyntax.whenAnyAncestorMatches(e)
            }, e.prototype.whenNoAncestorMatches = function(e) {
                return this._bindingWhenSyntax.whenNoAncestorMatches(e)
            }, e.prototype.onActivation = function(e) {
                return this._bindingOnSyntax.onActivation(e)
            }, e
        }();
    ot.BindingInWhenOnSyntax = Pt, Object.defineProperty(it, "__esModule", {
        value: !0
    }), it.BindingToSyntax = void 0;
    var wt = U,
        kt = k,
        Mt = ot,
        Lt = ct,
        Dt = function() {
            function e(e) {
                this._binding = e
            }
            return e.prototype.to = function(e) {
                return this._binding.type = kt.BindingTypeEnum.Instance, this._binding.implementationType = e, new Mt.BindingInWhenOnSyntax(this._binding)
            }, e.prototype.toSelf = function() {
                if ("function" != typeof this._binding.serviceIdentifier) throw new Error("" + wt.INVALID_TO_SELF_VALUE);
                var e = this._binding.serviceIdentifier;
                return this.to(e)
            }, e.prototype.toConstantValue = function(e) {
                return this._binding.type = kt.BindingTypeEnum.ConstantValue, this._binding.cache = e, this._binding.dynamicValue = null, this._binding.implementationType = null, this._binding.scope = kt.BindingScopeEnum.Singleton, new Lt.BindingWhenOnSyntax(this._binding)
            }, e.prototype.toDynamicValue = function(e) {
                return this._binding.type = kt.BindingTypeEnum.DynamicValue, this._binding.cache = null, this._binding.dynamicValue = e, this._binding.implementationType = null, new Mt.BindingInWhenOnSyntax(this._binding)
            }, e.prototype.toConstructor = function(e) {
                return this._binding.type = kt.BindingTypeEnum.Constructor, this._binding.implementationType = e, this._binding.scope = kt.BindingScopeEnum.Singleton, new Lt.BindingWhenOnSyntax(this._binding)
            }, e.prototype.toFactory = function(e) {
                return this._binding.type = kt.BindingTypeEnum.Factory, this._binding.factory = e, this._binding.scope = kt.BindingScopeEnum.Singleton, new Lt.BindingWhenOnSyntax(this._binding)
            }, e.prototype.toFunction = function(e) {
                if ("function" != typeof e) throw new Error(wt.INVALID_FUNCTION_BINDING);
                var t = this.toConstantValue(e);
                return this._binding.type = kt.BindingTypeEnum.Function, this._binding.scope = kt.BindingScopeEnum.Singleton, t
            }, e.prototype.toAutoFactory = function(e) {
                return this._binding.type = kt.BindingTypeEnum.Factory, this._binding.factory = function(t) {
                    return function() {
                        return t.container.get(e)
                    }
                }, this._binding.scope = kt.BindingScopeEnum.Singleton, new Lt.BindingWhenOnSyntax(this._binding)
            }, e.prototype.toProvider = function(e) {
                return this._binding.type = kt.BindingTypeEnum.Provider, this._binding.provider = e, this._binding.scope = kt.BindingScopeEnum.Singleton, new Lt.BindingWhenOnSyntax(this._binding)
            }, e.prototype.toService = function(e) {
                this.toDynamicValue((function(t) {
                    return t.container.get(e)
                }))
            }, e
        }();
    it.BindingToSyntax = Dt;
    var xt = {};
    Object.defineProperty(xt, "__esModule", {
        value: !0
    }), xt.ContainerSnapshot = void 0;
    var jt = function() {
        function e() {}
        return e.of = function(t, n) {
            var r = new e;
            return r.bindings = t, r.middleware = n, r
        }, e
    }();
    xt.ContainerSnapshot = jt;
    var Ut = {};
    Object.defineProperty(Ut, "__esModule", {
        value: !0
    }), Ut.Lookup = void 0;
    var Ft = U,
        Bt = function() {
            function e() {
                this._map = new window[window.TiktokAnalyticsObject || "ttq"]._ttq_map
            }
            return e.prototype.getMap = function() {
                return this._map
            }, e.prototype.add = function(e, t) {
                if (null == e) throw new Error(Ft.NULL_ARGUMENT);
                if (null == t) throw new Error(Ft.NULL_ARGUMENT);
                var n = this._map.get(e);
                void 0 !== n ? (n.push(t), this._map.set(e, n)) : this._map.set(e, [t])
            }, e.prototype.get = function(e) {
                if (null == e) throw new Error(Ft.NULL_ARGUMENT);
                var t = this._map.get(e);
                if (void 0 !== t) return t;
                throw new Error(Ft.KEY_NOT_FOUND)
            }, e.prototype.remove = function(e) {
                if (null == e) throw new Error(Ft.NULL_ARGUMENT);
                if (!this._map.delete(e)) throw new Error(Ft.KEY_NOT_FOUND)
            }, e.prototype.removeByCondition = function(e) {
                var t = this;
                this._map.forEach((function(n, r) {
                    var i = n.filter((function(t) {
                        return !e(t)
                    }));
                    i.length > 0 ? t._map.set(r, i) : t._map.delete(r)
                }))
            }, e.prototype.hasKey = function(e) {
                if (null == e) throw new Error(Ft.NULL_ARGUMENT);
                return this._map.has(e)
            }, e.prototype.clone = function() {
                var t = new e;
                return this._map.forEach((function(e, n) {
                    e.forEach((function(e) {
                        return t.add(n, e.clone())
                    }))
                })), t
            }, e.prototype.traverse = function(e) {
                this._map.forEach((function(t, n) {
                    e(n, t)
                }))
            }, e
        }();
    Ut.Lookup = Bt;
    var Gt = N && N.__awaiter || function(e, t, n, r) {
            return new(n || (n = Promise))((function(i, o) {
                function a(e) {
                    try {
                        s(r.next(e))
                    } catch (e) {
                        o(e)
                    }
                }

                function c(e) {
                    try {
                        s(r.throw(e))
                    } catch (e) {
                        o(e)
                    }
                }

                function s(e) {
                    var t;
                    e.done ? i(e.value) : (t = e.value, t instanceof n ? t : new n((function(e) {
                        e(t)
                    }))).then(a, c)
                }
                s((r = r.apply(e, t || [])).next())
            }))
        },
        Ht = N && N.__generator || function(e, t) {
            var n, r, i, o, a = {
                label: 0,
                sent: function() {
                    if (1 & i[0]) throw i[1];
                    return i[1]
                },
                trys: [],
                ops: []
            };
            return o = {
                next: c(0),
                throw: c(1),
                return: c(2)
            }, "function" == typeof Symbol && (o[Symbol.iterator] = function() {
                return this
            }), o;

            function c(o) {
                return function(c) {
                    return function(o) {
                        if (n) throw new TypeError("Generator is already executing.");
                        for (; a;) try {
                            if (n = 1, r && (i = 2 & o[0] ? r.return : o[0] ? r.throw || ((i = r.return) && i.call(r), 0) : r.next) && !(i = i.call(r, o[1])).done) return i;
                            switch (r = 0, i && (o = [2 & o[0], i.value]), o[0]) {
                                case 0:
                                case 1:
                                    i = o;
                                    break;
                                case 4:
                                    return a.label++, {
                                        value: o[1],
                                        done: !1
                                    };
                                case 5:
                                    a.label++, r = o[1], o = [0];
                                    continue;
                                case 7:
                                    o = a.ops.pop(), a.trys.pop();
                                    continue;
                                default:
                                    if (!(i = a.trys, (i = i.length > 0 && i[i.length - 1]) || 6 !== o[0] && 2 !== o[0])) {
                                        a = 0;
                                        continue
                                    }
                                    if (3 === o[0] && (!i || o[1] > i[0] && o[1] < i[3])) {
                                        a.label = o[1];
                                        break
                                    }
                                    if (6 === o[0] && a.label < i[1]) {
                                        a.label = i[1], i = o;
                                        break
                                    }
                                    if (i && a.label < i[2]) {
                                        a.label = i[2], a.ops.push(o);
                                        break
                                    }
                                    i[2] && a.ops.pop(), a.trys.pop();
                                    continue
                            }
                            o = t.call(e, a)
                        } catch (e) {
                            o = [6, e], r = 0
                        } finally {
                            n = i = 0
                        }
                        if (5 & o[0]) throw o[1];
                        return {
                            value: o[0] ? o[1] : void 0,
                            done: !0
                        }
                    }([o, c])
                }
            }
        },
        Vt = N && N.__spreadArray || function(e, t) {
            for (var n = 0, r = t.length, i = e.length; n < r; n++, i++) e[i] = t[n];
            return e
        };
    Object.defineProperty(P, "__esModule", {
        value: !0
    }), P.Container = void 0;
    var Jt = w,
        Kt = U,
        Wt = k,
        Yt = C,
        qt = F,
        Xt = H,
        zt = Ke,
        Qt = it,
        Zt = M,
        $t = W,
        en = xt,
        tn = Ut,
        nn = function() {
            function e(e) {
                this._appliedMiddleware = [];
                var t = e || {};
                if ("object" != typeof t) throw new Error("" + Kt.CONTAINER_OPTIONS_MUST_BE_AN_OBJECT);
                if (void 0 === t.defaultScope) t.defaultScope = Wt.BindingScopeEnum.Transient;
                else if (t.defaultScope !== Wt.BindingScopeEnum.Singleton && t.defaultScope !== Wt.BindingScopeEnum.Transient && t.defaultScope !== Wt.BindingScopeEnum.Request) throw new Error("" + Kt.CONTAINER_OPTIONS_INVALID_DEFAULT_SCOPE);
                if (void 0 === t.autoBindInjectable) t.autoBindInjectable = !1;
                else if ("boolean" != typeof t.autoBindInjectable) throw new Error("" + Kt.CONTAINER_OPTIONS_INVALID_AUTO_BIND_INJECTABLE);
                if (void 0 === t.skipBaseClassChecks) t.skipBaseClassChecks = !1;
                else if ("boolean" != typeof t.skipBaseClassChecks) throw new Error("" + Kt.CONTAINER_OPTIONS_INVALID_SKIP_BASE_CHECK);
                this.options = {
                    autoBindInjectable: t.autoBindInjectable,
                    defaultScope: t.defaultScope,
                    skipBaseClassChecks: t.skipBaseClassChecks
                }, this.id = Zt.id(), this._bindingDictionary = new tn.Lookup, this._snapshots = [], this._middleware = null, this.parent = null, this._metadataReader = new qt.MetadataReader
            }
            return e.merge = function(t, n) {
                for (var r = [], i = 2; i < arguments.length; i++) r[i - 2] = arguments[i];
                var o = new e,
                    a = Vt([t, n], r).map((function(e) {
                        return Xt.getBindingDictionary(e)
                    })),
                    c = Xt.getBindingDictionary(o);

                function s(e, t) {
                    e.traverse((function(e, n) {
                        n.forEach((function(e) {
                            t.add(e.serviceIdentifier, e.clone())
                        }))
                    }))
                }
                return a.forEach((function(e) {
                    s(e, c)
                })), o
            }, e.prototype.load = function() {
                for (var e = [], t = 0; t < arguments.length; t++) e[t] = arguments[t];
                for (var n = this._getContainerModuleHelpersFactory(), r = 0, i = e; r < i.length; r++) {
                    var o = i[r],
                        a = n(o.id);
                    o.registry(a.bindFunction, a.unbindFunction, a.isboundFunction, a.rebindFunction)
                }
            }, e.prototype.loadAsync = function() {
                for (var e = [], t = 0; t < arguments.length; t++) e[t] = arguments[t];
                return Gt(this, void 0, void 0, (function() {
                    var t, n, r, i, o;
                    return Ht(this, (function(a) {
                        switch (a.label) {
                            case 0:
                                t = this._getContainerModuleHelpersFactory(), n = 0, r = e, a.label = 1;
                            case 1:
                                return n < r.length ? (i = r[n], o = t(i.id), [4, i.registry(o.bindFunction, o.unbindFunction, o.isboundFunction, o.rebindFunction)]) : [3, 4];
                            case 2:
                                a.sent(), a.label = 3;
                            case 3:
                                return n++, [3, 1];
                            case 4:
                                return [2]
                        }
                    }))
                }))
            }, e.prototype.unload = function() {
                for (var e = this, t = [], n = 0; n < arguments.length; n++) t[n] = arguments[n];
                var r = function(e) {
                    return function(t) {
                        return t.moduleId === e
                    }
                };
                t.forEach((function(t) {
                    var n = r(t.id);
                    e._bindingDictionary.removeByCondition(n)
                }))
            }, e.prototype.bind = function(e) {
                var t = this.options.defaultScope || Wt.BindingScopeEnum.Transient,
                    n = new Jt.Binding(e, t);
                return this._bindingDictionary.add(e, n), new Qt.BindingToSyntax(n)
            }, e.prototype.rebind = function(e) {
                return this.unbind(e), this.bind(e)
            }, e.prototype.unbind = function(e) {
                try {
                    this._bindingDictionary.remove(e)
                } catch (t) {
                    throw new Error(Kt.CANNOT_UNBIND + " " + $t.getServiceIdentifierAsString(e))
                }
            }, e.prototype.unbindAll = function() {
                this._bindingDictionary = new tn.Lookup
            }, e.prototype.isBound = function(e) {
                var t = this._bindingDictionary.hasKey(e);
                return !t && this.parent && (t = this.parent.isBound(e)), t
            }, e.prototype.isBoundNamed = function(e, t) {
                return this.isBoundTagged(e, Yt.NAMED_TAG, t)
            }, e.prototype.isBoundTagged = function(e, t, n) {
                var r = !1;
                if (this._bindingDictionary.hasKey(e)) {
                    var i = this._bindingDictionary.get(e),
                        o = Xt.createMockRequest(this, e, t, n);
                    r = i.some((function(e) {
                        return e.constraint(o)
                    }))
                }
                return !r && this.parent && (r = this.parent.isBoundTagged(e, t, n)), r
            }, e.prototype.snapshot = function() {
                this._snapshots.push(en.ContainerSnapshot.of(this._bindingDictionary.clone(), this._middleware))
            }, e.prototype.restore = function() {
                var e = this._snapshots.pop();
                if (void 0 === e) throw new Error(Kt.NO_MORE_SNAPSHOTS_AVAILABLE);
                this._bindingDictionary = e.bindings, this._middleware = e.middleware
            }, e.prototype.createChild = function(t) {
                var n = new e(t || this.options);
                return n.parent = this, n
            }, e.prototype.applyMiddleware = function() {
                for (var e = [], t = 0; t < arguments.length; t++) e[t] = arguments[t];
                this._appliedMiddleware = this._appliedMiddleware.concat(e);
                var n = this._middleware ? this._middleware : this._planAndResolve();
                this._middleware = e.reduce((function(e, t) {
                    return t(e)
                }), n)
            }, e.prototype.applyCustomMetadataReader = function(e) {
                this._metadataReader = e
            }, e.prototype.get = function(e) {
                return this._get(!1, !1, Wt.TargetTypeEnum.Variable, e)
            }, e.prototype.getTagged = function(e, t, n) {
                return this._get(!1, !1, Wt.TargetTypeEnum.Variable, e, t, n)
            }, e.prototype.getNamed = function(e, t) {
                return this.getTagged(e, Yt.NAMED_TAG, t)
            }, e.prototype.getAll = function(e) {
                return this._get(!0, !0, Wt.TargetTypeEnum.Variable, e)
            }, e.prototype.getAllTagged = function(e, t, n) {
                return this._get(!1, !0, Wt.TargetTypeEnum.Variable, e, t, n)
            }, e.prototype.getAllNamed = function(e, t) {
                return this.getAllTagged(e, Yt.NAMED_TAG, t)
            }, e.prototype.resolve = function(e) {
                var t = this.createChild();
                return t.bind(e).toSelf(), this._appliedMiddleware.forEach((function(e) {
                    t.applyMiddleware(e)
                })), t.get(e)
            }, e.prototype._getContainerModuleHelpersFactory = function() {
                var e = this,
                    t = function(e, t) {
                        e._binding.moduleId = t
                    },
                    n = function(n) {
                        return function(r) {
                            var i = e.rebind.bind(e)(r);
                            return t(i, n), i
                        }
                    };
                return function(r) {
                    return {
                        bindFunction: (i = r, function(n) {
                            var r = e.bind.bind(e)(n);
                            return t(r, i), r
                        }),
                        isboundFunction: function(t) {
                            return e.isBound.bind(e)(t)
                        },
                        rebindFunction: n(r),
                        unbindFunction: function(t) {
                            e.unbind.bind(e)(t)
                        }
                    };
                    var i
                }
            }, e.prototype._get = function(e, t, n, r, i, o) {
                var a = null,
                    c = {
                        avoidConstraints: e,
                        contextInterceptor: function(e) {
                            return e
                        },
                        isMultiInject: t,
                        key: i,
                        serviceIdentifier: r,
                        targetType: n,
                        value: o
                    };
                if (this._middleware) {
                    if (null == (a = this._middleware(c))) throw new Error(Kt.INVALID_MIDDLEWARE_RETURN)
                } else a = this._planAndResolve()(c);
                return a
            }, e.prototype._planAndResolve = function() {
                var e = this;
                return function(t) {
                    var n = Xt.plan(e._metadataReader, e, t.isMultiInject, t.targetType, t.serviceIdentifier, t.key, t.value, t.avoidConstraints);
                    return n = t.contextInterceptor(n), zt.resolve(n)
                }
            }, e
        }();
    P.Container = nn;
    var rn = {};
    Object.defineProperty(rn, "__esModule", {
        value: !0
    }), rn.AsyncContainerModule = rn.ContainerModule = void 0;
    var on = M,
        an = function(e) {
            this.id = on.id(), this.registry = e
        };
    rn.ContainerModule = an;
    var cn = function(e) {
        this.id = on.id(), this.registry = e
    };
    rn.AsyncContainerModule = cn;
    var sn = {};
    Object.defineProperty(sn, "__esModule", {
        value: !0
    }), sn.injectable = void 0;
    var un = U,
        ln = C;
    sn.injectable = function() {
        return function(e) {
            if (Reflect.ttq_hasOwnMetadata(ln.PARAM_TYPES, e)) throw new Error(un.DUPLICATED_INJECTABLE_DECORATOR);
            var t = Reflect.ttq_getMetadata(ln.DESIGN_PARAM_TYPES, e) || [];
            return Reflect.ttq_defineMetadata(ln.PARAM_TYPES, t, e), e
        }
    };
    var fn = {};
    Object.defineProperty(fn, "__esModule", {
        value: !0
    }), fn.tagged = void 0;
    var dn = ee,
        hn = ce;
    fn.tagged = function(e, t) {
        return function(n, r, i) {
            var o = new dn.Metadata(e, t);
            "number" == typeof i ? hn.tagParameter(n, r, i, o) : hn.tagProperty(n, r, o)
        }
    };
    var pn = {};
    Object.defineProperty(pn, "__esModule", {
        value: !0
    }), pn.named = void 0;
    var vn = C,
        _n = ee,
        gn = ce;
    pn.named = function(e) {
        return function(t, n, r) {
            var i = new _n.Metadata(vn.NAMED_TAG, e);
            "number" == typeof r ? gn.tagParameter(t, n, r, i) : gn.tagProperty(t, n, i)
        }
    };
    var yn = {};
    Object.defineProperty(yn, "__esModule", {
        value: !0
    }), yn.optional = void 0;
    var mn = C,
        En = ee,
        bn = ce;
    yn.optional = function() {
        return function(e, t, n) {
            var r = new En.Metadata(mn.OPTIONAL_TAG, !0);
            "number" == typeof n ? bn.tagParameter(e, t, n, r) : bn.tagProperty(e, t, r)
        }
    };
    var Tn = {};
    Object.defineProperty(Tn, "__esModule", {
        value: !0
    }), Tn.unmanaged = void 0;
    var In = C,
        On = ee,
        Sn = ce;
    Tn.unmanaged = function() {
        return function(e, t, n) {
            var r = new On.Metadata(In.UNMANAGED_TAG, !0);
            Sn.tagParameter(e, t, n, r)
        }
    };
    var Nn = {};
    Object.defineProperty(Nn, "__esModule", {
        value: !0
    }), Nn.multiInject = void 0;
    var Rn = C,
        An = ee,
        Cn = ce;
    Nn.multiInject = function(e) {
        return function(t, n, r) {
            var i = new An.Metadata(Rn.MULTI_INJECT_TAG, e);
            "number" == typeof r ? Cn.tagParameter(t, n, r, i) : Cn.tagProperty(t, n, i)
        }
    };
    var Pn = {};
    Object.defineProperty(Pn, "__esModule", {
        value: !0
    }), Pn.targetName = void 0;
    var wn = C,
        kn = ee,
        Mn = ce;
    Pn.targetName = function(e) {
        return function(t, n, r) {
            var i = new kn.Metadata(wn.NAME_TAG, e);
            Mn.tagParameter(t, n, r, i)
        }
    };
    var Ln = {};
    Object.defineProperty(Ln, "__esModule", {
        value: !0
    }), Ln.postConstruct = void 0;
    var Dn = U,
        xn = C,
        jn = ee;
    Ln.postConstruct = function() {
        return function(e, t, n) {
            var r = new jn.Metadata(xn.POST_CONSTRUCT, t);
            if (Reflect.ttq_hasOwnMetadata(xn.POST_CONSTRUCT, e.constructor)) throw new Error(Dn.MULTIPLE_POST_CONSTRUCT_METHODS);
            Reflect.ttq_defineMetadata(xn.POST_CONSTRUCT, r, e.constructor)
        }
    };
    var Un = {};
    Object.defineProperty(Un, "__esModule", {
        value: !0
    }), Un.multiBindToService = void 0;
    Un.multiBindToService = function(e) {
            return function(t) {
                return function() {
                    for (var n = [], r = 0; r < arguments.length; r++) n[r] = arguments[r];
                    return n.forEach((function(n) {
                        return e.bind(n).toService(t)
                    }))
                }
            }
        },
        function(e) {
            Object.defineProperty(e, "__esModule", {
                value: !0
            }), e.multiBindToService = e.getServiceIdentifierAsString = e.typeConstraint = e.namedConstraint = e.taggedConstraint = e.traverseAncerstors = e.decorate = e.id = e.MetadataReader = e.postConstruct = e.targetName = e.multiInject = e.unmanaged = e.optional = e.LazyServiceIdentifer = e.inject = e.named = e.tagged = e.injectable = e.ContainerModule = e.AsyncContainerModule = e.TargetTypeEnum = e.BindingTypeEnum = e.BindingScopeEnum = e.Container = e.METADATA_KEY = void 0;
            var t = C;
            e.METADATA_KEY = t;
            var n = P;
            Object.defineProperty(e, "Container", {
                enumerable: !0,
                get: function() {
                    return n.Container
                }
            });
            var r = k;
            Object.defineProperty(e, "BindingScopeEnum", {
                enumerable: !0,
                get: function() {
                    return r.BindingScopeEnum
                }
            }), Object.defineProperty(e, "BindingTypeEnum", {
                enumerable: !0,
                get: function() {
                    return r.BindingTypeEnum
                }
            }), Object.defineProperty(e, "TargetTypeEnum", {
                enumerable: !0,
                get: function() {
                    return r.TargetTypeEnum
                }
            });
            var i = rn;
            Object.defineProperty(e, "AsyncContainerModule", {
                enumerable: !0,
                get: function() {
                    return i.AsyncContainerModule
                }
            }), Object.defineProperty(e, "ContainerModule", {
                enumerable: !0,
                get: function() {
                    return i.ContainerModule
                }
            });
            var o = sn;
            Object.defineProperty(e, "injectable", {
                enumerable: !0,
                get: function() {
                    return o.injectable
                }
            });
            var a = fn;
            Object.defineProperty(e, "tagged", {
                enumerable: !0,
                get: function() {
                    return a.tagged
                }
            });
            var c = pn;
            Object.defineProperty(e, "named", {
                enumerable: !0,
                get: function() {
                    return c.named
                }
            });
            var s = ae;
            Object.defineProperty(e, "inject", {
                enumerable: !0,
                get: function() {
                    return s.inject
                }
            }), Object.defineProperty(e, "LazyServiceIdentifer", {
                enumerable: !0,
                get: function() {
                    return s.LazyServiceIdentifer
                }
            });
            var u = yn;
            Object.defineProperty(e, "optional", {
                enumerable: !0,
                get: function() {
                    return u.optional
                }
            });
            var l = Tn;
            Object.defineProperty(e, "unmanaged", {
                enumerable: !0,
                get: function() {
                    return l.unmanaged
                }
            });
            var f = Nn;
            Object.defineProperty(e, "multiInject", {
                enumerable: !0,
                get: function() {
                    return f.multiInject
                }
            });
            var d = Pn;
            Object.defineProperty(e, "targetName", {
                enumerable: !0,
                get: function() {
                    return d.targetName
                }
            });
            var h = Ln;
            Object.defineProperty(e, "postConstruct", {
                enumerable: !0,
                get: function() {
                    return h.postConstruct
                }
            });
            var p = F;
            Object.defineProperty(e, "MetadataReader", {
                enumerable: !0,
                get: function() {
                    return p.MetadataReader
                }
            });
            var v = M;
            Object.defineProperty(e, "id", {
                enumerable: !0,
                get: function() {
                    return v.id
                }
            });
            var _ = ce;
            Object.defineProperty(e, "decorate", {
                enumerable: !0,
                get: function() {
                    return _.decorate
                }
            });
            var g = lt;
            Object.defineProperty(e, "traverseAncerstors", {
                enumerable: !0,
                get: function() {
                    return g.traverseAncerstors
                }
            }), Object.defineProperty(e, "taggedConstraint", {
                enumerable: !0,
                get: function() {
                    return g.taggedConstraint
                }
            }), Object.defineProperty(e, "namedConstraint", {
                enumerable: !0,
                get: function() {
                    return g.namedConstraint
                }
            }), Object.defineProperty(e, "typeConstraint", {
                enumerable: !0,
                get: function() {
                    return g.typeConstraint
                }
            });
            var y = W;
            Object.defineProperty(e, "getServiceIdentifierAsString", {
                enumerable: !0,
                get: function() {
                    return y.getServiceIdentifierAsString
                }
            });
            var m = Un;
            Object.defineProperty(e, "multiBindToService", {
                enumerable: !0,
                get: function() {
                    return m.multiBindToService
                }
            })
        }(A);
    var Fn, Bn, Gn, Hn, Vn, Jn, Kn, Wn, Yn, qn, Xn = ["ttuts", "ad_info_from"];
    ! function(e) {
        e.LDU = "limited_data_use", e.EVENTID = "eventID", e.EVENT_ID = "event_id"
    }(Fn || (Fn = {})),
    function(e) {
        e[e.defaultReport = 0] = "defaultReport", e[e.httpReport = 1] = "httpReport", e[e.htmlHttpReport = 2] = "htmlHttpReport"
    }(Bn || (Bn = {})),
    function(e) {
        e.Normal = "1", e.Iframe = "2", e.WebWorker = "3", e.SandboxIframe = "4"
    }(Gn || (Gn = {})),
    function(e) {
        e.EMPTY_VALUE = "empty_value", e.WRONG_FORMAT = "wrong_format", e.CORRECT_FORMAT = "correct_format", e.HASHED = "hashed", e.HASHED_ERR = "hashed_err", e.HASHED_CORRECT = "hashed_correct", e.PLAINTEXT_EMAIL = "plaintext_email", e.PLAINTEXT_PHONE = "plaintext_phone"
    }(Hn || (Hn = {})),
    function(e) {
        e.EMPTY_VALUE = "empty_value", e.PLAIN_EMAIL = "plain_email", e.PLAIN_PHONE = "plain_phone", e.HASHED = "hashed", e.FILTER_EVENTS = "filter_events", e.UNKNOWN_INVALID = "unknown_invalid", e.BASE64_STRING_HASHED = "base64_string_hashed", e.BASE64_HEX_HASHED = "base64_hex_hashed", e.PLAIN_MDN_EMAIL = "plain_mdn_email", e.ZIP_CODE_IS_NOT_HASHED = "zip_code_is_not_hashed", e.ZIP_CODE_IS_NOT_US = "zip_code_is_not_us", e.ZIP_CODE_IS_HASHED = "zip_code_is_hashed", e.ZIP_CODE_IS_US = "zip_code_is_us"
    }(Vn || (Vn = {})),
    function(e) {
        e.Manual = "manual", e.ManualV2 = "manual_v2", e.Auto = "auto"
    }(Jn || (Jn = {})),
    function(e) {
        e.empty = "empty", e.whitespace = "whitespace", e.hardcode = "hardcode", e.encode = "encode"
    }(Kn || (Kn = {})),
    function(e) {
        e.letterCase = "letter_case", e.isNotValidEmail = "is_not_valid_email", e.isNotPossibleEmail = "is_not_possible_email", e.domainTypo = "domain_typo", e.addressFormat = "address_format"
    }(Wn || (Wn = {})),
    function(e) {
        e.invalidCountry = "invalid_country", e.notANumber = "not_a_number", e.tooShort = "too_short", e.tooLong = "too_long", e.invalidLength = "invalid_length", e.emptyCountryCodeThroughIP = "empty_country_code_through_ip", e.invalidCountryAfterInjectPlus = "invalid_country_after_inject_plus", e.notANumberAfterInjectPlus = "not_a_number_after_inject_plus", e.tooShortAfterInjectPlus = "too_short_after_inject_plus", e.tooLongAfterInjectPlus = "too_long_after_inject_plus", e.invalidLengthAfterInjectPlus = "invalid_length_after_inject_plus", e.invalidCountryAfterInjectCountry = "invalid_country_after_inject_country", e.notANumberAfterInjectCountry = "not_a_number_after_inject_country", e.tooShortAfterInjectCountry = "too_short_after_inject_country", e.tooLongAfterInjectCountry = "too_long_after_inject_country", e.invalidLengthAfterInjectCountry = "invalid_length_after_inject_country"
    }(Yn || (Yn = {})),
    function(e) {
        e.missing = "missing", e.valid = "valid", e.invalid = "invalid"
    }(qn || (qn = {}));
    var zn, Qn, Zn = {
        raw_email: {
            label: qn.missing
        },
        raw_auto_email: {
            label: qn.missing
        },
        raw_phone: {
            label: qn.missing
        },
        raw_auto_phone: {
            label: qn.missing
        },
        hashed_email: {
            label: qn.missing
        },
        hashed_phone: {
            label: qn.missing
        }
    };
    ! function(e) {
        e[e.UNKNOWN = 0] = "UNKNOWN", e[e.HOLD = 1] = "HOLD", e[e.REVOKE = 2] = "REVOKE", e[e.GRANT = 3] = "GRANT"
    }(zn || (zn = {})),
    function(e) {
        e[e.NOT_SURE = 0] = "NOT_SURE", e[e.INVOKE_METHOD_ENABLED = 1] = "INVOKE_METHOD_ENABLED", e[e.INVOKE_METHOD_NOT_ENABLED = 2] = "INVOKE_METHOD_NOT_ENABLED", e[e.TOUTIAO_BRIDGE_NOT_ENABLED = 3] = "TOUTIAO_BRIDGE_NOT_ENABLED"
    }(Qn || (Qn = {}));
    var $n = function(e) {
            return "[object Object]" === Object.prototype.toString.call(e)
        },
        er = function(e) {
            return "{}" === JSON.stringify(e)
        },
        tr = function(e) {
            return "".concat(e, "-").concat(Date.now(), "-").concat(Math.floor(8999999999999 * Math.random()) + 1e12)
        },
        nr = function(e, t) {
            return "".concat(e, "-").concat(t)
        },
        rr = function() {
            return new Date(Date.now() + 864e5).toUTCString()
        };

    function ir(e) {
        var t = arguments.length > 1 && void 0 !== arguments[1] ? arguments[1] : 500,
            n = -1;
        return function() {
            var r = Array.prototype.slice.apply(arguments),
                i = Date.now();
            i - n >= t && (e.apply(void 0, y(r)), n = Date.now())
        }
    }
    var or, ar, cr, sr, ur = "tt_adInfo",
        lr = "tt_appInfo",
        fr = "_tt_enable_cookie",
        dr = "_ttp",
        hr = "pageId",
        pr = "messageId",
        vr = "tt_sessionId",
        _r = "tt_pixel_session_index",
        gr = "default_eventId";
    ! function(e) {
        e[e.OFFSITE = 0] = "OFFSITE", e[e.ONSITE = 1] = "ONSITE"
    }(or || (or = {})),
    function(e) {
        e.INIT_START = "initStart", e.INIT_END = "initEnd", e.CONTEXT_INIT_START = "contextInitStart", e.CONTEXT_INIT_END = "contextInitEnd", e.PAGE_URL_WILL_CHANGE = "pageUrlWillChange", e.PAGE_URL_DID_CHANGE = "pageUrlDidChange", e.PAGE_DID_LOAD = "pageDidLoad", e.PAGE_WILL_LEAVE = "pageWillLeave", e.AD_INFO_INIT_START = "adInfoInitStart", e.AD_INFO_INIT_END = "adInfoInitEnd", e.BEFORE_AD_INFO_INIT_START = "beforeAdInfoInitStart", e.BEFORE_SHOPIFY_PIXEL_SEND = "beforeShopifyPixelSend", e.PIXEL_SEND = "pixelSend", e.PIXEL_DID_MOUNT = "pixelDidMount"
    }(ar || (ar = {})),
    function(e) {
        e.UNKNOWN = "-1", e.LOADING = "0", e.INTERACTIVE = "1", e.COMPLETE = "2"
    }(cr || (cr = {})),
    function(e) {
        e.EXTERNAL = "external", e.APP = "app", e.TIKTOK = "tiktok"
    }(sr || (sr = {}));
    var yr, mr = "Pageview",
        Er = [],
        br = {
            TTQ: Symbol.for("TTQ"),
            GLOBAL_TTQ: Symbol.for("GLOBAL_TTQ"),
            SHOPIFY_TTQ: Symbol.for("SHOPIFY_TTQ"),
            ENV: Symbol.for("ENV"),
            CONTEXT: Symbol.for("CONTEXT"),
            REPORTER: Symbol.for("REPORTER"),
            REPORTERS: Symbol.for("REPORTERS"),
            PLUGIN: Symbol.for("PLUGIN"),
            PLUGINS: Symbol.for("PLUGINS"),
            TTQ_GLOBAL_OPTIONS: Symbol.for("TTQ_GLOBAL_OPTIONS"),
            PERFORMANCE_PLUGIN: Symbol.for("PERFORMANCE_PLUGIN"),
            INTERACTION_PLUGIN: Symbol.for("INTERACTION_PLUGIN"),
            INTERACTION_PLUGIN_MONITOR: Symbol.for("INTERACTION_PLUGIN_MONITOR"),
            PERFORMANCE_PLUGIN_MONITOR: Symbol.for("PERFORMANCE_PLUGIN_MONITOR"),
            ADVANCED_MATCHING_PLUGIN: Symbol.for("ADVANCED_MATCHING_PLUGIN"),
            AUTO_ADVANCED_MATCHING_PLUGIN: Symbol.for("AUTO_ADVANCED_MATCHING_PLUGIN"),
            CALLBACK_PLUGIN: Symbol.for("CALLBACK_PLUGIN"),
            IDENTIFY_PLUGIN: Symbol.for("IDENTIFY_PLUGIN"),
            MONITOR_PLUGIN: Symbol.for("MONITOR_PLUGIN"),
            PERFORMANCE_INTERACTION_PLUGIN: Symbol.for("PERFORMANCE_INTERACTION_PLUGIN"),
            WEB_FL_PLUGIN: Symbol.for("WEB_FL_PLUGIN"),
            SHOPIFY_PLUGIN: Symbol.for("SHOPIFY_PLUGIN"),
            AUTO_CONFIG_PLUGIN: Symbol.for("AUTO_CONFIG_PLUGIN"),
            DIAGNOSTICS_CONSOLE_PLUGIN: Symbol.for("DIAGNOSTICS_CONSOLE_PLUGIN"),
            COMPETITOR_INSIGHT_PLUGIN: Symbol.for("COMPETITOR_INSIGHT_PLUGIN"),
            PANGLE_COOKIE_MATCHING_PLUGIN: Symbol.for("PANGLE_COOKIE_MATCHING_PLUGIN"),
            EVENT_BUILDER_PLUGIN: Symbol.for("EVENT_BUILDER_PLUGIN"),
            ENRICH_IPV6_PLUGIN: Symbol.for("ENRICH_IPV6_PLUGIN"),
            PAGE_PERFORMANCE_MONITOR: Symbol.for("PAGE_PERFORMANCE_MONITOR"),
            PAGE_INTERACTION_MONITOR: Symbol.for("PAGE_INTERACTION_MONITOR"),
            PAGEDATA_PLUGIN: Symbol.for("PAGEDATA_PLUGIN"),
            BATCH_SERVICE: Symbol.for("BATCH_SERVICE"),
            REPORT_SERVICE: Symbol.for("REPORT_SERVICE"),
            AD_SERVICE: Symbol.for("AD_SERVICE"),
            APP_SERVICE: Symbol.for("APP_SERVICE"),
            BRIDGE_SERVICE: Symbol.for("BRIDGE"),
            HTTP_SERVICE: Symbol.for("HTTP_SERVICE"),
            COOKIE_SERVICE: Symbol.for("COOKIE_SERVICE"),
            CONSENT_SERVICE: Symbol.for("CONSENT_SERVICE"),
            JS_BRIDGE: Symbol.for("JS_BRIDGE"),
            TTQ_REPORTERS: Symbol.for("TTQ_REPORTERS"),
            INTERACTION_MONITOR: Symbol.for("INTERACTION_MONITOR"),
            PERFORMANCE_MONITOR: Symbol.for("PERFORMANCE_MONITOR")
        };
    ! function(e) {
        e.TRACK = "track", e.PERFORMANCE = "performance", e.INTERACTION = "interaction", e.PCM = "PCM", e.PERFORMANCE_INTERACTION = "performance_interaction", e.SELFHOST = "selfhost", e.AUTO_CONFIG = "auto_config", e.PAGE = "Pf"
    }(yr || (yr = {}));
    var Tr, Ir, Or = ["EnrichAM"],
        Sr = "https://analytics.tiktok.com/api/v2",
        Nr = "".concat(Sr, "/pixel"),
        Rr = "".concat(Sr, "/performance"),
        Ar = "".concat(Sr, "/interaction"),
        Cr = "".concat(Sr, "/performance_interaction"),
        Pr = "".concat(Sr, "/pixel/act"),
        wr = "ttclid",
        kr = "ext_params",
        Mr = "_toutiao_params",
        Lr = "ttuts",
        Dr = ["phone_number", "email", "external_id"],
        xr = "email_is_hashed",
        jr = "phone_is_hashed",
        Ur = "sha256_email",
        Fr = "sha256_phone",
        Br = "auto_trigger_type";
    ! function(e) {
        e.LOAD_START = "load_start", e.LOAD_END = "load_end", e.BEFORE_INIT = "before_init", e.INIT_START = "init_start", e.INIT_END = "init_end", e.JSB_INIT_START = "jsb_init_start", e.JSB_INIT_END = "jsb_init_end", e.BEFORE_AD_INFO_INIT_START = "before_ad_info_init_start", e.AD_INFO_INIT_START = "ad_info_init_start", e.AD_INFO_INIT_END = "ad_info_init_end", e.IDENTIFY_INIT_START = "identify_init_start", e.IDENTIFY_INIT_END = "identify_init_end", e.PLUGIN_INIT_START = "_init_start", e.PLUGIN_INIT_END = "_init_end", e.PIXEL_SEND = "pixel_send", e.PIXEL_SEND_PCM = "pixel_send_PCM", e.JSB_SEND = "jsb_send", e.HTTP_SEND = "http_send", e.HANDLE_CACHE = "handle_cache", e.INIT_ERROR = "init_error", e.PIXEL_EMPTY = "pixel_empty", e.JSB_ERROR = "jsb_error", e.API_ERROR = "api_error", e.PLUGIN_ERROR = "plugin_error", e.CUSTOM_INFO = "custom_info", e.CUSTOM_ERROR = "custom_error", e.CUSTOM_TIMER = "custom_timer"
    }(Tr || (Tr = {})),
    function(e) {
        e.EMPTY_EVENT_TYPE_NAME = "EMPTY_EVENT_TYPE_NAME", e.MISMATCHED_EVENT_TYPE_NAME_FOR_CUSTOM_EVENT = "MISMATCHED_EVENT_TYPE_NAME_FOR_CUSTOM_EVENT", e.LONG_EVENT_TYPE_NAME = "LONG_EVENT_TYPE_NAME", e.MISSING_VALUE_PARAMETER = "MISSING_VALUE_PARAMETER", e.MISSING_CURRENCY_PARAMETER = "MISSING_CURRENCY_PARAMETER", e.MISSING_CONTENT_ID = "MISSING_CONTENT_ID", e.MISSING_EMAIL_AND_PHONE = "MISSING_EMAIL_AND_PHONE", e.INVALID_EVENT_PARAMETER_VALUE = "INVALID_EVENT_PARAMETER_VALUE", e.INVALID_CURRENCY_CODE = "INVALID_CURRENCY_CODE", e.INVALID_CONTENT_ID = "INVALID_CONTENT_ID", e.INVALID_CONTENT_TYPE = "INVALID_CONTENT_TYPE", e.INVALID_EMAIL_FORMAT = "INVALID_EMAIL_FORMAT", e.INVALID_PHONE_NUMBER_FORMAT = "INVALID_PHONE_NUMBER_FORMAT", e.INVALID_EMAIL_INFORMATION = "INVALID_EMAIL_INFORMATION", e.INVALID_PHONE_NUMBER_INFORMATION = "INVALID_PHONE_NUMBER_INFORMATION", e.DUPLICATE_PIXEL_CODE = "DUPLICATE_PIXEL_CODE", e.MISSING_PIXEL_CODE = "MISSING_PIXEL_CODE", e.INVALID_PIXEL_CODE = "INVALID_PIXEL_CODE"
    }(Ir || (Ir = {}));
    var Gr = null,
        Hr = function() {
            return "object" === ("undefined" == typeof window ? "undefined" : t(window)) && window.TiktokAnalyticsObject || "ttq"
        },
        Vr = function() {
            return Gr || "object" === ("undefined" == typeof window ? "undefined" : t(window)) && window[Hr()]
        },
        Jr = function() {
            return "undefined" != typeof globalThis ? globalThis : "undefined" != typeof self ? self : "undefined" != typeof window ? window : "undefined" != typeof global ? global : new Function("return this")()
        },
        Kr = function() {
            return !!Vr()._is_onsite
        },
        Wr = function() {
            var e = Jr();
            return "object" === ("undefined" == typeof navigator ? "undefined" : t(navigator)) ? navigator.userAgent : e._userAgent || ""
        },
        Yr = function(e) {
            try {
                var t = Vr();
                return t && t._self_host_config && t._self_host_config[e] || ""
            } catch (e) {
                return ""
            }
        },
        qr = function() {
            var e = Vr();
            return e._partner ? e._partner : ""
        },
        Xr = function(e) {
            try {
                var t = Vr()._plugins || {};
                return null == t[e] || !!t[e]
            } catch (e) {
                return !0
            }
        };
    var zr = function(e) {
            return Boolean(e)
        },
        Qr = function(e) {
            var t;
            return Object.keys((null === (t = null == e ? void 0 : e.context) || void 0 === t ? void 0 : t.user) || {}).some((function(e) {
                return -1 !== Dr.indexOf(e)
            }))
        };

    function Zr(e, t) {
        var n, r = e;
        return function() {
            if (r) {
                for (var i = arguments.length, o = new Array(i), a = 0; a < i; a++) o[a] = arguments[a];
                n = e.apply(t, o), r = null
            }
            return n
        }
    }
    var $r = function(e) {
        return ((e = 21) => crypto.getRandomValues(new Uint8Array(e)).reduce(((e, t) => e + ((t &= 63) < 36 ? t.toString(36) : t < 62 ? (t - 26).toString(36).toUpperCase() : t > 62 ? "-" : "_")), ""))(e)
    };

    function ei(e, t) {
        var n = Object.assign({}, e);
        return t.forEach((function(e) {
            null !== n[e] && void 0 !== n[e] && delete n[e]
        })), n
    }
    var ti = function(e, t) {
        if (!e) return {};
        var n = {};
        return Object.keys(e).forEach((function(r) {
            t[r] && (n[r] = e[r])
        })), n
    };

    function ni(e, t, n) {
        var r;
        return function() {
            for (var i = arguments.length, o = new Array(i), a = 0; a < i; a++) o[a] = arguments[a];
            clearTimeout(r), r = setTimeout((function() {
                e.apply(n, o)
            }), t)
        }
    }

    function ri() {
        return ii.apply(this, arguments)
    }

    function ii() {
        return ii = r(e().mark((function t() {
            var n, r = arguments;
            return e().wrap((function(e) {
                for (;;) switch (e.prev = e.next) {
                    case 0:
                        return n = r.length > 0 && void 0 !== r[0] ? r[0] : 500, e.abrupt("return", new Promise((function(e) {
                            setTimeout((function() {
                                e(!0)
                            }), n)
                        })));
                    case 2:
                    case "end":
                        return e.stop()
                }
            }), t)
        }))), ii.apply(this, arguments)
    }
    var oi = ["input[type='button']", "input[type='image']", "input[type='submit']", "button", "[class*=btn]", "[class*=Btn]", "[class*=button]", "[class*=Button]", "[role*=button]", "[id*=btn]", "[id*=Btn]", "[id*=button]", "[id*=Button]", "a"],
        ai = ["[href^='tel:']", "[href^='callto:']", "[href^='sms:']", "[href^='skype:']", "[href^='whatsapp:']", "[href^='mailto:']"],
        ci = function(e) {
            var t = oi.some((function(t) {
                    return e.matches(t)
                })),
                n = ai.some((function(t) {
                    return e.matches(t)
                }));
            return t && !n
        };

    function si(e, n) {
        var r = {};
        for (var i in e)
            if (e.hasOwnProperty(i) && !n.hasOwnProperty(i)) r[i] = e[i];
            else if (e.hasOwnProperty(i) && n.hasOwnProperty(i) && e[i] !== n[i])
            if ("object" === t(e[i]) && "object" === t(n[i])) {
                var o = si(e[i], n[i]);
                Object.keys(o).length > 0 && (r[i] = o)
            } else r[i] = e[i];
        for (var a in n) n.hasOwnProperty(a) && !e.hasOwnProperty(a) && (r[a] = n[a]);
        return r
    }

    function ui(e, t) {
        return Object.keys(si(e, t)).length > 0
    }

    function li(e, t) {
        var n = {};
        return e && (function(e) {
            return "string" == typeof e
        }(e) || function(e) {
            return "number" == typeof e
        }(e) ? n.external_id = e.toString() : $n(e) && (n = e)), t && $n(t) && Object.assign(n, t), n
    }
    var fi = function(e) {
            try {
                var t = e && function(e) {
                    for (var t = Array.prototype.slice.call(document.getElementsByTagName("script")), n = 0; n < t.length; n++) {
                        var r = t[n];
                        if (r.innerHTML && r.innerHTML.indexOf(e) > -1) return r
                    }
                }(e);
                if (t) {
                    if (di(t)) return "isInHead";
                    if (hi(t)) return "isInBodyTop10"
                }
                return "unknown"
            } catch (e) {
                return "unknown"
            }
        },
        di = function e(t) {
            var n = t.parentElement;
            return !!n && ("HEAD" === n.tagName || e(n))
        },
        hi = function(e, n) {
            for (var r, i = [document.body], o = 0; o <= e && i.length;) {
                var a = i.pop();
                if (a === n) return !0;
                if (!("script" === (null == a ? void 0 : a.tagName.toLowerCase()) && (null === (r = a.src) || void 0 === r ? void 0 : r.indexOf("analytics.tiktok.com")) > -1) && (o++, "object" === t(a) && a.children))
                    for (var c = a.children.length - 1; c >= 0; c--) i.push(a.children[c])
            }
            return !1
        }.bind(null, 10),
        pi = function() {
            var e, t;
            return (null === (t = null === (e = Vr()) || void 0 === e ? void 0 : e._env) || void 0 === t ? void 0 : t.env) || sr.EXTERNAL
        },
        vi = function() {
            var e, t;
            return null !== (t = null === (e = Vr()) || void 0 === e ? void 0 : e._is_onsite) && void 0 !== t ? t : or.OFFSITE
        },
        _i = function(e) {
            return (e || pi()) !== sr.EXTERNAL
        },
        gi = function(e) {
            return (e || pi()) === sr.TIKTOK
        },
        yi = function() {
            var e = Wr();
            return /windows phone/i.test(e) ? "Windows Phone" : /android/i.test(e) ? "android" : /iPad|iPhone|iPod/.test(e) ? "ios" : "pc"
        },
        mi = function() {
            try {
                return navigator.userAgentData.getHighEntropyValues(["model", "platformVersion"])
            } catch (e) {
                return Promise.resolve({})
            }
        },
        Ei = function() {
            return "android" === yi()
        },
        bi = function() {
            return "ios" === yi()
        },
        Ti = Zr((function() {
            return /open_news/i.test(Wr())
        })),
        Ii = Zr((function() {
            return /ultralite/i.test(Wr())
        }));

    function Oi() {
        var e;
        return [Qn.INVOKE_METHOD_ENABLED, Qn.INVOKE_METHOD_NOT_ENABLED, Qn.TOUTIAO_BRIDGE_NOT_ENABLED][
            [!!(null === (e = null === window || void 0 === window ? void 0 : window.ToutiaoJSBridge) || void 0 === e ? void 0 : e.invokeMethod), !!(null === window || void 0 === window ? void 0 : window.ToutiaoJSBridge), !0].findIndex((function(e) {
                return e
            }))
        ]
    }
    var Si = function() {
            return (void 0 !== (e = Jr()).DedicatedWorkerGlobalScope ? e instanceof e.DedicatedWorkerGlobalScope : "DedicatedWorkerGlobalScope" === e.constructor.name) ? Gn.WebWorker : globalThis.self && globalThis.self !== globalThis.self.top ? Gn.Iframe : Gn.Normal;
            var e
        },
        Ni = {
            info: [],
            error: []
        };

    function Ri(e) {
        var t = arguments.length > 1 && void 0 !== arguments[1] ? arguments[1] : {},
            n = arguments.length > 2 && void 0 !== arguments[2] && arguments[2];
        try {
            var r = Vr(),
                i = r.getPlugin && r.getPlugin("Monitor") || null;
            i && i.info && "function" == typeof i.info ? i.info.call(i, e, t, n) : Xr("Monitor") && Ni.info.push({
                event: e,
                detail: t,
                withoutJSB: n
            })
        } catch (e) {}
    }

    function Ai(e, t) {
        var n = arguments.length > 2 && void 0 !== arguments[2] ? arguments[2] : {},
            r = arguments.length > 3 && void 0 !== arguments[3] && arguments[3];
        try {
            var i = Vr(),
                o = i.getPlugin && i.getPlugin("Monitor") || null;
            o && o.error && "function" == typeof o.error ? o.error.call(o, e, t, n, r) : Xr("Monitor") && Ni.error.push({
                event: e,
                err: t,
                detail: n,
                withoutJSB: r
            })
        } catch (e) {}
    }

    function Ci(e, t) {
        try {
            var n = Vr(),
                r = n.getPlugin && n.getPlugin("DiagnosticsConsole") || null;
            r && r.warn.apply(r, [e, t])
        } catch (e) {}
    }

    function Pi() {
        try {
            0;
            var e = document && document.currentScript,
                t = e && e.src || "http://emptyURLSrc";
            return {
                pixelCode: new URL(t).searchParams.get("sdkid") || e && e.getAttribute("data-id") || "",
                lib: Hr() || "ttq"
            }
        } catch (e) {
            return {
                lib: "ttq",
                pixelCode: ""
            }
        }
    }
    var wi = function(e, t) {
            if ("selfhost" === e && t && Yr(t)) return "https://".concat(Yr(t), "/api/v2/pixel");
            var n = {
                track: Nr,
                performance: Rr,
                interaction: Ar,
                performance_interaction: Cr,
                auto_config: Pr
            }[e];
            return n || null
        },
        ki = function(e) {
            try {
                var t = window.sessionStorage.getItem(e);
                return t ? JSON.parse(t) : null
            } catch (e) {
                return null
            }
        },
        Mi = function(e, t) {
            try {
                var n = JSON.stringify(t);
                window.sessionStorage.setItem(e, n)
            } catch (e) {}
        };

    function Li(e, t) {
        try {
            return new URL(e).searchParams.get(t) || ""
        } catch (e) {
            return ""
        }
    }
    var Di = function(e, t) {
            var n = Li(t || window.location.href, e);
            return n || Li(document.referrer, e)
        },
        xi = "",
        ji = function(e) {
            if (0 === document.cookie.length) return "";
            var t, n, r = (t = e, n = {}, document.cookie.split(";").forEach((function(e) {
                var t = e.split("="),
                    r = t[0].trim();
                n[r] = t.slice(1).join("=")
            })), n[t] || "");
            return r ? unescape(r) : ""
        },
        Ui = function(e, t, n) {
            try {
                if (n) {
                    if (xi) return n.domain = xi, void(document.cookie = "".concat(e, "=").concat(t).concat(Fi(n)));
                    for (var r = (n.domain || window.location.hostname).split("."), i = r.length, o = "", a = 0; a < i; a++) {
                        if (o = ".".concat(r[i - a - 1]).concat(o), n.domain = o, document.cookie = "".concat(e, "=").concat(t).concat(Fi(n)), ji(e)) {
                            xi = o;
                            break
                        }
                    }
                } else document.cookie = "".concat(e, "=").concat(t).concat(Fi(n))
            } catch (e) {}
        },
        Fi = function() {
            var e = arguments.length > 0 && void 0 !== arguments[0] ? arguments[0] : {},
                t = Object.assign({}, {
                    path: "/"
                }, e);
            "number" == typeof t.expires && (t.expires = new Date(Date.now() + 864e5 * t.expires)), t.expires instanceof Date && (t.expires = t.expires.toUTCString());
            var n = "";
            for (var r in t) t[r] && (n += "; ".concat(r), !0 !== t[r] && (n += "=".concat(t[r].split(";")[0])));
            return n
        },
        Bi = function(e, t) {
            var n = arguments.length > 2 && void 0 !== arguments[2] ? arguments[2] : "/",
                r = arguments.length > 3 && void 0 !== arguments[3] ? arguments[3] : rr(),
                i = {
                    path: n,
                    expires: r
                };
            Ui(e, t, i)
        };

    function Gi() {
        try {
            var e = document.readyState;
            return "loading" == e ? cr.LOADING : "interactive" == e ? cr.INTERACTIVE : "complete" == e ? cr.COMPLETE : cr.UNKNOWN
        } catch (e) {
            return cr.UNKNOWN
        }
    }

    function Hi(e) {
        return new Promise((function(t, n) {
            var r = document.createElement("script");
            r.type = "text/javascript", r.async = !0, r.src = e;
            var i = document.getElementsByTagName("script")[0];
            i && i.parentNode ? i.parentNode.insertBefore(r, i) : n("none element"), r.onload = function() {
                t(!0)
            }, r.onerror = n
        }))
    }
    var Vi = function() {
            var t = r(e().mark((function t(n) {
                var r, i = arguments;
                return e().wrap((function(e) {
                    for (;;) switch (e.prev = e.next) {
                        case 0:
                            if (!((r = i.length > 1 && void 0 !== i[1] ? i[1] : 1) >= 0)) {
                                e.next = 13;
                                break
                            }
                            return e.prev = 2, e.next = 5, Hi(n);
                        case 5:
                            return e.abrupt("return", Promise.resolve(!0));
                        case 8:
                            return e.prev = 8, e.t0 = e.catch(2), e.abrupt("return", Vi.call(null, n, r - 1));
                        case 11:
                            e.next = 14;
                            break;
                        case 13:
                            throw Error;
                        case 14:
                        case "end":
                            return e.stop()
                    }
                }), t, null, [
                    [2, 8]
                ])
            })));
            return function(e) {
                return t.apply(this, arguments)
            }
        }(),
        Ji = function(e) {
            return "function" == typeof Promise.allSettled ? Promise.allSettled(e) : function(e) {
                var t = new Array(e.length),
                    n = 0;
                return new Promise((function(r, i) {
                    for (var o = function(i) {
                            var o = e[i];
                            o && "function" == typeof o.then ? o.then((function(o) {
                                t[i] = {
                                    status: "fulfilled",
                                    value: o
                                }, ++n === e.length && r(t)
                            })).catch((function(o) {
                                t[i] = {
                                    status: "rejected",
                                    reason: o
                                }, ++n === e.length && r(t)
                            })) : (t[i] = {
                                status: "fulfilled",
                                value: o
                            }, ++n === e.length && r(t))
                        }, a = 0; a < e.length; a++) o(a)
                }))
            }(e)
        },
        Ki = ["COP", "USD", "DZD", "TWD", "QAR", "VES", "NGN", "EGP", "IDR", "HNL", "ISK", "CRC", "PEN", "AED", "GBP", "BOB", "DKK", "CAD", "PKR", "MXN", "HUF", "VND", "KWD", "RON", "BIF", "MYR", "ZAR", "SAR", "NOK", "SGD", "HKD", "AUD", "CHF", "KRW", "CNY", "TRY", "BDT", "NZD", "CLP", "THB", "EUR", "ARS", "NIO", "KZT", "GTQ", "RUB", "SEK", "MOP", "PYG", "INR", "JPY", "CZK", "BRL", "MAD", "PLN", "PHP", "KES", "ILS"];

    function Wi(e) {
        var t = arguments.length > 1 && void 0 !== arguments[1] ? arguments[1] : null,
            n = t || Ki;
        return n.includes(e)
    }

    function Yi(e) {
        return !isNaN(e) && e >= 0
    }
    var qi, Xi = String.fromCharCode.bind(String),
        zi = Array.prototype.slice.call("ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789+/="),
        Qi = function(e) {
            if (e.length < 2) {
                var t = e.charCodeAt(0);
                return t < 128 ? e : t < 2048 ? Xi(192 | t >>> 6) + Xi(128 | 63 & t) : Xi(224 | t >>> 12 & 15) + Xi(128 | t >>> 6 & 63) + Xi(128 | 63 & t)
            }
            var n = 65536 + 1024 * (e.charCodeAt(0) - 55296) + (e.charCodeAt(1) - 56320);
            return Xi(240 | n >>> 18 & 7) + Xi(128 | n >>> 12 & 63) + Xi(128 | n >>> 6 & 63) + Xi(128 | 63 & n)
        },
        Zi = /[\uD800-\uDBFF][\uDC00-\uDFFFF]|[^\x00-\x7F]/g,
        $i = function(e) {
            return function(e) {
                return e.replace(/=/g, "").replace(/[+\/]/g, (function(e) {
                    return "+" === e ? "-" : "_"
                }))
            }(function(e) {
                for (var t, n, r, i, o = "", a = e.length % 3, c = 0; c < e.length;) {
                    if ((n = e.charCodeAt(c++)) > 255 || (r = e.charCodeAt(c++)) > 255 || (i = e.charCodeAt(c++)) > 255) throw new TypeError("invalid character found");
                    o += zi[(t = n << 16 | r << 8 | i) >> 18 & 63] + zi[t >> 12 & 63] + zi[t >> 6 & 63] + zi[63 & t]
                }
                return a ? o.slice(0, a - 3) + "===".substring(a) : o
            }(function(e) {
                return e.replace(Zi, Qi)
            }(e)))
        },
        eo = {};

    function to(e) {
        var t = !(arguments.length > 1 && void 0 !== arguments[1]) || arguments[1];
        t && eo["".concat(e)] || (eo["".concat(e)] = {
            start: performance.now()
        })
    }

    function no(e) {
        var t = !(arguments.length > 1 && void 0 !== arguments[1]) || arguments[1];
        if (!(t && eo["".concat(e)] && eo["".concat(e)].end)) {
            var n = eo["".concat(e)];
            n && (n.end = performance.now());
            var r = n.end - n.start;
            return Ri(Tr.CUSTOM_TIMER, {
                custom_name: e,
                latency: Math.ceil(1e3 * r)
            }), r
        }
    }! function(e) {
        e.AUTO_CONFIG_CONTENT = "auto_config_content", e.AUTO_CONFIG_FORM = "auto_config_form", e.AUTO_CONFIG_CLICK = "auto_config_click", e.EB_RULE_COMPUTE_TOKENIZE_TEXT = "eb_rule_compute_tokenize_text", e.EB_RULE_COMPUTE_IMG_SRC = "eb_rule_compute_img_src", e.EB_RULE_COMPUTE_ELEMENT_XPATH = "eb_rule_compute_element_xpath", e.EB_PARAMETER_V2 = "eb_parameter_v2", e.EB_PARAMETER_V1 = "eb_parameter_v1"
    }(qi || (qi = {}));
    var ro = function(e, n, r, i) {
            var o, a = arguments.length,
                c = a < 3 ? n : null === i ? i = Object.getOwnPropertyDescriptor(n, r) : i;
            if ("object" === ("undefined" == typeof Reflect ? "undefined" : t(Reflect)) && "function" == typeof Reflect.decorate) c = Reflect.decorate(e, n, r, i);
            else
                for (var s = e.length - 1; s >= 0; s--)(o = e[s]) && (c = (a < 3 ? o(c) : a > 3 ? o(n, r, c) : o(n, r)) || c);
            return a > 3 && c && Object.defineProperty(n, r, c), c
        },
        io = function() {
            function e(t) {
                i(this, e), this.userFormatInfo = {}, this.userFormatInfoV2 = {}, this.enableAdTracking = !0, this.offsiteAdInfo = {}, this.tt_test_id = "", this.signalDiagnosticLabels = Object.assign({}, Zn), this.init(t)
            }
            return a(e, [{
                key: "init",
                value: function(e) {
                    this.userInfo = {}, this.adInfo = {}, this.appInfo = {}, this.pageInfo = {
                        url: "",
                        referrer: ""
                    }, this.pageSign = {
                        sessionId: "",
                        pageId: ""
                    }, this.libraryInfo = e
                }
            }, {
                key: "getAllData",
                value: function() {
                    return {
                        userInfo: this.userInfo,
                        adInfo: this.adInfo,
                        appInfo: this.appInfo,
                        libraryInfo: this.libraryInfo,
                        pageInfo: this.pageInfo,
                        pageSign: this.pageSign,
                        signalType: this.signalType,
                        userFormatInfo: this.userFormatInfo,
                        userFormatInfoV2: this.userFormatInfoV2,
                        enableAdTracking: this.enableAdTracking,
                        offsiteAdInfo: this.offsiteAdInfo,
                        tt_test_id: this.tt_test_id
                    }
                }
            }, {
                key: "getLibraryInfo",
                value: function() {
                    return this.libraryInfo
                }
            }, {
                key: "setSignalType",
                value: function(e) {
                    this.signalType = e
                }
            }, {
                key: "getSignalType",
                value: function() {
                    return this.signalType
                }
            }, {
                key: "setTestID",
                value: function(e) {
                    this.tt_test_id = e
                }
            }, {
                key: "getTestID",
                value: function() {
                    return this.tt_test_id
                }
            }, {
                key: "setEnableAdTracking",
                value: function(e) {
                    this.enableAdTracking = e
                }
            }, {
                key: "getEnableAdTracking",
                value: function() {
                    return this.enableAdTracking
                }
            }, {
                key: "setOffsiteAdInfo",
                value: function(e) {
                    this.offsiteAdInfo = Object.assign({}, this.offsiteAdInfo, e)
                }
            }, {
                key: "getOffsiteAdInfo",
                value: function() {
                    return this.offsiteAdInfo
                }
            }, {
                key: "getUserFormatInfo",
                value: function() {
                    return this.userFormatInfo
                }
            }, {
                key: "setUserFormatInfo",
                value: function() {
                    var e = arguments.length > 0 && void 0 !== arguments[0] ? arguments[0] : {};
                    Object.assign(this.userFormatInfo, e)
                }
            }, {
                key: "getUserFormatInfoV2",
                value: function() {
                    return this.userFormatInfoV2
                }
            }, {
                key: "setUserFormatInfoV2",
                value: function() {
                    var e = arguments.length > 0 && void 0 !== arguments[0] ? arguments[0] : {};
                    Object.assign(this.userFormatInfoV2, e)
                }
            }, {
                key: "setUserInfo",
                value: function() {
                    var e = arguments.length > 0 && void 0 !== arguments[0] ? arguments[0] : {};
                    Object.assign(this.userInfo, e)
                }
            }, {
                key: "setUserInfoWithoutIdentifyPlugin",
                value: function(e) {
                    e && Object.assign(this.userInfo, e)
                }
            }, {
                key: "getUserInfo",
                value: function() {
                    return this.userInfo
                }
            }, {
                key: "getAdInfo",
                value: function() {
                    return this.adInfo
                }
            }, {
                key: "setAdInfo",
                value: function(e) {
                    e && (this.adInfo ? this.adInfo = Object.assign({}, this.adInfo, e) : this.adInfo = e)
                }
            }, {
                key: "getAppInfo",
                value: function() {
                    return this.appInfo
                }
            }, {
                key: "setAppInfo",
                value: function(e) {
                    e && (this.appInfo = Object.assign({}, this.appInfo, e))
                }
            }, {
                key: "getPageInfo",
                value: function() {
                    return this.pageInfo
                }
            }, {
                key: "getPageSign",
                value: function() {
                    return this.pageSign
                }
            }, {
                key: "setPageInfo",
                value: function(e, t) {
                    var n = Object.assign({}, this.pageInfo),
                        r = Object.assign({}, this.pageSign);
                    if (n.url !== e) {
                        var i = n.url;
                        if (void 0 !== n.url && (n.referrer = n.url), void 0 !== t && (n.referrer = t), void 0 !== r.pageIndex) {
                            var o = r.pageIndex,
                                a = o.index,
                                c = o.sub,
                                s = o.main;
                            r.pageIndex = {
                                    index: ++a,
                                    sub: ++c,
                                    main: s
                                },
                                function(e) {
                                    var t = e.index,
                                        n = e.main;
                                    sessionStorage.setItem(_r, JSON.stringify({
                                        index: t,
                                        main: n
                                    }))
                                }(r.pageIndex)
                        }
                        return n.url = e, this.pageInfo = n, this.pageSign = r, {
                            from: i
                        }
                    }
                }
            }, {
                key: "setPageInfoData",
                value: function(e) {
                    this.pageInfo = Object.assign({}, this.pageInfo, e)
                }
            }, {
                key: "getSessionIdFromCache",
                value: function() {
                    return null
                }
            }, {
                key: "setSessionIdToCache",
                value: function(e) {}
            }, {
                key: "setSignalDiagnosticLabels",
                value: function(e) {
                    Object.assign(this.signalDiagnosticLabels, e)
                }
            }, {
                key: "getSignalDiagnosticLabels",
                value: function() {
                    return this.signalDiagnosticLabels
                }
            }, {
                key: "getPageId",
                value: function() {
                    return tr(hr)
                }
            }, {
                key: "getPageViewId",
                value: function() {
                    var e = this.pageSign,
                        t = e.pageId,
                        n = e.pageIndex;
                    return "".concat(t).concat(n ? ".".concat(n.main, ".").concat(n.sub) : "")
                }
            }, {
                key: "getVariationId",
                value: function() {
                    return ""
                }
            }, {
                key: "isLegacyPixel",
                value: function(e) {
                    return !1
                }
            }, {
                key: "initPageSign",
                value: function() {
                    var e = this.getSessionIdFromCache();
                    null === e && (e = tr("sessionId"), this.setSessionIdToCache(e));
                    var t = {
                        sessionId: e,
                        pageId: tr(hr)
                    };
                    this.pageSign = t
                }
            }]), e
        }();
    io = ro([A.injectable()], io);
    var oo = function(e, n, r, i) {
            var o, a = arguments.length,
                c = a < 3 ? n : null === i ? i = Object.getOwnPropertyDescriptor(n, r) : i;
            if ("object" === ("undefined" == typeof Reflect ? "undefined" : t(Reflect)) && "function" == typeof Reflect.decorate) c = Reflect.decorate(e, n, r, i);
            else
                for (var s = e.length - 1; s >= 0; s--)(o = e[s]) && (c = (a < 3 ? o(c) : a > 3 ? o(n, r, c) : o(n, r)) || c);
            return a > 3 && c && Object.defineProperty(n, r, c), c
        },
        ao = function() {
            function e() {
                i(this, e), this.events = {}
            }
            return a(e, [{
                key: "on",
                value: function(e, t) {
                    var n = this.events[e] || [];
                    n.push(t), this.events[e] = n
                }
            }, {
                key: "emit",
                value: function(e) {
                    for (var t = arguments.length, n = new Array(t > 1 ? t - 1 : 0), r = 1; r < t; r++) n[r - 1] = arguments[r];
                    var i = this.events[e] || [];
                    i.forEach((function(e) {
                        return e.apply(void 0, n)
                    }))
                }
            }, {
                key: "off",
                value: function(e, t) {
                    var n = this.events[e] || [];
                    this.events[e] = n.filter((function(e) {
                        return e !== t
                    }))
                }
            }]), e
        }();
    ao = oo([A.injectable()], ao);
    var co = function() {
        function e(t) {
            i(this, e), this.pixelCode = "", this.loaded = !1, this.status = 1, this.name = "", this.advertiserID = "", this.setupMode = 0, this.partner = "", this.reporterInfo = {}, this.plugins = {}, this.options = {}, this.rules = [], this.pixelCode = t
        }
        return a(e, [{
            key: "getParameterInfo",
            value: function() {
                return Promise.resolve({
                    pixelCode: this.pixelCode,
                    name: this.name,
                    status: this.status,
                    setupMode: this.setupMode,
                    advertiserID: this.advertiserID,
                    partner: this.partner,
                    is_onsite: !1,
                    advancedMatchingAvailableProperties: {}
                })
            }
        }, {
            key: "getReporterId",
            value: function() {
                return ""
            }
        }, {
            key: "getReporterPartner",
            value: function() {}
        }, {
            key: "getReporterInfo",
            value: function() {
                return {
                    reporter: {}
                }
            }
        }, {
            key: "getReportResultSet",
            value: function() {
                return []
            }
        }, {
            key: "isOnsite",
            value: function() {
                return !1
            }
        }, {
            key: "setAdvancedMatchingAvailableProperties",
            value: function(e) {}
        }, {
            key: "clearHistory",
            value: function() {}
        }, {
            key: "page",
            value: function(e) {}
        }, {
            key: "track",
            value: function(e, t, n) {
                return Promise.resolve(null)
            }
        }, {
            key: "getUserInfo",
            value: function(e) {
                return {}
            }
        }, {
            key: "getReporterMatchedUserFormatInfo",
            value: function() {
                return {}
            }
        }, {
            key: "getReporterMatchedUserFormatInfoV2",
            value: function() {
                return {}
            }
        }, {
            key: "assemblyData",
            value: function() {
                return {
                    event: "",
                    message_id: "",
                    event_id: "",
                    is_onsite: !1,
                    properties: {},
                    context: {
                        ad: {},
                        device: {},
                        library: {
                            name: "",
                            version: ""
                        },
                        page: {
                            url: ""
                        },
                        pageview_id: "",
                        session_id: "",
                        variation_id: "",
                        user: {}
                    },
                    partner: "",
                    timestamp: ""
                }
            }
        }, {
            key: "assemblySelfHostData",
            value: function() {
                return this.assemblyData()
            }
        }, {
            key: "trackSync",
            value: function() {}
        }, {
            key: "getReportEventHistoryKey",
            value: function(e) {
                return "tiktok"
            }
        }, {
            key: "hasReportEventHistory",
            value: function(e, t) {
                return !1
            }
        }]), e
    }();
    new co("empty");
    var so = function(e, n, r, i) {
            var o, a = arguments.length,
                c = a < 3 ? n : null === i ? i = Object.getOwnPropertyDescriptor(n, r) : i;
            if ("object" === ("undefined" == typeof Reflect ? "undefined" : t(Reflect)) && "function" == typeof Reflect.decorate) c = Reflect.decorate(e, n, r, i);
            else
                for (var s = e.length - 1; s >= 0; s--)(o = e[s]) && (c = (a < 3 ? o(c) : a > 3 ? o(n, r, c) : o(n, r)) || c);
            return a > 3 && c && Object.defineProperty(n, r, c), c
        },
        uo = function(e) {
            s(n, e);
            var t = h(n);

            function n(e, r) {
                var o;
                return i(this, n), (o = t.call(this)).reporterInfo = {}, o.options = {}, o.plugins = {}, o.rules = [], o.reportEventHistory = {}, o.reportResultSet = [], o.selfHostConfig = {}, o.currentHref = "", o.advancedMatchingAvailableProperties = {
                    external_id: !0
                }, o.reportService = r, o.context = e, o
            }
            return a(n, [{
                key: "getParameterInfo",
                value: function() {
                    var e = this;
                    return this.getInstance().then((function() {
                        var t = e.reporterInfo,
                            n = t.name,
                            r = void 0 === n ? "" : n,
                            i = t.status,
                            o = void 0 === i ? 1 : i,
                            a = t.setupMode,
                            c = void 0 === a ? 0 : a,
                            s = t.advertiserID,
                            u = void 0 === s ? "" : s,
                            l = t.is_onsite,
                            f = void 0 !== l && l;
                        return {
                            pixelCode: e.getReporterId(),
                            name: r,
                            status: o,
                            setupMode: c,
                            advertiserID: u.toString(),
                            partner: e.getReporterPartner() || "",
                            is_onsite: f,
                            advancedMatchingAvailableProperties: e.advancedMatchingAvailableProperties,
                            rules: e.rules
                        }
                    }))
                }
            }, {
                key: "getInstance",
                value: function() {
                    return this.pixelPromise = Promise.resolve(this)
                }
            }, {
                key: "getReporterId",
                value: function() {
                    return ""
                }
            }, {
                key: "getReporterPartner",
                value: function() {}
            }, {
                key: "getReporterInfo",
                value: function() {
                    return {
                        pixel: {
                            code: this.getReporterId()
                        }
                    }
                }
            }, {
                key: "setAdvancedMatchingAvailableProperties",
                value: function(e) {
                    this.advancedMatchingAvailableProperties = Object.assign({}, this.advancedMatchingAvailableProperties, e)
                }
            }, {
                key: "isOnsite",
                value: function() {
                    return !1
                }
            }, {
                key: "getReportResultSet",
                value: function() {
                    return this.reportResultSet
                }
            }, {
                key: "getUserInfo",
                value: function(e) {
                    return {}
                }
            }, {
                key: "getReporterMatchedUserFormatInfo",
                value: function() {
                    return {}
                }
            }, {
                key: "getReporterMatchedUserFormatInfoV2",
                value: function() {
                    return {}
                }
            }, {
                key: "getReportEventHistoryKey",
                value: function(e) {
                    return "tiktok"
                }
            }, {
                key: "clearHistory",
                value: function() {
                    this.reportEventHistory = {}
                }
            }, {
                key: "pushReport",
                value: function(e) {
                    var t = arguments.length > 1 && void 0 !== arguments[1] ? arguments[1] : "tiktok";
                    this.reportEventHistory[t] || (this.reportEventHistory[t] = []), this.reportEventHistory[t].push(e)
                }
            }, {
                key: "hasReportEventHistory",
                value: function(e, t) {
                    var n = this.getReportEventHistoryKey(t);
                    return this.reportEventHistory[n] ? !(!Er.includes(e) || !this.reportEventHistory[n].includes(e)) : (this.reportEventHistory[n] = [], !1)
                }
            }, {
                key: "page",
                value: function() {}
            }, {
                key: "track",
                value: function(e, t, n, r, i) {
                    var o = this,
                        a = r || yr.TRACK,
                        c = i || Bn.defaultReport;
                    return !this.reportService || this.hasReportEventHistory(e, c) ? Promise.resolve(null) : (this.pushReport(e, this.getReportEventHistoryKey(c)), Ji(this.reportService.reportPreposition || []).then((function() {
                        var r = o.getReporterId(),
                            i = o.trackSync(r, e, t, n, a, c);
                        if (o.trackPostTask({
                                reporterId: r,
                                eventType: e,
                                properties: t,
                                eventConfig: n,
                                type: a,
                                reportType: c,
                                reportData: i
                            }) && i) {
                            var s = {
                                reporterId: r,
                                eventType: e,
                                properties: t,
                                eventConfig: n,
                                type: a,
                                reportType: c,
                                reportData: i
                            };
                            return Promise.resolve(s)
                        }
                        return Promise.resolve(null)
                    })))
                }
            }, {
                key: "getEventType",
                value: function(e) {
                    return e
                }
            }, {
                key: "trackPostTask",
                value: function(e) {
                    return !0
                }
            }, {
                key: "trackSync",
                value: function(e, t, n, r) {
                    var i = arguments.length > 4 && void 0 !== arguments[4] ? arguments[4] : yr.TRACK,
                        o = arguments.length > 5 && void 0 !== arguments[5] ? arguments[5] : Bn.defaultReport,
                        a = i !== yr.SELFHOST ? this.assemblyData(e, t, n, r, i) : this.assemblySelfHostData(e, t, n, r, i),
                        c = wi(i, e);
                    if (null !== c && this.reportService) return this.emit("beforeReport", e, t, a, r, i), this.reportResultSet.push(this.reportService.report(c, a, o)), a
                }
            }, {
                key: "handlePropertiesToOptions",
                value: function(e, t) {
                    var n = {};
                    return t.forEach((function(t) {
                        n[t] = e[t], delete e[t]
                    })), n
                }
            }, {
                key: "assemblyData",
                value: function(e, t) {
                    var n = arguments.length > 2 && void 0 !== arguments[2] ? arguments[2] : {},
                        r = arguments.length > 3 && void 0 !== arguments[3] ? arguments[3] : {};
                    arguments.length > 4 && void 0 !== arguments[4] || yr.TRACK;
                    var i = this.context.getAllData(),
                        o = i.adInfo,
                        a = i.userInfo,
                        c = i.appInfo,
                        s = i.pageSign,
                        u = i.libraryInfo,
                        l = i.pageInfo,
                        f = i.signalType,
                        d = s.sessionId,
                        h = s.variationId,
                        p = Object.assign({}, n),
                        v = p && p.pixelMethod || "";
                    p && p.pixelMethod && delete p.pixelMethod;
                    var _ = Object.assign({}, u, {
                            version: this.context.isLegacyPixel(e) ? "legacy-".concat(u.version) : u.version
                        }),
                        g = ei(o, Xn),
                        y = Object.assign({}, g, {
                            device_id: c.device_id,
                            uid: c.user_id
                        }),
                        m = this.handlePropertiesToOptions(p, [Fn.LDU, Fn.EVENTID, Fn.EVENT_ID]),
                        E = this.options.limited_data_use,
                        b = null !== m.limited_data_use && void 0 !== m.limited_data_use ? m.limited_data_use : E;
                    null == b ? delete m.limited_data_use : m.limited_data_use = !!b;
                    var T = r && (r.event_id || r.eventID) || "";
                    m.event_id = T || m.event_id || m.eventID || "", delete m.eventID;
                    var I = this.getReporterInfo();
                    I.pixel && (I.pixel.runtime = Si(), v && (I.pixel.mode = v));
                    var O = this.getUserInfo(Jn.Manual) || {},
                        S = this.getUserInfo(Jn.ManualV2) || {},
                        N = this.getReporterMatchedUserFormatInfoV2() || {};
                    (null == p ? void 0 : p.dynamic_parameter_config) && (N.dynamic_parameter_config = null == p ? void 0 : p.dynamic_parameter_config, null == p || delete p.dynamic_parameter_config), (null == p ? void 0 : p.eb_version) && (N.eb_version = null == p ? void 0 : p.eb_version, null == p || delete p.eb_version);
                    var R = this.getUserInfo(Jn.Auto) || {};
                    R.auto_trigger_type && (Object.assign(p, {
                        auto_trigger_type: R.auto_trigger_type
                    }), delete R.auto_trigger_type), Ei() && Object.assign(p, {
                        android_version: c.android_version,
                        device_model: c.device_model
                    });
                    var A = {};
                    a.anonymous_id && (A.anonymous_id = a.anonymous_id);
                    var C = this.getEventType(t),
                        P = {
                            event: C,
                            event_id: T,
                            message_id: nr(tr(pr), e),
                            is_onsite: !!f,
                            timestamp: (new Date).toJSON(),
                            context: Object.assign(Object.assign({
                                ad: y,
                                device: {
                                    platform: c.platform
                                },
                                user: Object.assign({}, A, O, S, R)
                            }, I), {
                                page: Object.assign({}, l),
                                library: Object.assign({}, _),
                                session_id: nr(d, e),
                                pageview_id: nr(this.context.getPageViewId(), e),
                                variation_id: h || ""
                            }),
                            _inspection: N,
                            properties: p
                        };
                    return Object.assign(P, m)
                }
            }, {
                key: "assemblySelfHostData",
                value: function(e, t) {
                    var n = arguments.length > 2 && void 0 !== arguments[2] ? arguments[2] : {},
                        r = arguments.length > 3 && void 0 !== arguments[3] ? arguments[3] : {},
                        i = arguments.length > 4 ? arguments[4] : void 0;
                    return this.assemblyData(e, t, n, r, i)
                }
            }]), n
        }(ao);
    uo = so([A.injectable()], uo);
    var lo = function(e, n, r, i) {
            var o, a = arguments.length,
                c = a < 3 ? n : null === i ? i = Object.getOwnPropertyDescriptor(n, r) : i;
            if ("object" === ("undefined" == typeof Reflect ? "undefined" : t(Reflect)) && "function" == typeof Reflect.decorate) c = Reflect.decorate(e, n, r, i);
            else
                for (var s = e.length - 1; s >= 0; s--)(o = e[s]) && (c = (a < 3 ? o(c) : a > 3 ? o(n, r, c) : o(n, r)) || c);
            return a > 3 && c && Object.defineProperty(n, r, c), c
        },
        fo = function() {
            function e(t) {
                var n = t.name,
                    r = t.context,
                    o = t.reporters;
                i(this, e), this.reporters = [], this.context = r, this.reporters = o, this.name = n
            }
            return a(e, [{
                key: "initStart",
                value: function() {}
            }, {
                key: "initEnd",
                value: function() {}
            }, {
                key: "adInfoInitStart",
                value: function() {}
            }, {
                key: "adInfoInitEnd",
                value: function() {}
            }, {
                key: "contextInitStart",
                value: function() {}
            }, {
                key: "contextInitEnd",
                value: function() {}
            }, {
                key: "pageUrlWillChange",
                value: function(e, t) {}
            }, {
                key: "pageUrlDidChange",
                value: function(e, t) {}
            }, {
                key: "pageDidLoad",
                value: function() {}
            }, {
                key: "pageWillLeave",
                value: function(e) {}
            }, {
                key: "pixelSend",
                value: function(e, t, n, r, i) {}
            }, {
                key: "pixelDidMount",
                value: function(e) {}
            }]), e
        }();
    fo = lo([A.injectable()], fo);
    var ho = function(e, n, r, i) {
            var o, a = arguments.length,
                c = a < 3 ? n : null === i ? i = Object.getOwnPropertyDescriptor(n, r) : i;
            if ("object" === ("undefined" == typeof Reflect ? "undefined" : t(Reflect)) && "function" == typeof Reflect.decorate) c = Reflect.decorate(e, n, r, i);
            else
                for (var s = e.length - 1; s >= 0; s--)(o = e[s]) && (c = (a < 3 ? o(c) : a > 3 ? o(n, r, c) : o(n, r)) || c);
            return a > 3 && c && Object.defineProperty(n, r, c), c
        },
        po = function() {
            function t(e, n, r, o) {
                i(this, t), this.initialize = !1, this.plugins = [], this.reporters = [], this.context = e, this.adService = n, this.appService = r, this.reportService = o
            }
            return a(t, [{
                key: "init",
                value: function() {
                    this.initContextInfo(), this.initialize = !0
                }
            }, {
                key: "initContextInfo",
                value: function() {
                    var e = this;
                    this.dispatch(ar.CONTEXT_INIT_START);
                    var t = (null === window || void 0 === window ? void 0 : window.location) || {
                        href: ""
                    };
                    this.initAdInfo(t.href), this.initAppInfo(t.href), this.reportService.pushPreposition(Promise.resolve().then((function() {
                        return e.initUserInfo()
                    }))), this.initTestId(t.href), this.dispatch(ar.CONTEXT_INIT_END)
                }
            }, {
                key: "setPageInfo",
                value: function(e, t) {
                    var n = this.context.getPageInfo();
                    if (n.url !== e) {
                        this.dispatch(ar.PAGE_URL_WILL_CHANGE, n.url, e);
                        var r = this.context.setPageInfo(e, t);
                        r && this.dispatch(ar.PAGE_URL_DID_CHANGE, e, r.from || "")
                    }
                }
            }, {
                key: "initAdInfo",
                value: function(t, n) {
                    var i = this;
                    this.reportService.pushPreposition(r(e().mark((function r() {
                        var o;
                        return e().wrap((function(e) {
                            for (;;) switch (e.prev = e.next) {
                                case 0:
                                    return e.prev = 0, e.next = 3, i.adService.getAdInfo(t);
                                case 3:
                                    o = e.sent, i.context.setAdInfo(o), i.initOffsiteAdInfo(o), e.next = 11;
                                    break;
                                case 8:
                                    e.prev = 8, e.t0 = e.catch(0), n && n(e.t0);
                                case 11:
                                case "end":
                                    return e.stop()
                            }
                        }), r, null, [
                            [0, 8]
                        ])
                    })))())
                }
            }, {
                key: "initOffsiteAdInfo",
                value: function(e) {}
            }, {
                key: "initAppInfo",
                value: function(t) {
                    var n = this;
                    this.reportService.pushPreposition(r(e().mark((function r() {
                        var i;
                        return e().wrap((function(e) {
                            for (;;) switch (e.prev = e.next) {
                                case 0:
                                    return e.next = 2, n.appService.getAppInfo(t);
                                case 2:
                                    i = e.sent, n.context.setAppInfo(i);
                                case 4:
                                case "end":
                                    return e.stop()
                            }
                        }), r)
                    })))())
                }
            }, {
                key: "initUserInfo",
                value: function() {}
            }, {
                key: "initTestId",
                value: function(e) {}
            }, {
                key: "usePlugin",
                value: function(e) {
                    try {
                        if (!this.plugins.find((function(t) {
                                return t.name === e.name
                            }))) {
                            this.plugins.push(e);
                            var t = e.name;
                            if (t) this["".concat(t[0].toLowerCase() + t.slice(1), "Plugin")] = e
                        }
                    } catch (e) {}
                }
            }, {
                key: "getPlugin",
                value: function(e) {
                    return this.plugins.find((function(t) {
                        return t.name === e
                    })) || null
                }
            }, {
                key: "getReporter",
                value: function(e) {
                    return this.reporters.find((function(t) {
                        return t.getReporterId() === e
                    }))
                }
            }, {
                key: "instance",
                value: function(e) {
                    var t = this.getReporter(e);
                    return t || (Ai(Tr.PIXEL_EMPTY, new Error(""), {
                        pixelCode: e
                    }), new co(e))
                }
            }, {
                key: "instances",
                value: function() {
                    return this.reporters
                }
            }, {
                key: "identify",
                value: function(e, t) {
                    var n = li(e, t);
                    this.context.setUserInfo(n)
                }
            }, {
                key: "page",
                value: function(e) {
                    e.url !== this.context.getPageInfo().url && (this.setPageInfo(e.url, e.referrer), this.reporters.forEach((function(e) {
                        e.clearHistory()
                    })));
                    var t = Object.assign({}, e);
                    delete t.url, delete t.referrer, this.reporters.forEach((function(e) {
                        e.page(t)
                    }))
                }
            }, {
                key: "isOnsitePage",
                value: function() {
                    return this.context.getSignalType() === or.ONSITE || this.reporters.every((function(e) {
                        return e.isOnsite()
                    }))
                }
            }, {
                key: "track",
                value: function(e) {
                    var t = arguments.length > 1 && void 0 !== arguments[1] ? arguments[1] : {},
                        n = arguments.length > 2 && void 0 !== arguments[2] ? arguments[2] : {};
                    this.instances().forEach((function(r, i) {
                        r.track(e, t, Object.assign({
                            _i: i
                        }, n))
                    }))
                }
            }, {
                key: "dispatch",
                value: function(e) {
                    for (var t = arguments.length, n = new Array(t > 1 ? t - 1 : 0), r = 1; r < t; r++) n[r - 1] = arguments[r];
                    this.plugins.forEach((function(t) {
                        if ("function" == typeof t[e]) try {
                            t[e].apply(t, n)
                        } catch (r) {
                            Ai(Tr.PLUGIN_ERROR, r, {
                                extJSON: {
                                    plugin_name: t.name,
                                    cycle_name: e,
                                    data: n
                                }
                            })
                        }
                    }))
                }
            }, {
                key: "getAllReportResultSet",
                value: function() {
                    return this.instances().reduce((function(e, t) {
                        return e.concat(t.getReportResultSet())
                    }), [])
                }
            }, {
                key: "resetCookieExpires",
                value: function() {}
            }, {
                key: "enableCookie",
                value: function() {}
            }, {
                key: "disableCookie",
                value: function() {}
            }]), t
        }();
    po = ho([A.injectable()], po);
    var vo, _o = function(e, n, r, i) {
            var o, a = arguments.length,
                c = a < 3 ? n : null === i ? i = Object.getOwnPropertyDescriptor(n, r) : i;
            if ("object" === ("undefined" == typeof Reflect ? "undefined" : t(Reflect)) && "function" == typeof Reflect.decorate) c = Reflect.decorate(e, n, r, i);
            else
                for (var s = e.length - 1; s >= 0; s--)(o = e[s]) && (c = (a < 3 ? o(c) : a > 3 ? o(n, r, c) : o(n, r)) || c);
            return a > 3 && c && Object.defineProperty(n, r, c), c
        },
        go = function() {
            function t(e, n) {
                i(this, t), this.reportPreposition = [], this.httpService = e, this.bridgeService = n
            }
            var n;
            return a(t, [{
                key: "pushPreposition",
                value: function(e) {
                    this.reportPreposition.push(e)
                }
            }, {
                key: "report",
                value: (n = r(e().mark((function t(n, r, i) {
                    return e().wrap((function(e) {
                        for (;;) switch (e.prev = e.next) {
                            case 0:
                                return e.abrupt("return", Promise.resolve());
                            case 1:
                            case "end":
                                return e.stop()
                        }
                    }), t)
                }))), function(e, t, r) {
                    return n.apply(this, arguments)
                })
            }]), t
        }();
    go = _o([A.injectable()], go),
        function(e) {
            e[e.Live = 0] = "Live", e[e.NoRecord = 1] = "NoRecord"
        }(vo || (vo = {}));
    var yo, mo = {
        ID: Symbol.for("ID"),
        Type: Symbol.for("type"),
        Partner: Symbol.for("partner"),
        Options: Symbol.for("Options"),
        Plugins: Symbol.for("Plugins"),
        Rules: Symbol.for("Rules"),
        Info: Symbol.for("Info"),
        ExtraParams: Symbol.for("extraParams"),
        WebLibraryInfo: Symbol.for("WebLibraryInfo"),
        SignalType: Symbol.for("SignalType"),
        IsOnsitePage: Symbol.for("IsOnsitePage")
    };
    ! function(e) {
        e.BIND = "bind", e.REBIND = "rebind"
    }(yo || (yo = {}));
    var Eo = {
            ViewForm: "ViewContent",
            ViewConsultationPage: "ViewContent",
            ViewDownloadPage: "ViewContent",
            Checkout: "PlaceAnOrder",
            Purchase: "CompletePayment",
            Registration: "CompleteRegistration",
            AddBilling: "AddPaymentInfo",
            StartCheckout: "InitiateCheckout",
            ClickInDownloadPage: "ClickButton",
            ClickInConsultationPage: "ClickButton",
            ClickForm: "ClickButton",
            ClickToDownload: "Download",
            Consult: "Contact",
            ConsultByPhone: "Contact"
        },
        bo = function() {
            var e = Vr();
            return "object" === t(e) && e._i ? e._i : {}
        },
        To = function(e, t) {
            var n = bo() || {};
            Object.keys(n).forEach((function(r) {
                var i = n[r];
                i._init || i.push([e].concat(t))
            }))
        },
        Io = function(e, t, n) {
            var r = (bo() || {})[e];
            if (r) {
                if (r._init) return;
                r.push([t].concat(n))
            }
        };

    function Oo(e, t) {
        var n = history[e];
        return function() {
            var e = Array.prototype.slice.call(arguments);
            n.apply(history, e), t()
        }
    }
    var So, No = function(e) {
            var t;
            return e.context.ad = {}, Object.keys((null === (t = null == e ? void 0 : e.context) || void 0 === t ? void 0 : t.user) || {}).forEach((function(t) {
                e.context.user[t] = ""
            })), e
        },
        Ro = function(e, n, r, i) {
            var o, a = arguments.length,
                c = a < 3 ? n : null === i ? i = Object.getOwnPropertyDescriptor(n, r) : i;
            if ("object" === ("undefined" == typeof Reflect ? "undefined" : t(Reflect)) && "function" == typeof Reflect.decorate) c = Reflect.decorate(e, n, r, i);
            else
                for (var s = e.length - 1; s >= 0; s--)(o = e[s]) && (c = (a < 3 ? o(c) : a > 3 ? o(n, r, c) : o(n, r)) || c);
            return a > 3 && c && Object.defineProperty(n, r, c), c
        },
        Ao = function(e, t) {
            return function(n, r) {
                t(n, r, e)
            }
        };
    ! function(e) {
        e.PIXEL_CODE = "pixelCode", e.EVENT_SOURCE_ID = "eventSourceId", e.SHOP_ID = "shopId"
    }(So || (So = {}));
    var Co = function(e) {
            s(r, e);
            var n = h(r);

            function r(e, t, o, a, s, u, l, f, d, h) {
                var p;
                return i(this, r), (p = n.call(this, a, l)).ttp = "", p.loaded = !1, p.id = e, p.pixelCode = e, p.type = t, p.isOnsitePage = o, p.options = h || {}, p.plugins = f || {}, p.rules = d || [], p.reporterInfo = Object.assign(s || {}, c({}, t, e)), p.ttp = u.ttp || "", p.currency_list = u.currency_list || null, p.ttqPartner = u.partner || "", p.selfHostConfig = u.self_host_config || {}, p.pixelPromise = p.getInstance(), p
            }
            return a(r, [{
                key: "identify",
                value: function(e, t) {
                    var n = li(e, t);
                    this.context.setUserInfo(n)
                }
            }, {
                key: "getReporterId",
                value: function() {
                    return this.id || ""
                }
            }, {
                key: "getReporterPartner",
                value: function() {
                    var e;
                    return (null === (e = this.reporterInfo) || void 0 === e ? void 0 : e.partner) || ""
                }
            }, {
                key: "setPixelInfo",
                value: function(e, t, n) {
                    var r = this.type;
                    this.reporterInfo = Object.assign(this.reporterInfo, Object.assign({}, e), c({}, r, this.getReporterId())), t && (this.rules = t), n && (this.plugins = n)
                }
            }, {
                key: "getInstance",
                value: function() {
                    var e = this;
                    if (this.pixelPromise) return this.pixelPromise;
                    var t = function(e) {
                        return bo()[e] || {}
                    }(this.id);
                    return Kr() || t && t.info ? (this.loaded = !0, this.pixelPromise = Promise.resolve(this)) : (this.pixelPromise = new Promise((function(t, n) {
                        var r, i;
                        Vi((r = e.id, i = location && location.hostname, "".concat("https://analytics.tiktok.com/i18n/pixel/config.js", "?sdkid=").concat(r, "&hostname=").concat(i))).then((function() {
                            e.loaded = !0, t(e)
                        })).catch((function(t) {
                            e.pixelPromise = null, n(t)
                        }))
                    })), this.pixelPromise)
                }
            }, {
                key: "getReporterInfo",
                value: function() {
                    return this.reporterInfo.pixelCode ? v(u(r.prototype), "getReporterInfo", this).call(this) : {
                        shop_id: this.reporterInfo.shopId,
                        eventSourceId: this.reporterInfo.eventSourceId
                    }
                }
            }, {
                key: "getUserInfo",
                value: function(e) {
                    var t = this.context.getUserInfo(),
                        n = ti(t, Object.assign({}, this.advancedMatchingAvailableProperties));
                    switch (e) {
                        case Jn.Manual:
                            var r = this.getReporterPartner();
                            return ti(r && "None" !== r ? n : t, {
                                external_id: !0,
                                email: !0,
                                phone_number: !0
                            });
                        case Jn.ManualV2:
                            return ti(n, {
                                first_name: !0,
                                last_name: !0,
                                city: !0,
                                state: !0,
                                country: !0,
                                zip_code: !0
                            });
                        case Jn.Auto:
                            var i = ti(n, {
                                external_id: !0,
                                auto_email: !0,
                                auto_phone_number: !0
                            });
                            return Object.assign(i, (i.auto_email || i.auto_phone_number) && t.auto_trigger_type ? {
                                auto_trigger_type: t.auto_trigger_type
                            } : {});
                        default:
                            return n
                    }
                }
            }, {
                key: "getReporterMatchedUserFormatInfo",
                value: function() {
                    var e = this.context.getUserFormatInfo(),
                        t = this.getReporterPartner(),
                        n = function(e, t) {
                            var n = {
                                identity_params: {}
                            };
                            return 0 === Object.keys(e).length ? {} : (Object.entries(t).forEach((function(t) {
                                var r = _(t, 2),
                                    i = r[0];
                                if (r[1])
                                    if (e[i] && e[i].length) {
                                        var o = e[i] || [Hn.EMPTY_VALUE];
                                        n.identity_params[i] = y(o)
                                    } else n.identity_params[i] = [Hn.EMPTY_VALUE]
                            })), n)
                        }(e, t && "None" !== t ? this.advancedMatchingAvailableProperties : {
                            external_id: !0,
                            email: !0,
                            phone_number: !0
                        }),
                        r = ti(e, {
                            auto_email: !0,
                            auto_phone_number: !0
                        });
                    return Object.keys(r).length > 0 && (n.identity_params || (n.identity_params = {}), Object.assign(n.identity_params, r)), n
                }
            }, {
                key: "getReporterMatchedUserFormatInfoV2",
                value: function() {
                    var e, t = this.context.getUserFormatInfoV2(),
                        n = this.getReporterPartner(),
                        r = n && "None" !== n ? this.advancedMatchingAvailableProperties : {
                            external_id: !0,
                            email: !0,
                            phone_number: !0
                        };
                    return r.zip_code = (null === (e = this.advancedMatchingAvailableProperties) || void 0 === e ? void 0 : e.zip_code) || !1,
                        function(e, t) {
                            if (0 === Object.keys(e).length) return {};
                            var n = {
                                    identity_params: {}
                                },
                                r = {
                                    email: ["email_is_hashed", "sha256_email"],
                                    phone_number: ["phone_is_hashed", "sha256_phone"],
                                    zip_code: ["zip_code"]
                                };
                            return Object.entries(t).forEach((function(t) {
                                var i = _(t, 2),
                                    o = i[0];
                                i[1] && r[o] && r[o].forEach((function(t) {
                                    if (n.identity_params[t] = [Hn.EMPTY_VALUE], e[t]) {
                                        var r = e[t] || [Hn.EMPTY_VALUE];
                                        n.identity_params && (n.identity_params[t] = y(r))
                                    }
                                }))
                            })), n
                        }(t, r)
                }
            }, {
                key: "isOnsite",
                value: function() {
                    var e;
                    return !!(null === (e = this.reporterInfo) || void 0 === e ? void 0 : e.is_onsite)
                }
            }, {
                key: "isNonPartner",
                value: function() {
                    var e = this.reporterInfo.partner;
                    return !e || "None" === e
                }
            }, {
                key: "getSignalDiagnosticLabels",
                value: function() {
                    var e = this.context.getSignalDiagnosticLabels();
                    if (!e) return Object.assign({}, Zn);
                    var t = this.advancedMatchingAvailableProperties,
                        n = t.email,
                        r = t.phone_number,
                        i = this.advancedMatchingAvailableProperties,
                        o = i.auto_email,
                        a = i.auto_phone_number;
                    n = !!this.isNonPartner() || n, r = !!this.isNonPartner() || r;
                    var c = ti(e, {
                        raw_email: n,
                        raw_phone: r,
                        hashed_email: n,
                        hashed_phone: r,
                        raw_auto_email: o,
                        raw_auto_phone: a
                    });
                    return Object.assign({}, Zn, c)
                }
            }, {
                key: "assemblyData",
                value: function(e, t) {
                    var n = arguments.length > 2 && void 0 !== arguments[2] ? arguments[2] : {},
                        i = arguments.length > 3 && void 0 !== arguments[3] ? arguments[3] : {},
                        o = arguments.length > 4 && void 0 !== arguments[4] ? arguments[4] : yr.TRACK,
                        a = v(u(r.prototype), "assemblyData", this).call(this, e, t, n, i, o);
                    a.is_onsite = this.isOnsitePage.value;
                    var c = this.ttqPartner;
                    c && (a.partner = c), a.signal_diagnostic_labels = this.getSignalDiagnosticLabels();
                    var s = Wr();
                    s && (a.context.userAgent = s);
                    var l = Gi();
                    return l && (a.context.page.load_progress = l), a.context.ad.sdk_env = pi(), a.context.ad.jsb_status = Oi(), o !== yr.INTERACTION && o !== yr.PERFORMANCE && o !== yr.PERFORMANCE_INTERACTION || !1 !== this.context.getEnableAdTracking() || this.isOnsitePage.value || (a.context.user = {}, a.context.ad = this.context.getOffsiteAdInfo(), a.context.ad = ei(a.context.ad, Xn)), a
                }
            }, {
                key: "page",
                value: function() {
                    var e = arguments.length > 0 && void 0 !== arguments[0] ? arguments[0] : {};
                    window.location.href !== this.currentHref && (this.currentHref = window.location.href, this.track(mr, e, {}))
                }
            }, {
                key: "track",
                value: function(e) {
                    var t = this,
                        n = arguments.length > 1 && void 0 !== arguments[1] ? arguments[1] : {},
                        i = arguments.length > 2 && void 0 !== arguments[2] ? arguments[2] : {},
                        o = arguments.length > 3 && void 0 !== arguments[3] ? arguments[3] : yr.TRACK,
                        a = arguments.length > 4 && void 0 !== arguments[4] ? arguments[4] : Bn.defaultReport;
                    return i && i.pixel_code && this.getReporterId() !== i.pixel_code ? Promise.resolve(null) : this.getInstance().then((function() {
                        var c = t.getReporterId();
                        if (Or.includes(e)) return v(u(r.prototype), "track", t).call(t, e, n, i, o, a);
                        var s = Object.assign({}, i);
                        return t.selfHostConfig[c] && !i.eventID && (s = Object.assign({}, s, {
                            eventID: nr(tr(gr), c)
                        })), v(u(r.prototype), "track", t).call(t, e, n, s, o, a)
                    }))
                }
            }, {
                key: "getEventType",
                value: function(e) {
                    return Eo[e] || e
                }
            }, {
                key: "trackSync",
                value: function(e, n) {
                    var i, o = arguments.length > 2 && void 0 !== arguments[2] ? arguments[2] : {},
                        a = arguments.length > 3 && void 0 !== arguments[3] ? arguments[3] : {},
                        c = arguments.length > 4 && void 0 !== arguments[4] ? arguments[4] : yr.TRACK,
                        s = arguments.length > 5 && void 0 !== arguments[5] ? arguments[5] : Bn.defaultReport;
                    if ("track" === c && Ri(Tr.PIXEL_SEND, {
                            pixelCode: e,
                            extJSON: {
                                event: n
                            }
                        }), c === yr.TRACK) {
                        o && "string" == typeof o.currency && (o.currency = o.currency.toUpperCase());
                        var l = this.context.getTestID();
                        if (l) {
                            var f = this.assemblyData(e, n, o, a);
                            f.tt_test_id = l;
                            var d = No(f);
                            return null === (i = null == this ? void 0 : this.reportService) || void 0 === i || i.report(Nr, d, Bn.httpReport), d
                        }
                        if (o && "object" === t(o)) {
                            var h = o.value,
                                p = o.currency;
                            void 0 === h || Yi(h) || Ri(Tr.CUSTOM_ERROR, {
                                pixelCode: e,
                                custom_name: "invalid_value",
                                extJSON: {
                                    event: n,
                                    value: h,
                                    currency: p
                                }
                            }), void 0 === p || Wi(p, this.currency_list) || Ri(Tr.CUSTOM_ERROR, {
                                pixelCode: e,
                                custom_name: "invalid_currency",
                                extJSON: {
                                    event: n,
                                    value: h,
                                    currency: p
                                }
                            })
                        }
                        return v(u(r.prototype), "trackSync", this).call(this, e, n, o, a, c, s)
                    }
                    v(u(r.prototype), "trackSync", this).call(this, e, n, o, a, c, s)
                }
            }, {
                key: "trackPostTask",
                value: function(e) {
                    var t = e.reporterId,
                        n = e.eventType,
                        r = e.properties,
                        i = e.eventConfig;
                    return !Or.includes(n) && (this.selfHostConfig[t] && !this.hasReportEventHistory(n, Bn.htmlHttpReport) && (this.pushReport(n, this.getReportEventHistoryKey(Bn.htmlHttpReport)), this.trackSync(t, n, r, i, yr.SELFHOST, Bn.htmlHttpReport)), !0)
                }
            }, {
                key: "getReportEventHistoryKey",
                value: function(e) {
                    return e === Bn.htmlHttpReport ? this.selfHostConfig[this.getReporterId()] : "tiktok"
                }
            }, {
                key: "assemblySelfHostData",
                value: function(e, t) {
                    var n = arguments.length > 2 && void 0 !== arguments[2] ? arguments[2] : {},
                        r = arguments.length > 3 && void 0 !== arguments[3] ? arguments[3] : {},
                        i = arguments.length > 4 ? arguments[4] : void 0,
                        o = this.assemblyData(e, t, n, r, i),
                        a = this.ttp;
                    return a && (o.context.user.ttp = a), o
                }
            }]), r
        }(uo),
        Po = function(e) {
            s(n, e);
            var t = h(n);

            function n() {
                return i(this, n), t.apply(this, arguments)
            }
            return a(n, [{
                key: "getInstance",
                value: function() {
                    return this.pixelPromise = Promise.resolve(this), this.pixelPromise
                }
            }, {
                key: "track",
                value: function(e) {
                    var t = arguments.length > 1 && void 0 !== arguments[1] ? arguments[1] : {},
                        n = arguments.length > 2 && void 0 !== arguments[2] ? arguments[2] : {};
                    return Io(this.getReporterId(), "track", [e, t, n]), Promise.resolve(null)
                }
            }]), n
        }(Co = Ro([A.injectable(), Ao(0, A.inject(mo.ID)), Ao(1, A.inject(mo.Type)), Ao(2, A.inject(mo.IsOnsitePage)), Ao(3, A.inject(br.CONTEXT)), Ao(4, A.inject(mo.Info)), Ao(5, A.inject(br.TTQ_GLOBAL_OPTIONS)), Ao(6, A.inject(br.REPORT_SERVICE)), Ao(6, A.optional()), Ao(7, A.inject(mo.Plugins)), Ao(7, A.optional()), Ao(8, A.inject(mo.Rules)), Ao(8, A.optional()), Ao(9, A.inject(mo.Options)), Ao(9, A.optional())], Co)),
        wo = function(e, n, r, i) {
            var o, a = arguments.length,
                c = a < 3 ? n : null === i ? i = Object.getOwnPropertyDescriptor(n, r) : i;
            if ("object" === ("undefined" == typeof Reflect ? "undefined" : t(Reflect)) && "function" == typeof Reflect.decorate) c = Reflect.decorate(e, n, r, i);
            else
                for (var s = e.length - 1; s >= 0; s--)(o = e[s]) && (c = (a < 3 ? o(c) : a > 3 ? o(n, r, c) : o(n, r)) || c);
            return a > 3 && c && Object.defineProperty(n, r, c), c
        },
        ko = function(e, t) {
            return function(n, r) {
                t(n, r, e)
            }
        },
        Mo = function(t) {
            s(c, t);
            var n, o = h(c);

            function c(e, t, n, r, a, s, u, l, f, d, h, p, v, _, g, y, m, E, b, T, I, O) {
                var S;
                return i(this, c), (S = o.call(this, e, n, r, a)).env = l, S.reporters = t, S.cookieService = s, S.consentService = u, S.autoAdvancedMatchingPlugin = d, S.callbackPlugin = h, S.identifyPlugin = p, S.monitorPlugin = f, S.performanceInteractionPlugin = v, S.webFLPlugin = _, S.shopifyPlugin = g, S.autoConfigPlugin = y, S.diagnosticsConsolePlugin = m, S.competitorInsightPlugin = E, S.pangleCookieMatchingPlugin = b, S.eventBuilderPlugin = T, S.pagedataPlugin = O, S.enrichIpv6Plugin = I, S.autoAdvancedMatchingPlugin && S.usePlugin(S.autoAdvancedMatchingPlugin), S.callbackPlugin && S.usePlugin(S.callbackPlugin), S.identifyPlugin && S.usePlugin(S.identifyPlugin), S.monitorPlugin && S.usePlugin(S.monitorPlugin), S.performanceInteractionPlugin && S.usePlugin(S.performanceInteractionPlugin), S.webFLPlugin && S.usePlugin(S.webFLPlugin), S.shopifyPlugin && S.usePlugin(S.shopifyPlugin), S.autoConfigPlugin && S.usePlugin(S.autoConfigPlugin), S.diagnosticsConsolePlugin && S.usePlugin(S.diagnosticsConsolePlugin), S.competitorInsightPlugin && S.usePlugin(S.competitorInsightPlugin), S.pangleCookieMatchingPlugin && S.usePlugin(S.pangleCookieMatchingPlugin), S.eventBuilderPlugin && S.usePlugin(S.eventBuilderPlugin), S.enrichIpv6Plugin && S.usePlugin(S.enrichIpv6Plugin), S.monitorPlugin && (Ni.info.forEach((function(e) {
                    var t;
                    null === (t = S.monitorPlugin) || void 0 === t || t.info(e.event, e.detail, e.withoutJSB)
                })), Ni.error.forEach((function(e) {
                    var t;
                    null === (t = S.monitorPlugin) || void 0 === t || t.error(e.event, e.err, e.detail, e.withoutJSB)
                })), Ni.info = [], Ni.error = []), S.dispatch(ar.INIT_START), S.pagedataPlugin && S.usePlugin(S.pagedataPlugin), S.onPageLoaded(), S.onPageLeave(), S.init(), S.initExtension(), S.setPageInfo(location.href, document.referrer), S.dispatch(ar.INIT_END), S
            }
            return a(c, [{
                key: "initExtension",
                value: function() {
                    this.listenSPAHistoryChange()
                }
            }, {
                key: "initAdInfo",
                value: function(e) {
                    var t = ki(ur);
                    this.dispatch(ar.BEFORE_AD_INFO_INIT_START), t ? this.initAdCache(t) : this.initBaseAdInfo(e)
                }
            }, {
                key: "initAdCache",
                value: function(e) {
                    this.dispatch(ar.AD_INFO_INIT_START), e.ad_info_from = "cache", e.ad_info_status = "fulfilled(cache)", this.setAdInfo(e), this.initOffsiteAdInfo(e)
                }
            }, {
                key: "initBaseAdInfo",
                value: function(e) {
                    this.adService.webBridgeService.jsbridge && this.dispatch(ar.AD_INFO_INIT_START), v(u(c.prototype), "initAdInfo", this).call(this, e, (function(e) {
                        Ai(Tr.INIT_ERROR, e, {
                            extJSON: {
                                position: "initAdInfo"
                            }
                        })
                    }))
                }
            }, {
                key: "initOffsiteAdInfo",
                value: function(e) {
                    var t = function(e, t) {
                        var n = {};
                        try {
                            var r = e.creative_id,
                                i = (e.callback, e.idc),
                                o = e.convert_id,
                                a = e.ad_info_from,
                                c = e.ad_info_status,
                                s = e.log_extra,
                                u = e.ext_params,
                                l = e.ATTStatus;
                            if (r && (n.creative_id = r), i && (n.idc = i), o && (n.convert_id = o), a && (n.ad_info_from = a), c && (n.ad_info_status = c), u && (n.ext_params = u), l && (n.ATTStatus = l), s) {
                                var f = JSON.parse(s),
                                    d = f.ad_user_agent,
                                    h = f.ad_id,
                                    p = f.rit,
                                    v = f.ocbs,
                                    _ = f.vid,
                                    g = f.idc,
                                    y = f.country_id;
                                h && (n.ad_id = h), p && (n.rit = p), d && (n.ad_user_agent = d), v && (n.ocbs = v), _ && (n.vid = _), g && (n.idc = g), y && (n.country_id = y)
                            }
                            return n
                        } catch (e) {
                            return t && t(e), n
                        }
                    }(e, (function(e) {
                        Ai(Tr.INIT_ERROR, e, {
                            extJSON: {
                                position: "handleAdInfoOfficial"
                            }
                        })
                    }));
                    this.context.setOffsiteAdInfo(t);
                    var n = function(e, t) {
                        try {
                            var n = e.log_extra,
                                r = e.ttuts;
                            return !bi() || (gi(t) ? n ? 1 !== JSON.parse(n).user_tracking_status : null === e.ATTStatus || void 0 === e.ATTStatus || 3 === e.ATTStatus : null == r || 1 !== r)
                        } catch (e) {
                            return !1
                        }
                    }(e, this.env);
                    this.context.setEnableAdTracking(n), this.dispatch(ar.AD_INFO_INIT_END, {
                        extJSON: {
                            enabledAdTracking: n
                        }
                    })
                }
            }, {
                key: "initAppInfo",
                value: function(t) {
                    var n = this,
                        i = ki(lr);
                    i ? this.context.setAppInfo(i) : this.reportService.pushPreposition(r(e().mark((function r() {
                        var i;
                        return e().wrap((function(e) {
                            for (;;) switch (e.prev = e.next) {
                                case 0:
                                    return e.next = 2, n.initBaseAppInfo(t);
                                case 2:
                                    return i = e.sent, e.abrupt("return", i);
                                case 4:
                                case "end":
                                    return e.stop()
                            }
                        }), r)
                    })))())
                }
            }, {
                key: "initBaseAppInfo",
                value: (n = r(e().mark((function t(n) {
                    var r;
                    return e().wrap((function(e) {
                        for (;;) switch (e.prev = e.next) {
                            case 0:
                                return e.next = 2, this.appService.getAppInfo(n);
                            case 2:
                                return r = e.sent, this.context.setAppInfo(r), e.abrupt("return", r);
                            case 5:
                            case "end":
                                return e.stop()
                        }
                    }), t, this)
                }))), function(e) {
                    return n.apply(this, arguments)
                })
            }, {
                key: "initTestId",
                value: function(e) {
                    if (!this.context.getTestID()) {
                        var t = function() {
                            var e = arguments.length > 0 && void 0 !== arguments[0] ? arguments[0] : "",
                                t = arguments.length > 1 && void 0 !== arguments[1] ? arguments[1] : "";
                            try {
                                var n = Di("tt_test_id", e);
                                return n && n !== t && Bi("tt_test_id", n, void 0, "session"), n || t
                            } catch (e) {
                                return ""
                            }
                        }(e, ji("tt_test_id"));
                        this.context.setTestID(t)
                    }
                }
            }, {
                key: "initUserInfo",
                value: function() {
                    this.setCookieInfo()
                }
            }, {
                key: "instance",
                value: function(e) {
                    var t = this.getReporter(e);
                    return t || new Po(e, So.PIXEL_CODE, {
                        value: !1
                    }, this.context, {
                        pixelCode: e
                    }, {})
                }
            }, {
                key: "instances",
                value: function() {
                    return this.reporters
                }
            }, {
                key: "page",
                value: function(e) {
                    v(u(c.prototype), "page", this).call(this, Object.assign({
                        url: (null == e ? void 0 : e.page) || location.href,
                        referrer: (null == e ? void 0 : e.referrer) || document.referrer
                    }, e))
                }
            }, {
                key: "track",
                value: function(e) {
                    var t = arguments.length > 1 && void 0 !== arguments[1] ? arguments[1] : {},
                        n = arguments.length > 2 && void 0 !== arguments[2] ? arguments[2] : {},
                        r = n.pixel_code;
                    if (void 0 === r) v(u(c.prototype), "track", this).call(this, e, t, n);
                    else {
                        var i = this.instance(r);
                        if (i instanceof Po) return;
                        i.track(e, t, n)
                    }
                }
            }, {
                key: "setAdInfo",
                value: function(e) {
                    this.context.setAdInfo(e)
                }
            }, {
                key: "enableFirstPartyCookie",
                value: function(e) {
                    this.cookieService.enableFirstPartyCookie(e), e && this.setCookieInfo()
                }
            }, {
                key: "enableCookie",
                value: function() {
                    this.cookieService.enableFirstPartyCookie(!0), this.setCookieInfo(), this.cookieService.enableCookie()
                }
            }, {
                key: "disableCookie",
                value: function() {
                    this.cookieService.disableCookie(), this.context.setUserInfoWithoutIdentifyPlugin({
                        anonymous_id: void 0
                    }), this.disablePangleCookie()
                }
            }, {
                key: "holdConsent",
                value: function() {
                    this.consentService.setConsentMode(zn.HOLD)
                }
            }, {
                key: "revokeConsent",
                value: function() {
                    this.consentService.setConsentMode(zn.REVOKE)
                }
            }, {
                key: "grantConsent",
                value: function() {
                    this.consentService.setConsentMode(zn.GRANT)
                }
            }, {
                key: "disablePangleCookie",
                value: function() {
                    this.pangleCookieMatchingPlugin && this.pangleCookieMatchingPlugin.disablePangleCookie()
                }
            }, {
                key: "setAnonymousId",
                value: function(e) {
                    this.cookieService.setAnonymousId(e), this.initUserInfo()
                }
            }, {
                key: "resetCookieExpires",
                value: function() {
                    this.cookieService.resetExpires()
                }
            }, {
                key: "setCookieInfo",
                value: function() {
                    if (this.cookieService.canUseCookie()) {
                        var e = this.cookieService.getAnonymousId();
                        if (e) {
                            var t = {
                                anonymous_id: e
                            };
                            this.context.setUserInfoWithoutIdentifyPlugin(t)
                        }
                    }
                }
            }, {
                key: "onPageLoaded",
                value: function() {
                    var e = this;
                    window.addEventListener("load", (function() {
                        e.dispatch(ar.PAGE_DID_LOAD)
                    }), {
                        once: !0
                    })
                }
            }, {
                key: "onPageLeave",
                value: function() {
                    var e = this,
                        t = function() {
                            var t = Date.now();
                            e.dispatch(ar.PAGE_WILL_LEAVE, t), e.consentService.updateCache()
                        };
                    window.addEventListener("beforeunload", t, {
                        once: !0
                    }), bi() && window.addEventListener("onpagehide" in window ? "pagehide" : "unload", t)
                }
            }, {
                key: "listenSPAHistoryChange",
                value: function() {
                    var e = this,
                        t = function(t) {
                            var n = location.href,
                                r = e.context.getPageInfo().url;
                            n !== r && (e.setPageInfo(n, r), e.reporters && e.reporters.length > 0 && Ri(Tr.CUSTOM_INFO, {
                                pixelCode: e.reporters[0].id,
                                custom_name: "history_change",
                                custom_enum: String(e.reporters.length)
                            }))
                        };
                    window.addEventListener("popstate", t), history.pushState = Oo("pushState", t), history.replaceState = Oo("replaceState", t)
                }
            }, {
                key: "loadPixel",
                value: function(e, t) {
                    e && (this.reporters.find((function(t) {
                        return t.getReporterId() === e
                    })) ? Ci(Ir.DUPLICATE_PIXEL_CODE) : Vr().load(e, t || {}))
                }
            }]), c
        }(po),
        Lo = Mo = wo([A.injectable(), ko(0, A.inject(br.CONTEXT)), ko(1, A.inject(br.TTQ_REPORTERS)), ko(2, A.inject(br.AD_SERVICE)), ko(3, A.inject(br.APP_SERVICE)), ko(4, A.inject(br.REPORT_SERVICE)), ko(5, A.inject(br.COOKIE_SERVICE)), ko(6, A.inject(br.CONSENT_SERVICE)), ko(7, A.inject(br.ENV)), ko(8, A.inject(br.MONITOR_PLUGIN)), ko(8, A.optional()), ko(9, A.inject(br.AUTO_ADVANCED_MATCHING_PLUGIN)), ko(9, A.optional()), ko(10, A.inject(br.CALLBACK_PLUGIN)), ko(10, A.optional()), ko(11, A.inject(br.IDENTIFY_PLUGIN)), ko(11, A.optional()), ko(12, A.inject(br.PERFORMANCE_INTERACTION_PLUGIN)), ko(12, A.optional()), ko(13, A.inject(br.WEB_FL_PLUGIN)), ko(13, A.optional()), ko(14, A.inject(br.SHOPIFY_PLUGIN)), ko(14, A.optional()), ko(15, A.inject(br.AUTO_CONFIG_PLUGIN)), ko(15, A.optional()), ko(16, A.inject(br.DIAGNOSTICS_CONSOLE_PLUGIN)), ko(16, A.optional()), ko(17, A.inject(br.COMPETITOR_INSIGHT_PLUGIN)), ko(17, A.optional()), ko(18, A.inject(br.PANGLE_COOKIE_MATCHING_PLUGIN)), ko(18, A.optional()), ko(19, A.inject(br.EVENT_BUILDER_PLUGIN)), ko(19, A.optional()), ko(20, A.inject(br.ENRICH_IPV6_PLUGIN)), ko(20, A.optional()), ko(21, A.inject(br.PAGEDATA_PLUGIN)), ko(21, A.optional())], Mo),
        Do = function(e, n, r, i) {
            var o, a = arguments.length,
                c = a < 3 ? n : null === i ? i = Object.getOwnPropertyDescriptor(n, r) : i;
            if ("object" === ("undefined" == typeof Reflect ? "undefined" : t(Reflect)) && "function" == typeof Reflect.decorate) c = Reflect.decorate(e, n, r, i);
            else
                for (var s = e.length - 1; s >= 0; s--)(o = e[s]) && (c = (a < 3 ? o(c) : a > 3 ? o(n, r, c) : o(n, r)) || c);
            return a > 3 && c && Object.defineProperty(n, r, c), c
        },
        xo = function(e, t) {
            return function(n, r) {
                t(n, r, e)
            }
        },
        jo = function(e) {
            s(n, e);
            var t = h(n);

            function n(e, r, o, a, c) {
                var s;
                return i(this, n), (s = t.call(this, e)).setSignalType(c || or.OFFSITE), s.pageSign = {
                    sessionId: "",
                    pageId: "",
                    variationId: "",
                    pageIndex: {
                        main: -1,
                        sub: -1,
                        index: -1
                    }
                }, s.legacy = o.legacy || [], s.variationId = o.variation_id || "", s.serverUniqueId = o.server_unqiue_id || "", s.reportService = r, s.initPageSign(), gi(a) && bi() && (s.enableAdTracking = !1), s.data = f(s), s
            }
            return a(n, [{
                key: "getSessionIdFromCache",
                value: function() {
                    var e = null;
                    try {
                        e = JSON.parse(sessionStorage.getItem(vr) || "")
                    } catch (e) {}
                    return e
                }
            }, {
                key: "setSessionIdToCache",
                value: function(e) {
                    Mi(vr, e)
                }
            }, {
                key: "getVariationId",
                value: function() {
                    return this.variationId
                }
            }, {
                key: "isLegacyPixel",
                value: function(e) {
                    return function(e) {
                        var t = arguments.length > 1 && void 0 !== arguments[1] ? arguments[1] : [];
                        try {
                            return t.includes(e)
                        } catch (e) {
                            return !1
                        }
                    }(e, this.legacy)
                }
            }, {
                key: "assignPageInfo",
                value: function(e) {
                    Object.assign(this.pageInfo, e)
                }
            }, {
                key: "getSessionIndex",
                value: function() {
                    var e = {
                        main: -1,
                        sub: -1,
                        index: -1
                    };
                    try {
                        var t = JSON.parse(sessionStorage.getItem(_r) || "{}");
                        if (t) return Object.assign({}, e, t)
                    } catch (e) {}
                    return e
                }
            }, {
                key: "setUserInfo",
                value: function() {
                    var e = this,
                        t = arguments.length > 0 && void 0 !== arguments[0] ? arguments[0] : {};
                    if (0 !== Object.keys(t).length) {
                        var n = {};
                        Object.entries(t).forEach((function(t) {
                            var r = _(t, 2),
                                i = r[0],
                                o = r[1];
                            o && (i !== Br ? n[i] = String(o).trim() : e.setUserInfoWithoutIdentifyPlugin(c({}, Br, o)))
                        }));
                        var r = Vr(),
                            i = null == r ? void 0 : r.getPlugin("Identify");
                        i && this.reportService.pushPreposition(i.handleUserProperties(n, t).then((function() {
                            var t = arguments.length > 0 && void 0 !== arguments[0] ? arguments[0] : {},
                                r = t.userProperties,
                                o = t.userDataFormat,
                                a = t.userDataFormatV2;
                            if (r) {
                                Object.assign(e.userInfo, r);
                                var c = e.getUserFormatInfo() || {},
                                    s = e.getUserFormatInfoV2() || {},
                                    u = e.getSignalDiagnosticLabels() || {};
                                if (e.setUserFormatInfo(Object.assign({}, c, o)), e.setUserFormatInfoV2(Object.assign({}, s, a)), e.setSignalDiagnosticLabels(Object.assign({}, u, t.identifierLabel || {})), 0 === Object.keys(e.userInfo).length || 1 === Object.keys(n).length && Object.keys(n).includes("external_id")) return;
                                var l = i.reporters[0] || null,
                                    f = l ? Object.keys(Object.assign({}, l.getUserInfo(Jn.Manual), l.getUserInfo(Jn.Auto))) : [];
                                l && f.length && l.track("EnrichAM", {}, {}, yr.TRACK)
                            }
                        })).catch((function(e) {
                            Ai(Tr.API_ERROR, e, {
                                extJSON: {
                                    api: "identify"
                                }
                            })
                        })))
                    }
                }
            }, {
                key: "initPageSign",
                value: function() {
                    var e, t = this.getSessionIdFromCache();
                    null === t && (t = (e = this.serverUniqueId) ? "".concat(e, "::").concat($r(20)) : tr("sessionId"), this.setSessionIdToCache(t));
                    var n = this.getPageId(),
                        r = this.getVariationId(),
                        i = this.getSessionIndex();
                    i.main++, this.pageSign = {
                        sessionId: t,
                        pageId: n,
                        variationId: r,
                        pageIndex: i
                    }
                }
            }]), n
        }(io);
    jo = Do([A.injectable(), xo(0, A.inject(mo.WebLibraryInfo)), xo(1, A.inject(br.REPORT_SERVICE)), xo(2, A.inject(br.TTQ_GLOBAL_OPTIONS)), xo(3, A.inject(br.ENV)), xo(3, A.optional()), xo(4, A.inject(mo.SignalType)), xo(4, A.optional())], jo);
    var Uo = function(e, n, r, i) {
            var o, a = arguments.length,
                c = a < 3 ? n : null === i ? i = Object.getOwnPropertyDescriptor(n, r) : i;
            if ("object" === ("undefined" == typeof Reflect ? "undefined" : t(Reflect)) && "function" == typeof Reflect.decorate) c = Reflect.decorate(e, n, r, i);
            else
                for (var s = e.length - 1; s >= 0; s--)(o = e[s]) && (c = (a < 3 ? o(c) : a > 3 ? o(n, r, c) : o(n, r)) || c);
            return a > 3 && c && Object.defineProperty(n, r, c), c
        },
        Fo = function(e, t) {
            return function(n, r) {
                t(n, r, e)
            }
        },
        Bo = function() {
            function t(e) {
                i(this, t), this.webBridgeService = e
            }
            var n;
            return a(t, [{
                key: "getAdInfo",
                value: (n = r(e().mark((function t() {
                    var n, r, i, o, a = arguments;
                    return e().wrap((function(e) {
                        for (;;) switch (e.prev = e.next) {
                            case 0:
                                if (n = a.length > 0 && void 0 !== a[0] ? a[0] : window.location.href, r = this.getAdInfoFromURL(n), !this.webBridgeService.jsbridge) {
                                    e.next = 8;
                                    break
                                }
                                return e.next = 5, this.webBridgeService.getAdInfo();
                            case 5:
                                e.t0 = e.sent, e.next = 9;
                                break;
                            case 8:
                                e.t0 = {};
                            case 9:
                                return i = e.t0, (o = Object.assign({}, r, i)) && (o.creative_id && o.log_extra || o.callback) && Mi(ur, o), e.abrupt("return", o);
                            case 13:
                            case "end":
                                return e.stop()
                        }
                    }), t, this)
                }))), function() {
                    return n.apply(this, arguments)
                })
            }, {
                key: "getAdInfoFromURL",
                value: function() {
                    var e = arguments.length > 0 && void 0 !== arguments[0] ? arguments[0] : window.location.href;
                    try {
                        var t = Di(wr, e) || void 0,
                            n = Di(kr, e) || void 0,
                            r = Di(Mr, e) || void 0,
                            i = parseInt(Di(Lr, e), 10) || void 0,
                            o = r ? JSON.parse(r) : {},
                            a = o.log_extra,
                            c = void 0 === a ? void 0 : a,
                            s = o.idc,
                            u = void 0 === s ? void 0 : s,
                            l = o.cid,
                            f = void 0 === l ? void 0 : l;
                        return {
                            callback: t,
                            ext_params: n,
                            log_extra: c,
                            creative_id: f,
                            idc: u,
                            ttuts: i,
                            ad_info_from: (c || u || f) && "url"
                        }
                    } catch (e) {
                        return {}
                    }
                }
            }]), t
        }();
    Bo = Uo([A.injectable(), Fo(0, A.inject(br.BRIDGE_SERVICE))], Bo);
    var Go = function(e, n, r, i) {
            var o, a = arguments.length,
                c = a < 3 ? n : null === i ? i = Object.getOwnPropertyDescriptor(n, r) : i;
            if ("object" === ("undefined" == typeof Reflect ? "undefined" : t(Reflect)) && "function" == typeof Reflect.decorate) c = Reflect.decorate(e, n, r, i);
            else
                for (var s = e.length - 1; s >= 0; s--)(o = e[s]) && (c = (a < 3 ? o(c) : a > 3 ? o(n, r, c) : o(n, r)) || c);
            return a > 3 && c && Object.defineProperty(n, r, c), c
        },
        Ho = function(e, t) {
            return function(n, r) {
                t(n, r, e)
            }
        },
        Vo = function() {
            function t(e) {
                i(this, t), this.webBridgeService = e
            }
            var n;
            return a(t, [{
                key: "getAppInfo",
                value: (n = r(e().mark((function t(n) {
                    var r, i, o, a, c;
                    return e().wrap((function(e) {
                        for (;;) switch (e.prev = e.next) {
                            case 0:
                                if (r = n || window.location.href, (i = this.getAppInfoFromURL(r)).platform = yi(), !Ei()) {
                                    e.next = 11;
                                    break
                                }
                                return e.next = 6, mi();
                            case 6:
                                o = e.sent, a = o.model, c = o.platformVersion, i.device_model = a, i.android_version = c;
                            case 11:
                                return er(i) || Mi(lr, i), e.abrupt("return", i);
                            case 13:
                            case "end":
                                return e.stop()
                        }
                    }), t, this)
                }))), function(e) {
                    return n.apply(this, arguments)
                })
            }, {
                key: "getAppInfoFromURL",
                value: function(e) {
                    try {
                        var t = Di(Mr, e || window.location.href),
                            n = t && JSON.parse(t);
                        return {
                            device_id: n.device_id,
                            user_id: n.uid
                        }
                    } catch (e) {
                        return {}
                    }
                }
            }]), t
        }();
    Vo = Go([A.injectable(), Ho(0, A.inject(br.BRIDGE_SERVICE))], Vo);
    var Jo = "ad_analytics_msg",
        Ko = "insight_log",
        Wo = function(e) {
            return t = JSON.stringify(e), $i(t);
            var t
        },
        Yo = function(e) {
            return Boolean(e)
        },
        qo = function(e) {
            return !!(e.code && e.data && e.ret)
        };

    function Xo(e) {
        var t = !(arguments.length > 1 && void 0 !== arguments[1]) || arguments[1],
            n = {};
        try {
            if ("string" == typeof e) n.data = JSON.parse(e);
            else if (qo(e))(n = e).__data && (n.data = n.__data);
            else if (void 0 !== e.code) {
                var r = Object.assign({}, e),
                    i = r.code;
                n.code = i, delete r.code, r.data ? n.data = r.data : n.data = r
            } else n.data = e
        } catch (e) {
            t && Ai(Tr.JSB_ERROR, e, {
                extJSON: {
                    position: "getCallPromise bridge.call"
                }
            })
        }
        return n
    }
    var zo, Qo = function(e, n, r, i) {
            var o, a = arguments.length,
                c = a < 3 ? n : null === i ? i = Object.getOwnPropertyDescriptor(n, r) : i;
            if ("object" === ("undefined" == typeof Reflect ? "undefined" : t(Reflect)) && "function" == typeof Reflect.decorate) c = Reflect.decorate(e, n, r, i);
            else
                for (var s = e.length - 1; s >= 0; s--)(o = e[s]) && (c = (a < 3 ? o(c) : a > 3 ? o(n, r, c) : o(n, r)) || c);
            return a > 3 && c && Object.defineProperty(n, r, c), c
        },
        Zo = function(e, t) {
            return function(n, r) {
                t(n, r, e)
            }
        },
        $o = function() {
            function t(e, n) {
                i(this, t), this.env = e, _i(this.env) && (this.jsbridge = n), this.bridgeTimeout = 400
            }
            var n, o, c, s, u, l, f;
            return a(t, [{
                key: "getAdInfo",
                value: (f = r(e().mark((function t() {
                    var n = this;
                    return e().wrap((function(t) {
                        for (;;) switch (t.prev = t.next) {
                            case 0:
                                if (this.jsbridge) {
                                    t.next = 3;
                                    break
                                }
                                return Ai(Tr.JSB_ERROR, new Error("tt bridge error when getting ad info"), {
                                    extJSON: {
                                        position: "getAdInfo"
                                    }
                                }), t.abrupt("return", Promise.resolve({}));
                            case 3:
                                return t.abrupt("return", new Promise(function() {
                                    var t = r(e().mark((function t(r) {
                                        var i;
                                        return e().wrap((function(e) {
                                            for (;;) switch (e.prev = e.next) {
                                                case 0:
                                                    return e.prev = 0, e.next = 3, n.callAdInfo();
                                                case 3:
                                                    (i = e.sent).ad_info_from = "jsb", i.ad_info_status = i.ad_info_status || "fulfilled", r(i), e.next = 13;
                                                    break;
                                                case 9:
                                                    e.prev = 9, e.t0 = e.catch(0), r({}), Ai(Tr.JSB_ERROR, e.t0, {
                                                        extJSON: {
                                                            position: "getAdInfo"
                                                        }
                                                    });
                                                case 13:
                                                case "end":
                                                    return e.stop()
                                            }
                                        }), t, null, [
                                            [0, 9]
                                        ])
                                    })));
                                    return function(e) {
                                        return t.apply(this, arguments)
                                    }
                                }()));
                            case 4:
                            case "end":
                                return t.stop()
                        }
                    }), t, this)
                }))), function() {
                    return f.apply(this, arguments)
                })
            }, {
                key: "callAdInfo",
                value: (l = r(e().mark((function t() {
                    var n, r;
                    return e().wrap((function(e) {
                        for (;;) switch (e.prev = e.next) {
                            case 0:
                                return e.prev = 0, e.next = 3, this.call("adInfo", {}, window.top !== window ? 3500 : 5e3);
                            case 3:
                                if ((n = e.sent).data) {
                                    e.next = 6;
                                    break
                                }
                                return e.abrupt("return", Promise.reject("adInfo no data"));
                            case 6:
                                return r = {
                                    creative_id: n.data.cid,
                                    log_extra: n.data.log_extra
                                }, e.abrupt("return", r);
                            case 10:
                                if (e.prev = 10, e.t0 = e.catch(0), "JSBRIDGE TIMEOUT" !== e.t0) {
                                    e.next = 17;
                                    break
                                }
                                return Ri(Tr.CUSTOM_INFO, {
                                    custom_name: "ad_info_init_timeout"
                                }), e.abrupt("return", {
                                    ad_info_status: "timeout"
                                });
                            case 17:
                                return Ai(Tr.JSB_ERROR, e.t0, {
                                    extJSON: {
                                        position: "getAdInfo"
                                    }
                                }), e.abrupt("return", {});
                            case 19:
                            case "end":
                                return e.stop()
                        }
                    }), t, this, [
                        [0, 10]
                    ])
                }))), function() {
                    return l.apply(this, arguments)
                })
            }, {
                key: "getAppInfo",
                value: (u = r(e().mark((function t() {
                    return e().wrap((function(e) {
                        for (;;) switch (e.prev = e.next) {
                            case 0:
                                return e.abrupt("return", Promise.resolve({}));
                            case 1:
                            case "end":
                                return e.stop()
                        }
                    }), t)
                }))), function() {
                    return u.apply(this, arguments)
                })
            }, {
                key: "send",
                value: (s = r(e().mark((function t(n, r) {
                    var i, o, a, c, s, u, l, f;
                    return e().wrap((function(e) {
                        for (;;) switch (e.prev = e.next) {
                            case 0:
                                if (this.jsbridge) {
                                    e.next = 2;
                                    break
                                }
                                return e.abrupt("return", Promise.resolve());
                            case 2:
                                if (a = (null === (o = null === (i = null == n ? void 0 : n.context) || void 0 === i ? void 0 : i.ad) || void 0 === o ? void 0 : o.creative_id) || "0", c = Wo(n), s = {
                                        analytics_message: c,
                                        trackLogData: JSON.stringify(n),
                                        category: "ad_analytics_msg",
                                        tag: Jo,
                                        label: Ko
                                    }, !gi(this.env)) {
                                    e.next = 13;
                                    break
                                }
                                if (!bi() || !r) {
                                    e.next = 9;
                                    break
                                }
                                return u = {
                                    eventName: Ko,
                                    params: s
                                }, e.abrupt("return", this.call("sendLogWithAdInfo", u, this.bridgeTimeout));
                            case 9:
                                return l = {
                                    eventName: Jo,
                                    labelName: Ko,
                                    value: a,
                                    extValue: "0",
                                    extJson: s
                                }, e.abrupt("return", this.call("sendLog", l, this.bridgeTimeout));
                            case 13:
                                return f = {
                                    event_name: Ko,
                                    version: 2,
                                    properties: s
                                }, e.abrupt("return", this.call("track_event", f, 400));
                            case 15:
                            case "end":
                                return e.stop()
                        }
                    }), t, this)
                }))), function(e, t) {
                    return s.apply(this, arguments)
                })
            }, {
                key: "call",
                value: (c = r(e().mark((function t(n) {
                    var r, i, o, a = this,
                        c = arguments;
                    return e().wrap((function(e) {
                        for (;;) switch (e.prev = e.next) {
                            case 0:
                                return r = c.length > 1 && void 0 !== c[1] ? c[1] : {}, i = c.length > 2 && void 0 !== c[2] ? c[2] : 400, o = !(c.length > 3 && void 0 !== c[3]) || c[3], e.abrupt("return", new Promise((function(e, t) {
                                    if (!a.jsbridge) return t("JSBRIDGE ERROR"), void(o && Ai(Tr.JSB_ERROR, new Error("JSBRIDGE ERROR"), {
                                        extJSON: {
                                            position: "getCallPromise"
                                        }
                                    }));
                                    var c;
                                    i > 0 && (c = window.setTimeout((function() {
                                        t("JSBRIDGE TIMEOUT"), o && Ai(Tr.JSB_ERROR, new Error("JSBRIDGE TIMEOUT"), {
                                            extJSON: {
                                                position: "getCallPromise",
                                                method: n
                                            }
                                        })
                                    }), i)), a.jsbridge && a.jsbridge.call && a.jsbridge.call(n, r, (function(t) {
                                        var n = Xo(t, o);
                                        e(n), window.clearTimeout(c)
                                    }))
                                })));
                            case 4:
                            case "end":
                                return e.stop()
                        }
                    }), t)
                }))), function(e) {
                    return c.apply(this, arguments)
                })
            }, {
                key: "sendAnalyticsEvent",
                value: (o = r(e().mark((function t(n) {
                    var r, i, o, a, c;
                    return e().wrap((function(e) {
                        for (;;) switch (e.prev = e.next) {
                            case 0:
                                return r = n.method, i = n.path, o = n.params, a = n.data, e.next = 3, this.call("sendAnalyticsEvent", {
                                    method: r,
                                    path: i,
                                    params: o,
                                    data: a,
                                    header: {
                                        "Content-Type": "application/json"
                                    }
                                }, 0, !1);
                            case 3:
                                return c = e.sent, e.abrupt("return", null == c ? void 0 : c.code);
                            case 5:
                            case "end":
                                return e.stop()
                        }
                    }), t, this)
                }))), function(e) {
                    return o.apply(this, arguments)
                })
            }, {
                key: "updateWebFlData",
                value: (n = r(e().mark((function t(n) {
                    return e().wrap((function(e) {
                        for (;;) switch (e.prev = e.next) {
                            case 0:
                                if (!gi(this.env) || !bi()) {
                                    e.next = 2;
                                    break
                                }
                                return e.abrupt("return", this.call("updateFLLocalConv", n, this.bridgeTimeout));
                            case 2:
                            case "end":
                                return e.stop()
                        }
                    }), t, this)
                }))), function(e) {
                    return n.apply(this, arguments)
                })
            }]), t
        }();
    $o = Qo([A.injectable(), Zo(0, A.inject(br.ENV)), Zo(0, A.optional()), Zo(1, A.inject(br.JS_BRIDGE)), Zo(1, A.optional())], $o),
        function(e) {
            e[e.P0 = 4] = "P0", e[e.P1 = 3] = "P1", e[e.P2 = 2] = "P2", e[e.P3 = 1] = "P3"
        }(zo || (zo = {}));
    var ea = function(e, n, r, i) {
            var o, a = arguments.length,
                c = a < 3 ? n : null === i ? i = Object.getOwnPropertyDescriptor(n, r) : i;
            if ("object" === ("undefined" == typeof Reflect ? "undefined" : t(Reflect)) && "function" == typeof Reflect.decorate) c = Reflect.decorate(e, n, r, i);
            else
                for (var s = e.length - 1; s >= 0; s--)(o = e[s]) && (c = (a < 3 ? o(c) : a > 3 ? o(n, r, c) : o(n, r)) || c);
            return a > 3 && c && Object.defineProperty(n, r, c), c
        },
        ta = "tt_hold_events",
        na = function(e) {
            s(n, e);
            var t = h(n);

            function n() {
                var e;
                return i(this, n), (e = t.apply(this, arguments)).consentMode = zn.UNKNOWN, e.queue = [], e.debounceUpdateCache = ni((function() {
                    e.updateCache()
                }), 200, f(e)), e.handleHistoryQueue = Zr((function() {
                    var t = ki(ta);
                    Array.isArray(t) && (e.queue = e.queue.concat(t), e.changeQueueWithConsent())
                })), e
            }
            return a(n, [{
                key: "on",
                value: function(e, t) {
                    v(u(n.prototype), "on", this).call(this, e, t), this.handleHistoryQueue()
                }
            }, {
                key: "setConsentMode",
                value: function(e) {
                    this.consentMode = e, this.changeQueueWithConsent()
                }
            }, {
                key: "changeQueueWithConsent",
                value: function() {
                    switch (this.consentMode) {
                        case zn.REVOKE:
                            this.cleanQueue();
                            break;
                        case zn.GRANT:
                            this.releaseQueue(), this.cleanQueue();
                        case zn.HOLD:
                        case zn.UNKNOWN:
                    }
                }
            }, {
                key: "getConsentMode",
                value: function() {
                    return this.consentMode
                }
            }, {
                key: "cacheReportTask",
                value: function(e, t) {
                    var n = arguments.length > 2 && void 0 !== arguments[2] ? arguments[2] : Bn.defaultReport;
                    this.queue.push({
                        url: e,
                        data: t,
                        type: n
                    }), this.debounceUpdateCache()
                }
            }, {
                key: "cleanQueue",
                value: function() {
                    this.queue = [],
                        function(e) {
                            try {
                                window.sessionStorage.removeItem(e)
                            } catch (e) {}
                        }(ta)
                }
            }, {
                key: "updateCache",
                value: function() {
                    this.queue && this.queue.length > 0 && Mi(ta, this.queue)
                }
            }, {
                key: "releaseQueue",
                value: function() {
                    var e = this;
                    this.queue.sort((function(t, n) {
                        return e.getEventPriority(n.data) - e.getEventPriority(t.data)
                    })), this.emit("queue", this.queue)
                }
            }, {
                key: "getEventPriority",
                value: function(e) {
                    return e.event && e.event.length > 0 ? zo.P0 : e.action && e.action.length > 0 ? zo.P1 : "" === e.event ? zo.P2 : zo.P3
                }
            }]), n
        }(ao);
    na = ea([A.injectable()], na);
    var ra = function(e, n, r, i) {
            var o, a = arguments.length,
                c = a < 3 ? n : null === i ? i = Object.getOwnPropertyDescriptor(n, r) : i;
            if ("object" === ("undefined" == typeof Reflect ? "undefined" : t(Reflect)) && "function" == typeof Reflect.decorate) c = Reflect.decorate(e, n, r, i);
            else
                for (var s = e.length - 1; s >= 0; s--)(o = e[s]) && (c = (a < 3 ? o(c) : a > 3 ? o(n, r, c) : o(n, r)) || c);
            return a > 3 && c && Object.defineProperty(n, r, c), c
        },
        ia = function() {
            function t() {
                i(this, t)
            }
            var n;
            return a(t, [{
                key: "send",
                value: (n = r(e().mark((function t(n, r) {
                    var i, o, a = arguments;
                    return e().wrap((function(e) {
                        for (;;) switch (e.prev = e.next) {
                            case 0:
                                if (i = a.length > 2 && void 0 !== a[2] ? a[2] : 0, e.prev = 1, navigator && navigator.sendBeacon) {
                                    e.next = 4;
                                    break
                                }
                                return e.abrupt("return", !1);
                            case 4:
                                if ((o = navigator.sendBeacon(n, JSON.stringify(r))) || "number" != typeof i || !(i > 0)) {
                                    e.next = 10;
                                    break
                                }
                                return i--, e.next = 9, ri(200);
                            case 9:
                                return e.abrupt("return", this.send(n, r, i));
                            case 10:
                                return e.abrupt("return", o);
                            case 13:
                                return e.prev = 13, e.t0 = e.catch(1), e.abrupt("return", !1);
                            case 16:
                            case "end":
                                return e.stop()
                        }
                    }), t, this, [
                        [1, 13]
                    ])
                }))), function(e, t) {
                    return n.apply(this, arguments)
                })
            }, {
                key: "sendByImage",
                value: function(e, t) {
                    (new Image).src = function(e, t) {
                        var n = new URL(e);
                        return Object.keys(t).forEach((function(e) {
                            var r = t[e].toJSON ? t[e].toJSON() : String(t[e]);
                            n.searchParams.set(e, r)
                        })), n.toString()
                    }(e, t)
                }
            }]), t
        }();
    ia = ra([A.injectable()], ia);
    var oa = function(e, n, r, i) {
            var o, a = arguments.length,
                c = a < 3 ? n : null === i ? i = Object.getOwnPropertyDescriptor(n, r) : i;
            if ("object" === ("undefined" == typeof Reflect ? "undefined" : t(Reflect)) && "function" == typeof Reflect.decorate) c = Reflect.decorate(e, n, r, i);
            else
                for (var s = e.length - 1; s >= 0; s--)(o = e[s]) && (c = (a < 3 ? o(c) : a > 3 ? o(n, r, c) : o(n, r)) || c);
            return a > 3 && c && Object.defineProperty(n, r, c), c
        },
        aa = function(e, t) {
            return function(n, r) {
                t(n, r, e)
            }
        },
        ca = function(t) {
            s(f, t);
            var n, o, c, u, l = h(f);

            function f(e, t, n, r) {
                var o;
                return i(this, f), (o = l.call(this, e, t)).supportSendAnalyticsEvent = !0, o.consentService = n, o.consentService.on("queue", (function(e) {
                    e.forEach((function(e) {
                        var t = e.url,
                            n = e.data,
                            r = e.type;
                        o.report(t, n, r)
                    }))
                })), o.env = r, o
            }
            return a(f, [{
                key: "send",
                value: (u = r(e().mark((function t(n, r, i) {
                    var o, a, c, s, u, l;
                    return e().wrap((function(e) {
                        for (;;) switch (e.prev = e.next) {
                            case 0:
                                if (this.bridgeService.jsbridge) {
                                    e.next = 2;
                                    break
                                }
                                return e.abrupt("return");
                            case 2:
                                return u = !!r.context && "timeout" === (null === (a = null === (o = r.context) || void 0 === o ? void 0 : o.ad) || void 0 === a ? void 0 : a.ad_info_status), l = {}, e.prev = 4, e.next = 7, this.bridgeService.send(r, u);
                            case 7:
                                if ((l = e.sent) && 1 === l.code) {
                                    e.next = 10;
                                    break
                                }
                                throw new Error("[fetch bridge] sendLog error: code ".concat(l && l.code, ", data: ").concat(l && JSON.stringify(l)));
                            case 10:
                                return Ri(Tr.JSB_SEND, {
                                    pixelCode: null === (c = r.context.pixel) || void 0 === c ? void 0 : c.code,
                                    app_name: Ii() ? "ultralite" : "",
                                    extJSON: {
                                        event: r.event,
                                        event_id: r.event_id,
                                        need_inject_ad_info: u
                                    }
                                }), e.abrupt("return", l);
                            case 14:
                                e.prev = 14, e.t0 = e.catch(4), Ai(Tr.JSB_ERROR, e.t0, {
                                    pixelCode: null === (s = r.context.pixel) || void 0 === s ? void 0 : s.code,
                                    custom_name: "sendReportData",
                                    custom_enum: l && l.code ? "".concat(l.code) : "non",
                                    app_name: Ii() ? "ultralite" : "",
                                    extJSON: {
                                        position: "sendReportData"
                                    }
                                }), Ii() && Ei() && this.sendHttpReport(n, r, i);
                            case 18:
                            case "end":
                                return e.stop()
                        }
                    }), t, this, [
                        [4, 14]
                    ])
                }))), function(e, t, n) {
                    return u.apply(this, arguments)
                })
            }, {
                key: "sendHttpReport",
                value: (c = r(e().mark((function t(n, r, i) {
                    var o, a, c, s = arguments;
                    return e().wrap((function(e) {
                        for (;;) switch (e.prev = e.next) {
                            case 0:
                                return o = !(s.length > 3 && void 0 !== s[3]) || s[3], a = s.length > 4 ? s[4] : void 0, e.next = 4, this.httpService.send(n, r, a);
                            case 4:
                                e.sent || this.httpService.sendByImage(n, {
                                    analytics_message: i
                                }), o && Ri(Tr.HTTP_SEND, {
                                    pixelCode: null === (c = r.context.pixel) || void 0 === c ? void 0 : c.code,
                                    extJSON: {
                                        event: r.event,
                                        event_id: r.event_id
                                    }
                                });
                            case 7:
                            case "end":
                                return e.stop()
                        }
                    }), t, this)
                }))), function(e, t, n) {
                    return c.apply(this, arguments)
                })
            }, {
                key: "beforeReport",
                value: (o = r(e().mark((function t(n, r) {
                    var i, o, a = arguments;
                    return e().wrap((function(e) {
                        for (;;) switch (e.prev = e.next) {
                            case 0:
                                if (i = a.length > 2 && void 0 !== a[2] ? a[2] : Bn.defaultReport, (o = this.consentService.getConsentMode()) !== zn.REVOKE) {
                                    e.next = 4;
                                    break
                                }
                                return e.abrupt("return", !1);
                            case 4:
                                if (o !== zn.HOLD) {
                                    e.next = 7;
                                    break
                                }
                                return this.consentService.cacheReportTask(n, r, i), e.abrupt("return", !1);
                            case 7:
                                return e.abrupt("return", !0);
                            case 8:
                            case "end":
                                return e.stop()
                        }
                    }), t, this)
                }))), function(e, t) {
                    return o.apply(this, arguments)
                })
            }, {
                key: "report",
                value: (n = r(e().mark((function t(n, r) {
                    var i, o, a, c, s, u = arguments;
                    return e().wrap((function(e) {
                        for (;;) switch (e.prev = e.next) {
                            case 0:
                                return i = u.length > 2 && void 0 !== u[2] ? u[2] : Bn.defaultReport, e.next = 3, this.beforeReport(n, r, i);
                            case 3:
                                if (e.sent) {
                                    e.next = 6;
                                    break
                                }
                                return e.abrupt("return");
                            case 6:
                                if (o = Wo(r), i !== Bn.defaultReport || !this.bridgeService.jsbridge) {
                                    e.next = 11;
                                    break
                                }
                                return e.next = 10, this.send(n, r, o);
                            case 10:
                                return e.abrupt("return", e.sent);
                            case 11:
                                if (i !== Bn.httpReport || !this.bridgeService.jsbridge || !gi(this.env) || Ti() || !this.supportSendAnalyticsEvent) {
                                    e.next = 30;
                                    break
                                }
                                return a = n, e.prev = 13, a = new URL(n).pathname, e.next = 17, this.bridgeService.sendAnalyticsEvent({
                                    path: a,
                                    method: "POST",
                                    data: r
                                });
                            case 17:
                                if (c = e.sent, s = new Error("sendAnalyticsEvent not support: code ".concat(c, ", path: ").concat(a, ", data: ").concat(JSON.stringify(r))), null != c && -2 !== c) {
                                    e.next = 22;
                                    break
                                }
                                throw this.supportSendAnalyticsEvent = !1, s;
                            case 22:
                                if (1 !== c) {
                                    e.next = 24;
                                    break
                                }
                                return e.abrupt("return");
                            case 24:
                                throw s;
                            case 27:
                                e.prev = 27, e.t0 = e.catch(13), Ai(Tr.CUSTOM_ERROR, e.t0, {
                                    custom_name: "sendAnalyticsEvent",
                                    custom_enum: String(c)
                                }, !0);
                            case 30:
                                this.sendHttpReport(n, r, o, !(!zr(r.event) || !Qr(r)), Yo(r.action) ? 3 : void 0);
                            case 31:
                            case "end":
                                return e.stop()
                        }
                    }), t, this, [
                        [13, 27]
                    ])
                }))), function(e, t) {
                    return n.apply(this, arguments)
                })
            }, {
                key: "reportFL",
                value: function(e) {
                    this.bridgeService.jsbridge && this.bridgeService.updateWebFlData(e)
                }
            }]), f
        }(go);
    ca = oa([A.injectable(), aa(0, A.inject(br.HTTP_SERVICE)), aa(1, A.inject(br.BRIDGE_SERVICE)), aa(2, A.inject(br.CONSENT_SERVICE)), aa(3, A.inject(br.ENV)), aa(3, A.optional())], ca);
    var sa = function(e, n, r, i) {
            var o, a = arguments.length,
                c = a < 3 ? n : null === i ? i = Object.getOwnPropertyDescriptor(n, r) : i;
            if ("object" === ("undefined" == typeof Reflect ? "undefined" : t(Reflect)) && "function" == typeof Reflect.decorate) c = Reflect.decorate(e, n, r, i);
            else
                for (var s = e.length - 1; s >= 0; s--)(o = e[s]) && (c = (a < 3 ? o(c) : a > 3 ? o(n, r, c) : o(n, r)) || c);
            return a > 3 && c && Object.defineProperty(n, r, c), c
        },
        ua = {
            expires: 390
        },
        la = function() {
            function t() {
                i(this, t)
            }
            var n;
            return a(t, [{
                key: "genCookieID",
                value: function() {
                    return $r(27)
                }
            }, {
                key: "enableCookie",
                value: (n = r(e().mark((function t() {
                    return e().wrap((function(e) {
                        for (;;) switch (e.prev = e.next) {
                            case 0:
                                return Ui(fr, "1", ua), e.abrupt("return", Vi("https://analytics.tiktok.com/i18n/pixel/enable_cookie"));
                            case 2:
                            case "end":
                                return e.stop()
                        }
                    }), t)
                }))), function() {
                    return n.apply(this, arguments)
                })
            }, {
                key: "enableFirstPartyCookie",
                value: function(e) {
                    if (e) {
                        Ui(fr, "1", ua);
                        var t = this.genCookieID(),
                            n = this.getAnonymousId();
                        this.setAnonymousId(n || t)
                    }
                }
            }, {
                key: "disableCookie",
                value: function() {
                    Ui(fr, "0", ua), Ui(dr, "", Object.assign(ua, {
                        expires: -1
                    })), Vi("https://analytics.tiktok.com/i18n/pixel/disable_cookie")
                }
            }, {
                key: "setAnonymousId",
                value: function(e) {
                    var t = this.getAnonymousId() || e;
                    t && Ui(dr, t, ua)
                }
            }, {
                key: "getAnonymousId",
                value: function() {
                    return ji(dr) || ""
                }
            }, {
                key: "canUseCookie",
                value: function() {
                    try {
                        return "0" !== ji(fr)
                    } catch (e) {}
                    return !1
                }
            }, {
                key: "resetExpires",
                value: function() {
                    var e = ji(fr);
                    e && Ui(fr, e, ua);
                    var t = this.getAnonymousId();
                    t && this.setAnonymousId(t)
                }
            }]), t
        }();
    la = sa([A.injectable()], la);
    var fa = function(e, n, r, i) {
            var o, a = arguments.length,
                c = a < 3 ? n : null === i ? i = Object.getOwnPropertyDescriptor(n, r) : i;
            if ("object" === ("undefined" == typeof Reflect ? "undefined" : t(Reflect)) && "function" == typeof Reflect.decorate) c = Reflect.decorate(e, n, r, i);
            else
                for (var s = e.length - 1; s >= 0; s--)(o = e[s]) && (c = (a < 3 ? o(c) : a > 3 ? o(n, r, c) : o(n, r)) || c);
            return a > 3 && c && Object.defineProperty(n, r, c), c
        },
        da = function(e, t) {
            return function(n, r) {
                t(n, r, e)
            }
        },
        ha = function(e) {
            s(n, e);
            var t = h(n);

            function n(e, r) {
                return i(this, n), t.call(this, {
                    name: "Callback",
                    reporters: r,
                    context: e
                })
            }
            return a(n, [{
                key: "pixelDidMount",
                value: function(e) {
                    var t = Di("ttclid");
                    t && Bi("ttclid", t)
                }
            }, {
                key: "beforeShopifyPixelSend",
                value: function(e, t) {
                    var n = Li(e, "ttclid");
                    n || (n = Li(t, "ttclid")), n && Bi("ttclid", n)
                }
            }]), n
        }(fo);
    ha = fa([A.injectable(), da(0, A.inject(br.CONTEXT)), da(1, A.inject(br.TTQ_REPORTERS))], ha);
    var pa = ["(null)", "", "''\"", void 0, "e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855", "eb045d78d273107348b0300c01d29b7552d622abbc6faf81b3ec55359aa9950c", "not set", null, "6181738008c985a1b5f106b796c98e719efcc3c0ff68ddcd14a049825f4900a8", "2a539d6520266b56c3b0c525b9e6128858baeccb5ee9b694a2906e123c8d6dd3", "c6e52c372287175a895926604fa738a0ad279538a67371cd56909c7917e69ea1", "None", "74234e98afe7498fb5daf1f36ac2d78acc339464f950703b8c019892f982b90b", "f24f02d3c35894296522abac8c4b2439b1c1b650e1fb4c97c0f3c50b580b0a3c", "no", "a683c5c5349f6f7fb903ba8a9e7e55d0ba1b8f03579f95be83f4954c33e81098", "f18a2548c063c5a2b1560c6f2b9ec44bf9ed9017884404016d74f330119aaefe", "449f06574cd639e1826848ff5d70ba95904574be84f34e61baa526d517dfb493", "fcbcf165908dd18a9e49f7ff27810176db8e9f63b4352213741664245224f8aa", "NA", "bc857c49633bbc75644c51f36b16b2f768cc0ee13f65402ec7c32c96308272dd", "42cbf37902c6911d7b4e371fe8f8708a0ceda6946249d4a3e23de8d5e60ae8b7"],
        va = {
            isHash: function(e) {
                return !1
            },
            genIdentifierLabelByUserProperties: function(e) {
                return {}
            }
        },
        _a = {
            validatePhoneNumberLength: function(e) {},
            parsePhoneNumberFromString: function(e) {}
        },
        ga = {
            tryDecodeHashedBase64String: function(e) {
                return null
            },
            tryDecodeHashedBase64Hex: function(e) {
                return null
            }
        },
        ya = function(e) {
            var t, n = e.parsePhoneNumberFromString,
                r = e.validatePhoneNumberLength,
                i = e.isHash,
                o = e.genIdentifierLabelByUserProperties,
                a = e.tryDecodeHashedBase64String,
                c = e.tryDecodeHashedBase64Hex,
                s = e.checkEmailFormat,
                u = e.checkMDNEmailFormat;
            e.sha256, t = {
                    checkEmailFormat: s,
                    checkMDNEmailFormat: u
                }, t.checkMDNEmailFormat,
                function(e) {
                    var t = e.tryDecodeHashedBase64String,
                        n = e.tryDecodeHashedBase64Hex;
                    ga.tryDecodeHashedBase64String = t, ga.tryDecodeHashedBase64Hex = n
                }({
                    tryDecodeHashedBase64String: a,
                    tryDecodeHashedBase64Hex: c
                }),
                function(e) {
                    var t = e.isHash,
                        n = e.genIdentifierLabelByUserProperties;
                    va.isHash = t, va.genIdentifierLabelByUserProperties = n
                }({
                    isHash: i,
                    genIdentifierLabelByUserProperties: o
                }),
                function(e) {
                    var t = e.parsePhoneNumberFromString,
                        n = e.validatePhoneNumberLength;
                    _a.parsePhoneNumberFromString = t, _a.validatePhoneNumberLength = n
                }({
                    parsePhoneNumberFromString: n,
                    validatePhoneNumberLength: r
                })
        },
        ma = function(e) {
            var t = arguments.length > 1 && void 0 !== arguments[1] ? arguments[1] : "",
                n = arguments.length > 2 && void 0 !== arguments[2] ? arguments[2] : _a.parsePhoneNumberFromString,
                r = e,
                i = t ? n(e, t) : n(e);
            return i ? r = "86" === i.countryCallingCode ? i.nationalNumber : i.number : e.replace(/[^0-9]/g, "").length > 0 && (r = e.replace(/[^0-9]/g, "")), r
        },
        Ea = function(e, n, r, i) {
            var o, a = arguments.length,
                c = a < 3 ? n : null === i ? i = Object.getOwnPropertyDescriptor(n, r) : i;
            if ("object" === ("undefined" == typeof Reflect ? "undefined" : t(Reflect)) && "function" == typeof Reflect.decorate) c = Reflect.decorate(e, n, r, i);
            else
                for (var s = e.length - 1; s >= 0; s--)(o = e[s]) && (c = (a < 3 ? o(c) : a > 3 ? o(n, r, c) : o(n, r)) || c);
            return a > 3 && c && Object.defineProperty(n, r, c), c
        },
        ba = function(e, t) {
            return function(n, r) {
                t(n, r, e)
            }
        },
        Ta = function(t) {
            s(u, t);
            var n, o, c = h(u);

            function u(e, t) {
                var n;
                return i(this, u), (n = c.call(this, {
                    name: "Identify",
                    reporters: t,
                    context: e
                })).init(), n
            }
            return a(u, [{
                key: "setIdentifyUtils",
                value: function(e) {
                    var t = e.isHash,
                        n = e.sha256,
                        r = e.genIdentifierLabelByUserProperties,
                        i = e.tryDecodeHashedBase64String,
                        o = e.tryDecodeHashedBase64Hex,
                        a = e.validatePhoneNumberLength,
                        c = e.parsePhoneNumberFromString,
                        s = e.checkEmailFormat,
                        u = e.checkMDNEmailFormat,
                        l = e.getCookieDeprecationLabel,
                        f = e.getAllTopics;
                    ya({
                        isHash: t,
                        sha256: n,
                        genIdentifierLabelByUserProperties: r,
                        tryDecodeHashedBase64String: i,
                        tryDecodeHashedBase64Hex: o,
                        validatePhoneNumberLength: a,
                        parsePhoneNumberFromString: c,
                        checkEmailFormat: s,
                        checkMDNEmailFormat: u
                    }), this.parsePhoneNumberFromString = c, this.checkMDNEmailFormat = u, this.checkEmailFormat = s, this.sha256 = n, this.getCookieDeprecationLabel = l, this.getAllTopics = f
                }
            }, {
                key: "init",
                value: function() {
                    var e = this;
                    return this.pluginPromise || (Ri(Tr.IDENTIFY_INIT_START), this.pluginPromise = Vi("https://analytics.tiktok.com/i18n/pixel/static/identify_ce1d8843.js").then((function() {
                        e.detectTopics(), Ri(Tr.IDENTIFY_INIT_END)
                    })).catch((function() {
                        var e = new Error("Loading chunk identify failed.\n(error: ".concat(window.location.host, "/static/identify.js)"));
                        return e.name = "ChunkLoadError", Promise.reject(e)
                    }))), this.pluginPromise
                }
            }, {
                key: "handleUserProperties",
                value: (o = r(e().mark((function t(n, r) {
                    var i, o, a, c = this;
                    return e().wrap((function(e) {
                        for (;;) switch (e.prev = e.next) {
                            case 0:
                                if (n) {
                                    e.next = 2;
                                    break
                                }
                                return e.abrupt("return", void 0);
                            case 2:
                                return e.next = 4, this.init();
                            case 4:
                                return i = this.identifyParamsFormattedInfo(n), o = this.identifyParamsFormattedInfoV2(n), a = va.genIdentifierLabelByUserProperties(r), this.handlePIIDiagnostics(o), Object.entries(n).forEach((function(e) {
                                    var t = _(e, 2),
                                        r = t[0],
                                        i = t[1],
                                        a = void 0 === i ? "" : i;
                                    if (a) {
                                        var s = String(a);
                                        if (["email", "phone_number", "sha256_email", "sha256_phone_number"].includes(r)) {
                                            var u = c.getUserDataFormatInfoV2KeyName(r),
                                                l = ga.tryDecodeHashedBase64Hex(s);
                                            if (null !== l) n[r] = l, null !== u && (o = c.updateUserDataFormatV2Label(u, Vn.BASE64_HEX_HASHED, o));
                                            else {
                                                var f = ga.tryDecodeHashedBase64String(s);
                                                f && (n[r] = f, null !== u && (o = c.updateUserDataFormatV2Label(u, Vn.BASE64_STRING_HASHED, o)))
                                            }
                                        }
                                        switch ("zip_code" === r && s && (va.isHash(s) ? o = c.updateUserDataFormatV2Label("zip_code", Vn.ZIP_CODE_IS_HASHED, o) : (o = c.updateUserDataFormatV2Label("zip_code", Vn.ZIP_CODE_IS_NOT_HASHED, o), c.isZipFromUs(n) ? (n.zip_code = c.sha256(c.truncateString(s, 5)), o = c.updateUserDataFormatV2Label("zip_code", Vn.ZIP_CODE_IS_US, o)) : (n.zip_code = c.sha256(s), o = c.updateUserDataFormatV2Label("zip_code", Vn.ZIP_CODE_IS_NOT_US, o)))), r) {
                                            case "email":
                                                n.email = va.isHash(s) && !c.checkEmailFormat(s) ? s : c.sha256(c.handleEmail(s));
                                                break;
                                            case "phone_number":
                                                n.phone_number = va.isHash(s) ? s : c.sha256(c.handlePhoneNumber(s));
                                                break;
                                            case "auto_email":
                                                n.auto_email = c.sha256(c.handleEmail(s));
                                                break;
                                            case "auto_phone_number":
                                                n.auto_phone_number = c.sha256(c.handlePhoneNumber(s));
                                                break;
                                            case "first_name":
                                                n.first_name = va.isHash(s) ? s : c.sha256(s);
                                                break;
                                            case "last_name":
                                                n.last_name = va.isHash(s) ? s : c.sha256(s);
                                                break;
                                            case "city":
                                                n.city = c.truncateString(s, 80);
                                                break;
                                            case "state":
                                                n.state = c.truncateString(s, 80);
                                                break;
                                            case "country":
                                                n.country = c.truncateString(s, 80);
                                                break;
                                            default:
                                                return
                                        }
                                    }
                                })), n.sha256_email && (n.email = this.handleCheckHashedEmailValue(String(n.sha256_email), i)), n.sha256_phone_number && (n.phone_number = this.handleCheckHashedPhoneValue(String(n.sha256_phone_number), i)), e.abrupt("return", {
                                    userProperties: n,
                                    userDataFormat: i,
                                    userDataFormatV2: o,
                                    identifierLabel: a
                                });
                            case 12:
                            case "end":
                                return e.stop()
                        }
                    }), t, this)
                }))), function(e, t) {
                    return o.apply(this, arguments)
                })
            }, {
                key: "identifyParamsFormattedInfo",
                value: function(e) {
                    var t = this,
                        n = {},
                        r = /^sha256_(.*)$/;
                    return Object.entries(e).forEach((function(e) {
                        var i = _(e, 2),
                            o = i[0],
                            a = i[1],
                            c = String(void 0 === a ? "" : a),
                            s = o.match(r);
                        switch (o) {
                            case "email":
                                t.handleEmailFormat(c, "email", n);
                                break;
                            case "phone_number":
                                t.handlePhoneNumberFormat(c, "phone_number", n);
                                break;
                            case "auto_email":
                                t.handleEmailFormat(c, "auto_email", n);
                                break;
                            case "auto_phone_number":
                                t.handlePhoneNumberFormat(c, "auto_phone_number", n);
                                break;
                            case (s || {}).input:
                                var u = null == s ? void 0 : s.pop();
                                u && Dr.includes(u) && (n[u] = [Hn.HASHED]);
                                break;
                            case "first_name":
                            case "last_name":
                            case "city":
                            case "state":
                            case "country":
                            case "zip_code":
                                t.handleNewPiisFormat(c, o, n);
                                break;
                            default:
                                n[o] = [Hn.CORRECT_FORMAT]
                        }
                    })), n
                }
            }, {
                key: "identifyParamsFormattedInfoV2",
                value: function(e) {
                    var t = this,
                        n = {};
                    return Object.entries(e).forEach((function(e) {
                        var r = _(e, 2),
                            i = r[0],
                            o = r[1],
                            a = String(void 0 === o ? "" : o);
                        switch (i) {
                            case "email":
                                t.handlePixelValidation(a, xr, n);
                                break;
                            case "phone_number":
                                t.handlePixelValidation(a, jr, n);
                                break;
                            case "sha256_email":
                                t.handlePixelValidation(a, Ur, n);
                                break;
                            case "sha256_phone_number":
                                t.handlePixelValidation(a, Fr, n);
                                break;
                            case "first_name":
                            case "last_name":
                            case "city":
                            case "state":
                            case "country":
                            case "zip_code":
                                break;
                            default:
                                n[i] = [Vn.UNKNOWN_INVALID]
                        }
                    })), n
                }
            }, {
                key: "handlePixelValidation",
                value: function(e, t, n) {
                    n[t] = [], pa.includes(e) && n[t].push(Vn.FILTER_EVENTS), e && va.isHash(e) && n[t].push(Vn.HASHED), e && this.checkEmailFormat(e) && n[t].push(Vn.PLAIN_EMAIL), e && this.checkMDNEmailFormat(e) && n[t].push(Vn.PLAIN_MDN_EMAIL), e && this.parsePhoneNumberFromString(e) && n[t].push(Vn.PLAIN_PHONE), e && 0 === n[t].length && n[t].push(Vn.UNKNOWN_INVALID)
                }
            }, {
                key: "handleEmail",
                value: function(e) {
                    return e.toLowerCase()
                }
            }, {
                key: "handlePhoneNumber",
                value: function(e) {
                    var t = arguments.length > 1 && void 0 !== arguments[1] ? arguments[1] : this.parsePhoneNumberFromString;
                    return ma(e, "", t)
                }
            }, {
                key: "handleEmailFormat",
                value: function(e, t, n) {
                    var r = this.handleCheckEmail(String(e), this.checkEmailFormat);
                    n && n[t] && (n[t] || []).includes(Hn.HASHED) || (n[t] = r)
                }
            }, {
                key: "handleNewPiisFormat",
                value: function(e, t, n) {
                    e && (n[t] = [Hn.CORRECT_FORMAT])
                }
            }, {
                key: "handlePhoneNumberFormat",
                value: function(e, t, n) {
                    var r = this.handleCheckPhoneNumber(String(e), this.parsePhoneNumberFromString);
                    n[t] = r
                }
            }, {
                key: "handleCheckPhoneNumber",
                value: function(e) {
                    var t = arguments.length > 1 && void 0 !== arguments[1] ? arguments[1] : this.parsePhoneNumberFromString,
                        n = [];
                    if (!e) return n.push(Hn.EMPTY_VALUE), n;
                    if (va.isHash(e)) return n.push(Hn.HASHED), n;
                    var r = t(e);
                    return r ? (n.push(Hn.CORRECT_FORMAT), n) : (n.push(Hn.WRONG_FORMAT), n)
                }
            }, {
                key: "handleCheckEmail",
                value: function(e) {
                    var t = arguments.length > 1 && void 0 !== arguments[1] ? arguments[1] : this.checkEmailFormat,
                        n = [];
                    return e ? va.isHash(e) ? (n.push(Hn.HASHED), n) : t(e) ? (n.push(Hn.CORRECT_FORMAT), n) : (n.push(Hn.WRONG_FORMAT), n) : (n.push(Hn.EMPTY_VALUE), n)
                }
            }, {
                key: "handleCheckHashedEmailValue",
                value: function(e, t) {
                    var n = arguments.length > 2 && void 0 !== arguments[2] ? arguments[2] : this.checkEmailFormat;
                    return t.email = t.email || [], va.isHash(e) ? (null == t || t.email.push(Hn.HASHED_CORRECT), e) : n(e) ? (null == t || t.email.push(Hn.PLAINTEXT_EMAIL), this.sha256(this.handleEmail(String(e)))) : (null == t || t.email.push(Hn.HASHED_ERR), this.sha256(e))
                }
            }, {
                key: "handleCheckHashedPhoneValue",
                value: function(e, t) {
                    var n = arguments.length > 2 && void 0 !== arguments[2] ? arguments[2] : this.parsePhoneNumberFromString;
                    return t.phone_number = t.phone_number || [], va.isHash(e) ? (null == t || t.phone_number.push(Hn.HASHED_CORRECT), e) : n(e) ? (t.phone_number.push(Hn.PLAINTEXT_PHONE), this.sha256(this.handlePhoneNumber(String(e), n))) : (null == t || t.phone_number.push(Hn.HASHED_ERR), this.sha256(e))
                }
            }, {
                key: "handlePIIDiagnostics",
                value: function(e) {
                    try {
                        var t = e.email_is_hashed,
                            n = void 0 === t ? [] : t,
                            r = e.sha256_email,
                            i = void 0 === r ? [] : r,
                            o = e.phone_is_hashed,
                            a = void 0 === o ? [] : o,
                            c = e.sha256_phone,
                            s = void 0 === c ? [] : c;
                        if (n.includes(Vn.UNKNOWN_INVALID) || i.includes(Vn.UNKNOWN_INVALID)) return void Ci(Ir.INVALID_EMAIL_FORMAT);
                        if (a.includes(Vn.UNKNOWN_INVALID) || s.includes(Vn.UNKNOWN_INVALID)) return void Ci(Ir.INVALID_PHONE_NUMBER_FORMAT);
                        if (n.includes(Vn.FILTER_EVENTS) || i.includes(Vn.FILTER_EVENTS)) return void Ci(Ir.INVALID_EMAIL_INFORMATION);
                        if (a.includes(Vn.FILTER_EVENTS) || s.includes(Vn.FILTER_EVENTS)) return void Ci(Ir.INVALID_PHONE_NUMBER_INFORMATION)
                    } catch (e) {}
                }
            }, {
                key: "getUserDataFormatInfoV2KeyName",
                value: function(e) {
                    return {
                        email: "email_is_hashed",
                        phone_number: "phone_is_hashed",
                        sha256_email: "sha256_email",
                        sha256_phone_number: "sha256_phone",
                        zip_code: "zip_code"
                    }[e] || null
                }
            }, {
                key: "updateUserDataFormatV2Label",
                value: function(e, t, n) {
                    var r, i;
                    return (null === n[e] || void 0 === n[e] || (null === (r = n[e]) || void 0 === r ? void 0 : r.includes(Vn.UNKNOWN_INVALID))) && (n[e] = []), null === (i = n[e]) || void 0 === i || i.push(t), n
                }
            }, {
                key: "isZipFromUs",
                value: function(e) {
                    var t;
                    return "us" === (null === (t = e.country) || void 0 === t ? void 0 : t.toLowerCase()) || !1
                }
            }, {
                key: "truncateString",
                value: function(e, t) {
                    var n = Array.from(e);
                    return n.length <= t ? e : n.slice(0, t).join("")
                }
            }, {
                key: "detectTopics",
                value: (n = r(e().mark((function t() {
                    var n, r;
                    return e().wrap((function(e) {
                        for (;;) switch (e.prev = e.next) {
                            case 0:
                                return e.prev = 0, e.next = 3, this.getCookieDeprecationLabel();
                            case 3:
                                return n = e.sent, e.next = 6, this.getAllTopics();
                            case 6:
                                (r = e.sent) && Ri(Tr.CUSTOM_INFO, {
                                    custom_name: "topics",
                                    custom_enum: r.toString(),
                                    extJSON: {
                                        cookie_label: String(n)
                                    }
                                }), e.next = 12;
                                break;
                            case 10:
                                e.prev = 10, e.t0 = e.catch(0);
                            case 12:
                            case "end":
                                return e.stop()
                        }
                    }), t, this, [
                        [0, 10]
                    ])
                }))), function() {
                    return n.apply(this, arguments)
                })
            }]), u
        }(fo);

    function Ia(e) {
        var t = arguments.length > 1 && void 0 !== arguments[1] ? arguments[1] : 500,
            n = Date.now();
        return function() {
            var r = Array.prototype.slice.call(arguments),
                i = Date.now();
            i - n >= t && (e.apply(void 0, y(r)), n = i)
        }
    }
    Ta = Ea([A.injectable(), ba(0, A.inject(br.CONTEXT)), ba(1, A.inject(br.TTQ_REPORTERS))], Ta);
    var Oa = {
            fcp: "first_contentful_paint",
            lcp: "largest_contentful_paint",
            cls: "cumulative_layout_shift",
            fid: "first_input_delay",
            tti: "time_to_interactive",
            navigationStart: "navigation_start",
            loadEventStart: "load_event_start",
            requestStart: "request_start",
            enterTime: "enter_time",
            leaveTime: "leave_time",
            docHeight: "doc_height",
            maxScrollHeight: "max_scroll_height",
            clickTimes: "click_times",
            scrollTimes: "scroll_times",
            connectionType: "connection_type"
        },
        Sa = function(e, n, r, i) {
            var o, a = arguments.length,
                c = a < 3 ? n : null === i ? i = Object.getOwnPropertyDescriptor(n, r) : i;
            if ("object" === ("undefined" == typeof Reflect ? "undefined" : t(Reflect)) && "function" == typeof Reflect.decorate) c = Reflect.decorate(e, n, r, i);
            else
                for (var s = e.length - 1; s >= 0; s--)(o = e[s]) && (c = (a < 3 ? o(c) : a > 3 ? o(n, r, c) : o(n, r)) || c);
            return a > 3 && c && Object.defineProperty(n, r, c), c
        },
        Na = function(e, t) {
            return function(n, r) {
                t(n, r, e)
            }
        },
        Ra = function(e) {
            s(n, e);
            var t = h(n);

            function n(e, r, o, a, c, s, u) {
                var l;
                return i(this, n), (l = t.call(this, {
                    name: "PerformanceInteraction",
                    reporters: o,
                    context: r
                })).monitors = [], l.currentUrl = "", l.ttqOptions = {}, l.env = e, l.reportService = a, l.interactionMonitor = c, l.performanceMonitor = s, l.ttqOptions = u, l.init(), l
            }
            return a(n, [{
                key: "reportSwitch",
                value: function() {
                    var e, t, n = Di(wr),
                        r = "";
                    try {
                        var i = window.sessionStorage && window.sessionStorage.getItem(ur);
                        if (i) r = JSON.parse(i).callback
                    } catch (e) {}
                    return !!(n || r || gi(this.env) || (null === (t = null === (e = this.ttqOptions) || void 0 === e ? void 0 : e.plugins) || void 0 === t ? void 0 : t.PerformanceInteraction))
                }
            }, {
                key: "init",
                value: function() {
                    var e = this;
                    this.reportSwitch() && (this.monitors.push(this.interactionMonitor), this.monitors.push(this.performanceMonitor), this.monitors.forEach((function(e) {
                        e.init()
                    })), setInterval((function() {
                        e.report()
                    }), 1e4))
                }
            }, {
                key: "pageUrlWillChange",
                value: function(e, t) {
                    this.reportSwitch() && (this.monitors.forEach((function(n) {
                        n.pageUrlWillChange(e, t)
                    })), e && this.report())
                }
            }, {
                key: "pageWillLeave",
                value: function(e) {
                    this.reportSwitch() && (this.monitors.forEach((function(t) {
                        t.pageWillLeave(e)
                    })), this.report())
                }
            }, {
                key: "pageUrlDidChange",
                value: function(e) {
                    this.currentUrl !== e && this.reportSwitch() && (this.currentUrl = e, this.monitors.forEach((function(t) {
                        t.pageUrlDidChange(e)
                    })), this.report())
                }
            }, {
                key: "report",
                value: function() {
                    var e = this;
                    if (this.reportSwitch()) {
                        var t = this.transformReportData(this.collectorData());
                        if (Object.keys(t).length) {
                            var n = yr.PERFORMANCE_INTERACTION,
                                r = wi(n);
                            null !== r && Ji(this.reportService.reportPreposition || []).then((function() {
                                e.reportService.report(r, e.assemblyMergedData(t, n), function(e) {
                                    return {
                                        performance_interaction: Bn.httpReport
                                    }[e] || Bn.htmlHttpReport
                                }(n))
                            }))
                        }
                    }
                }
            }, {
                key: "assemblyMergedData",
                value: function(e, t) {
                    var n, r = this.context.getPageSign(),
                        i = this.reporters[0],
                        o = (null == i ? void 0 : i.getReporterId()) || "",
                        a = this.reporters.map((function(e) {
                            return e.getReporterId()
                        })).join("|"),
                        c = null == i ? void 0 : i.assemblyData(o, "", e, {}, t);
                    return c && (c.context.pixel && (c.context.pixel.codes = a), c.context.index = null === (n = r.pageIndex) || void 0 === n ? void 0 : n.index, c.context.session_id = r.sessionId), c || {}
                }
            }, {
                key: "collectorData",
                value: function() {
                    return this.monitors.reduce((function(e, t) {
                        return t.isChanged() && (e = Object.assign({}, e, t.getResult())), e
                    }), {})
                }
            }, {
                key: "transformReportData",
                value: function(e) {
                    return Object.entries(e).reduce((function(e, t) {
                        var n = _(t, 2),
                            r = n[0],
                            i = n[1];
                        return e[Oa[r]] = i, e
                    }), {})
                }
            }]), n
        }(fo);

    function Aa() {
        var e = document.body,
            t = document.documentElement;
        return Math.max(e ? e.scrollHeight : 0, e ? e.offsetHeight : 0, t ? t.clientHeight : 0, t ? t.scrollHeight : 0, t ? t.offsetHeight : 0)
    }

    function Ca() {
        return document.documentElement.clientHeight + window.pageYOffset
    }
    Ra = Sa([A.injectable(), Na(0, A.inject(br.ENV)), Na(1, A.inject(br.CONTEXT)), Na(2, A.inject(br.TTQ_REPORTERS)), Na(3, A.inject(br.REPORT_SERVICE)), Na(4, A.inject(br.INTERACTION_MONITOR)), Na(5, A.inject(br.PERFORMANCE_MONITOR)), Na(6, A.inject(br.TTQ_GLOBAL_OPTIONS))], Ra);
    var Pa = function(e, n, r, i) {
            var o, a = arguments.length,
                c = a < 3 ? n : null === i ? i = Object.getOwnPropertyDescriptor(n, r) : i;
            if ("object" === ("undefined" == typeof Reflect ? "undefined" : t(Reflect)) && "function" == typeof Reflect.decorate) c = Reflect.decorate(e, n, r, i);
            else
                for (var s = e.length - 1; s >= 0; s--)(o = e[s]) && (c = (a < 3 ? o(c) : a > 3 ? o(n, r, c) : o(n, r)) || c);
            return a > 3 && c && Object.defineProperty(n, r, c), c
        },
        wa = function() {
            function e() {
                i(this, e), this.connectionType = "", this._docHeight = 0, this._maxScrollHeight = 0, this.clickTimes = 0, this.scrollTimes = 0, this.isDocHeightChanged = !1, this.isMaxScrollHeightChanged = !1, this.enterTime = 0, this.leaveTime = 0, this.isFirstReport = !0
            }
            return a(e, [{
                key: "init",
                value: function() {
                    ! function(e) {
                        var t = Ia((function(t) {
                            e()
                        }), 100);
                        window.addEventListener("click", t, {
                            capture: !0
                        })
                    }(this.updateClickTimes.bind(this)),
                    function(e) {
                        var t = Ia((function() {
                            var t = {
                                scrollHeight: Ca(),
                                docHeight: Aa()
                            };
                            e(t)
                        }), 500);
                        window.addEventListener("scroll", t, {
                            passive: !0
                        })
                    }(this.updateScrollData.bind(this))
                }
            }, {
                key: "pageUrlWillChange",
                value: function(e, t) {
                    "" !== e ? this.leaveTime = Date.now() : this.enterTime = window.performance.timing.navigationStart
                }
            }, {
                key: "pageUrlDidChange",
                value: function(e) {
                    0 !== this.enterTime && (this.resetAfterPageChange(), this.initInteractionData(), this.enterTime = Date.now())
                }
            }, {
                key: "pageWillLeave",
                value: function(e) {
                    this.leaveTime = e
                }
            }, {
                key: "updateClickTimes",
                value: function() {
                    this.clickTimes += 1
                }
            }, {
                key: "updateScrollData",
                value: function(e) {
                    var t = e.scrollHeight,
                        n = e.docHeight;
                    this.scrollTimes += 1, this.maxScrollHeight = t, this.docHeight = n
                }
            }, {
                key: "initInteractionData",
                value: function() {
                    var e, t = {
                            docHeight: Aa(),
                            scrollHeight: Ca(),
                            connectionType: (e = navigator.connection, e && e.effectiveType ? e.effectiveType : "")
                        },
                        n = t.docHeight,
                        r = t.scrollHeight,
                        i = t.connectionType;
                    this.docHeight = n, this.maxScrollHeight = r, this.connectionType = i
                }
            }, {
                key: "resetAfterPageChange",
                value: function() {
                    this.clearAfterReport(), this.maxScrollHeight = 0, this.docHeight = 0, this.leaveTime = 0, this.isFirstReport = !0, this.connectionType = ""
                }
            }, {
                key: "clearAfterReport",
                value: function() {
                    this.clickTimes = 0, this.scrollTimes = 0, this.isDocHeightChanged = !1, this.isMaxScrollHeightChanged = !1, this.isFirstReport = !1
                }
            }, {
                key: "getResult",
                value: function() {
                    var e = {};
                    return this.scrollTimes && (e.scrollTimes = this.scrollTimes), this.clickTimes && (e.clickTimes = this.clickTimes), this.leaveTime && (e.leaveTime = this.leaveTime), this.isDocHeightChanged && (e.docHeight = this.docHeight), this.isMaxScrollHeightChanged && (e.maxScrollHeight = this.maxScrollHeight), this.isFirstReport && (e.connectionType = this.connectionType, e.enterTime = this.enterTime), this.clearAfterReport(), e
                }
            }, {
                key: "isChanged",
                value: function() {
                    return this.isDocHeightChanged || this.isMaxScrollHeightChanged || 0 !== this.scrollTimes || 0 !== this.clickTimes || 0 !== this.leaveTime
                }
            }, {
                key: "docHeight",
                get: function() {
                    return this._docHeight
                },
                set: function(e) {
                    e > this._docHeight ? (this._docHeight = e, this.isDocHeightChanged = !0) : 0 === e && (this._docHeight = 0, this.isDocHeightChanged = !1)
                }
            }, {
                key: "maxScrollHeight",
                get: function() {
                    return this._maxScrollHeight
                },
                set: function(e) {
                    e > this._maxScrollHeight ? (this._maxScrollHeight = e, this.isMaxScrollHeightChanged = !0) : 0 === e && (this._maxScrollHeight = 0, this.isMaxScrollHeightChanged = !1)
                }
            }]), e
        }();
    wa = Pa([A.injectable()], wa);
    var ka, Ma = function(e, t) {
            try {
                var n = null == t ? void 0 : t.type;
                if (n && PerformanceObserver.supportedEntryTypes.indexOf(n) > -1) {
                    var r = new PerformanceObserver((function(t) {
                        t.getEntries().forEach(e)
                    }));
                    return r.observe(t), r
                }
            } catch (e) {}
        },
        La = function(e) {
            var t = arguments.length > 1 && void 0 !== arguments[1] && arguments[1];
            document.addEventListener("visibilitychange", (function(t) {
                "hidden" === document.visibilityState && e(t)
            }), {
                once: t
            })
        },
        Da = function() {
            return void 0 === ka && (ka = "hidden" === document.visibilityState ? 0 : 1 / 0, La((function(e) {
                ka = Math.min(ka, e.timeStamp)
            }))), {
                get timeStamp() {
                    return ka
                }
            }
        },
        xa = "first-contentful-paint";

    function ja(e) {
        if (!(window && window.performance && (null === (t = window.performance) || void 0 === t ? void 0 : t.getEntries))) return -1;
        var t, n = performance.getEntriesByType("paint");
        if (Array.isArray(n)) {
            var r = n.filter((function(t) {
                return t.name === e
            }));
            return r.length && r[0] && r[0].startTime && r[0].startTime || -1
        }
        return -1
    }
    var Ua, Fa = {
        exports: {}
    };
    Ua = Fa,
        function() {
            var e = "undefined" != typeof window && window === this ? this : void 0 !== N && null != N ? N : this,
                t = "function" == typeof Object.defineProperties ? Object.defineProperty : function(e, t, n) {
                    e != Array.prototype && e != Object.prototype && (e[t] = n.value)
                };

            function n() {
                n = function() {}, e.Symbol || (e.Symbol = i)
            }
            var r = 0;

            function i(e) {
                return "jscomp_symbol_" + (e || "") + r++
            }

            function o() {
                n();
                var r = e.Symbol.iterator;
                r || (r = e.Symbol.iterator = e.Symbol("iterator")), "function" != typeof Array.prototype[r] && t(Array.prototype, r, {
                    configurable: !0,
                    writable: !0,
                    value: function() {
                        return a(this)
                    }
                }), o = function() {}
            }

            function a(t) {
                var n = 0;
                return function(t) {
                    return o(), (t = {
                        next: t
                    })[e.Symbol.iterator] = function() {
                        return this
                    }, t
                }((function() {
                    return n < t.length ? {
                        done: !1,
                        value: t[n++]
                    } : {
                        done: !0
                    }
                }))
            }

            function c(e) {
                o();
                var t = e[Symbol.iterator];
                return t ? t.call(e) : a(e)
            }

            function s(e) {
                if (!(e instanceof Array)) {
                    e = c(e);
                    for (var t, n = []; !(t = e.next()).done;) n.push(t.value);
                    e = n
                }
                return e
            }
            var u = 0,
                l = "img script iframe link audio video source".split(" ");

            function f(e, t) {
                for (var n = (e = c(e)).next(); !n.done; n = e.next())
                    if (n = n.value, t.includes(n.nodeName.toLowerCase()) || f(n.children, t)) return !0;
                return !1
            }

            function d(e, t) {
                if (2 < e.length) return performance.now();
                for (var n = [], r = (t = c(t)).next(); !r.done; r = t.next()) r = r.value, n.push({
                    timestamp: r.start,
                    type: "requestStart"
                }), n.push({
                    timestamp: r.end,
                    type: "requestEnd"
                });
                for (r = (t = c(e)).next(); !r.done; r = t.next()) n.push({
                    timestamp: r.value,
                    type: "requestStart"
                });
                for (n.sort((function(e, t) {
                        return e.timestamp - t.timestamp
                    })), e = e.length, t = n.length - 1; 0 <= t; t--) switch (r = n[t], r.type) {
                    case "requestStart":
                        e--;
                        break;
                    case "requestEnd":
                        if (2 < ++e) return r.timestamp;
                        break;
                    default:
                        throw Error("Internal Error: This should never happen")
                }
                return 0
            }

            function h(e) {
                e = e || {}, this.w = !!e.useMutationObserver, this.u = e.minValue || null, e = window.__tti && window.__tti.e;
                var t = window.__tti && window.__tti.o;
                this.a = e ? e.map((function(e) {
                        return {
                            start: e.startTime,
                            end: e.startTime + e.duration
                        }
                    })) : [], t && t.disconnect(), this.b = [], this.f = new window[window.TiktokAnalyticsObject || "ttq"]._ttq_map, this.j = null, this.v = -1 / 0, this.i = !1, this.h = this.c = this.s = null,
                    function(e, t) {
                        var n = XMLHttpRequest.prototype.send,
                            r = u++;
                        XMLHttpRequest.prototype.send = function(i) {
                            for (var o = [], a = 0; a < arguments.length; ++a) o[a - 0] = arguments[a];
                            var c = this;
                            return e(r), this.addEventListener("readystatechange", (function() {
                                4 === c.readyState && t(r)
                            })), n.apply(this, o)
                        }
                    }(this.m.bind(this), this.l.bind(this)),
                    function(e, t) {
                        var n = fetch;
                        fetch = function(r) {
                            for (var i = [], o = 0; o < arguments.length; ++o) i[o - 0] = arguments[o];
                            return new Promise((function(r, o) {
                                var a = u++;
                                e(a), n.apply(null, [].concat(s(i))).then((function(e) {
                                    t(a), r(e)
                                }), (function(e) {
                                    t(e), o(e)
                                }))
                            }))
                        }
                    }(this.m.bind(this), this.l.bind(this)),
                    function(e) {
                        e.c = new PerformanceObserver((function(t) {
                            for (var n = (t = c(t.getEntries())).next(); !n.done; n = t.next())
                                if ("resource" === (n = n.value).entryType && (e.b.push({
                                        start: n.fetchStart,
                                        end: n.responseEnd
                                    }), v(e, d(e.g, e.b) + 5e3)), "longtask" === n.entryType) {
                                    var r = n.startTime + n.duration;
                                    e.a.push({
                                        start: n.startTime,
                                        end: r
                                    }), v(e, r + 5e3)
                                }
                        })), e.c.observe({
                            entryTypes: ["longtask", "resource"]
                        })
                    }(this), this.w && (this.h = function(e) {
                        var t = new MutationObserver((function(t) {
                            for (var n = (t = c(t)).next(); !n.done; n = t.next())("childList" == (n = n.value).type && f(n.addedNodes, l) || "attributes" == n.type && l.includes(n.target.tagName.toLowerCase())) && e(n)
                        }));
                        return t.observe(document, {
                            attributes: !0,
                            childList: !0,
                            subtree: !0,
                            attributeFilter: ["href", "src"]
                        }), t
                    }(this.B.bind(this)))
            }

            function p(e) {
                e.i = !0;
                var t = 0 < e.a.length ? e.a[e.a.length - 1].end : 0,
                    n = d(e.g, e.b);
                v(e, Math.max(n + 5e3, t))
            }

            function v(e, t) {
                !e.i || e.v > t || (clearTimeout(e.j), e.j = setTimeout((function() {
                    var t = performance.timing.navigationStart,
                        n = d(e.g, e.b);
                    if (t = (window.a && window.a.A ? 1e3 * window.a.A().C - t : 0) || performance.timing.domContentLoadedEventEnd - t, e.u) var r = e.u;
                    else r = performance.timing.domContentLoadedEventEnd ? (r = performance.timing).domContentLoadedEventEnd - r.navigationStart : null;
                    var i = performance.now();
                    null === r && v(e, Math.max(n + 5e3, i + 1e3));
                    var o = e.a;
                    (n = 5e3 > i - n || 5e3 > i - (n = o.length ? o[o.length - 1].end : t) ? null : Math.max(n, r)) && (e.s(n), clearTimeout(e.j), e.i = !1, e.c && e.c.disconnect(), e.h && e.h.disconnect()), v(e, performance.now() + 1e3)
                }), t - performance.now()), e.v = t)
            }
            h.prototype.getFirstConsistentlyInteractive = function() {
                var e = this;
                return new Promise((function(t) {
                    e.s = t, "complete" == document.readyState ? p(e) : window.addEventListener("load", (function() {
                        p(e)
                    }))
                }))
            }, h.prototype.m = function(e) {
                this.f.set(e, performance.now())
            }, h.prototype.l = function(e) {
                this.f.delete(e)
            }, h.prototype.B = function() {
                v(this, performance.now() + 5e3)
            }, e.Object.defineProperties(h.prototype, {
                g: {
                    configurable: !0,
                    enumerable: !0,
                    get: function() {
                        return [].concat(s(this.f.values()))
                    }
                }
            });
            var _ = {
                getFirstConsistentlyInteractive: function(e) {
                    return e = e || {}, "PerformanceLongTaskTiming" in window ? new h(e).getFirstConsistentlyInteractive() : Promise.resolve(null)
                }
            };
            Ua.exports ? Ua.exports = _ : window.ttiPolyfill = _
        }();
    var Ba = Fa.exports,
        Ga = function(e, n, r, i) {
            var o, a = arguments.length,
                c = a < 3 ? n : null === i ? i = Object.getOwnPropertyDescriptor(n, r) : i;
            if ("object" === ("undefined" == typeof Reflect ? "undefined" : t(Reflect)) && "function" == typeof Reflect.decorate) c = Reflect.decorate(e, n, r, i);
            else
                for (var s = e.length - 1; s >= 0; s--)(o = e[s]) && (c = (a < 3 ? o(c) : a > 3 ? o(n, r, c) : o(n, r)) || c);
            return a > 3 && c && Object.defineProperty(n, r, c), c
        },
        Ha = ["fcp", "lcp", "cls", "fid", "tti", "navigationStart", "loadEventStart", "requestStart"],
        Va = function() {
            function e() {
                i(this, e), this.fcp = -1, this.lcp = -1, this.cls = -1, this.fid = -1, this.tti = -1, this.navigationStart = -1, this.loadEventStart = -1, this.requestStart = -1, this.everythingDone = !1, this.changedMap = {}, this.init()
            }
            return a(e, [{
                key: "init",
                value: function() {
                    var e, t, n, r;
                    this.updatePerformanceTiming(), e = this.baseHandler.bind(this, "cls"), t = 0, r = Ma(n = function(e) {
                            e.hadRecentInput || (t += e.value)
                        }, {
                            type: "layout-shift",
                            buffered: !0
                        }), La((function() {
                            r && (r.takeRecords().forEach(n), r.disconnect()), e(t)
                        })),
                        function(e) {
                            var t = ja(xa);
                            if (-1 === t) {
                                var n = Da();
                                Ma((function(t) {
                                    if (t.name === xa) {
                                        if (t.startTime < n.timeStamp) return void e(t.startTime);
                                        e(-1)
                                    }
                                }), {
                                    type: "paint",
                                    buffered: !0
                                })
                            } else e(t)
                        }(this.baseHandler.bind(this, "fcp")),
                        function(e) {
                            var t = Da();
                            Ma((function(n) {
                                if (n.startTime < t.timeStamp) {
                                    var r = n.processingStart - n.startTime;
                                    e(r)
                                }
                            }), {
                                type: "first-input"
                            })
                        }(this.baseHandler.bind(this, "fid")),
                        function(e) {
                            var t = Da(),
                                n = 0,
                                r = function(r) {
                                    r.startTime < t.timeStamp && (n = r.startTime, e(n))
                                },
                                i = Ma(r, {
                                    type: "largest-contentful-paint",
                                    buffered: !0
                                });
                            La((function() {
                                i && (i.takeRecords().forEach(r), i.disconnect()), e(n)
                            }))
                        }(this.baseHandler.bind(this, "lcp")),
                        function(e) {
                            try {
                                Ba.getFirstConsistentlyInteractive({}).then((function(t) {
                                    e(t)
                                }))
                            } catch (e) {}
                        }(this.baseHandler.bind(this, "tti"))
                }
            }, {
                key: "updatePerformanceTiming",
                value: function() {
                    var e = this,
                        t = function() {
                            var e = window.performance.timing;
                            return {
                                navigationStart: (null == e ? void 0 : e.navigationStart) || 0,
                                loadEventStart: (null == e ? void 0 : e.loadEventStart) || 0,
                                requestStart: (null == e ? void 0 : e.responseStart) || 0
                            }
                        }(),
                        n = t.navigationStart,
                        r = t.loadEventStart,
                        i = t.requestStart;
                    this.baseHandler("navigationStart", n), this.baseHandler("loadEventStart", r), this.baseHandler("requestStart", i), 0 !== n && 0 !== r && 0 !== i || setTimeout((function() {
                        e.updatePerformanceTiming()
                    }), 5e3)
                }
            }, {
                key: "baseHandler",
                value: function(e, t) {
                    this.everythingDone || -1 === this[e] && 0 !== t && -1 !== t && (this.changedMap[e] = !0, this[e] = t)
                }
            }, {
                key: "isChanged",
                value: function() {
                    return 0 !== Object.keys(this.changedMap).length
                }
            }, {
                key: "getResult",
                value: function() {
                    var e = {};
                    if (this.everythingDone) e = this.getAllData();
                    else
                        for (var t = 0, n = Object.keys(this.changedMap); t < n.length; t++) {
                            var r = n[t];
                            e[r] = this[r]
                        }
                    return this.clearAfterReport(), e
                }
            }, {
                key: "getAllData",
                value: function() {
                    var e = this;
                    return Ha.reduce((function(t, n) {
                        return t[n] = e[n], t
                    }), {})
                }
            }, {
                key: "clearAfterReport",
                value: function() {
                    this.changedMap = {}
                }
            }, {
                key: "pageUrlWillChange",
                value: function(e, t) {}
            }, {
                key: "pageUrlDidChange",
                value: function(e) {
                    var t = this;
                    this.everythingDone = Ha.every((function(e) {
                        return -1 !== t[e]
                    }), this), this.changedMap.navigationStart = !0
                }
            }, {
                key: "pageWillLeave",
                value: function(e) {}
            }]), e
        }();
    Va = Ga([A.injectable()], Va);
    var Ja, Ka = function(e, n, r, i) {
            var o, a = arguments.length,
                c = a < 3 ? n : null === i ? i = Object.getOwnPropertyDescriptor(n, r) : i;
            if ("object" === ("undefined" == typeof Reflect ? "undefined" : t(Reflect)) && "function" == typeof Reflect.decorate) c = Reflect.decorate(e, n, r, i);
            else
                for (var s = e.length - 1; s >= 0; s--)(o = e[s]) && (c = (a < 3 ? o(c) : a > 3 ? o(n, r, c) : o(n, r)) || c);
            return a > 3 && c && Object.defineProperty(n, r, c), c
        },
        Wa = function(e, t) {
            return function(n, r) {
                t(n, r, e)
            }
        },
        Ya = function(e) {
            s(n, e);
            var t = h(n);

            function n(e, r, o, a) {
                var c;
                return i(this, n), (c = t.call(this, {
                    name: "WebFL",
                    reporters: r,
                    context: e
                })).reportService = o, c.ttqOptions = a, c.useExchangeRate = a.usd_exchange_rate, c
            }
            return a(n, [{
                key: "pixelSend",
                value: function(e, t, n) {
                    var r, i;
                    Boolean(null === (i = null === (r = this.ttqOptions) || void 0 === r ? void 0 : r.plugins) || void 0 === i ? void 0 : i.WebFL) && n && this.reportFlConv(n)
                }
            }, {
                key: "reportFlConv",
                value: function(e) {
                    var t;
                    if (e && "Pageview" !== e.event) {
                        var n, r = e.context,
                            i = e.properties,
                            o = void 0 === i ? {} : i,
                            a = void 0 !== r.ad.log_extra ? r.ad.log_extra : "{}";
                        try {
                            n = JSON.parse(a)
                        } catch (e) {
                            n = {}
                        }
                        var c = {
                                req_id: n.req_id || "",
                                cid: r.ad.creative_id || "",
                                value: o.value || "",
                                currency: o.currency || "",
                                raw: Object.assign({}, o)
                            },
                            s = o.value,
                            u = o.currency,
                            l = function(e, t, n) {
                                return isNaN(e) || e < 0 || null === n || !n[t] ? "" : (e / n[t] * 1e5).toFixed(0)
                            }(s, u, this.useExchangeRate || null),
                            f = r.pixel ? r.pixel.code : "";
                        l && (c.usd_value = l, Ri(Tr.CUSTOM_INFO, {
                            pixelCode: f,
                            custom_name: "odfl_rate_exchange",
                            extJSON: {
                                message_id: e.message_id,
                                cid: c.cid,
                                event: e.event,
                                value: s,
                                currency: u,
                                usdValue: l
                            }
                        }));
                        var d = {
                            business: "devicefl_join_label",
                            entrance: "app_to_web_conversion",
                            inputParams: {
                                message_id: e.message_id,
                                event: e.event,
                                event_props: c,
                                event_source_id: null === (t = r.pixel) || void 0 === t ? void 0 : t.code,
                                event_source_type: "web"
                            }
                        };
                        this.reportService && this.reportService.reportFL && (this.reportService.reportFL(d), Ri(Tr.CUSTOM_INFO, {
                            pixelCode: f,
                            custom_name: "fl_jsb_report",
                            extJSON: {
                                message_id: e.message_id,
                                cid: c.cid,
                                event: e.event
                            }
                        }))
                    }
                }
            }]), n
        }(fo);
    Ya = Ka([A.injectable(), Wa(0, A.inject(br.CONTEXT)), Wa(1, A.inject(br.TTQ_REPORTERS)), Wa(2, A.inject(br.REPORT_SERVICE)), Wa(3, A.inject(br.TTQ_GLOBAL_OPTIONS))], Ya),
        function(e) {
            e.ERROR_FORMAT = "error_format", e.OVER_LENGTH = "over_length_3e4", e.FILTER_SENSITIVE_FIELDS = "filter_sensitive_fields"
        }(Ja || (Ja = {}));
    var qa, Xa, za, Qa, Za, $a = "form_detail_error";
    ! function(e) {
        e.GET_ELEMENTS_ERROR = "get_elements_error", e.INIT_ERROR = "init_error", e.ASSEMBLE_FORM_DETAIL_ERROR = "assemble_form_detail_error", e.DETECT_FORM_ELEMENT_ERROR = "detect_form_element_error", e.GET_OVERALL_FORM_DETAIL_ERROR = "get_overall_form_detail_error", e.FORM_OBSERVER_ERROR = "form_observer_error", e.OVER_LENGTH = "over_length_3e4"
    }(qa || (qa = {})),
    function(e) {
        e.METADATA = "Metadata", e.CLICK = "Click"
    }(Xa || (Xa = {})),
    function(e) {
        e.AUTO_COLLECTION = "AUTO_COLLECTION", e.AUTO_FORM = "AUTO_FORM", e.AUTO_CLICK = "AUTO_CLICK", e.AUTO_VC = "AUTO_VC", e.AUTO_VC_REVERSE = "AUTO_VC_REVERSE"
    }(za || (za = {})),
    function(e) {
        e.AUTO_FORM = "form_rules", e.AUTO_VC = "vc_rules", e.AUTO_VC_REVERSE = "vc_rules_reverse"
    }(Qa || (Qa = {})),
    function(e) {
        e.PAGE_LEAVE = "PageLeave", e.PAGE_VIEW = "PageView", e.DOM_CHANGE = "DomChange", e.URL_CHANGE = "UrlChange", e.CLICK = "Click", e.SCROLL = "Scroll"
    }(Za || (Za = {}));
    var ec = ["AnatomicalStructure", "AnatomicalSystem", "ApprovedIndication", "ArriveAction", "Artery", "BioChemEntity", "BloodTest", "Bone", "BorrowAction", "BrainStructure", "BrokerageAccount", "CDCPMDRecord", "ChemicalSubstance", "CovidTestingFacility", "DDxElement", "DepartAction", "DepositAccount", "DiagnosticLab", "DiagnosticProcedure", "Diet", "DietarySupplement", "DoseSchedule", "ElementarySchool", "HighSchool", "ExercisePlan", "Gene", "GovernmentBenefitsType", "GovernmentService", "HealthAspectEnumeration", "HealthInsurancePlan", "HealthPlanCostSharingSpecification", "HealthTopicContent", "Hospital", "ImagingTest", "InfectiousAgentClass", "InvestmentFund", "InvestmentOrDeposit", "Invoice", "Joint", "LendAction", "LifestyleModification", "Ligament", "LoanOrCredit", "LymphaticVessel", "MaximumDoseSchedule", "MedicalAudience", "MedicalAudienceType", "MedicalCause", "MedicalCode", "MedicalCondition", "MedicalConditionStage", "MedicalContraindication", "MedicalDevice", "MedicalEntity", "MedicalEvidenceLevel", "MedicalGuidelineContraindication", "MedicalIndication", "MedicalIntangible", "MedicalObservationalStudy", "MedicalOrganization", "MedicalProcedure", "MedicalProcedureType", "MedicalRiskCalculator", "MedicalRiskFactor", "MedicalRiskScore", "MedicalSign", "MedicalSignOrSymptom", "MedicalStudy", "MedicalSymptom", "MedicalTest", "MedicalTestPanel", "MedicalTherapy", "MedicalTrial", "MiddleSchool", "MoneyTransfer", "Muscle", "Nerve", "OccupationalTherapy", "Order", "PalliativeProcedure", "ParentAudience", "PathologyTest", "Patient", "PeopleAudience", "Person", "Pharmacy", "PhysicalActivity", "PhysicalTherapy", "Physician", "PoliticalParty", "Preschool", "PreventionIndication", "Protein", "PsychologicalTreatment", "RadiationTherapy", "RecommendedDoseSchedule", "ReportedDoseSchedule", "School", "Substance", "SuperficialAnatomy", "SurgicalProcedure", "Text", "TherapeuticProcedure", "TreatmentIndication", "URL", "Vein", "Vessel", "VitalSign", "WorkersUnion"],
        tc = 2e3;

    function nc(e) {
        return /([a-zA-Z0-9._-]+@[a-zA-Z0-9._-]+\.[a-zA-Z0-9._-]+)/gi.test(e) || /(\+?0?86-?)?1[3-9]\d{9}/g.test(e) || /(\+\d{1,2}\s?)?\(?\d{3}\)?[\s.-]?\d{3}[\s.-]?\d{4}/g.test(e) || /^[\-!$><-==&_\/\?\.,0-9:; \]\[%~\"\{\}\)\(\+\@\^\`]/g.test(e) || ec.some((function(t) {
            return e.toLowerCase().indexOf(t.toLowerCase()) > -1
        }))
    }
    var rc = function e(t) {
        if (!t || t.nodeType !== Node.ELEMENT_NODE) return "";
        if (t === document.documentElement) return "/HTML";
        for (var n = 1, r = t.previousSibling; r;) r.nodeType === Node.ELEMENT_NODE && r.tagName === t.tagName && n++, r = r.previousSibling;
        var i = t.tagName.toLowerCase(),
            o = e(t.parentNode);
        return "".concat(o, "/").concat(i, "[").concat(n, "]")
    };

    function ic(e) {
        return rc(e)
    }

    function oc(e, t) {
        return function() {
            for (var n = arguments.length, r = new Array(n), i = 0; i < n; i++) r[i] = arguments[i];
            window.requestIdleCallback && window.requestIdleCallback(e.bind.apply(e, [t].concat(r))), e.apply(t, r)
        }
    }

    function ac(e) {
        var t = e.options,
            n = e.plugins;
        return t && !1 !== t.autoConfig && n && n[qc]
    }

    function cc(e, t) {
        if (!Qa[t]) return !0;
        var n = e.plugins;
        return t === za.AUTO_VC_REVERSE ? ac(e) && n[qc] && !n[qc][Qa.AUTO_VC] : ac(e) && n[qc] && n[qc][Qa[t]]
    }
    var sc = function e(t) {
            for (var n = 0, r = t.children, i = 0; i < r.length; i++) {
                var o = r[i],
                    a = !1;
                try {
                    a = ci(o)
                } catch (e) {
                    Ai(Tr.CUSTOM_ERROR, e, {
                        custom_name: "button_check_error",
                        custom_enum: "auto_click",
                        extJSON: {
                            element: o
                        }
                    }), a = !1
                }
                a && n++, n += e(o)
            }
            return n
        },
        uc = function(e) {
            var t, n, r, i, o = "";
            if ("A" === e.tagName.toUpperCase()) o = null !== (t = e.getAttribute("href")) && void 0 !== t ? t : "";
            else if ("BUTTON" === e.tagName.toUpperCase()) {
                var a = null !== (n = e.getAttribute("onclick")) && void 0 !== n ? n : "",
                    c = null !== (r = e.getAttribute("formaction")) && void 0 !== r ? r : "",
                    s = a.match(/^.*=(['"])(.*)\1.*$/);
                c ? o = c : s && (o = s[2])
            } else "FORM" === e.tagName.toUpperCase() && (o = null !== (i = e.getAttribute("action")) && void 0 !== i ? i : "");
            return o
        };

    function lc(e) {
        var t = arguments.length > 1 && void 0 !== arguments[1] ? arguments[1] : 500;
        return "string" != typeof e ? "" : (e = e.trim()).length < t ? e : e.slice(0, 500)
    }

    function fc(e) {
        return null != ["og:image"].filter((function(t) {
            return t === e
        }))[0]
    }

    function dc(e, t) {
        return null != [{
            property: "image",
            type: "Product"
        }].filter((function(n) {
            return (e === "https://schema.org/" + n.type || e === "http://schema.org/" + n.type) && n.property === t
        }))[0]
    }

    function hc() {
        var e = arguments.length > 0 && void 0 !== arguments[0] ? arguments[0] : [];
        return {
            items: e,
            has: function(e) {
                return this.items.some((function(t) {
                    return t === e
                }))
            },
            add: function(e) {
                this.has(e) || this.items.push(e)
            }
        }
    }

    function pc(e) {
        var t;
        switch (e.tagName.toLowerCase()) {
            case "meta":
                t = e.getAttribute("content");
                break;
            case "audio":
            case "embed":
            case "iframe":
            case "img":
            case "source":
            case "track":
            case "video":
                t = e.getAttribute("src");
                break;
            case "a":
            case "area":
            case "link":
                t = e.getAttribute("href");
                break;
            case "object":
                t = e.getAttribute("data");
                break;
            case "data":
            case "meter":
                t = e.getAttribute("value");
                break;
            case "time":
                t = e.getAttribute("datetime");
                break;
            default:
                t = function(e) {
                    if (e) {
                        if (e.innerText && e.innerText.length > 0) return e.innerText;
                        if (e.textContent && e.textContent.length > 0) return e.textContent
                    }
                    return ""
                }(e) || ""
        }
        return "string" == typeof t ? lc(t) : ""
    }

    function vc(e, n) {
        if ("object" === t(e)) {
            if (Array.isArray(e)) return e.map((function(e) {
                return vc(e, n)
            }));
            var r = {};
            for (var i in e) _c(i, n) || (r[i] = vc(e[i], n));
            return r
        }
        return e
    }

    function _c(e, t) {
        return !!(t && t.length > 0) && t.some((function(t) {
            return e.toLowerCase() === t.toLowerCase()
        }))
    }

    function gc(e) {
        if ("object" === t(e)) {
            if (Array.isArray(e)) return e.map((function(e) {
                return gc(e)
            }));
            var n = Object.assign({}, e),
                r = n["@type"];
            for (var i in n) "@type" !== i && "@context" !== i && ("object" === t(n[i]) ? n[i] = gc(n[i]) : r && yc(r) && delete n[i]);
            return n
        }
        return e
    }

    function yc(e) {
        return Array.isArray(e) ? e.some((function(e) {
            return yc(e)
        })) : "string" == typeof e && (e = e.toLowerCase().replace(/https?:\/\/schema\.org\//, ""), ec.some((function(t) {
            return e === t.toLowerCase()
        })))
    }

    function mc(e) {
        var t = {
            open_graph: "{}",
            microdata: "[]",
            json_ld: "[]",
            meta: "{}"
        };
        try {
            t.microdata = function() {
                for (var e = document.querySelectorAll("[itemscope]"), t = [], n = hc(), r = 0; r < e.length; r++) n.add(e[r]);
                for (var i = e.length - 1; i >= 0; i--) {
                    var o = e[i],
                        a = o.getAttribute("itemtype");
                    if ("string" == typeof a && "" !== a) {
                        for (var c = {}, s = o.querySelectorAll("[itemprop]"), u = 0; u < s.length; u++) {
                            var l = s[u];
                            if (!n.has(l)) {
                                n.add(l);
                                var f = l.getAttribute("itemprop");
                                if ("string" == typeof f && "" !== f) {
                                    var d = pc(l);
                                    if (null != d) {
                                        var h = c[f];
                                        null != h && dc(a, f) ? Array.isArray(h) ? c[f].push(d) : c[f] = [h, d] : c[f] = d
                                    }
                                }
                            }
                        }
                        t.unshift({
                            schema: {
                                dimensions: {
                                    h: o.clientHeight,
                                    w: o.clientWidth
                                },
                                properties: yc(a) ? {} : c,
                                subscopes: [],
                                type: a
                            },
                            scope: o
                        })
                    }
                }
                for (var p = [], v = [], _ = 0; _ < t.length; _++) {
                    for (var g = t[_], y = g.scope, m = g.schema, E = p.length - 1; E >= 0; E--) {
                        if (p[E].scope.contains(y)) {
                            p[E].schema.subscopes.push(m);
                            break
                        }
                        p.pop()
                    }
                    0 === p.length && v.push(m), p.push({
                        schema: m,
                        scope: y
                    })
                }
                return JSON.stringify(v)
            }()
        } catch (e) {
            Ai(Tr.CUSTOM_ERROR, e, {
                custom_name: "assemble_auto_config_failed",
                custom_enum: "microdata"
            })
        }
        try {
            var n = function() {
                    for (var e = [], t = [], n = document.querySelectorAll('script[type="application/ld+json"]'), r = 0, i = 0; i < n.length; i++) {
                        var o = n[i].innerText;
                        if (null != o && "" !== o) {
                            if ((r += o.length) > 3e4) return {
                                data: JSON.stringify([]),
                                errors: [{
                                    name: Ja.OVER_LENGTH,
                                    message: "".concat(String(r))
                                }]
                            };
                            var a = void 0;
                            try {
                                a = JSON.parse(o.replace(/[\n\r\t]+/g, " "))
                            } catch (e) {
                                t.push({
                                    name: Ja.ERROR_FORMAT,
                                    message: e.message
                                })
                            }
                            try {
                                a = gc(a)
                            } catch (e) {
                                return {
                                    data: JSON.stringify([]),
                                    errors: [{
                                        name: Ja.FILTER_SENSITIVE_FIELDS,
                                        message: e.message
                                    }]
                                }
                            }
                            a && e.push(a)
                        }
                    }
                    return {
                        data: JSON.stringify(e),
                        errors: t
                    }
                }(),
                r = n.data,
                i = n.errors;
            t.json_ld = r, i && i.forEach((function(e) {
                var t = e.name,
                    n = e.message;
                Ai(Tr.CUSTOM_ERROR, {
                    message: n
                }, {
                    custom_name: "parse_json_ld_failed",
                    custom_enum: t
                })
            }))
        } catch (e) {
            Ai(Tr.CUSTOM_ERROR, e, {
                custom_name: "assemble_auto_config_failed",
                custom_enum: "json_ld"
            })
        }
        try {
            t.open_graph = function(e) {
                for (var t = hc(["og", "product", "music", "video", "article", "book", "profile", "website", "twitter"]), n = {}, r = document.querySelectorAll("meta[property],meta[name]"), i = 0; i < r.length; i++) {
                    var o = r[i],
                        a = o.getAttribute("property") || o.getAttribute("name"),
                        c = lc(o.getAttribute("content"));
                    if ("string" == typeof a && -1 !== a.indexOf(":") && "string" == typeof c && t.has(a.split(":")[0])) {
                        var s = n[a];
                        null != s && fc(a) ? Array.isArray(s) ? n[a].push(c) : n[a] = [s, c] : n[a] = c
                    }
                }
                return JSON.stringify(vc(n, e))
            }(e.open_graph)
        } catch (e) {
            Ai(Tr.CUSTOM_ERROR, e, {
                custom_name: "assemble_auto_config_failed",
                custom_enum: "open_graph"
            })
        }
        try {
            t.meta = function(e) {
                var t = {},
                    n = hc(["description", "keywords", "keyword"]),
                    r = document.querySelector("title");
                r && (t.title = lc(r.innerText));
                for (var i = document.querySelectorAll("meta[property],meta[name]"), o = 0; o < i.length; o++) {
                    var a = i[o],
                        c = a.getAttribute("name") || a.getAttribute("property"),
                        s = lc(a.getAttribute("content"));
                    "string" == typeof c && "string" == typeof s && n.has(c) && (t[c] = s)
                }
                return JSON.stringify(vc({
                    title: t.title,
                    "meta:description": t.description,
                    "meta:keywords": t.keywords || t.keyword
                }, e))
            }(e.meta)
        } catch (e) {
            Ai(Tr.CUSTOM_ERROR, e, {
                custom_name: "assemble_auto_config_failed",
                custom_enum: "meta"
            })
        }
        return t
    }
    var Ec, bc = ["form", "[id*=form], [class*=form]"],
        Tc = ["label"],
        Ic = ["input,select,textarea"],
        Oc = ["radio", "checkbox"],
        Sc = ["hidden", "reset", "submit", "password"];

    function Nc(e, t) {
        try {
            for (var n = 0; n < e.length; n++) {
                var r = t.querySelectorAll(e[n]);
                if (r && r.length > 0) return Array.from(r)
            }
            return []
        } catch (e) {
            return Ai(Tr.CUSTOM_ERROR, e, {
                custom_name: $a,
                custom_enum: qa.GET_ELEMENTS_ERROR
            }), []
        }
    }

    function Rc(e) {
        var t = "";
        return function e(n) {
            for (; n;) n.nodeType === Node.TEXT_NODE ? t += n.textContent : "SELECT" !== n.nodeName && n.firstChild && e(n.firstChild), n = n.nextSibling
        }(e.firstChild), t.replace(/[\t\n]/g, "").trim()
    }

    function Ac(e) {
        if (!e) return !1;
        var t = window.getComputedStyle(e);
        return "none" !== t.display && ("visible" === t.visibility && (!Cc(e) && (0 !== e.offsetWidth || 0 !== e.offsetHeight)))
    }

    function Cc(e) {
        return !(!e || e.isSameNode(document.body) || e.isSameNode(document)) && ("0" == window.getComputedStyle(e).opacity || Cc(e.parentElement))
    }

    function Pc(e) {
        var t = e.getAttribute("type");
        return !!t && Sc.indexOf(t) > -1
    }

    function wc(e) {
        return e && nc(e) ? "__Text__" : e
    }! function(e) {
        e[e.CONTAIN = 0] = "CONTAIN", e[e.ID = 1] = "ID", e[e.SELECTOR = 2] = "SELECTOR"
    }(Ec || (Ec = {}));
    var kc = function() {
            function e(t) {
                i(this, e), this.formUpdateHandlers = [], this.answerMap = {}, this.rules = this.getRules(t), this.init()
            }
            return a(e, [{
                key: "getRules",
                value: function(e) {
                    var t = e.plugins && e.plugins.AutoConfig;
                    return t && t[Qa.AUTO_FORM]
                }
            }, {
                key: "init",
                value: function() {
                    var e = this;
                    try {
                        this.forms = this.detectFormElement(), this.forms && this.forms.forEach((function(t) {
                            t.formDetail = e.assembleFormDetail(t), e.startFormObserver(t, e.formUpdateHandlers)
                        }))
                    } catch (e) {
                        Ai(Tr.CUSTOM_ERROR, e, {
                            custom_name: $a,
                            custom_enum: qa.INIT_ERROR
                        })
                    }
                }
            }, {
                key: "getOverallFormDetail",
                value: function() {
                    try {
                        return this.forms && this.forms.length > 0 ? (this.forms.some((function(e) {
                            var t = e.el;
                            return !document.body.contains(t)
                        })) && this.init(), JSON.stringify(this.forms.map((function(e) {
                            return e.formDetail
                        })).filter((function(e) {
                            return e
                        })))) : "[]"
                    } catch (e) {
                        return Ai(Tr.CUSTOM_ERROR, e, {
                            custom_name: $a,
                            custom_enum: qa.GET_OVERALL_FORM_DETAIL_ERROR
                        }), "[]"
                    }
                }
            }, {
                key: "addFormUpdateHandler",
                value: function(e) {
                    this.formUpdateHandlers.push(e)
                }
            }, {
                key: "startFormObserver",
                value: function(e, t) {
                    var n = this;
                    try {
                        var r = ni((function() {
                            var r = n.assembleFormDetail(e);
                            (!e.formDetail || r && ui(r, e.formDetail)) && (e.formDetail = r, t.forEach((function(t) {
                                return t.call(n, e.formDetail)
                            })))
                        }), tc, this);
                        if (e.el.parentNode) {
                            var i = e.el.parentNode;
                            this.observer && this.observer.disconnect(), this.observer = new MutationObserver(r), this.observer.observe(i, {
                                attributes: !0,
                                childList: !0,
                                subtree: !0
                            }), i.addEventListener("click", r, {
                                capture: !0
                            })
                        }
                    } catch (e) {
                        Ai(Tr.CUSTOM_ERROR, e, {
                            custom_name: $a,
                            custom_enum: qa.FORM_OBSERVER_ERROR
                        })
                    }
                }
            }, {
                key: "detectFormElement",
                value: function() {
                    try {
                        var e = [0, 0, 0],
                            t = function(e) {
                                return (t = Nc(e || bc, document)).filter((function(e) {
                                    return !t.some((function(t) {
                                        return t.contains(e) && t !== e
                                    }))
                                }));
                                var t
                            }(this.rules);
                        if (!t) return [];
                        var n = t.map((function(e) {
                            return {
                                el: e,
                                questions: []
                            }
                        }));
                        return n.forEach((function(t) {
                            var n, r = function(e) {
                                    return Nc(Tc, e)
                                }(t.el),
                                i = new Set([]);
                            r.forEach((function(n) {
                                var r = function(e, t) {
                                    var n = Nc(Ic, e);
                                    if (n && n.length) return {
                                        els: n,
                                        from: Ec.CONTAIN
                                    };
                                    var r = e.getAttribute("for");
                                    return !(!r || (n = function(e, t) {
                                        return Nc(["input[id='".concat(e, "'],select[id='").concat(e, "'],textarea[id='").concat(e, "']")], t)
                                    }(r, t), !n)) && {
                                        els: n,
                                        from: Ec.ID
                                    }
                                }(n, t.el);
                                if (r) {
                                    var o = r.els,
                                        a = r.from,
                                        c = o.filter((function(e) {
                                            return !Pc(e)
                                        })).map((function(e) {
                                            return i.add(e), {
                                                el: e,
                                                from: a
                                            }
                                        }));
                                    c && c.length && (e[a] = 1, t.questions.push({
                                        el: n,
                                        answers: c
                                    }))
                                }
                            })), (n = t.el, Nc(Ic, n)).filter((function(e) {
                                return !Pc(e)
                            })).forEach((function(n) {
                                if (!i.has(n)) {
                                    e[Ec.SELECTOR] = 1;
                                    var r = function(e, t) {
                                        return function e(n) {
                                            return null == n || n.isSameNode(t) ? t : Rc(n).length > 0 ? n : e(n.parentNode)
                                        }(e.parentNode)
                                    }(n, t.el);
                                    t.questions.push({
                                        el: r,
                                        answers: [{
                                            el: n,
                                            from: Ec.SELECTOR
                                        }]
                                    })
                                }
                            }))
                        })), Ri(Tr.CUSTOM_INFO, {
                            custom_name: "form_detail_answer_from",
                            custom_enum: e.join("")
                        }), n
                    } catch (e) {
                        return Ai(Tr.CUSTOM_ERROR, e, {
                            custom_name: $a,
                            custom_enum: qa.DETECT_FORM_ELEMENT_ERROR
                        }), []
                    }
                }
            }, {
                key: "calculateQuestionFilledTime",
                value: function(e) {
                    var t = e.el,
                        n = e.answers,
                        r = ic(t),
                        i = n.reduce((function(e, t) {
                            var n = t.el,
                                r = n.getAttribute("type");
                            return r && Oc.indexOf(r.toLowerCase()) > -1 ? "".concat(e, ",").concat(n.checked) : "".concat(e, ",").concat(n.value)
                        }), "");
                    this.answerMap[r] || (this.answerMap[r] = {
                        defaultValue: i,
                        value: i
                    });
                    var o = this.answerMap[r],
                        a = o.defaultValue,
                        c = o.filledTime;
                    if (this.answerMap[r].value = i, a !== i) return c || (this.answerMap[r].filledTime = +new Date);
                    delete this.answerMap[r].filledTime
                }
            }, {
                key: "assembleFormDetail",
                value: function(e) {
                    var t = this,
                        n = e.el,
                        r = e.questions;
                    try {
                        var i = {
                            xpath: ic(n),
                            id: n.id,
                            name: wc(n.getAttribute("name")),
                            tag: n.tagName.toLowerCase(),
                            class_name: n.className,
                            questions: [],
                            width: n.offsetWidth,
                            height: n.offsetHeight,
                            is_visible: Ac(n)
                        };
                        return i.questions = r.map((function(e) {
                            var n = e.el,
                                r = e.answers,
                                i = {
                                    xpath: ic(n),
                                    id: n.id,
                                    name: wc(Rc(n)),
                                    tag: n.tagName.toLowerCase(),
                                    class_name: n.className,
                                    filled_time: t.calculateQuestionFilledTime(e),
                                    answers: [],
                                    width: n.offsetWidth,
                                    height: n.offsetHeight,
                                    is_visible: Ac(n)
                                };
                            return r.forEach((function(e) {
                                var t = e.el,
                                    n = e.from;
                                t && "SELECT" === t.tagName.toUpperCase() ? i.answers = i.answers.concat(Array.from(t.querySelectorAll("option")).map((function(e) {
                                    return {
                                        xpath: ic(e),
                                        id: e.id,
                                        name: wc(e.value || e.innerText),
                                        tag: e.tagName.toLowerCase(),
                                        class_name: e.className,
                                        from: n,
                                        width: e.offsetWidth,
                                        height: e.offsetHeight,
                                        is_visible: Ac(t)
                                    }
                                }))) : i.answers.push({
                                    xpath: ic(t),
                                    id: t.id,
                                    name: wc(t.getAttribute("name")),
                                    tag: t.tagName.toLowerCase(),
                                    class_name: t.className,
                                    input_type: t.getAttribute("type"),
                                    placeholder: wc(t.getAttribute("placeholder")),
                                    from: n,
                                    width: t.offsetWidth,
                                    height: t.offsetHeight,
                                    is_visible: Ac(t)
                                })
                            })), i
                        })), i
                    } catch (e) {
                        return void Ai(Tr.CUSTOM_ERROR, e, {
                            custom_name: $a,
                            custom_enum: qa.ASSEMBLE_FORM_DETAIL_ERROR
                        })
                    }
                }
            }]), e
        }(),
        Mc = ["United States", "US", "Canada", "CA", "Australia", "AU", "Mexico", "MX", "Argentina", "AR", "Chile", "CL", "Colombia", "CO", "Fiji", "FJ", "Liberia", "LR", "Namibia", "NA", "New Zealand", "NZ", "Singapore", "SG", "Solomon Islands", "SB", "Suriname", "SR", "South Africa", "ZA", "Barbados", "BB", "Belize", "BZ", "Cuba", "CU", "Dominican Republic", "DO", "Guyana", "GY", "Jamaica", "JM", "Cayman Islands", "KY", "Trinidad and Tobago", "TT", "Tuvalu", "TV", "Zimbabwe", "ZW", "United Kingdom", "GB", "Egypt", "EG", "Falkland Islands", "FK", "Gibraltar", "GI", "Guernsey", "GG", "Isle of Man", "IM", "Jersey", "JE", "Lebanon", "LB", "Saint Helena", "SH", "Syria", "SY", "Sudan", "SD", "Japan", "JP", "China", "CN", "Japan", "JP", "CN", "South Korea", "KR", "Philippines", "PH", "Cuba", "CU", "Sweden", "SE", "Norway", "NO", "Denmark", "DK", "Iceland", "IS", "Costa Rica", "CR", "El Salvador", "SV", "Bolivia", "BO", "Venezuela", "VE", "Bahamas", "BS", "Brunei", "BN", "Ethiopia", "ET", "Eritrea", "ER", "Iran", "IR", "Oman", "OM", "Qatar", "QA", "Saudi Arabia", "SA", "Yemen", "YE", "Bulgaria", "BG", "Kyrgyzstan", "KG", "Central African CFA franc zone", "XAF", "West African CFA franc zone", "XOF"].map((function(e) {
            return e.toUpperCase()
        })),
        Lc = ["AED", "AFN", "ALL", "AMD", "ANG", "AOA", "ARS", "AUD", "AWG", "AZN", "BAM", "BBD", "BDT", "BGN", "BHD", "BIF", "BMD", "BND", "BOB", "BOV", "BRL", "BSD", "BTC", "BTN", "BWP", "BYN", "BYR", "BZD", "CAD", "CDF", "CHE", "CHF", "CHW", "CLF", "CLP", "CNH", "CNY", "COP", "COU", "CRC", "CUC", "CUP", "CVE", "CZK", "DJF", "DKK", "DOP", "DZD", "EEK", "EGP", "ERN", "ETB", "ETH", "EUR", "FJD", "FKP", "GBP", "GEL", "GGP", "GHC", "GHS", "GIP", "GMD", "GNF", "GTQ", "GYD", "HKD", "HNL", "HRK", "HTG", "HUF", "IDR", "ILS", "IMP", "INR", "IQD", "IRR", "ISK", "JEP", "JMD", "JOD", "JPY", "KES", "KGS", "KHR", "KMF", "KPW", "KRW", "KWD", "KYD", "KZT", "LAK", "LBP", "LKR", "LRD", "LSL", "LTC", "LTL", "LVL", "LYD", "MAD", "MDL", "MGA", "MKD", "MMK", "MNT", "MOP", "MRO", "MRU", "MUR", "MVR", "MWK", "MXN", "MXV", "MYR", "MZN", "NAD", "NGN", "NIO", "NOK", "NPR", "NZD", "OMR", "PAB", "PEN", "PGK", "PHP", "PKR", "PLN", "PYG", "QAR", "RMB", "RON", "RSD", "RUB", "RWF", "SAR", "SBD", "SCR", "SDG", "SEK", "SGD", "SHP", "SLL", "SOS", "SRD", "SSP", "STD", "STN", "SVC", "SYP", "SZL", "THB", "TJS", "TMT", "TND", "TOP", "TRL", "TRY", "TTD", "TVD", "TWD", "TZS", "UAH", "UGX", "USD", "UYI", "UYU", "UYW", "UZS", "VEF", "VES", "VND", "VUV", "WST", "XAF", "XBT", "XCD", "XOF", "XPF", "XSU", "XUA", "YER", "ZAR", "ZMW", "ZWD", "ZWL"],
        Dc = function(e) {
            try {
                var t = e.plugins && e.plugins.AutoConfig;
                return t && t.vc_rules
            } catch (e) {
                return
            }
        },
        xc = function(e, t) {
            var n, r;
            try {
                var i = e.getPageInfo();
                if (i.url.includes("checkout")) {
                    var o = Object.values(t)[0];
                    for (var a in t) i.url.includes(a) && (o = t[a]);
                    if (o) {
                        var c, s = O(o);
                        try {
                            for (s.s(); !(c = s.n()).done;) {
                                var u = c.value,
                                    l = u.currency.val,
                                    f = jc(u.valueXpath, u.valueClass),
                                    d = null == f ? void 0 : f.textContent;
                                if (d) {
                                    var h = Uc(d);
                                    if (h) {
                                        var p = void 0,
                                            v = void 0,
                                            _ = void 0;
                                        if (u.currency.xpath) {
                                            var g = null === (n = document.evaluate(u.currency.xpath, document, null, XPathResult.FIRST_ORDERED_NODE_TYPE, null).singleNodeValue) || void 0 === n ? void 0 : n.textContent;
                                            g && Ri(Tr.CUSTOM_INFO, {
                                                custom_name: "auto_value_currency_currency_code_form_xpath",
                                                extJSON: {
                                                    url: i.url,
                                                    currencyCode: g,
                                                    vcConfig: t
                                                }
                                            }), g && Lc.includes(g.toUpperCase().trim()) && (v = g.toUpperCase().trim())
                                        }
                                        if (u.countryCodeXpath) {
                                            var y = null === (r = document.evaluate(u.countryCodeXpath, document, null, XPathResult.FIRST_ORDERED_NODE_TYPE, null).singleNodeValue) || void 0 === r ? void 0 : r.textContent;
                                            y && Ri(Tr.CUSTOM_INFO, {
                                                custom_name: "auto_value_currency_country_form_xpath",
                                                extJSON: {
                                                    url: i.url,
                                                    country: y,
                                                    vcConfig: t
                                                }
                                            }), y && Mc.includes(y.toUpperCase().trim()) && (p = y.toUpperCase().trim())
                                        }
                                        try {
                                            var m = new URL(null == i ? void 0 : i.url).hostname.split(".");
                                            for (var E in m) Mc.includes(m[E].toUpperCase()) && (_ = m[E].toUpperCase())
                                        } catch (e) {}
                                        var b = {
                                            vc_properties: {
                                                value: h,
                                                currency: v || l,
                                                ori_value: d,
                                                rule_key: u.rule_key,
                                                country_code: p || _
                                            }
                                        };
                                        return Ri(Tr.CUSTOM_INFO, {
                                            custom_name: "auto_value_currency_update_info",
                                            extJSON: {
                                                url: i.url,
                                                autoProperties: b,
                                                vcConfig: t
                                            }
                                        }), Fc(Gc, b), b
                                    }
                                }
                            }
                        } catch (e) {
                            s.e(e)
                        } finally {
                            s.f()
                        }
                    }
                    return null
                }
                return null
            } catch (e) {
                return Ai(Tr.CUSTOM_ERROR, e, {
                    custom_name: "auto_value_currency_update_error",
                    custom_enum: "auto_value_currency",
                    extJSON: {
                        error: e
                    }
                }), null
            }
        };

    function jc(e, t) {
        for (var n, r = document.evaluate(e, document, null, XPathResult.ORDERED_NODE_ITERATOR_TYPE, null), i = null; n = r.iterateNext();) /\d/.test(n.innerText) && (i = n);
        if (!i && t)
            for (var o = document.getElementsByClassName(t), a = 0; a < o.length; a++) {
                var c = o[a];
                c instanceof HTMLElement && /\d/.test(c.innerText) && (i = c)
            }
        return i
    }

    function Uc(e) {
        var t, n, r, i, o = e.match(/(?:\d[\d\s,.]*\d|\d)/g);
        if (o) {
            var a, c = o[0],
                s = O(o);
            try {
                for (s.s(); !(a = s.n()).done;) {
                    if (a.value !== c) return null
                }
            } catch (e) {
                s.e(e)
            } finally {
                s.f()
            }
            return n = (t = c).replace(/[\s,\.]/g, ""), r = Math.max(t.lastIndexOf("."), t.lastIndexOf(",")), i = !1, -1 !== r && r >= t.length - 3 && (i = !0), i && (n = n.slice(0, r - (t.length - 1)) + "." + n.slice(r - (t.length - 1))), n
        }
        return null
    }
    var Fc = function(e, t) {
            try {
                sessionStorage.setItem(e, JSON.stringify(t))
            } catch (e) {}
        },
        Bc = function(e) {
            try {
                var t = sessionStorage.getItem(e);
                return t ? JSON.parse(t) : null
            } catch (e) {
                return null
            }
        },
        Gc = "value_currency_rule",
        Hc = [Za.CLICK, Za.SCROLL],
        Vc = function() {
            function e(t) {
                var n = this;
                i(this, e), this.handlerArray = t, Hc.forEach((function(e) {
                    window.addEventListener(e.toLowerCase(), ni((function() {
                        n.interactionHandler(e)
                    }), tc, n), {
                        capture: !0,
                        passive: !0
                    })
                }))
            }
            return a(e, [{
                key: "iterateHandlerArray",
                value: function(e) {
                    this.handlerArray.forEach((function(t) {
                        return t(e)
                    }))
                }
            }, {
                key: "interactionHandler",
                value: function(e) {
                    var t = this;
                    this.timeoutId && clearTimeout(this.timeoutId), this.iterateHandlerArray(e), this.timeoutId = setTimeout((function() {
                        t.iterateHandlerArray(e)
                    }), tc)
                }
            }]), e
        }(),
        Jc = function() {
            function e() {
                i(this, e), this.history = {}
            }
            return a(e, [{
                key: "hasReport",
                value: function(e, t, n) {
                    var r = this.genHistoryKey(e, t);
                    return this.history[r] && this.history[r].indexOf(n) > -1
                }
            }, {
                key: "addHistory",
                value: function(e, t, n) {
                    var r = this.genHistoryKey(e, t);
                    this.history[r] || (this.history[r] = []), this.history[r].push(n)
                }
            }, {
                key: "clearHistory",
                value: function() {
                    this.history = {}
                }
            }, {
                key: "genHistoryKey",
                value: function(e, t) {
                    return "".concat(e, ":").concat(t)
                }
            }]), e
        }(),
        Kc = function() {
            function e(t, n, r) {
                i(this, e), this.context = t, this.reportHistory = new Jc, this.reporters = n, this.reportService = r
            }
            return a(e, [{
                key: "report",
                value: function(e, t, n) {
                    var r = this,
                        i = wi(yr.AUTO_CONFIG),
                        o = this.getReportPixelList(t, n),
                        a = this.assemblyReportData(e, n, o);
                    a && i && Ji(this.reportService.reportPreposition || []).then((function() {
                        r.reportService.report(i, a, Bn.defaultReport)
                    }))
                }
            }, {
                key: "clearHistory",
                value: function() {
                    this.reportHistory.clearHistory()
                }
            }, {
                key: "getReportPixelList",
                value: function(e, t) {
                    var n = this,
                        r = JSON.stringify(Object.assign({}, t, {
                            page_trigger: void 0
                        }));
                    return this.reporters.filter((function(t) {
                        return !!ac(t) && cc(t, e)
                    })).filter((function(t) {
                        var i = t.getReporterId();
                        return !([za.AUTO_COLLECTION, za.AUTO_FORM].indexOf(e) > -1 && n.reportHistory.hasReport(e, i, r)) && (n.reportHistory.addHistory(e, i, r), t)
                    }))
                }
            }, {
                key: "assemblyReportData",
                value: function(e, t, n) {
                    var r;
                    if (0 !== n.length) {
                        var i = n.map((function(e) {
                                return e.getReporterId()
                            })),
                            o = this.context.getPageSign(),
                            a = this.reporters[0].assemblyData(i[0], "", {}, {}, yr.AUTO_CONFIG);
                        return delete a.event, a.action = e, a.auto_collected_properties = t, a.context.pixel || (a.context.pixel = {}), a.context.pixel.code = i[0], a.context.pixel.codes = i.join("|"), a.context.index = null === (r = o.pageIndex) || void 0 === r ? void 0 : r.index, a.context.session_id = o.sessionId, a.context.pageview_id = this.context.getPageViewId(), a.message_id = a.message_id.replace(/-[^-]*$/, ""), a
                    }
                }
            }]), e
        }(),
        Wc = function(e, n, r, i) {
            var o, a = arguments.length,
                c = a < 3 ? n : null === i ? i = Object.getOwnPropertyDescriptor(n, r) : i;
            if ("object" === ("undefined" == typeof Reflect ? "undefined" : t(Reflect)) && "function" == typeof Reflect.decorate) c = Reflect.decorate(e, n, r, i);
            else
                for (var s = e.length - 1; s >= 0; s--)(o = e[s]) && (c = (a < 3 ? o(c) : a > 3 ? o(n, r, c) : o(n, r)) || c);
            return a > 3 && c && Object.defineProperty(n, r, c), c
        },
        Yc = function(e, t) {
            return function(n, r) {
                t(n, r, e)
            }
        },
        qc = "AutoConfig",
        Xc = function(e) {
            s(n, e);
            var t = h(n);

            function n(e, r, o, a) {
                var c;
                return i(this, n), (c = t.call(this, {
                    name: qc,
                    reporters: r,
                    context: e
                })).autoCollectedMetadata = {}, c.initialize = !1, c.autoFormUpdateHandler = ni((function(e) {
                    if (c.autoForm) {
                        if (c.autoCollectedFormDetail = c.autoForm.getOverallFormDetail(), c.autoCollectedFormDetail.length > 3e4) return void Ai(Tr.CUSTOM_ERROR, {
                            message: "".concat(String(c.autoCollectedFormDetail.length))
                        }, {
                            custom_name: $a,
                            custom_enum: qa.OVER_LENGTH
                        });
                        c.actTracker.report(Xa.METADATA, za.AUTO_FORM, {
                            page_trigger: e,
                            form_details: c.autoCollectedFormDetail
                        })
                    }
                }), 200, f(c)), c.autoCollectionUpdateHandler = ni((function(e) {
                    to(qi.AUTO_CONFIG_CONTENT), c.autoCollectedMetadata = mc(c.filter), no(qi.AUTO_CONFIG_CONTENT), c.actTracker.report(Xa.METADATA, za.AUTO_COLLECTION, {
                        page_trigger: e,
                        content_data: c.autoCollectedMetadata
                    })
                }), 200, f(c)), c.autoClickCallback = function(e) {
                    try {
                        c.signal_insights_config && xc(c.context, c.signal_insights_config);
                        var t = function(e) {
                            var t = e,
                                n = e.parentNode,
                                r = 0,
                                i = !1;
                            try {
                                i = ci(t)
                            } catch (e) {
                                Ai(Tr.CUSTOM_ERROR, e, {
                                    custom_name: "button_check_error",
                                    custom_enum: "auto_click",
                                    extJSON: {
                                        element: t
                                    }
                                }), i = !1
                            }
                            if (i) return t;
                            for (; r < 5 && n && n !== document;) {
                                var o = !1;
                                try {
                                    o = ci(n)
                                } catch (e) {
                                    Ai(Tr.CUSTOM_ERROR, e, {
                                        custom_name: "button_check_error",
                                        custom_enum: "auto_click",
                                        extJSON: {
                                            element: t
                                        }
                                    }), o = !1
                                }
                                if (o) return n;
                                n = n.parentNode, r++
                            }
                            return e
                        }(e.target);
                        if (t) {
                            var n = function(e) {
                                var t = e.tag,
                                    n = e.class,
                                    r = e.destination,
                                    i = e.id,
                                    o = e.name,
                                    a = e.type,
                                    c = e.value,
                                    s = e.rect,
                                    u = e.xpath,
                                    l = e.inner_text,
                                    f = e.image_url,
                                    d = {
                                        tag: t,
                                        attributes: {},
                                        inner_text: l,
                                        xpath: u,
                                        num_child_buttons: e.num_child_buttons,
                                        timestamp: (new Date).toISOString(),
                                        position: s ? {
                                            x: s.x,
                                            y: s.y
                                        } : {
                                            x: "",
                                            y: ""
                                        }
                                    };
                                return n && (d.attributes.class = n), r && (d.attributes.destination = r), i && (d.attributes.id = i), o && (d.attributes.name = o), a && (d.attributes.type = a), c && (d.attributes.value = c), f && (d.image_url = f), d
                            }(function(e) {
                                for (var t, n, r, i, o, a, c, s = !(arguments.length > 1 && void 0 !== arguments[1]) || arguments[1], u = e.attributes, l = {
                                        type: "",
                                        value: "",
                                        name: "",
                                        class: "",
                                        dataset: "",
                                        id: "",
                                        tag: "",
                                        destination: "",
                                        xpath: "",
                                        inner_text: "",
                                        image_url: "",
                                        num_child_buttons: 0
                                    }, f = 0; f < u.length; f++) {
                                    var d = u[f];
                                    l[d.name] = d.value
                                }
                                var h = e.dataset;
                                l.dataset = JSON.stringify(h), l.id = null !== (t = e.id) && void 0 !== t ? t : "", l.class = null !== (n = e.className) && void 0 !== n ? n : "", l.tag = e.tagName, l.destination = uc(e), l.name = null !== (r = e.getAttribute("name")) && void 0 !== r ? r : "", l.value = null !== (i = e.getAttribute("value")) && void 0 !== i ? i : "", l.type = null !== (o = e.getAttribute("type")) && void 0 !== o ? o : "";
                                var p = e.getBoundingClientRect();
                                l.rect = p;
                                try {
                                    l.xpath = rc(e)
                                } catch (t) {
                                    l.xpath = "", Ai(Tr.CUSTOM_ERROR, t, {
                                        custom_name: "button_check_error",
                                        custom_enum: "auto_click",
                                        extJSON: {
                                            element: e
                                        }
                                    })
                                }
                                return l.inner_text = null !== (a = e.innerText) && void 0 !== a ? a : "", l.image_url = null !== (c = e.getAttribute("src")) && void 0 !== c ? c : "", l.num_child_buttons = s ? sc(e) : 0, l
                            }(t));
                            if (function(e) {
                                    var t, n, r = (null === (t = e.inner_text) || void 0 === t ? void 0 : t.toString().toLowerCase()) || "",
                                        i = (null === (n = e.image_url) || void 0 === n ? void 0 : n.toString().toLowerCase()) || "",
                                        o = [];
                                    if (e.attributes) {
                                        var a = e.attributes;
                                        o = [a.class, a.id, a.name, a.type, a.value, a.destination].map((function(e) {
                                            return (null == e ? void 0 : e.toString().toLowerCase()) || ""
                                        }))
                                    }
                                    return [r, i].concat(y(o)).some(nc)
                                }(n)) return void Ri(Tr.CUSTOM_INFO, {
                                custom_name: "sensitive_button",
                                extJSON: {
                                    attributes: {
                                        id: n.attributes.id,
                                        tag: n.tag,
                                        class: n.attributes.class
                                    }
                                }
                            });
                            c.reportButtonClick(n)
                        }
                    } catch (e) {
                        Ai(Tr.CUSTOM_ERROR, e, {
                            custom_name: "auto_click_callback_error",
                            custom_enum: "auto_click"
                        })
                    }
                }, c.filter = o.auto_config || {
                    open_graph: [],
                    microdata: [],
                    json_ld: [],
                    meta: []
                }, c.actTracker = new Kc(e, r, a), c
            }
            return a(n, [{
                key: "initBaseFeature",
                value: function(e) {
                    !this.initialize && ac(e) && (this.initAutoClick(), this.initAutoCollection(), this.initInteractionListener(e), this.initialize = !0)
                }
            }, {
                key: "initExtraFeature",
                value: function(e) {
                    !this.autoForm && this.initialize && cc(e, za.AUTO_FORM) && this.initAutoForm(e), this.initAutoVC(e)
                }
            }, {
                key: "initInteractionListener",
                value: function(e) {
                    var t = this,
                        n = e.options;
                    !this.initialize && n && !1 !== n.autoConfigListener && new Vc([function(e) {
                        oc(t.autoCollectionUpdateHandler, t)(e)
                    }, function(e) {
                        oc(t.autoFormUpdateHandler, t)(e)
                    }])
                }
            }, {
                key: "initAutoClick",
                value: function() {
                    ! function(e) {
                        var t = ir((function(t) {
                            to(qi.AUTO_CONFIG_CLICK), e(t), no(qi.AUTO_CONFIG_CLICK)
                        }), 1e3);
                        document.querySelectorAll(oi.join(", ")).forEach((function(e) {
                            ai.some((function(t) {
                                return e.matches(t)
                            })) || e.addEventListener("click", t, {
                                capture: !0
                            })
                        }))
                    }(this.autoClickCallback)
                }
            }, {
                key: "initAutoVC",
                value: function(e) {
                    var t = Dc(e);
                    t && (this.signal_insights_config = t)
                }
            }, {
                key: "initAutoCollection",
                value: function() {}
            }, {
                key: "initAutoForm",
                value: function(e) {
                    to(qi.AUTO_CONFIG_FORM), this.autoForm = new kc(e), no(qi.AUTO_CONFIG_FORM), this.autoForm.addFormUpdateHandler(this.autoFormUpdateHandler.bind(this)), this.autoCollectedFormDetail = this.autoForm.getOverallFormDetail()
                }
            }, {
                key: "pixelDidMount",
                value: function(e) {
                    this.initBaseFeature(e), this.initExtraFeature(e)
                }
            }, {
                key: "pixelSend",
                value: function(e, t, n) {
                    var r = this.reporters.find((function(t) {
                        return t.getReporterId() === e
                    }));
                    this.signal_insights_config && xc(this.context, this.signal_insights_config), r && Dc(r) && Bc(Gc) && ("CompletePayment" === t || "Pageview" === t || "InitiateCheckout" === t || "PlaceAnOrder" === t) && (n.auto_collected_properties = Bc(Gc)), "CompletePayment" === t && setTimeout((function() {
                        ! function(e) {
                            try {
                                sessionStorage.removeItem(e)
                            } catch (e) {}
                        }(Gc)
                    }), 500), "Pageview" === t && (r && !ac(r) || (oc(this.autoCollectionUpdateHandler, this)(Za.PAGE_VIEW), oc(this.autoFormUpdateHandler, this)(Za.PAGE_VIEW)))
                }
            }, {
                key: "pageUrlDidChange",
                value: function(e, t) {
                    null != t && "" != t && (this.autoCollectionUpdateHandler(Za.URL_CHANGE), this.autoFormUpdateHandler(Za.URL_CHANGE))
                }
            }, {
                key: "pageWillLeave",
                value: function() {
                    this.autoCollectionUpdateHandler(Za.PAGE_LEAVE), this.autoFormUpdateHandler(Za.PAGE_LEAVE)
                }
            }, {
                key: "reportButtonClick",
                value: function(e) {
                    var t;
                    this.actTracker.report(Xa.CLICK, za.AUTO_VC, {
                        page_trigger: Za.CLICK,
                        trigger_element: e,
                        vc_properties: null === (t = Bc(Gc)) || void 0 === t ? void 0 : t.vc_properties
                    }), this.actTracker.report(Xa.CLICK, za.AUTO_VC_REVERSE, {
                        page_trigger: Za.CLICK,
                        trigger_element: e
                    })
                }
            }]), n
        }(fo);
    Xc = Wc([A.injectable(), Yc(0, A.inject(br.CONTEXT)), Yc(1, A.inject(br.TTQ_REPORTERS)), Yc(2, A.inject(br.TTQ_GLOBAL_OPTIONS)), Yc(3, A.inject(br.REPORT_SERVICE))], Xc);
    var zc = {
        exports: {}
    };
    ! function(e, t) {
        var n = "__lodash_hash_undefined__",
            r = 9007199254740991,
            i = "[object Arguments]",
            o = "[object Boolean]",
            a = "[object Date]",
            c = "[object Function]",
            s = "[object GeneratorFunction]",
            u = "[object Map]",
            l = "[object Number]",
            f = "[object Object]",
            d = "[object Promise]",
            h = "[object RegExp]",
            p = "[object Set]",
            v = "[object String]",
            _ = "[object Symbol]",
            g = "[object WeakMap]",
            y = "[object ArrayBuffer]",
            m = "[object DataView]",
            E = "[object Float32Array]",
            b = "[object Float64Array]",
            T = "[object Int8Array]",
            I = "[object Int16Array]",
            O = "[object Int32Array]",
            S = "[object Uint8Array]",
            R = "[object Uint8ClampedArray]",
            A = "[object Uint16Array]",
            C = "[object Uint32Array]",
            P = /\w*$/,
            w = /^\[object .+?Constructor\]$/,
            k = /^(?:0|[1-9]\d*)$/,
            M = {};
        M[i] = M["[object Array]"] = M[y] = M[m] = M[o] = M[a] = M[E] = M[b] = M[T] = M[I] = M[O] = M[u] = M[l] = M[f] = M[h] = M[p] = M[v] = M[_] = M[S] = M[R] = M[A] = M[C] = !0, M["[object Error]"] = M[c] = M[g] = !1;
        var L = "object" == typeof N && N && N.Object === Object && N,
            D = "object" == typeof self && self && self.Object === Object && self,
            x = L || D || Function("return this")(),
            j = t && !t.nodeType && t,
            U = j && e && !e.nodeType && e,
            F = U && U.exports === j;

        function B(e, t) {
            return e.set(t[0], t[1]), e
        }

        function G(e, t) {
            return e.add(t), e
        }

        function H(e, t, n, r) {
            var i = -1,
                o = e ? e.length : 0;
            for (r && o && (n = e[++i]); ++i < o;) n = t(n, e[i], i, e);
            return n
        }

        function V(e) {
            var t = !1;
            if (null != e && "function" != typeof e.toString) try {
                t = !!(e + "")
            } catch (e) {}
            return t
        }

        function J(e) {
            var t = -1,
                n = Array(e.size);
            return e.forEach((function(e, r) {
                n[++t] = [r, e]
            })), n
        }

        function K(e, t) {
            return function(n) {
                return e(t(n))
            }
        }

        function W(e) {
            var t = -1,
                n = Array(e.size);
            return e.forEach((function(e) {
                n[++t] = e
            })), n
        }
        var Y = Array.prototype,
            q = Function.prototype,
            X = Object.prototype,
            z = x["__core-js_shared__"],
            Q = function() {
                var e = /[^.]+$/.exec(z && z.keys && z.keys.IE_PROTO || "");
                return e ? "Symbol(src)_1." + e : ""
            }(),
            Z = q.toString,
            $ = X.hasOwnProperty,
            ee = X.toString,
            te = RegExp("^" + Z.call($).replace(/[\\^$.*+?()[\]{}|]/g, "\\$&").replace(/hasOwnProperty|(function).*?(?=\\\()| for .+?(?=\\\])/g, "$1.*?") + "$"),
            ne = F ? x.Buffer : void 0,
            re = x.Symbol,
            ie = x.Uint8Array,
            oe = K(Object.getPrototypeOf, Object),
            ae = Object.create,
            ce = X.propertyIsEnumerable,
            se = Y.splice,
            ue = Object.getOwnPropertySymbols,
            le = ne ? ne.isBuffer : void 0,
            fe = K(Object.keys, Object),
            de = je(x, "DataView"),
            he = je(x, "Map"),
            pe = je(x, "Promise"),
            ve = je(x, "Set"),
            _e = je(x, "WeakMap"),
            ge = je(Object, "create"),
            ye = He(de),
            me = He(he),
            Ee = He(pe),
            be = He(ve),
            Te = He(_e),
            Ie = re ? re.prototype : void 0,
            Oe = Ie ? Ie.valueOf : void 0;

        function Se(e) {
            var t = -1,
                n = e ? e.length : 0;
            for (this.clear(); ++t < n;) {
                var r = e[t];
                this.set(r[0], r[1])
            }
        }

        function Ne(e) {
            var t = -1,
                n = e ? e.length : 0;
            for (this.clear(); ++t < n;) {
                var r = e[t];
                this.set(r[0], r[1])
            }
        }

        function Re(e) {
            var t = -1,
                n = e ? e.length : 0;
            for (this.clear(); ++t < n;) {
                var r = e[t];
                this.set(r[0], r[1])
            }
        }

        function Ae(e) {
            this.__data__ = new Ne(e)
        }

        function Ce(e, t) {
            var n = Je(e) || function(e) {
                    return function(e) {
                        return function(e) {
                            return !!e && "object" == typeof e
                        }(e) && Ke(e)
                    }(e) && $.call(e, "callee") && (!ce.call(e, "callee") || ee.call(e) == i)
                }(e) ? function(e, t) {
                    for (var n = -1, r = Array(e); ++n < e;) r[n] = t(n);
                    return r
                }(e.length, String) : [],
                r = n.length,
                o = !!r;
            for (var a in e) !t && !$.call(e, a) || o && ("length" == a || Be(a, r)) || n.push(a);
            return n
        }

        function Pe(e, t, n) {
            var r = e[t];
            $.call(e, t) && Ve(r, n) && (void 0 !== n || t in e) || (e[t] = n)
        }

        function we(e, t) {
            for (var n = e.length; n--;)
                if (Ve(e[n][0], t)) return n;
            return -1
        }

        function ke(e, t, n, r, d, g, N) {
            var w;
            if (r && (w = g ? r(e, d, g, N) : r(e)), void 0 !== w) return w;
            if (!qe(e)) return e;
            var k = Je(e);
            if (k) {
                if (w = function(e) {
                        var t = e.length,
                            n = e.constructor(t);
                        t && "string" == typeof e[0] && $.call(e, "index") && (n.index = e.index, n.input = e.input);
                        return n
                    }(e), !t) return function(e, t) {
                    var n = -1,
                        r = e.length;
                    t || (t = Array(r));
                    for (; ++n < r;) t[n] = e[n];
                    return t
                }(e, w)
            } else {
                var L = Fe(e),
                    D = L == c || L == s;
                if (We(e)) return function(e, t) {
                    if (t) return e.slice();
                    var n = new e.constructor(e.length);
                    return e.copy(n), n
                }(e, t);
                if (L == f || L == i || D && !g) {
                    if (V(e)) return g ? e : {};
                    if (w = function(e) {
                            return "function" != typeof e.constructor || Ge(e) ? {} : (t = oe(e), qe(t) ? ae(t) : {});
                            var t
                        }(D ? {} : e), !t) return function(e, t) {
                        return De(e, Ue(e), t)
                    }(e, function(e, t) {
                        return e && De(t, Xe(t), e)
                    }(w, e))
                } else {
                    if (!M[L]) return g ? e : {};
                    w = function(e, t, n, r) {
                        var i = e.constructor;
                        switch (t) {
                            case y:
                                return Le(e);
                            case o:
                            case a:
                                return new i(+e);
                            case m:
                                return function(e, t) {
                                    var n = t ? Le(e.buffer) : e.buffer;
                                    return new e.constructor(n, e.byteOffset, e.byteLength)
                                }(e, r);
                            case E:
                            case b:
                            case T:
                            case I:
                            case O:
                            case S:
                            case R:
                            case A:
                            case C:
                                return function(e, t) {
                                    var n = t ? Le(e.buffer) : e.buffer;
                                    return new e.constructor(n, e.byteOffset, e.length)
                                }(e, r);
                            case u:
                                return function(e, t, n) {
                                    return H(t ? n(J(e), !0) : J(e), B, new e.constructor)
                                }(e, r, n);
                            case l:
                            case v:
                                return new i(e);
                            case h:
                                return function(e) {
                                    var t = new e.constructor(e.source, P.exec(e));
                                    return t.lastIndex = e.lastIndex, t
                                }(e);
                            case p:
                                return function(e, t, n) {
                                    return H(t ? n(W(e), !0) : W(e), G, new e.constructor)
                                }(e, r, n);
                            case _:
                                return c = e, Oe ? Object(Oe.call(c)) : {}
                        }
                        var c
                    }(e, L, ke, t)
                }
            }
            N || (N = new Ae);
            var x = N.get(e);
            if (x) return x;
            if (N.set(e, w), !k) var j = n ? function(e) {
                return function(e, t, n) {
                    var r = t(e);
                    return Je(e) ? r : function(e, t) {
                        for (var n = -1, r = t.length, i = e.length; ++n < r;) e[i + n] = t[n];
                        return e
                    }(r, n(e))
                }(e, Xe, Ue)
            }(e) : Xe(e);
            return function(e, t) {
                for (var n = -1, r = e ? e.length : 0; ++n < r && !1 !== t(e[n], n, e););
            }(j || e, (function(i, o) {
                j && (i = e[o = i]), Pe(w, o, ke(i, t, n, r, o, e, N))
            })), w
        }

        function Me(e) {
            return !(!qe(e) || (t = e, Q && Q in t)) && (Ye(e) || V(e) ? te : w).test(He(e));
            var t
        }

        function Le(e) {
            var t = new e.constructor(e.byteLength);
            return new ie(t).set(new ie(e)), t
        }

        function De(e, t, n, r) {
            n || (n = {});
            for (var i = -1, o = t.length; ++i < o;) {
                var a = t[i],
                    c = r ? r(n[a], e[a], a, n, e) : void 0;
                Pe(n, a, void 0 === c ? e[a] : c)
            }
            return n
        }

        function xe(e, t) {
            var n, r, i = e.__data__;
            return ("string" == (r = typeof(n = t)) || "number" == r || "symbol" == r || "boolean" == r ? "__proto__" !== n : null === n) ? i["string" == typeof t ? "string" : "hash"] : i.map
        }

        function je(e, t) {
            var n = function(e, t) {
                return null == e ? void 0 : e[t]
            }(e, t);
            return Me(n) ? n : void 0
        }
        Se.prototype.clear = function() {
            this.__data__ = ge ? ge(null) : {}
        }, Se.prototype.delete = function(e) {
            return this.has(e) && delete this.__data__[e]
        }, Se.prototype.get = function(e) {
            var t = this.__data__;
            if (ge) {
                var r = t[e];
                return r === n ? void 0 : r
            }
            return $.call(t, e) ? t[e] : void 0
        }, Se.prototype.has = function(e) {
            var t = this.__data__;
            return ge ? void 0 !== t[e] : $.call(t, e)
        }, Se.prototype.set = function(e, t) {
            return this.__data__[e] = ge && void 0 === t ? n : t, this
        }, Ne.prototype.clear = function() {
            this.__data__ = []
        }, Ne.prototype.delete = function(e) {
            var t = this.__data__,
                n = we(t, e);
            return !(n < 0) && (n == t.length - 1 ? t.pop() : se.call(t, n, 1), !0)
        }, Ne.prototype.get = function(e) {
            var t = this.__data__,
                n = we(t, e);
            return n < 0 ? void 0 : t[n][1]
        }, Ne.prototype.has = function(e) {
            return we(this.__data__, e) > -1
        }, Ne.prototype.set = function(e, t) {
            var n = this.__data__,
                r = we(n, e);
            return r < 0 ? n.push([e, t]) : n[r][1] = t, this
        }, Re.prototype.clear = function() {
            this.__data__ = {
                hash: new Se,
                map: new(he || Ne),
                string: new Se
            }
        }, Re.prototype.delete = function(e) {
            return xe(this, e).delete(e)
        }, Re.prototype.get = function(e) {
            return xe(this, e).get(e)
        }, Re.prototype.has = function(e) {
            return xe(this, e).has(e)
        }, Re.prototype.set = function(e, t) {
            return xe(this, e).set(e, t), this
        }, Ae.prototype.clear = function() {
            this.__data__ = new Ne
        }, Ae.prototype.delete = function(e) {
            return this.__data__.delete(e)
        }, Ae.prototype.get = function(e) {
            return this.__data__.get(e)
        }, Ae.prototype.has = function(e) {
            return this.__data__.has(e)
        }, Ae.prototype.set = function(e, t) {
            var n = this.__data__;
            if (n instanceof Ne) {
                var r = n.__data__;
                if (!he || r.length < 199) return r.push([e, t]), this;
                n = this.__data__ = new Re(r)
            }
            return n.set(e, t), this
        };
        var Ue = ue ? K(ue, Object) : function() {
                return []
            },
            Fe = function(e) {
                return ee.call(e)
            };

        function Be(e, t) {
            return !!(t = null == t ? r : t) && ("number" == typeof e || k.test(e)) && e > -1 && e % 1 == 0 && e < t
        }

        function Ge(e) {
            var t = e && e.constructor;
            return e === ("function" == typeof t && t.prototype || X)
        }

        function He(e) {
            if (null != e) {
                try {
                    return Z.call(e)
                } catch (e) {}
                try {
                    return e + ""
                } catch (e) {}
            }
            return ""
        }

        function Ve(e, t) {
            return e === t || e != e && t != t
        }(de && Fe(new de(new ArrayBuffer(1))) != m || he && Fe(new he) != u || pe && Fe(pe.resolve()) != d || ve && Fe(new ve) != p || _e && Fe(new _e) != g) && (Fe = function(e) {
            var t = ee.call(e),
                n = t == f ? e.constructor : void 0,
                r = n ? He(n) : void 0;
            if (r) switch (r) {
                case ye:
                    return m;
                case me:
                    return u;
                case Ee:
                    return d;
                case be:
                    return p;
                case Te:
                    return g
            }
            return t
        });
        var Je = Array.isArray;

        function Ke(e) {
            return null != e && function(e) {
                return "number" == typeof e && e > -1 && e % 1 == 0 && e <= r
            }(e.length) && !Ye(e)
        }
        var We = le || function() {
            return !1
        };

        function Ye(e) {
            var t = qe(e) ? ee.call(e) : "";
            return t == c || t == s
        }

        function qe(e) {
            var t = typeof e;
            return !!e && ("object" == t || "function" == t)
        }

        function Xe(e) {
            return Ke(e) ? Ce(e) : function(e) {
                if (!Ge(e)) return fe(e);
                var t = [];
                for (var n in Object(e)) $.call(e, n) && "constructor" != n && t.push(n);
                return t
            }(e)
        }
        e.exports = function(e) {
            return ke(e, !0, !0)
        }
    }(zc, zc.exports);
    var Qc = zc.exports,
        Zc = {
            EMPTY_EVENT_TYPE_NAME: {
                title: "Missing Event Name",
                desc: "The event name for one or more of your events is empty. This can affect the accuracy of reporting for your conversions.",
                suggestion: "Go to your source code and add a name that follows our format requirements and TikTok policies.",
                link: "https://ads.tiktok.com/marketing_api/docs?rid=5ipocbxyw8v&id=1701890973258754"
            },
            INVALID_CONTENT_ID: {
                title: "Missing value for content ID",
                desc: "Include a value for your 'content_id' parameter. This is required for Video Shopping Ads (VSA).",
                suggestion: "If you are or plan to run Video Shopping Ads (VSA), go to your source code and include a value for the 'content_id' parameter.",
                link: "https://ads.tiktok.com/help/article/standard-events-parameters?redirected=2"
            },
            INVALID_CONTENT_TYPE: {
                title: "Invalid content type",
                desc: 'The content type for one or more of your events is invalid. Content type must be either "product" or "product_group".',
                suggestion: "Go to your source code and update the content type.",
                link: "https://ads.tiktok.com/help/article/standard-events-parameters?redirected=2"
            },
            INVALID_CURRENCY_CODE: {
                title: "Invalid currency code",
                desc: "The currency code for one or more of your events isn't supported. This can affect the accuracy of reporting for your ROAS.",
                suggestion: "Go to your source code and update the 'currency' parameters with a supported currency code.",
                link: "https://ads.tiktok.com/help/article/standard-events-parameters?redirected=2"
            },
            INVALID_EMAIL_FORMAT: {
                title: "Incorrect email format",
                desc: "The email format for your events does not match the format supported. This can impact Advanced Matching and your ad performance.",
                suggestion: "Go to your source code and update the format of your shared emails. It should follow 'xxx@xxx.com' format.",
                link: "https://ads.tiktok.com/marketing_api/docs?id=1739585700402178"
            },
            INVALID_EMAIL_INFORMATION: {
                title: "Invalid email information",
                desc: "The emails shared with your events were invalid.",
                suggestion: 'Go to your source code to double check shared emails. Leave your string empty when customer information isn\'t available. Avoid spaces, "undefined", or other hardcoded values.',
                link: "https://ads.tiktok.com/marketing_api/docs?id=1739585700402178"
            },
            INVALID_EVENT_PARAMETER_VALUE: {
                title: "Invalid value parameter",
                desc: "The 'value' parameter for one or more of your events is invalid. This is used calculate ROAS for people and the bid for your highest value customers. Parameters must be an integer or in the decimal format (e.g. 9.99). Also, they can't contain currency symbols, special characters, letters, or commas.",
                suggestion: "Go to your source code and update the 'value' parameter. It can only include numbers greater than or equal to zero (e.g. 9.99). Do not include currency symbols, special characters, letters, or commas.",
                link: "https://ads.tiktok.com/help/article/standard-events-parameters?redirected=2"
            },
            INVALID_PHONE_NUMBER_FORMAT: {
                title: "Incorrect phone number format",
                desc: "The phone number format for your events doesn't follow the E.164 format. This can affect Advanced Matching and your ad performance.",
                suggestion: "Go to your source code and update your shared phone numbers. It should follow the E.164 format.",
                link: "https://ads.tiktok.com/marketing_api/docs?id=1739585700402178"
            },
            INVALID_PHONE_NUMBER_INFORMATION: {
                title: "Invalid phone number information",
                desc: "The phone numbers shared with your events were invalid.",
                suggestion: 'Go to your source code to double check shared phone numbers. Leave your string empty when customer information isn\'t available. Avoid spaces, "undefined", or other hardcoded values.',
                link: "https://ads.tiktok.com/marketing_api/docs?id=1739585700402178"
            },
            LONG_EVENT_TYPE_NAME: {
                title: "Event Name Too Long",
                desc: "1 event type exceeds the 50 character limit.",
                suggestion: "Go to your source code and make these event names 50 characters or less.",
                link: "https://ads.tiktok.com/help/article/custom-events?lang=en"
            },
            MISMATCHED_EVENT_TYPE_NAME_FOR_CUSTOM_EVENT: {
                title: "Invalid Event Name Format",
                desc: "1 event name was rejected for not following TikTok format requirements.",
                suggestion: "Go to your source code and update these event types according to TikTok format requirements.",
                link: "https://ads.tiktok.com/help/article/custom-events?lang=en"
            },
            MISSING_CONTENT_ID: {
                title: "Missing 'content_id' paramter",
                desc: "The 'content_id' parameter isn't being received. This is required for Video Shopping Ads (VSA).",
                suggestion: "Include the 'content_id' parameter in your source code. This is required for Video Shopping Ads (VSA).",
                link: "https://ads.tiktok.com/help/article/standard-events-parameters?redirected=2"
            },
            MISSING_CURRENCY_PARAMETER: {
                title: 'Missing "currency" parameter',
                desc: "Events shared are missing a 'currency' parameter. This impacts our ability to receive the value amount correctly, which can affect the accuracy of reporting for your return on ad spend.",
                suggestion: 'Go to your source code and include the "currency" parameter. You can check supported currency codes. {{learn_more}}',
                link: "https://ads.tiktok.com/help/article/standard-events-parameters?redirected=2"
            },
            MISSING_EMAIL_AND_PHONE: {
                title: "Missing email and phone number",
                desc: "Email and phone number info isn't being received. This information is required for Complete Payment events.",
                suggestion: "Improve your email and phone coverage. This allows you to attribute more conversions and reach more people with your ads.",
                link: "https://ads.tiktok.com/marketing_api/docs?rid=5ipocbxyw8v&id=1701890972946433"
            },
            MISSING_VALUE_PARAMETER: {
                title: 'Missing "value" parameter',
                desc: "Events shared are missing a 'value' parameter'. This is used calculate ROAS for people and the bid for your highest value customers. ",
                suggestion: 'Go to your source code and include the "value" parameter.',
                link: "https://ads.tiktok.com/help/article/standard-events-parameters?redirected=2"
            },
            DUPLICATE_PIXEL_CODE: {
                title: "Duplicate Pixel ID",
                desc: "The pixel ID is duplicate. This could impact the pixel data accuracy.",
                suggestion: "Please double check and delete any unnecessary pixel code.",
                link: ""
            },
            MISSING_PIXEL_CODE: {
                title: "Missing pixel ID",
                desc: "Some of the events sent to your TikTok account are missing a pixel ID.",
                suggestion: "Go to your source code and double check that the 20-character pixel ID has been added to the ttq.load() function. Don't send null values or spaces. If you edited the base code, ensure the event.js has the 'sdkid' in the Chrome network panel.",
                link: ""
            },
            INVALID_PIXEL_CODE: {
                title: "Invalid pixel ID",
                desc: "The pixel ID is invalid. This could prevent your pixel from receiving data.",
                suggestion: "Please go to Events Manager and find the correct pixel ID.",
                link: ""
            }
        },
        $c = /^[a-zA-Z\d]([a-zA-Z_\-\d ]{0,}[a-zA-Z_\-\d])?$/,
        es = ["product", "product_group"],
        ts = ["email_is_hashed", "phone_is_hashed", "sha256_email", "sha256_phone"],
        ns = ["AED", "ARS", "AUD", "BDT", "BHD", "BIF", "BOB", "BRL", "CAD", "CHF", "CLP", "CNY", "COP", "CRC", "CZK", "DKK", "DZD", "EGP", "EUR", "GBP", "GTQ", "HKD", "HNL", "HUF", "IDR", "ILS", "INR", "ISK", "JPY", "KES", "KHR", "KRW", "KWD", "KZT", "MAD", "MOP", "MXN", "MYR", "NGN", "NIO", "NOK", "NZD", "OMR", "PEN", "PHP", "PKR", "PLN", "PYG", "QAR", "RON", "RUB", "SAR", "SEK", "SGD", "THB", "TRY", "TWD", "UAH", "USD", "VES", "VND", "ZAR"],
        rs = ["CompletePayment", "InitiateCheckout", "AddToCart", "PlaceAnOrder", "ViewContent", "AddToWishlist"],
        is = function(e) {
            return void 0 === e
        },
        os = "CompletePayment",
        as = function(e) {
            var t = e.event,
                n = void 0 === t ? "" : t;
            return !!["null", "undefined"].includes(n) || (!!/^\s*$/.test(n) || !n)
        },
        cs = function(e, n, r, i) {
            var o, a = arguments.length,
                c = a < 3 ? n : null === i ? i = Object.getOwnPropertyDescriptor(n, r) : i;
            if ("object" === ("undefined" == typeof Reflect ? "undefined" : t(Reflect)) && "function" == typeof Reflect.decorate) c = Reflect.decorate(e, n, r, i);
            else
                for (var s = e.length - 1; s >= 0; s--)(o = e[s]) && (c = (a < 3 ? o(c) : a > 3 ? o(n, r, c) : o(n, r)) || c);
            return a > 3 && c && Object.defineProperty(n, r, c), c
        },
        ss = function(e, t) {
            return function(n, r) {
                t(n, r, e)
            }
        },
        us = function(e) {
            s(n, e);
            var t = h(n);

            function n(e, r, o) {
                var a, c;
                return i(this, n), (a = t.call(this, {
                    name: "DiagnosticsConsole",
                    reporters: r,
                    context: e
                })).isEnableDiagnosticsConsole = !1, a.isEnableDiagnosticsConsole = Boolean(null === (c = null == o ? void 0 : o.plugins) || void 0 === c ? void 0 : c.DiagnosticsConsole), a
            }
            return a(n, [{
                key: "isDisableDiagnosticsConsole",
                value: function() {
                    try {
                        return !this.isEnableDiagnosticsConsole || Boolean(Object.values(this.reporters).some((function(e) {
                            var t, n;
                            return void 0 !== (null === (t = null == e ? void 0 : e.options) || void 0 === t ? void 0 : t.diagnostics) && !(null === (n = null == e ? void 0 : e.options) || void 0 === n ? void 0 : n.diagnostics)
                        })))
                    } catch (e) {
                        return !1
                    }
                }
            }, {
                key: "warn",
                value: function(e, t) {
                    try {
                        if (this.isDisableDiagnosticsConsole()) return;
                        ! function(e, t) {
                            if (Ir[e]) {
                                var n = Jr(),
                                    r = Zc[e],
                                    i = "".concat("[TikTok Pixel]", " - ").concat(r.title);
                                r.desc && (i += "\nIssue: ".concat(r.desc)), r.suggestion && (i += "\nSuggestion: ".concat(r.suggestion)), t && Object.keys(t).forEach((function(e) {
                                    i = i.split("{{".concat(e, "}}")).join(t[e])
                                })), i = i.trim(), r.link && (i += " See ".concat(r.link, " for more information.")), n && n.console && n.console.warn && n.console.warn(i)
                            }
                        }(e, t)
                    } catch (t) {
                        Ai(Tr.CUSTOM_ERROR, t, {
                            custom_name: "diagnostics_console",
                            custom_enum: e
                        })
                    }
                }
            }, {
                key: "pixelDidMount",
                value: function(e) {
                    var t = this;
                    e.getParameterInfo().then((function(e) {
                        t.handlePixelInfoValidate(e)
                    })).catch((function(e) {
                        Ai(Tr.CUSTOM_ERROR, e, {
                            custom_name: "diagnostics_console",
                            custom_enum: "pixel"
                        })
                    }))
                }
            }, {
                key: "pixelSend",
                value: function(e, t, n) {
                    var r = arguments.length > 3 && void 0 !== arguments[3] ? arguments[3] : {},
                        i = arguments.length > 4 ? arguments[4] : void 0;
                    try {
                        r && r._i || i !== yr.TRACK || t === mr || this.handleEventPayloadValidate(Qc(n || {}))
                    } catch (e) {
                        Ai(Tr.CUSTOM_ERROR, e, {
                            custom_name: "diagnostics_console",
                            custom_enum: "track"
                        })
                    }
                }
            }, {
                key: "handlePixelInfoValidate",
                value: function(e) {
                    if (e.status === vo.Live);
                    else this.warn(Ir.INVALID_PIXEL_CODE)
                }
            }, {
                key: "handleEventPayloadValidate",
                value: function(e) {
                    e.properties || (e.properties = {}), as(e) && this.warn(Ir.EMPTY_EVENT_TYPE_NAME),
                        function(e) {
                            var t = e.event,
                                n = void 0 === t ? "" : t;
                            return !!as(e) || $c.test(n)
                        }(e) || this.warn(Ir.MISMATCHED_EVENT_TYPE_NAME_FOR_CUSTOM_EVENT),
                        function(e) {
                            var t = e.event;
                            return (void 0 === t ? "" : t).length <= 50
                        }(e) || this.warn(Ir.LONG_EVENT_TYPE_NAME),
                        function(e) {
                            var t = e.event,
                                n = e._inspection;
                            if (t === os) {
                                var r = (void 0 === n ? {} : n).identity_params,
                                    i = void 0 === r ? {} : r;
                                return 0 === Object.keys(i).length || ts.every((function(e) {
                                    return (i[e] || []).includes(Vn.EMPTY_VALUE)
                                }))
                            }
                            return !1
                        }(e) && this.warn(Ir.MISSING_EMAIL_AND_PHONE),
                        function(e) {
                            var t = e._inspection,
                                n = void 0 === t ? {} : t;
                            return !(!n || !n.identity_params) && ((n.identity_params.email_is_hashed || []).includes(Vn.FILTER_EVENTS) || (n.identity_params.sha256_email || []).includes(Vn.FILTER_EVENTS))
                        }(e) && this.warn(Ir.INVALID_EMAIL_INFORMATION),
                        function(e) {
                            var t = e._inspection,
                                n = void 0 === t ? {} : t;
                            return !(!n || !n.identity_params) && ((n.identity_params.email_is_hashed || []).includes(Vn.UNKNOWN_INVALID) || (n.identity_params.sha256_email || []).includes(Vn.UNKNOWN_INVALID))
                        }(e) && this.warn(Ir.INVALID_EMAIL_FORMAT),
                        function(e) {
                            var t = e._inspection,
                                n = void 0 === t ? {} : t;
                            return !(!n || !n.identity_params) && ((n.identity_params.phone_is_hashed || []).includes(Vn.FILTER_EVENTS) || (n.identity_params.sha256_phone || []).includes(Vn.FILTER_EVENTS))
                        }(e) && this.warn(Ir.INVALID_PHONE_NUMBER_INFORMATION),
                        function(e) {
                            var t = e._inspection,
                                n = void 0 === t ? {} : t;
                            return !(!n || !n.identity_params) && ((n.identity_params.phone_is_hashed || []).includes(Vn.UNKNOWN_INVALID) || (n.identity_params.sha256_phone || []).includes(Vn.UNKNOWN_INVALID))
                        }(e) && this.warn(Ir.INVALID_PHONE_NUMBER_FORMAT),
                        function(e) {
                            var t = e.event,
                                n = void 0 === t ? "" : t,
                                r = e.properties,
                                i = void 0 === r ? {} : r;
                            if (rs.includes(n)) {
                                if (is(i.contents) && is(i.content_id)) return !0;
                                if (!is(i.contents)) return !Array.isArray(i.contents) || i.contents.length < 1 || !i.contents.every((function(e) {
                                    return e && !is(e.content_id)
                                }))
                            }
                            return !1
                        }(e) && this.warn(Ir.MISSING_CONTENT_ID),
                        function(e) {
                            var t = e.properties,
                                n = void 0 === t ? {} : t,
                                r = n.content_id,
                                i = n.contents;
                            return !(!is(r) && /^\s*$/.test(r)) && (!(!is(i) && Array.isArray(i)) || i.every((function(e) {
                                return e && !is(e.content_id) && !/^\s*$/.test(e.content_id)
                            })))
                        }(e) || this.warn(Ir.INVALID_CONTENT_ID),
                        function(e) {
                            var t = e.properties.content_type;
                            return !t || es.includes(t)
                        }(e) || this.warn(Ir.INVALID_CONTENT_TYPE),
                        function(e) {
                            var t = e.properties.value;
                            return !t || "number" == typeof t || !("string" != typeof t || !/^\d+(\.\d+)?$/.test(t) && !/^\d+$/.test(t))
                        }(e) || this.warn(Ir.INVALID_EVENT_PARAMETER_VALUE),
                        function(e) {
                            var t = e.event,
                                n = void 0 === t ? "" : t,
                                r = e.properties,
                                i = void 0 === r ? {} : r;
                            return !(n !== os || !is(i.value)) || !(is(i.currency) || !is(i.value))
                        }(e) && this.warn(Ir.MISSING_VALUE_PARAMETER),
                        function(e) {
                            var t = e.properties.currency;
                            return !t || ns.includes(t)
                        }(e) || this.warn(Ir.INVALID_CURRENCY_CODE),
                        function(e) {
                            var t = e.event,
                                n = void 0 === t ? "" : t,
                                r = e.properties,
                                i = void 0 === r ? {} : r;
                            return !(n !== os || !is(i.currency)) || !(is(i.value) || !is(i.currency))
                        }(e) && this.warn(Ir.MISSING_CURRENCY_PARAMETER, {
                            learn_more: ""
                        })
                }
            }]), n
        }(fo);
    us = cs([A.injectable(), ss(0, A.inject(br.CONTEXT)), ss(1, A.inject(br.TTQ_REPORTERS)), ss(2, A.inject(br.TTQ_GLOBAL_OPTIONS))], us);
    var ls = function(e, n, r, i) {
            var o, a = arguments.length,
                c = a < 3 ? n : null === i ? i = Object.getOwnPropertyDescriptor(n, r) : i;
            if ("object" === ("undefined" == typeof Reflect ? "undefined" : t(Reflect)) && "function" == typeof Reflect.decorate) c = Reflect.decorate(e, n, r, i);
            else
                for (var s = e.length - 1; s >= 0; s--)(o = e[s]) && (c = (a < 3 ? o(c) : a > 3 ? o(n, r, c) : o(n, r)) || c);
            return a > 3 && c && Object.defineProperty(n, r, c), c
        },
        fs = function(e, t) {
            return function(n, r) {
                t(n, r, e)
            }
        },
        ds = function(e) {
            s(n, e);
            var t = h(n);

            function n(e, r, o, a) {
                var c;
                return i(this, n), (c = t.call(this, {
                    name: "PangleCookieMatching",
                    reporters: r,
                    context: e
                })).hasReport = !1, c.reportService = o, c.env = a, c
            }
            return a(n, [{
                key: "isPixelPangleCookieMatching",
                value: function() {
                    var e = arguments.length > 0 && void 0 !== arguments[0] ? arguments[0] : "",
                        t = this.reporters;
                    if (e) {
                        var n = t.find((function(t) {
                            return t.getReporterId() === e
                        }));
                        if (n && n.plugins.PangleCookieMatching) return !0
                    } else if (t.some((function(e) {
                            return Boolean(e.plugins.PangleCookieMatching)
                        }))) return !0;
                    return !1
                }
            }, {
                key: "disablePangleCookie",
                value: function() {
                    this.isPixelPangleCookieMatching() && Vi("https://analytics.pangle-ads.com/api/v2/pangle_disable_cookie")
                }
            }, {
                key: "pixelSend",
                value: function(e, t, n) {
                    var r;
                    try {
                        if (0 === (null === (r = this.context.getPageSign().pageIndex) || void 0 === r ? void 0 : r.index) && !_i(this.env) && n && n.message_id && this.isPixelPangleCookieMatching(e) && !this.hasReport) {
                            var i = {
                                event: n.event,
                                message_id: n.message_id,
                                context: {
                                    library: n.context.library
                                },
                                timestamp: (new Date).toJSON()
                            };
                            this.hasReport = !0, this.reportService.report("https://analytics.pangle-ads.com/api/v2/pangle_pixel", i, Bn.httpReport)
                        }
                    } catch (e) {
                        Ai(Tr.CUSTOM_ERROR, e, {
                            custom_name: "pangle_report"
                        })
                    }
                }
            }]), n
        }(fo);
    ds = ls([A.injectable(), fs(0, A.inject(br.CONTEXT)), fs(1, A.inject(br.TTQ_REPORTERS)), fs(2, A.inject(br.REPORT_SERVICE)), fs(3, A.inject(br.ENV))], ds);
    var hs, ps = "https://analytics.tiktok.com/i18n/pixel/eb.js",
        vs = "_tt_event_builder";
    ! function(e) {
        e.EVENT_BUILD_BOOTSTRAP_ACK = "event_builder_bootstrap_ack", e.EVENT_BUILD_WRONG_CODE = "event_builder_wrong_code", e.EVENT_BUILD_BOOTSTRAP = "event_builder_bootstrap"
    }(hs || (hs = {}));
    var _s = function(e, n, r, i) {
            var o, a = arguments.length,
                c = a < 3 ? n : null === i ? i = Object.getOwnPropertyDescriptor(n, r) : i;
            if ("object" === ("undefined" == typeof Reflect ? "undefined" : t(Reflect)) && "function" == typeof Reflect.decorate) c = Reflect.decorate(e, n, r, i);
            else
                for (var s = e.length - 1; s >= 0; s--)(o = e[s]) && (c = (a < 3 ? o(c) : a > 3 ? o(n, r, c) : o(n, r)) || c);
            return a > 3 && c && Object.defineProperty(n, r, c), c
        },
        gs = function(e, t) {
            return function(n, r) {
                t(n, r, e)
            }
        },
        ys = function(e) {
            s(n, e);
            var t = h(n);

            function n(e, r) {
                var o;
                return i(this, n), (o = t.call(this, {
                    name: "EventBuilder",
                    reporters: r,
                    context: e
                })).pluginMounted = !1, o
            }
            return a(n, [{
                key: "pixelDidMount",
                value: function(e) {
                    var t = this;
                    if (!this.pluginMounted) {
                        this.pluginMounted = !0;
                        var n = Vr(),
                            r = function(e) {
                                e.data.type !== hs.EVENT_BUILD_BOOTSTRAP || n._event_builder_pickup_sdk_loaded || (t.reporters.find((function(t) {
                                    return t.getReporterId() === e.data.pixelCode
                                })) ? (n._event_builder_pickup_sdk_loaded = !0, Vi(ps).then((function() {
                                    Mi(vs, {
                                        pixelCode: e.data.pixelCode,
                                        token: e.data.token,
                                        advId: e.data.advId,
                                        emUrl: e.data.emUrl,
                                        lang: e.data.lang
                                    }), window.opener.window.postMessage({
                                        type: hs.EVENT_BUILD_BOOTSTRAP_ACK
                                    }, "*")
                                })).catch((function(e) {
                                    Ai(Tr.CUSTOM_ERROR, e, {
                                        custom_name: "event_builder_load_error",
                                        custom_enum: "load_ebjs"
                                    })
                                }))) : n._event_builder_pickup_sdk_verify_flag || (setTimeout((function() {
                                    t.reporters.find((function(t) {
                                        return t.getReporterId() === e.data.pixelCode
                                    })) || window.opener.window.postMessage({
                                        type: hs.EVENT_BUILD_WRONG_CODE
                                    }, "*")
                                }), 5e3), n._event_builder_pickup_sdk_verify_flag = !0))
                            };
                        n._event_builder_pickup_sdk_loaded || (ki(vs) ? Vi(ps).then((function() {
                            n._event_builder_pickup_sdk_loaded = !0
                        })) : window.opener && (window.addEventListener("message", r), setTimeout((function() {
                            window.removeEventListener("message", r)
                        }), 8e3)))
                    }
                }
            }]), n
        }(fo);
    ys = _s([A.injectable(), gs(0, A.inject(br.CONTEXT)), gs(1, A.inject(br.TTQ_REPORTERS))], ys);
    var ms = "https://analytics-ipv6.tiktokw.us/ipv6/enrich_ipv6",
        Es = function(e, n, r, i) {
            var o, a = arguments.length,
                c = a < 3 ? n : null === i ? i = Object.getOwnPropertyDescriptor(n, r) : i;
            if ("object" === ("undefined" == typeof Reflect ? "undefined" : t(Reflect)) && "function" == typeof Reflect.decorate) c = Reflect.decorate(e, n, r, i);
            else
                for (var s = e.length - 1; s >= 0; s--)(o = e[s]) && (c = (a < 3 ? o(c) : a > 3 ? o(n, r, c) : o(n, r)) || c);
            return a > 3 && c && Object.defineProperty(n, r, c), c
        },
        bs = function(e, t) {
            return function(n, r) {
                t(n, r, e)
            }
        },
        Ts = "tt_pixel_is_enrich_ipv6_triggered_by_enrich_am",
        Is = function(e) {
            s(n, e);
            var t = h(n);

            function n(e, r, o, a) {
                var c;
                return i(this, n), (c = t.call(this, {
                    name: "EnrichIpv6",
                    reporters: r,
                    context: e
                })).hasReported = !1, c.shouldReportAfterEnrichAM = !1, c.reportService = o, c.env = a, c
            }
            return a(n, [{
                key: "isPixelEnrichIpv6",
                value: function() {
                    var e = this.reporters;
                    return !(!e || 0 === e.length) && e.every((function(e) {
                        return e && e.plugins && !0 === e.plugins.EnrichIpv6
                    }))
                }
            }, {
                key: "buildEnrichIpv6Data",
                value: function(e) {
                    return Object.assign(Object.assign({}, e), {
                        event: "EnrichIpv6",
                        trigger_event: e.event
                    })
                }
            }, {
                key: "pixelSend",
                value: function(e, t, n) {
                    var r, i = arguments.length > 4 ? arguments[4] : void 0;
                    try {
                        if (i !== yr.TRACK) return;
                        if ("Shopify" !== qr()) return;
                        if (_i(this.env) || !n || !n.message_id) return;
                        var o = this.context.getPageSign();
                        0 === (null === (r = o.pageIndex) || void 0 === r ? void 0 : r.index) && !this.hasReported && this.isPixelEnrichIpv6() && (this.hasReported = !0, this.reportService.report(ms, this.buildEnrichIpv6Data(n), Bn.htmlHttpReport));
                        var a = "true" === sessionStorage.getItem(Ts);
                        if (a) return;
                        "EnrichAM" === t && (this.shouldReportAfterEnrichAM = !0), this.shouldReportAfterEnrichAM && this.isPixelEnrichIpv6() && (this.shouldReportAfterEnrichAM = !1, sessionStorage.setItem(Ts, "true"), this.reportService.report(ms, this.buildEnrichIpv6Data(n), Bn.htmlHttpReport))
                    } catch (e) {
                        Ai(Tr.CUSTOM_ERROR, e, {
                            custom_name: "enrich_ipv6_report"
                        })
                    }
                }
            }]), n
        }(fo);

    function Os(e, t) {
        return function() {
            for (var n = arguments.length, r = new Array(n), i = 0; i < n; i++) r[i] = arguments[i];
            window.requestIdleCallback ? window.requestIdleCallback(e.bind.apply(e, [t].concat(r))) : e.apply(t, r)
        }
    }

    function Ss() {
        var e = performance.getEntriesByType("navigation");
        if (e.length > 0) {
            var t = e[0];
            return t.domContentLoadedEventEnd - t.startTime
        }
        return -1
    }

    function Ns(e) {
        var t = arguments.length > 1 && void 0 !== arguments[1] ? arguments[1] : 4;
        try {
            return Number.isInteger(e) ? e : parseFloat(e.toFixed(t))
        } catch (e) {
            return -1
        }
    }
    Is = Es([A.injectable(), bs(0, A.inject(br.CONTEXT)), bs(1, A.inject(br.TTQ_REPORTERS)), bs(2, A.inject(br.REPORT_SERVICE)), bs(3, A.inject(br.ENV))], Is);
    var Rs;
    ! function(e) {
        e.FIRST_CONTENTFUL_PAINT = "fcp", e.LARGEST_CONTENTFUL_PAINT = "lcp", e.FIRST_INPUT_DELAY = "fid", e.TIME_TO_FIRST_BYTE = "ttfb", e.PAGE_LEAVE = "pl", e.LOAD_FINISH = "lf", e.TIME_TO_INTERACTIVE = "tti", e.TIME_WINDOW_TRACKER = "twt", e.DOM_COTENT_LOADED = "load2"
    }(Rs || (Rs = {}));
    var As, Cs, Ps, ws, ks = function() {
            function e(t, n, r) {
                i(this, e), this.reportService = r, this.context = t, this.reporters = n
            }
            return a(e, [{
                key: "getResult",
                value: function(e) {
                    return {
                        action_event: e
                    }
                }
            }, {
                key: "report",
                value: function(e) {
                    var t = this;
                    if (void 0 !== e) {
                        var n = wi(yr.AUTO_CONFIG);
                        if (void 0 !== n) {
                            var r = this.getReportPixelList(),
                                i = this.assemblyReportData(yr.PAGE, e, r);
                            i && n && Ji(this.reportService.reportPreposition || []).then((function() {
                                t.reportService.report(n, i, Bn.defaultReport)
                            })), this.resetAfterReport()
                        }
                    }
                }
            }, {
                key: "getReportPixelList",
                value: function() {
                    return this.reporters
                }
            }, {
                key: "assemblyReportData",
                value: function(e, t, n) {
                    var r;
                    if (0 !== n.length) {
                        var i = n.map((function(e) {
                                return e.getReporterId()
                            })),
                            o = this.context.getPageSign(),
                            a = this.reporters[0].assemblyData(i[0], "", {}, {}, yr.AUTO_CONFIG);
                        return delete a.event, a.action = e, a.auto_collected_properties = t, a.context.pixel || (a.context.pixel = {}), a.context.pixel.code = i[0], a.context.pixel.codes = i.join("|"), a.context.index = null === (r = o.pageIndex) || void 0 === r ? void 0 : r.index, a.context.session_id = o.sessionId, a.context.pageview_id = o.pageId, a.message_id = a.message_id.replace(/-[^-]*$/, ""), a
                    }
                }
            }]), e
        }(),
        Ms = function(e) {
            s(n, e);
            var t = h(n);

            function n(e, r, o) {
                var a;
                return i(this, n), (a = t.call(this, e, r, o)).clickTimes = 0, a.scrollTimes = 0, a.init(), a
            }
            return a(n, [{
                key: "init",
                value: function() {
                    var e = this;
                    ! function(e) {
                        var t = ir((function(t) {
                            e()
                        }), 100);
                        window.addEventListener("click", t, {
                            capture: !0
                        })
                    }(Os(this.updateClickTimes, this)),
                    function(e) {
                        var t = ir((function() {
                            e()
                        }), 500);
                        window.addEventListener("scroll", t, {
                            passive: !0
                        })
                    }(Os(this.updateScrollTimes, this)), setInterval((function() {
                        e.reportInteraction()
                    }), 1e4)
                }
            }, {
                key: "reportInteraction",
                value: function() {
                    this.isUpdated() && (this.report(this.getResult(Rs.TIME_WINDOW_TRACKER)), this.resetAfterReport())
                }
            }, {
                key: "getResult",
                value: function(e) {
                    return {
                        action_event: e,
                        inter: {
                            ct: this.clickTimes,
                            st: this.scrollTimes
                        }
                    }
                }
            }, {
                key: "updateClickTimes",
                value: function() {
                    this.clickTimes += 1
                }
            }, {
                key: "updateScrollTimes",
                value: function() {
                    this.scrollTimes += 1
                }
            }, {
                key: "isUpdated",
                value: function() {
                    return 0 != this.clickTimes || 0 != this.scrollTimes
                }
            }, {
                key: "resetAfterReport",
                value: function() {
                    this.clickTimes = 0, this.scrollTimes = 0
                }
            }]), n
        }(ks),
        Ls = -1,
        Ds = function(e) {
            addEventListener("pageshow", (function(t) {
                t.persisted && (Ls = t.timeStamp, e(t))
            }), !0)
        },
        xs = function() {
            return window.performance && performance.getEntriesByType && performance.getEntriesByType("navigation")[0]
        },
        js = function() {
            var e = xs();
            return e && e.activationStart || 0
        },
        Us = function(e, t) {
            var n = xs(),
                r = "navigate";
            return Ls >= 0 ? r = "back-forward-cache" : n && (document.prerendering || js() > 0 ? r = "prerender" : document.wasDiscarded ? r = "restore" : n.type && (r = n.type.replace(/_/g, "-"))), {
                name: e,
                value: void 0 === t ? -1 : t,
                rating: "good",
                delta: 0,
                entries: [],
                id: "v3-".concat(Date.now(), "-").concat(Math.floor(8999999999999 * Math.random()) + 1e12),
                navigationType: r
            }
        },
        Fs = function(e, t, n) {
            try {
                if (PerformanceObserver.supportedEntryTypes.includes(e)) {
                    var r = new PerformanceObserver((function(e) {
                        Promise.resolve().then((function() {
                            t(e.getEntries())
                        }))
                    }));
                    return r.observe(Object.assign({
                        type: e,
                        buffered: !0
                    }, n || {})), r
                }
            } catch (e) {}
        },
        Bs = function(e, t, n, r) {
            var i, o;
            return function(a) {
                t.value >= 0 && (a || r) && ((o = t.value - (i || 0)) || void 0 === i) && (i = t.value, t.delta = o, t.rating = function(e, t) {
                    return e > t[1] ? "poor" : e > t[0] ? "needs-improvement" : "good"
                }(t.value, n), e(t))
            }
        },
        Gs = function(e) {
            requestAnimationFrame((function() {
                return requestAnimationFrame((function() {
                    return e()
                }))
            }))
        },
        Hs = function(e) {
            var t = function(t) {
                "pagehide" !== t.type && "hidden" !== document.visibilityState || e(t)
            };
            addEventListener("visibilitychange", t, !0), addEventListener("pagehide", t, !0)
        },
        Vs = function(e) {
            var t = !1;
            return function(n) {
                t || (e(n), t = !0)
            }
        },
        Js = -1,
        Ks = function() {
            return "hidden" !== document.visibilityState || document.prerendering ? 1 / 0 : 0
        },
        Ws = function(e) {
            "hidden" === document.visibilityState && Js > -1 && (Js = "visibilitychange" === e.type ? e.timeStamp : 0, qs())
        },
        Ys = function() {
            addEventListener("visibilitychange", Ws, !0), addEventListener("prerenderingchange", Ws, !0)
        },
        qs = function() {
            removeEventListener("visibilitychange", Ws, !0), removeEventListener("prerenderingchange", Ws, !0)
        },
        Xs = function() {
            return Js < 0 && (Js = Ks(), Ys(), Ds((function() {
                setTimeout((function() {
                    Js = Ks(), Ys()
                }), 0)
            }))), {
                get firstHiddenTime() {
                    return Js
                }
            }
        },
        zs = function(e) {
            document.prerendering ? addEventListener("prerenderingchange", (function() {
                return e()
            }), !0) : e()
        },
        Qs = [1800, 3e3],
        Zs = function(e, t) {
            t = t || {}, zs((function() {
                var n, r = Xs(),
                    i = Us("FCP"),
                    o = Fs("paint", (function(e) {
                        e.forEach((function(e) {
                            "first-contentful-paint" === e.name && (o.disconnect(), e.startTime < r.firstHiddenTime && (i.value = Math.max(e.startTime - js(), 0), i.entries.push(e), n(!0)))
                        }))
                    }));
                o && (n = Bs(e, i, Qs, t.reportAllChanges), Ds((function(r) {
                    i = Us("FCP"), n = Bs(e, i, Qs, t.reportAllChanges), Gs((function() {
                        i.value = performance.now() - r.timeStamp, n(!0)
                    }))
                })))
            }))
        },
        $s = [.1, .25],
        eu = {
            passive: !0,
            capture: !0
        },
        tu = new Date,
        nu = function(e, t) {
            As || (As = t, Cs = e, Ps = new Date, ou(removeEventListener), ru())
        },
        ru = function() {
            if (Cs >= 0 && Cs < Ps - tu) {
                var e = {
                    entryType: "first-input",
                    name: As.type,
                    target: As.target,
                    cancelable: As.cancelable,
                    startTime: As.timeStamp,
                    processingStart: As.timeStamp + Cs
                };
                ws.forEach((function(t) {
                    t(e)
                })), ws = []
            }
        },
        iu = function(e) {
            if (e.cancelable) {
                var t = (e.timeStamp > 1e12 ? new Date : performance.now()) - e.timeStamp;
                "pointerdown" == e.type ? function(e, t) {
                    var n = function() {
                            nu(e, t), i()
                        },
                        r = function() {
                            i()
                        },
                        i = function() {
                            removeEventListener("pointerup", n, eu), removeEventListener("pointercancel", r, eu)
                        };
                    addEventListener("pointerup", n, eu), addEventListener("pointercancel", r, eu)
                }(t, e) : nu(t, e)
            }
        },
        ou = function(e) {
            ["mousedown", "keydown", "touchstart", "pointerdown"].forEach((function(t) {
                return e(t, iu, eu)
            }))
        },
        au = [100, 300],
        cu = [2500, 4e3],
        su = {},
        uu = [800, 1800],
        lu = function e(t) {
            document.prerendering ? zs((function() {
                return e(t)
            })) : "complete" !== document.readyState ? addEventListener("load", (function() {
                return e(t)
            }), !0) : setTimeout(t, 0)
        },
        fu = function(e, t) {
            t = t || {};
            var n = Us("TTFB"),
                r = Bs(e, n, uu, t.reportAllChanges);
            lu((function() {
                var i = xs();
                if (i) {
                    var o = i.responseStart;
                    if (o <= 0 || o > performance.now()) return;
                    n.value = Math.max(o - js(), 0), n.entries = [i], r(!0), Ds((function() {
                        n = Us("TTFB", 0), (r = Bs(e, n, uu, t.reportAllChanges))(!0)
                    }))
                }
            }))
        },
        du = function(e, n, r, i) {
            var o, a = arguments.length,
                c = a < 3 ? n : null === i ? i = Object.getOwnPropertyDescriptor(n, r) : i;
            if ("object" === ("undefined" == typeof Reflect ? "undefined" : t(Reflect)) && "function" == typeof Reflect.decorate) c = Reflect.decorate(e, n, r, i);
            else
                for (var s = e.length - 1; s >= 0; s--)(o = e[s]) && (c = (a < 3 ? o(c) : a > 3 ? o(n, r, c) : o(n, r)) || c);
            return a > 3 && c && Object.defineProperty(n, r, c), c
        },
        hu = function(e, t) {
            return function(n, r) {
                t(n, r, e)
            }
        },
        pu = function(e) {
            s(n, e);
            var t = h(n);

            function n(e, r, o) {
                var a;
                return i(this, n), (a = t.call(this, e, r, o)).cls = -1, a.init(), a
            }
            return a(n, [{
                key: "init",
                value: function() {
                    ! function(e, t) {
                        t = t || {}, Zs(Vs((function() {
                            var n, r = Us("CLS", 0),
                                i = 0,
                                o = [],
                                a = function(e) {
                                    e.forEach((function(e) {
                                        if (!e.hadRecentInput) {
                                            var t = o[0],
                                                n = o[o.length - 1];
                                            i && e.startTime - n.startTime < 1e3 && e.startTime - t.startTime < 5e3 ? (i += e.value, o.push(e)) : (i = e.value, o = [e])
                                        }
                                    })), i > r.value && (r.value = i, r.entries = o, n())
                                },
                                c = Fs("layout-shift", a);
                            c && (n = Bs(e, r, $s, t.reportAllChanges), Hs((function() {
                                a(c.takeRecords()), n(!0)
                            })), Ds((function() {
                                i = 0, r = Us("CLS", 0), n = Bs(e, r, $s, t.reportAllChanges), Gs((function() {
                                    return n()
                                }))
                            })), setTimeout(n, 0))
                        })))
                    }(this.clsHandler.bind(this), {
                        reportAllChanges: !0
                    }), Zs(this.webVitalHandler.bind(this), {
                            reportAllChanges: !0
                        }),
                        function(e, t) {
                            t = t || {}, zs((function() {
                                var n, r = Xs(),
                                    i = Us("LCP"),
                                    o = function(e) {
                                        var t = e[e.length - 1];
                                        t && t.startTime < r.firstHiddenTime && (i.value = Math.max(t.startTime - js(), 0), i.entries = [t], n())
                                    },
                                    a = Fs("largest-contentful-paint", o);
                                if (a) {
                                    n = Bs(e, i, cu, t.reportAllChanges);
                                    var c = Vs((function() {
                                        su[i.id] || (o(a.takeRecords()), a.disconnect(), su[i.id] = !0, n(!0))
                                    }));
                                    ["keydown", "click"].forEach((function(e) {
                                        addEventListener(e, (function() {
                                            return setTimeout(c, 0)
                                        }), !0)
                                    })), Hs(c), Ds((function(r) {
                                        i = Us("LCP"), n = Bs(e, i, cu, t.reportAllChanges), Gs((function() {
                                            i.value = performance.now() - r.timeStamp, su[i.id] = !0, n(!0)
                                        }))
                                    }))
                                }
                            }))
                        }(this.webVitalHandler.bind(this), {
                            reportAllChanges: !0
                        }),
                        function(e, t) {
                            t = t || {}, zs((function() {
                                var n, r = Xs(),
                                    i = Us("FID"),
                                    o = function(e) {
                                        e.startTime < r.firstHiddenTime && (i.value = e.processingStart - e.startTime, i.entries.push(e), n(!0))
                                    },
                                    a = function(e) {
                                        e.forEach(o)
                                    },
                                    c = Fs("first-input", a);
                                n = Bs(e, i, au, t.reportAllChanges), c && Hs(Vs((function() {
                                    a(c.takeRecords()), c.disconnect()
                                }))), c && Ds((function() {
                                    var r;
                                    i = Us("FID"), n = Bs(e, i, au, t.reportAllChanges), ws = [], Cs = -1, As = null, ou(addEventListener), r = o, ws.push(r), ru()
                                }))
                            }))
                        }(this.webVitalHandler.bind(this), {
                            reportAllChanges: !0
                        }), fu(this.webVitalHandler.bind(this), {
                            reportAllChanges: !0
                        }),
                        function(e) {
                            try {
                                Ba.getFirstConsistentlyInteractive({}).then((function(t) {
                                    e(Rs.TIME_TO_INTERACTIVE, t)
                                }))
                            } catch (e) {}
                        }(this.baseHandler.bind(this)),
                        function(e) {
                            if ("complete" === window.document.readyState) {
                                var t = Ss();
                                e(Rs.LOAD_FINISH, t)
                            } else window.addEventListener("load", (function() {
                                var t = Ss();
                                e(Rs.LOAD_FINISH, t)
                            }))
                        }(this.baseHandler.bind(this))
                }
            }, {
                key: "getResult",
                value: function(e) {
                    var t;
                    return {
                        action_event: e,
                        perf: {
                            ttns: Math.floor(performance && performance.timing ? t ? Date.now() - t : Date.now() - performance.timing.navigationStart : -1),
                            cls: Ns(this.cls),
                            idx: this.getSessionIndex(),
                            pep: Ns(this.getPep())
                        }
                    }
                }
            }, {
                key: "resetAfterReport",
                value: function() {}
            }, {
                key: "clsHandler",
                value: function(e) {
                    this.cls = e.value || -1
                }
            }, {
                key: "webVitalHandler",
                value: function(e) {
                    var t = this.getResult(e.name.toLocaleLowerCase());
                    t.perf && (t.perf.ttns = (null == e ? void 0 : e.value) ? Math.floor(e.value) : -1), this.report(t), this.resetAfterReport()
                }
            }, {
                key: "baseHandler",
                value: function(e, t) {
                    var n = this.getResult(e);
                    n.perf && (n.perf.ttns = t ? Math.floor(t) : -1), this.report(n), this.resetAfterReport()
                }
            }, {
                key: "getSessionIndex",
                value: function() {
                    var e, t = null === (e = this.context.getPageSign().pageIndex) || void 0 === e ? void 0 : e.index;
                    return null == t ? -1 : t
                }
            }, {
                key: "getCurrScrollPosition",
                value: function() {
                    return document.documentElement.scrollTop || document.body.scrollTop
                }
            }, {
                key: "getViewportHeight",
                value: function() {
                    return window.innerHeight || document.documentElement.clientHeight
                }
            }, {
                key: "getMaxHeight",
                value: function() {
                    var e = document.body,
                        t = document.documentElement;
                    return Math.max(e.scrollHeight, e.offsetHeight, t.clientHeight, t.scrollHeight, t.offsetHeight)
                }
            }, {
                key: "getPep",
                value: function() {
                    return (this.getCurrScrollPosition() + this.getViewportHeight()) / this.getMaxHeight()
                }
            }]), n
        }(ks);
    pu = du([hu(0, A.inject(br.CONTEXT)), hu(1, A.inject(br.TTQ_REPORTERS)), hu(2, A.inject(br.REPORT_SERVICE))], pu);
    var vu = function(e, n, r, i) {
            var o, a = arguments.length,
                c = a < 3 ? n : null === i ? i = Object.getOwnPropertyDescriptor(n, r) : i;
            if ("object" === ("undefined" == typeof Reflect ? "undefined" : t(Reflect)) && "function" == typeof Reflect.decorate) c = Reflect.decorate(e, n, r, i);
            else
                for (var s = e.length - 1; s >= 0; s--)(o = e[s]) && (c = (a < 3 ? o(c) : a > 3 ? o(n, r, c) : o(n, r)) || c);
            return a > 3 && c && Object.defineProperty(n, r, c), c
        },
        _u = function(e, t) {
            return function(n, r) {
                t(n, r, e)
            }
        },
        gu = function(e) {
            s(n, e);
            var t = h(n);

            function n(e, r, o, a) {
                var c;
                return i(this, n), (c = t.call(this, {
                    name: "PageData",
                    reporters: r,
                    context: e
                })).monitors = [], c.ttqOptions = {}, c.reportService = o, c.context = e, c.reporters = r, c.ttqOptions = a, c.init(), c
            }
            return a(n, [{
                key: "init",
                value: function() {
                    this.isPageDataEnabled() && (this.interactionMonitor = new Ms(this.context, this.reporters, this.reportService), this.performanceMonitor = new pu(this.context, this.reporters, this.reportService), this.monitors.push(this.performanceMonitor), this.monitors.push(this.interactionMonitor))
                }
            }, {
                key: "isPageDataEnabled",
                value: function() {
                    var e, t;
                    return null === (t = null === (e = this.ttqOptions) || void 0 === e ? void 0 : e.plugins) || void 0 === t ? void 0 : t.PageData
                }
            }, {
                key: "report",
                value: function(e) {
                    var t = this.performanceMonitor,
                        n = this.performanceMonitor.getResult(e),
                        r = this.interactionMonitor.getResult(e),
                        i = this.mergeReportData(e, r, n);
                    t.report(i), this.interactionMonitor.resetAfterReport(), this.performanceMonitor.resetAfterReport()
                }
            }, {
                key: "mergeReportData",
                value: function(e, t, n) {
                    var r = {
                        action_event: e
                    };
                    return r.perf = n.perf, r.inter = t.inter, r
                }
            }, {
                key: "pageWillLeave",
                value: function(e) {
                    this.report(Rs.PAGE_LEAVE)
                }
            }]), n
        }(fo);
    gu = vu([A.injectable(), _u(0, A.inject(br.CONTEXT)), _u(1, A.inject(br.TTQ_REPORTERS)), _u(2, A.inject(br.REPORT_SERVICE)), _u(3, A.inject(br.TTQ_GLOBAL_OPTIONS))], gu);
    var yu = [{
            identifier: br.CALLBACK_PLUGIN,
            to: ha,
            name: "Callback"
        }, {
            identifier: br.IDENTIFY_PLUGIN,
            to: Ta,
            name: "Identify",
            required: !0
        }, {
            identifier: br.WEB_FL_PLUGIN,
            to: Ya,
            name: "WebFL"
        }, {
            identifier: br.PERFORMANCE_INTERACTION_PLUGIN,
            to: Ra,
            required: !0,
            name: "PerformanceInteraction"
        }, {
            identifier: br.INTERACTION_MONITOR,
            to: wa,
            name: "WebInteractionMonitor",
            required: !0
        }, {
            identifier: br.PERFORMANCE_MONITOR,
            to: Va,
            name: "WebPerformanceMonitor",
            required: !0
        }, {
            identifier: br.AUTO_CONFIG_PLUGIN,
            to: Xc,
            name: "AutoConfig"
        }, {
            identifier: br.DIAGNOSTICS_CONSOLE_PLUGIN,
            to: us,
            name: "DiagnosticsConsole"
        }, {
            identifier: br.PANGLE_COOKIE_MATCHING_PLUGIN,
            to: ds,
            name: "PangleCookieMatching"
        }, {
            identifier: br.EVENT_BUILDER_PLUGIN,
            to: ys,
            name: "EventBuilder"
        }, {
            identifier: br.ENRICH_IPV6_PLUGIN,
            to: Is,
            name: "EnrichIpv6"
        }, {
            identifier: br.PAGEDATA_PLUGIN,
            to: gu,
            name: "PageData"
        }],
        mu = function(e, t) {
            return mu = Object.setPrototypeOf || {
                __proto__: []
            }
            instanceof Array && function(e, t) {
                e.__proto__ = t
            } || function(e, t) {
                for (var n in t) t.hasOwnProperty(n) && (e[n] = t[n])
            }, mu(e, t)
        };

    function Eu(e, t) {
        function n() {
            this.constructor = e
        }
        mu(e, t), e.prototype = null === t ? Object._ttq_create(t) : (n.prototype = t.prototype, new n)
    }
    var bu, Tu = function() {
        return Tu = Object.assign || function(e) {
            for (var t, n = 1, r = arguments.length; n < r; n++)
                for (var i in t = arguments[n]) Object.prototype.hasOwnProperty.call(t, i) && (e[i] = t[i]);
            return e
        }, Tu.apply(this, arguments)
    };
    ! function(e) {
        e[e.Failure = 0] = "Failure", e[e.Success = 1] = "Success", e[e.Unauthorized = -1] = "Unauthorized", e[e.NotExist = -2] = "NotExist"
    }(bu || (bu = {}));
    var Iu = function() {
            function e(e) {
                this.version = e.version || "2.0.2", this.nativeMethodInvoker = e.nativeMethodInvoker, this.nativeEventListener = e.nativeEventListener, this.scheme = e.scheme || "nativeapp://", this.dispatchMessagePath = e.dispatchMessagePath || "dispatch_message/", this.setResultPath = e.setResultPath || "private/setresult/SCENE_FETCHQUEUE", this.dispatchMessageIFrameId = e.dispatchMessageIFrameId || "__JSBridgeIframe__", this.setResultIFrameId = e.setResultIFrameId || "__JSBridgeIframe_SetResult__", this.listenNativeEvent = !0 === e.listenNativeEvent, this.callbackId = 1023, this.callbackMap = {}, this.eventMap = {}, this.javascriptMessageQueue = [], this.callbackProcessor = e.callbackProcessor
            }
            return e.prototype.call = function(e, t, n, r) {
                void 0 === r && (r = this.version);
                var i, o = this.version;
                if (e && "string" == typeof e) {
                    "object" != typeof t && (t = {}), "string" == typeof r ? o = r || this.version : "object" == typeof r && (i = r.namespace, o = r.sdkVersion || this.version);
                    var a = {
                        func: e,
                        params: t,
                        JSSDK: o,
                        __msg_type: "call",
                        namespace: i
                    };
                    if ("function" == typeof n || void 0 === n) {
                        var c = this.registerCallback(e, n);
                        a.__callback_id = c
                    }
                    "undefined" == typeof __PIA_WORKER__ && window.parent !== window && (a.__iframe_url = window.location.href), this.sendMessageToNative(a)
                }
            }, e.prototype.on = function(e, t, n) {
                if (void 0 === n && (n = !1), e && "string" == typeof e && "function" == typeof t) {
                    var r = this.registerCallback(e, t);
                    return this.eventMap[e] = this.eventMap[e] || {}, this.eventMap[e][r] = {
                        once: n
                    }, this.listenNativeEvent && (this.nativeEventListener ? this.nativeEventListener(e) : this.call("addEventListener", {
                        name: e
                    }, null, {
                        sdkVersion: 1
                    })), r
                }
            }, e.prototype.once = function(e, t) {
                return this.on(e, t, !0)
            }, e.prototype.off = function(e, t) {
                if (!e || "string" != typeof e) return !0;
                var n = this.eventMap[e];
                return !n || "object" != typeof n || !n.hasOwnProperty(t) || (this.deregisterCallback(t), delete n[t], !0)
            }, e.prototype.trigger = function(e, t) {
                return this.handleMessageFromNative({
                    __msg_type: "event",
                    __params: t,
                    __event_id: e
                })
            }, e.prototype.handleMessageFromNative = function(e) {
                var t = this,
                    n = e,
                    r = String(n.__callback_id);
                if (this.callbackProcessor && "function" == typeof this.callbackProcessor) {
                    var i = (this.callbackMap && this.callbackMap[r] || {}).method;
                    this.callbackProcessor(n, i)
                }
                var o = n.__params,
                    a = String(n.__event_id || ""),
                    c = n.__msg_type;
                this.callbackMap[r] ? c = "callback" : this.eventMap[r] && (c = "event", a = a || r);
                var s = {
                    __err_code: "cb404"
                };
                switch (c) {
                    case "callback":
                        var u = (this.callbackMap && this.callbackMap[r] || {}).callback;
                        "function" == typeof u && (s = u(o)), this.deregisterCallback(r);
                        break;
                    case "event":
                        var l = this.eventMap[a];
                        l && "object" == typeof l && Object.keys(l).forEach((function(e) {
                            var n = (t.callbackMap && t.callbackMap[e] || {}).callback,
                                r = l[e];
                            "function" == typeof n && (s = n(o)), r && r.once && (t.deregisterCallback(e), delete l[e])
                        }))
                }
                return s
            }, e.prototype.fetchJavaScriptMessageQueue = function() {
                var e = JSON.stringify(this.javascriptMessageQueue),
                    t = btoa(unescape(encodeURIComponent(e)));
                return this.setResultIFrame && this.javascriptMessageQueue.length > 0 && (this.setResultIFrame.src = "" + this.scheme + this.setResultPath + "&" + t), this.javascriptMessageQueue.splice(0, this.javascriptMessageQueue.length), e
            }, e.prototype.sendMessageToNative = function(e) {
                if ("1" !== String(e.JSSDK) && this.nativeMethodInvoker) {
                    var t = this.nativeMethodInvoker(e);
                    if (t) {
                        var n = JSON.parse(t);
                        this.handleMessageFromNative(n)
                    }
                } else this.javascriptMessageQueue.push(e), this.dispatchMessageIFrame || this.tryCreateIFrames(), this.dispatchMessageIFrame.src = "" + this.scheme + this.dispatchMessagePath
            }, e.prototype.registerCallback = function(e, t) {
                var n = String(this.callbackId++);
                return this.callbackMap[n] = {
                    method: e,
                    callback: t
                }, n
            }, e.prototype.deregisterCallback = function(e) {
                delete this.callbackMap[e]
            }, e.prototype.tryCreateIFrames = function() {
                this.dispatchMessageIFrame = this.createIFrame(this.dispatchMessageIFrameId), this.setResultIFrame = this.createIFrame(this.setResultIFrameId)
            }, e.prototype.createIFrame = function(e) {
                var t = document.getElementById(e);
                return t && "IFRAME" === t.tagName || ((t = document.createElement("iframe")).style.display = "none", t.id = e, document.documentElement.appendChild(t)), t
            }, e
        }(),
        Ou = "2.2.15",
        Su = "undefined" != typeof __PIA_WORKER__ ? new Function("return this")() : "undefined" != typeof window ? window : {},
        Nu = void 0 !== Su && Su.navigator ? Su.navigator.userAgent : "",
        Ru = (!!Nu.match(/(newsarticle|videoarticle|lv|faceu|ulike|beauty_me_|faceu-os|ulike-os|beauty_me_oversea_|retouch)\/([\d.]+)/i) || /super|automobile/gi.test(Nu)) && !/webcast/gi.test(Nu) && !/luckycatversion/gi.test(Nu),
        Au = !!Nu.match(/(faceu)\/([\d.]+)/i) || /gsdk/gi.test(Nu) || /PIANativeWorker/gi.test(Nu),
        Cu = !!Nu.match(/ttad\/0/i),
        Pu = !!Nu.match(/aweme|trill|musical_ly|phoenix_\d+|TikTokNow_\d+/i),
        wu = !!Nu.match(/live_stream/i),
        ku = !!Nu.match(/Webcast/i),
        Mu = !!Nu.match(/super/i),
        Lu = !!Nu.match(/life_service_merchant/i),
        Du = /super/gi.test(Nu);

    function xu() {
        var e;
        if (Ru) return Su.JSBridge && Su.JSBridge.on ? e = Su.JSBridge.on : Su.JS2NativeBridge && Su.JS2NativeBridge.on ? e = function(e) {
            var t = {
                JSSDK: Ou,
                __msg_type: "event",
                __callback_id: e,
                func: e
            };
            Su.JS2NativeBridge.on(e, JSON.stringify(t))
        } : Su.webkit && Su.webkit.messageHandlers && Su.webkit.messageHandlers.onMethodParams ? e = function(e) {
            var t = {
                JSSDK: Ou,
                __msg_type: "event",
                __callback_id: e,
                func: e
            };
            Su.webkit.messageHandlers.onMethodParams.postMessage(t)
        } : Su.onMethodParams && (e = function(e) {
            var t = {
                JSSDK: Ou,
                __msg_type: "event",
                __callback_id: e,
                func: e
            };
            return Su.onMethodParams(e, t)
        }), e
    }

    function ju(e, t) {
        if (("string" != typeof t || !0 !== /^(x|tc)\./.test(t)) && (Pu || wu || ku || Lu)) {
            var n = e.__params;
            Su.JS2NativeBridge && Su.JS2NativeBridge._invokeMethod && (e.__params = Tu({
                code: n.code
            }, n.data))
        }
    }
    var Uu = function(e) {
            function t() {
                var t = e.call(this, {
                    version: Ou,
                    scheme: "bytedance://",
                    listenNativeEvent: !0,
                    dispatchMessageIFrameId: "__JSBridgeIframe_1.0__",
                    setResultIFrameId: "__JSBridgeIframe_SetResult_1.0__",
                    nativeEventListener: xu(),
                    callbackProcessor: ju
                }) || this;
                return t.publicApi = {
                    call: t.call.bind(t),
                    on: t.on.bind(t),
                    once: t.once.bind(t),
                    off: t.off.bind(t),
                    trigger: t.trigger.bind(t),
                    _fetchQueue: t.fetchJavaScriptMessageQueue.bind(t),
                    _handleMessageFromToutiao: t.handleMessageFromNative.bind(t)
                }, t
            }
            return Eu(t, e), t.prototype.exposePublicApiToGlobal = function() {
                Su.ToutiaoJSBridge = Object.assign(Su.ToutiaoJSBridge || {}, this.publicApi)
            }, t
        }(Iu),
        Fu = function(e) {
            function t(t) {
                var n, r = e.call(this, {
                    version: Ou,
                    nativeMethodInvoker: (Su.JS2NativeBridge && Su.JS2NativeBridge._invokeMethod ? n = function(e) {
                        return Su.JS2NativeBridge._invokeMethod(JSON.stringify(e))
                    } : Su.ToutiaoJSBridge && Su.ToutiaoJSBridge.invokeMethod ? n = function(e) {
                        return Su.ToutiaoJSBridge.invokeMethod(JSON.stringify(e))
                    } : Su.JS2NativeBridge && Su.JS2NativeBridge.call ? n = function(e) {
                        return Su.JS2NativeBridge.call(e.func, JSON.stringify(e))
                    } : Su.webkit && Su.webkit.messageHandlers && Su.webkit.messageHandlers.callMethodParams ? n = function(e) {
                        Su.webkit.messageHandlers.callMethodParams.postMessage(e)
                    } : Su.callMethodParams && (n = function(e) {
                        return Su.callMethodParams(e.func, e)
                    }), n),
                    nativeEventListener: xu(),
                    scheme: Mu ? "bds://" : Du ? "bytedance://" : Ru || Su.JSBridge && Su.JSBridge._invokeMethod ? "nativeapp://" : "bytedance://",
                    listenNativeEvent: Ru,
                    callbackProcessor: ju
                }) || this;
                return r.toutiaoLegacyJSB = t, r.publicApi = {
                    call: r.call.bind(r),
                    on: r.on.bind(r),
                    once: r.once.bind(r),
                    off: r.off.bind(r),
                    trigger: r.trigger.bind(r),
                    _fetchQueue: r.fetchJavaScriptMessageQueue.bind(r),
                    _handleMessageFromApp: r.handleMessageFromNative.bind(r),
                    _handleMessageFromToutiao: r.handleMessageFromNative.bind(r)
                }, r
            }
            return Eu(t, e), t.prototype.call = function(t, n, r, i) {
                void 0 === i && (i = Ou), this.isLegacyCall(t) ? this.toutiaoLegacyJSB.call(t, n, r, i) : e.prototype.call.call(this, t, n, r, i)
            }, t.prototype.on = function(t, n, r, i) {
                return void 0 === r && (r = !1), (i || {}).useLegacy || this.isLegacyCall(t) ? this.toutiaoLegacyJSB.on(t, n, r) : e.prototype.on.call(this, t, n, r)
            }, t.prototype.once = function(t, n) {
                return this.isLegacyCall(t) ? this.toutiaoLegacyJSB.once(t, n) : e.prototype.once.call(this, t, n)
            }, t.prototype.off = function(t, n) {
                return this.isLegacyCall(t) ? this.toutiaoLegacyJSB.off(t, n) : e.prototype.off.call(this, t, n)
            }, t.prototype.trigger = function(t, n) {
                return this.isLegacyCall(t) ? this.toutiaoLegacyJSB.trigger(t, n) : e.prototype.trigger.call(this, t, n)
            }, t.prototype.exposePublicApiToGlobal = function() {
                var e = this;
                Su.JSBridge = Object.assign(Su.JSBridge || {}, this.publicApi), Su.__DISABLE_JSB_PROTOCAL2__ || (Su.Native2JSBridge = Object.assign(Su.Native2JSBridge || {}, this.publicApi)), Du ? Su.ToutiaoJSBridge = Object.assign(Su.ToutiaoJSBridge || {}, this.publicApi) : (Ru || Cu) && this.toutiaoLegacyJSB ? this.toutiaoLegacyJSB.exposePublicApiToGlobal() : Su.ToutiaoJSBridge = Object.assign(Su.ToutiaoJSBridge || {}, this.publicApi), Su.parent !== Su && Su.addEventListener && Su.addEventListener("message", (function(t) {
                    t && t.data && t.data.__callback_id && e.handleMessageFromNative(t.data)
                }), !1), Object.defineProperties(Su, {
                    JSBridge: {
                        writable: !1
                    },
                    Native2JSBridge: {
                        writable: !1
                    },
                    ToutiaoJSBridge: {
                        writable: !1
                    }
                }), Object.freeze(Su.JSBridge), Object.freeze(Su.Native2JSBridge), Object.freeze(Su.ToutiaoJSBridge)
            }, t.prototype.isLegacyCall = function(e) {
                return !(!e || "string" != typeof e || !this.toutiaoLegacyJSB) && (!!Cu || !Au && !Du && (Ru && e.indexOf(".") < 0))
            }, t
        }(Iu);

    function Bu(e, t) {
        if (null == e) throw new TypeError("Cannot convert first argument to object");
        for (var n = Object(e), r = 1; r < arguments.length; r++) {
            var i = arguments[r];
            if (null != i)
                for (var o = Object.keys(Object(i)), a = 0, c = o.length; a < c; a++) {
                    var s = o[a],
                        u = Object.getOwnPropertyDescriptor(i, s);
                    void 0 !== u && u.enumerable && (n[s] = i[s])
                }
        }
        return n
    }({
        assign: Bu,
        polyfill: function() {
            Object.assign || Object.defineProperty(Object, "assign", {
                enumerable: !1,
                configurable: !0,
                writable: !0,
                value: Bu
            })
        }
    }).polyfill();
    var Gu = new Fu(new Uu);
    try {
        Gu.exposePublicApiToGlobal()
    } catch (QR) {}
    var Hu = Gu.publicApi;
    globalThis.window && (window.CustomEvent || function() {
        var e = function(e, t) {
            var n;
            return t = t || {
                bubbles: !1,
                cancelable: !1,
                detail: void 0
            }, (n = document.createEvent("CustomEvent")).initCustomEvent(e, t.bubbles, t.cancelable, t.detail), n
        };
        e.prototype = window.Event.prototype, window.CustomEvent = e
    }());
    var Vu = function(e) {
            var n, r, i;
            return r = function(e) {
                var t = document.createElement("iframe");
                t.style.display = "none", t.src = e, document.body.appendChild(t), setTimeout((function() {
                    document.body.removeChild(t)
                }), 100)
            }, n = window.webkit && window.webkit.messageHandlers && window.webkit.messageHandlers.pacific ? function(e, t) {
                i = {
                    action: e,
                    parameters: (t = t || {}).params,
                    print: !!t.print
                }, "string" == typeof t.callback ? i.callback = {
                    type: 0,
                    name: t.callback,
                    parameters: ["key"]
                } : i.callback = t.callback, window.webkit.messageHandlers.pacific.postMessage(i)
            } : function(n, i) {
                var o, a, c, s = [];
                if (o = ((i = i || {}).protocol || "sslocal") + "://" + n, i.callback && (i.params = i.params || {}, i.params.callback = i.callback), i.params) {
                    for (a in c = i.params)
                        if (c.hasOwnProperty(a)) {
                            var u = c[a];
                            "object" == t(u) && (u = JSON.stringify(u)), s.push(encodeURIComponent(a) + "=" + encodeURIComponent(u))
                        }
                    s.push("r=" + (Math.random() + "").slice(2)), o += "?" + s.join("&")
                }
                e ? (i.debugCall && i.debugCall(n, i.params), (console.dir || console.log)(o)) : r(o)
            }, {
                call: function(t, r, i) {
                    var o = r = r || {};
                    if (i && "function" == typeof i) {
                        var a = t + "DidFinish" + (e ? "" : "_" + Math.random().toString(36).slice(2));
                        document.addEventListener(a, (function e(t) {
                            "success" === t.detail.message && i(t.detail.data), document.removeEventListener(a, e)
                        }))
                    }
                    n(t, {
                        callback: a,
                        params: o
                    })
                }
            }
        }(!!window.globalConfig && window.globalConfig.isDebug),
        Ju = Vu,
        Ku = Vr(),
        Wu = (null == Ku ? void 0 : Ku._container) || new A.Container,
        Yu = (null == Ku ? void 0 : Ku._container) ? yo.REBIND : yo.BIND;
    pi();
    var qu = Wu[Yu](br.ENV),
        Xu = Wu[Yu](mo.SignalType),
        zu = Wu[Yu](mo.ID),
        Qu = Wu[Yu](mo.Type),
        Zu = Wu[Yu](mo.Options),
        $u = Wu[Yu](mo.Plugins),
        el = Wu[Yu](mo.Rules),
        tl = Wu[Yu](mo.Info),
        nl = Wu[Yu](mo.WebLibraryInfo),
        rl = Wu[Yu](br.TTQ_GLOBAL_OPTIONS);
    try {
        if (!Wu.get(br.TTQ_GLOBAL_OPTIONS)) throw new Error("")
    } catch (e) {
        rl.toConstantValue({})
    }
    var il = function(e, t) {
            var n = function(e) {
                    return {
                        name: "pixel.js",
                        version: "2.2.0",
                        options: e
                    }
                }(),
                r = vi();
            nl.toConstantValue(n), qu.toConstantValue(t), Xu.toConstantValue(r), !e || e._mounted || Wu.isBound(br.JS_BRIDGE) || _i(t) && (gi(t) ? Wu.bind(br.JS_BRIDGE).toConstantValue(function() {
                if (window && window.ToutiaoJSBridge && window.ToutiaoJSBridge.call) return window.ToutiaoJSBridge
            }() || Hu) : Wu.bind(br.JS_BRIDGE).toConstantValue(Ju))
        },
        ol = function(e) {
            var t = e || {},
                n = t._partner,
                r = t._ttp,
                i = t._self_host_config,
                o = t._usd_exchange_rate,
                a = t._legacy,
                c = t._cc,
                s = t._variation_id,
                u = t._server_unique_id,
                l = t._currency_list,
                f = t._plugins,
                d = t._aam,
                h = t._auto_config,
                p = Wu.get(br.TTQ_GLOBAL_OPTIONS) || {};
            Object.assign(p, {
                partner: n,
                ttp: r,
                cc: c,
                self_host_config: i,
                usd_exchange_rate: o,
                legacy: a,
                variation_id: s,
                server_unqiue_id: u,
                currency_list: l,
                plugins: f,
                aam: d,
                auto_config: h
            }), rl.toConstantValue(p)
        },
        al = function(e) {
            (null == e ? void 0 : e._container) || (Wu.bind(br.TTQ).to(Lo).inSingletonScope(), Wu.bind(br.CONTEXT).to(jo).inSingletonScope(), Wu.bind(br.REPORTER).to(Co), Wu.bind(br.TTQ_REPORTERS).toConstantValue([]), Wu.bind(br.REPORT_SERVICE).to(ca).inSingletonScope(), Wu.bind(br.AD_SERVICE).to(Bo).inSingletonScope(), Wu.bind(br.APP_SERVICE).to(Vo).inSingletonScope(), Wu.bind(br.BRIDGE_SERVICE).to($o).inSingletonScope(), Wu.bind(br.HTTP_SERVICE).to(ia).inSingletonScope(), Wu.bind(mo.IsOnsitePage).toConstantValue({
                value: !1
            }), Wu.bind(br.COOKIE_SERVICE).to(la).inSingletonScope(), Wu.bind(br.CONSENT_SERVICE).to(na).inSingletonScope()), e && !e._container && (e._container = Wu)
        },
        cl = function() {
            yu.forEach((function(e) {
                var t = e.to,
                    n = e.name,
                    r = void 0 === n ? "" : n,
                    i = e.required,
                    o = void 0 !== i && i,
                    a = e.identifier;
                !o && !Xr(r) || Wu.isBound(a) || Wu.bind(a).to(t).inSingletonScope()
            }))
        },
        sl = function(e) {
            var t = e.id,
                n = e.type,
                r = void 0 === n ? So.PIXEL_CODE : n,
                i = e.info,
                o = e.options,
                a = void 0 === o ? {} : o,
                s = e.plugins,
                u = void 0 === s ? {} : s,
                l = e.rules,
                f = void 0 === l ? [] : l,
                d = Wu.get(br.TTQ),
                h = Wu.get(br.TTQ_REPORTERS);
            if (!h.some((function(e) {
                    return e.getReporterId() === t
                }))) {
                zu.toConstantValue(t), Qu.toConstantValue(r), tl.toConstantValue(i || c({}, r, t)), Zu.toConstantValue(a), $u.toConstantValue(u), el.toConstantValue(f), d.enableFirstPartyCookie((null == i ? void 0 : i.firstPartyCookieEnabled) || !1);
                var p = Wu.get(br.REPORTER);
                if (u) {
                    var v = u.AdvancedMatching,
                        _ = u.AutoAdvancedMatching,
                        g = {};
                    v && Object.assign(g, v), _ && Object.assign(g, _), p.setAdvancedMatchingAvailableProperties(g)
                }
                return p.on("beforeReport", (function(e, t, n, r, i) {
                    d.dispatch(ar.PIXEL_SEND, e, t, n, r, i)
                })), h.push(p), Wu.rebind(br.TTQ_REPORTERS).toConstantValue(h), d.dispatch(ar.PIXEL_DID_MOUNT, p), p
            }
        },
        ul = function(e) {
            return e && e.Math == Math && e
        },
        ll = ul("object" == typeof globalThis && globalThis) || ul("object" == typeof window && window) || ul("object" == typeof self && self) || ul("object" == typeof N && N) || function() {
            return this
        }() || Function("return this")(),
        fl = {},
        dl = function(e) {
            try {
                return !!e()
            } catch (e) {
                return !0
            }
        },
        hl = !dl((function() {
            return 7 != Object.defineProperty({}, 1, {
                get: function() {
                    return 7
                }
            })[1]
        })),
        pl = !dl((function() {
            var e = function() {}.bind();
            return "function" != typeof e || e.hasOwnProperty("prototype")
        })),
        vl = pl,
        _l = Function.prototype.call,
        gl = vl ? _l.bind(_l) : function() {
            return _l.apply(_l, arguments)
        },
        yl = {},
        ml = {}.propertyIsEnumerable,
        El = Object.getOwnPropertyDescriptor,
        bl = El && !ml.call({
            1: 2
        }, 1);
    yl.f = bl ? function(e) {
        var t = El(this, e);
        return !!t && t.enumerable
    } : ml;
    var Tl, Il, Ol = function(e, t) {
            return {
                enumerable: !(1 & e),
                configurable: !(2 & e),
                writable: !(4 & e),
                value: t
            }
        },
        Sl = pl,
        Nl = Function.prototype,
        Rl = Nl.bind,
        Al = Nl.call,
        Cl = Sl && Rl.bind(Al, Al),
        Pl = Sl ? function(e) {
            return e && Cl(e)
        } : function(e) {
            return e && function() {
                return Al.apply(e, arguments)
            }
        },
        wl = Pl,
        kl = wl({}.toString),
        Ml = wl("".slice),
        Ll = function(e) {
            return Ml(kl(e), 8, -1)
        },
        Dl = dl,
        xl = Ll,
        jl = Object,
        Ul = Pl("".split),
        Fl = Dl((function() {
            return !jl("z").propertyIsEnumerable(0)
        })) ? function(e) {
            return "String" == xl(e) ? Ul(e, "") : jl(e)
        } : jl,
        Bl = TypeError,
        Gl = function(e) {
            if (null == e) throw Bl("Can't call method on " + e);
            return e
        },
        Hl = Fl,
        Vl = Gl,
        Jl = function(e) {
            return Hl(Vl(e))
        },
        Kl = function(e) {
            return "function" == typeof e
        },
        Wl = Kl,
        Yl = function(e) {
            return "object" == typeof e ? null !== e : Wl(e)
        },
        ql = ll,
        Xl = Kl,
        zl = function(e) {
            return Xl(e) ? e : void 0
        },
        Ql = function(e, t) {
            return arguments.length < 2 ? zl(ql[e]) : ql[e] && ql[e][t]
        },
        Zl = Pl({}.isPrototypeOf),
        $l = Ql("navigator", "userAgent") || "",
        ef = ll,
        tf = $l,
        nf = ef.process,
        rf = ef.Deno,
        of = nf && nf.versions || rf && rf.version,
        af = of && of .v8;
    af && (Il = (Tl = af.split("."))[0] > 0 && Tl[0] < 4 ? 1 : +(Tl[0] + Tl[1])), !Il && tf && (!(Tl = tf.match(/Edge\/(\d+)/)) || Tl[1] >= 74) && (Tl = tf.match(/Chrome\/(\d+)/)) && (Il = +Tl[1]);
    var cf = Il,
        sf = cf,
        uf = dl,
        lf = !!Object.getOwnPropertySymbols && !uf((function() {
            var e = Symbol();
            return !String(e) || !(Object(e) instanceof Symbol) || !Symbol.sham && sf && sf < 41
        })),
        ff = lf && !Symbol.sham && "symbol" == typeof Symbol.iterator,
        df = Ql,
        hf = Kl,
        pf = Zl,
        vf = Object,
        _f = ff ? function(e) {
            return "symbol" == typeof e
        } : function(e) {
            var t = df("Symbol");
            return hf(t) && pf(t.prototype, vf(e))
        },
        gf = String,
        yf = function(e) {
            try {
                return gf(e)
            } catch (e) {
                return "Object"
            }
        },
        mf = Kl,
        Ef = yf,
        bf = TypeError,
        Tf = function(e) {
            if (mf(e)) return e;
            throw bf(Ef(e) + " is not a function")
        },
        If = Tf,
        Of = function(e, t) {
            var n = e[t];
            return null == n ? void 0 : If(n)
        },
        Sf = gl,
        Nf = Kl,
        Rf = Yl,
        Af = TypeError,
        Cf = {
            exports: {}
        },
        Pf = ll,
        wf = Object.defineProperty,
        kf = function(e, t) {
            try {
                wf(Pf, e, {
                    value: t,
                    configurable: !0,
                    writable: !0
                })
            } catch (n) {
                Pf[e] = t
            }
            return t
        },
        Mf = kf,
        Lf = "__core-js_shared__",
        Df = ll[Lf] || Mf(Lf, {}),
        xf = Df;
    (Cf.exports = function(e, t) {
        return xf[e] || (xf[e] = void 0 !== t ? t : {})
    })("versions", []).push({
        version: "3.23.5",
        mode: "global",
        copyright: "© 2014-2022 Denis Pushkarev (zloirock.ru)",
        license: "https://github.com/zloirock/core-js/blob/v3.23.5/LICENSE",
        source: "https://github.com/zloirock/core-js"
    });
    var jf = Gl,
        Uf = Object,
        Ff = function(e) {
            return Uf(jf(e))
        },
        Bf = Ff,
        Gf = Pl({}.hasOwnProperty),
        Hf = Object.hasOwn || function(e, t) {
            return Gf(Bf(e), t)
        },
        Vf = Pl,
        Jf = 0,
        Kf = Math.random(),
        Wf = Vf(1..toString),
        Yf = function(e) {
            return "Symbol(" + (void 0 === e ? "" : e) + ")_" + Wf(++Jf + Kf, 36)
        },
        qf = ll,
        Xf = Cf.exports,
        zf = Hf,
        Qf = Yf,
        Zf = lf,
        $f = ff,
        ed = Xf("wks"),
        td = qf.Symbol,
        nd = td && td.for,
        rd = $f ? td : td && td.withoutSetter || Qf,
        id = function(e) {
            if (!zf(ed, e) || !Zf && "string" != typeof ed[e]) {
                var t = "Symbol." + e;
                Zf && zf(td, e) ? ed[e] = td[e] : ed[e] = $f && nd ? nd(t) : rd(t)
            }
            return ed[e]
        },
        od = gl,
        ad = Yl,
        cd = _f,
        sd = Of,
        ud = function(e, t) {
            var n, r;
            if ("string" === t && Nf(n = e.toString) && !Rf(r = Sf(n, e))) return r;
            if (Nf(n = e.valueOf) && !Rf(r = Sf(n, e))) return r;
            if ("string" !== t && Nf(n = e.toString) && !Rf(r = Sf(n, e))) return r;
            throw Af("Can't convert object to primitive value")
        },
        ld = TypeError,
        fd = id("toPrimitive"),
        dd = function(e, t) {
            if (!ad(e) || cd(e)) return e;
            var n, r = sd(e, fd);
            if (r) {
                if (void 0 === t && (t = "default"), n = od(r, e, t), !ad(n) || cd(n)) return n;
                throw ld("Can't convert object to primitive value")
            }
            return void 0 === t && (t = "number"), ud(e, t)
        },
        hd = _f,
        pd = function(e) {
            var t = dd(e, "string");
            return hd(t) ? t : t + ""
        },
        vd = Yl,
        _d = ll.document,
        gd = vd(_d) && vd(_d.createElement),
        yd = function(e) {
            return gd ? _d.createElement(e) : {}
        },
        md = yd,
        Ed = !hl && !dl((function() {
            return 7 != Object.defineProperty(md("div"), "a", {
                get: function() {
                    return 7
                }
            }).a
        })),
        bd = hl,
        Td = gl,
        Id = yl,
        Od = Ol,
        Sd = Jl,
        Nd = pd,
        Rd = Hf,
        Ad = Ed,
        Cd = Object.getOwnPropertyDescriptor;
    fl.f = bd ? Cd : function(e, t) {
        if (e = Sd(e), t = Nd(t), Ad) try {
            return Cd(e, t)
        } catch (e) {}
        if (Rd(e, t)) return Od(!Td(Id.f, e, t), e[t])
    };
    var Pd = {},
        wd = hl && dl((function() {
            return 42 != Object.defineProperty((function() {}), "prototype", {
                value: 42,
                writable: !1
            }).prototype
        })),
        kd = Yl,
        Md = String,
        Ld = TypeError,
        Dd = function(e) {
            if (kd(e)) return e;
            throw Ld(Md(e) + " is not an object")
        },
        xd = hl,
        jd = Ed,
        Ud = wd,
        Fd = Dd,
        Bd = pd,
        Gd = TypeError,
        Hd = Object.defineProperty,
        Vd = Object.getOwnPropertyDescriptor,
        Jd = "enumerable",
        Kd = "configurable",
        Wd = "writable";
    Pd.f = xd ? Ud ? function(e, t, n) {
        if (Fd(e), t = Bd(t), Fd(n), "function" == typeof e && "prototype" === t && "value" in n && Wd in n && !n.writable) {
            var r = Vd(e, t);
            r && r.writable && (e[t] = n.value, n = {
                configurable: Kd in n ? n.configurable : r.configurable,
                enumerable: Jd in n ? n.enumerable : r.enumerable,
                writable: !1
            })
        }
        return Hd(e, t, n)
    } : Hd : function(e, t, n) {
        if (Fd(e), t = Bd(t), Fd(n), jd) try {
            return Hd(e, t, n)
        } catch (e) {}
        if ("get" in n || "set" in n) throw Gd("Accessors not supported");
        return "value" in n && (e[t] = n.value), e
    };
    var Yd = Pd,
        qd = Ol,
        Xd = hl ? function(e, t, n) {
            return Yd.f(e, t, qd(1, n))
        } : function(e, t, n) {
            return e[t] = n, e
        },
        zd = {
            exports: {}
        },
        Qd = hl,
        Zd = Hf,
        $d = Function.prototype,
        eh = Qd && Object.getOwnPropertyDescriptor,
        th = Zd($d, "name"),
        nh = {
            EXISTS: th,
            PROPER: th && "something" === function() {}.name,
            CONFIGURABLE: th && (!Qd || Qd && eh($d, "name").configurable)
        },
        rh = Kl,
        ih = Df,
        oh = Pl(Function.toString);
    rh(ih.inspectSource) || (ih.inspectSource = function(e) {
        return oh(e)
    });
    var ah, ch, sh, uh = ih.inspectSource,
        lh = Kl,
        fh = uh,
        dh = ll.WeakMap,
        hh = lh(dh) && /native code/.test(fh(dh)),
        ph = Cf.exports,
        vh = Yf,
        _h = ph("keys"),
        gh = function(e) {
            return _h[e] || (_h[e] = vh(e))
        },
        yh = {},
        mh = hh,
        Eh = ll,
        bh = Pl,
        Th = Yl,
        Ih = Xd,
        Oh = Hf,
        Sh = Df,
        Nh = gh,
        Rh = yh,
        Ah = "Object already initialized",
        Ch = Eh.TypeError,
        Ph = Eh.WeakMap;
    if (mh || Sh.state) {
        var wh = Sh.state || (Sh.state = new Ph),
            kh = bh(wh.get),
            Mh = bh(wh.has),
            Lh = bh(wh.set);
        ah = function(e, t) {
            if (Mh(wh, e)) throw new Ch(Ah);
            return t.facade = e, Lh(wh, e, t), t
        }, ch = function(e) {
            return kh(wh, e) || {}
        }, sh = function(e) {
            return Mh(wh, e)
        }
    } else {
        var Dh = Nh("state");
        Rh[Dh] = !0, ah = function(e, t) {
            if (Oh(e, Dh)) throw new Ch(Ah);
            return t.facade = e, Ih(e, Dh, t), t
        }, ch = function(e) {
            return Oh(e, Dh) ? e[Dh] : {}
        }, sh = function(e) {
            return Oh(e, Dh)
        }
    }
    var xh = {
            set: ah,
            get: ch,
            has: sh,
            enforce: function(e) {
                return sh(e) ? ch(e) : ah(e, {})
            },
            getterFor: function(e) {
                return function(t) {
                    var n;
                    if (!Th(t) || (n = ch(t)).type !== e) throw Ch("Incompatible receiver, " + e + " required");
                    return n
                }
            }
        },
        jh = dl,
        Uh = Kl,
        Fh = Hf,
        Bh = hl,
        Gh = nh.CONFIGURABLE,
        Hh = uh,
        Vh = xh.enforce,
        Jh = xh.get,
        Kh = Object.defineProperty,
        Wh = Bh && !jh((function() {
            return 8 !== Kh((function() {}), "length", {
                value: 8
            }).length
        })),
        Yh = String(String).split("String"),
        qh = zd.exports = function(e, t, n) {
            "Symbol(" === String(t).slice(0, 7) && (t = "[" + String(t).replace(/^Symbol\(([^)]*)\)/, "$1") + "]"), n && n.getter && (t = "get " + t), n && n.setter && (t = "set " + t), (!Fh(e, "name") || Gh && e.name !== t) && (Bh ? Kh(e, "name", {
                value: t,
                configurable: !0
            }) : e.name = t), Wh && n && Fh(n, "arity") && e.length !== n.arity && Kh(e, "length", {
                value: n.arity
            });
            try {
                n && Fh(n, "constructor") && n.constructor ? Bh && Kh(e, "prototype", {
                    writable: !1
                }) : e.prototype && (e.prototype = void 0)
            } catch (e) {}
            var r = Vh(e);
            return Fh(r, "source") || (r.source = Yh.join("string" == typeof t ? t : "")), e
        };
    Function.prototype.toString = qh((function() {
        return Uh(this) && Jh(this).source || Hh(this)
    }), "toString");
    var Xh = Kl,
        zh = Pd,
        Qh = zd.exports,
        Zh = kf,
        $h = function(e, t, n, r) {
            r || (r = {});
            var i = r.enumerable,
                o = void 0 !== r.name ? r.name : t;
            if (Xh(n) && Qh(n, o, r), r.global) i ? e[t] = n : Zh(t, n);
            else {
                try {
                    r.unsafe ? e[t] && (i = !0) : delete e[t]
                } catch (e) {}
                i ? e[t] = n : zh.f(e, t, {
                    value: n,
                    enumerable: !1,
                    configurable: !r.nonConfigurable,
                    writable: !r.nonWritable
                })
            }
            return e
        },
        ep = {},
        tp = Math.ceil,
        np = Math.floor,
        rp = Math.trunc || function(e) {
            var t = +e;
            return (t > 0 ? np : tp)(t)
        },
        ip = rp,
        op = function(e) {
            var t = +e;
            return t != t || 0 === t ? 0 : ip(t)
        },
        ap = op,
        cp = Math.max,
        sp = Math.min,
        up = function(e, t) {
            var n = ap(e);
            return n < 0 ? cp(n + t, 0) : sp(n, t)
        },
        lp = op,
        fp = Math.min,
        dp = function(e) {
            return e > 0 ? fp(lp(e), 9007199254740991) : 0
        },
        hp = function(e) {
            return dp(e.length)
        },
        pp = Jl,
        vp = up,
        _p = hp,
        gp = function(e) {
            return function(t, n, r) {
                var i, o = pp(t),
                    a = _p(o),
                    c = vp(r, a);
                if (e && n != n) {
                    for (; a > c;)
                        if ((i = o[c++]) != i) return !0
                } else
                    for (; a > c; c++)
                        if ((e || c in o) && o[c] === n) return e || c || 0;
                return !e && -1
            }
        },
        yp = {
            includes: gp(!0),
            indexOf: gp(!1)
        },
        mp = Hf,
        Ep = Jl,
        bp = yp.indexOf,
        Tp = yh,
        Ip = Pl([].push),
        Op = function(e, t) {
            var n, r = Ep(e),
                i = 0,
                o = [];
            for (n in r) !mp(Tp, n) && mp(r, n) && Ip(o, n);
            for (; t.length > i;) mp(r, n = t[i++]) && (~bp(o, n) || Ip(o, n));
            return o
        },
        Sp = ["constructor", "hasOwnProperty", "isPrototypeOf", "propertyIsEnumerable", "toLocaleString", "toString", "valueOf"],
        Np = Op,
        Rp = Sp.concat("length", "prototype");
    ep.f = Object.getOwnPropertyNames || function(e) {
        return Np(e, Rp)
    };
    var Ap = {};
    Ap.f = Object.getOwnPropertySymbols;
    var Cp = Ql,
        Pp = ep,
        wp = Ap,
        kp = Dd,
        Mp = Pl([].concat),
        Lp = Cp("Reflect", "ownKeys") || function(e) {
            var t = Pp.f(kp(e)),
                n = wp.f;
            return n ? Mp(t, n(e)) : t
        },
        Dp = Hf,
        xp = Lp,
        jp = fl,
        Up = Pd,
        Fp = function(e, t, n) {
            for (var r = xp(t), i = Up.f, o = jp.f, a = 0; a < r.length; a++) {
                var c = r[a];
                Dp(e, c) || n && Dp(n, c) || i(e, c, o(t, c))
            }
        },
        Bp = dl,
        Gp = Kl,
        Hp = /#|\.prototype\./,
        Vp = function(e, t) {
            var n = Kp[Jp(e)];
            return n == Yp || n != Wp && (Gp(t) ? Bp(t) : !!t)
        },
        Jp = Vp.normalize = function(e) {
            return String(e).replace(Hp, ".").toLowerCase()
        },
        Kp = Vp.data = {},
        Wp = Vp.NATIVE = "N",
        Yp = Vp.POLYFILL = "P",
        qp = Vp,
        Xp = ll,
        zp = fl.f,
        Qp = Xd,
        Zp = $h,
        $p = kf,
        ev = Fp,
        tv = qp,
        nv = function(e, t) {
            var n, r, i, o, a, c = e.target,
                s = e.global,
                u = e.stat;
            if (n = s ? Xp : u ? Xp[c] || $p(c, {}) : (Xp[c] || {}).prototype)
                for (r in t) {
                    if (o = t[r], i = e.dontCallGetSet ? (a = zp(n, r)) && a.value : n[r], !tv(s ? r : c + (u ? "." : "#") + r, e.forced) && void 0 !== i) {
                        if (typeof o == typeof i) continue;
                        ev(o, i)
                    }(e.sham || i && i.sham) && Qp(o, "sham", !0), Zp(n, r, o, e)
                }
        },
        rv = {};
    rv[id("toStringTag")] = "z";
    var iv = "[object z]" === String(rv),
        ov = iv,
        av = Kl,
        cv = Ll,
        sv = id("toStringTag"),
        uv = Object,
        lv = "Arguments" == cv(function() {
            return arguments
        }()),
        fv = ov ? cv : function(e) {
            var t, n, r;
            return void 0 === e ? "Undefined" : null === e ? "Null" : "string" == typeof(n = function(e, t) {
                try {
                    return e[t]
                } catch (e) {}
            }(t = uv(e), sv)) ? n : lv ? cv(t) : "Object" == (r = cv(t)) && av(t.callee) ? "Arguments" : r
        },
        dv = fv,
        hv = String,
        pv = function(e) {
            if ("Symbol" === dv(e)) throw TypeError("Cannot convert a Symbol value to a string");
            return hv(e)
        },
        vv = {},
        _v = Op,
        gv = Sp,
        yv = Object.keys || function(e) {
            return _v(e, gv)
        },
        mv = hl,
        Ev = wd,
        bv = Pd,
        Tv = Dd,
        Iv = Jl,
        Ov = yv;
    vv.f = mv && !Ev ? Object.defineProperties : function(e, t) {
        Tv(e);
        for (var n, r = Iv(t), i = Ov(t), o = i.length, a = 0; o > a;) bv.f(e, n = i[a++], r[n]);
        return e
    };
    var Sv, Nv = Ql("document", "documentElement"),
        Rv = Dd,
        Av = vv,
        Cv = Sp,
        Pv = yh,
        wv = Nv,
        kv = yd,
        Mv = gh("IE_PROTO"),
        Lv = function() {},
        Dv = function(e) {
            return "<script>" + e + "</" + "script>"
        },
        xv = function(e) {
            e.write(Dv("")), e.close();
            var t = e.parentWindow.Object;
            return e = null, t
        },
        jv = function() {
            try {
                Sv = new ActiveXObject("htmlfile")
            } catch (e) {}
            var e, t;
            jv = "undefined" != typeof document ? document.domain && Sv ? xv(Sv) : ((t = kv("iframe")).style.display = "none", wv.appendChild(t), t.src = String("javascript:"), (e = t.contentWindow.document).open(), e.write(Dv("document.F=Object")), e.close(), e.F) : xv(Sv);
            for (var n = Cv.length; n--;) delete jv.prototype[Cv[n]];
            return jv()
        };
    Pv[Mv] = !0;
    var Uv = Object.create || function(e, t) {
            var n;
            return null !== e ? (Lv.prototype = Rv(e), n = new Lv, Lv.prototype = null, n[Mv] = e) : n = jv(), void 0 === t ? n : Av.f(n, t)
        },
        Fv = {},
        Bv = pd,
        Gv = Pd,
        Hv = Ol,
        Vv = function(e, t, n) {
            var r = Bv(t);
            r in e ? Gv.f(e, r, Hv(0, n)) : e[r] = n
        },
        Jv = up,
        Kv = hp,
        Wv = Vv,
        Yv = Array,
        qv = Math.max,
        Xv = Ll,
        zv = Jl,
        Qv = ep.f,
        Zv = function(e, t, n) {
            for (var r = Kv(e), i = Jv(t, r), o = Jv(void 0 === n ? r : n, r), a = Yv(qv(o - i, 0)), c = 0; i < o; i++, c++) Wv(a, c, e[i]);
            return a.length = c, a
        },
        $v = "object" == typeof window && window && Object.getOwnPropertyNames ? Object.getOwnPropertyNames(window) : [];
    Fv.f = function(e) {
        return $v && "Window" == Xv(e) ? function(e) {
            try {
                return Qv(e)
            } catch (e) {
                return Zv($v)
            }
        }(e) : Qv(zv(e))
    };
    var e_ = {},
        t_ = id;
    e_.f = t_;
    var n_ = ll,
        r_ = n_,
        i_ = Hf,
        o_ = e_,
        a_ = Pd.f,
        c_ = gl,
        s_ = Ql,
        u_ = id,
        l_ = $h,
        f_ = Pd.f,
        d_ = Hf,
        h_ = id("toStringTag"),
        p_ = function(e, t, n) {
            e && !n && (e = e.prototype), e && !d_(e, h_) && f_(e, h_, {
                configurable: !0,
                value: t
            })
        },
        v_ = Tf,
        __ = pl,
        g_ = Pl(Pl.bind),
        y_ = function(e, t) {
            return v_(e), void 0 === t ? e : __ ? g_(e, t) : function() {
                return e.apply(t, arguments)
            }
        },
        m_ = Ll,
        E_ = Array.isArray || function(e) {
            return "Array" == m_(e)
        },
        b_ = Pl,
        T_ = dl,
        I_ = Kl,
        O_ = fv,
        S_ = uh,
        N_ = function() {},
        R_ = [],
        A_ = Ql("Reflect", "construct"),
        C_ = /^\s*(?:class|function)\b/,
        P_ = b_(C_.exec),
        w_ = !C_.exec(N_),
        k_ = function(e) {
            if (!I_(e)) return !1;
            try {
                return A_(N_, R_, e), !0
            } catch (e) {
                return !1
            }
        },
        M_ = function(e) {
            if (!I_(e)) return !1;
            switch (O_(e)) {
                case "AsyncFunction":
                case "GeneratorFunction":
                case "AsyncGeneratorFunction":
                    return !1
            }
            try {
                return w_ || !!P_(C_, S_(e))
            } catch (e) {
                return !0
            }
        };
    M_.sham = !0;
    var L_ = !A_ || T_((function() {
            var e;
            return k_(k_.call) || !k_(Object) || !k_((function() {
                e = !0
            })) || e
        })) ? M_ : k_,
        D_ = E_,
        x_ = L_,
        j_ = Yl,
        U_ = id("species"),
        F_ = Array,
        B_ = function(e) {
            var t;
            return D_(e) && (t = e.constructor, (x_(t) && (t === F_ || D_(t.prototype)) || j_(t) && null === (t = t[U_])) && (t = void 0)), void 0 === t ? F_ : t
        },
        G_ = y_,
        H_ = Fl,
        V_ = Ff,
        J_ = hp,
        K_ = function(e, t) {
            return new(B_(e))(0 === t ? 0 : t)
        },
        W_ = Pl([].push),
        Y_ = function(e) {
            var t = 1 == e,
                n = 2 == e,
                r = 3 == e,
                i = 4 == e,
                o = 6 == e,
                a = 7 == e,
                c = 5 == e || o;
            return function(s, u, l, f) {
                for (var d, h, p = V_(s), v = H_(p), _ = G_(u, l), g = J_(v), y = 0, m = f || K_, E = t ? m(s, g) : n || a ? m(s, 0) : void 0; g > y; y++)
                    if ((c || y in v) && (h = _(d = v[y], y, p), e))
                        if (t) E[y] = h;
                        else if (h) switch (e) {
                    case 3:
                        return !0;
                    case 5:
                        return d;
                    case 6:
                        return y;
                    case 2:
                        W_(E, d)
                } else switch (e) {
                    case 4:
                        return !1;
                    case 7:
                        W_(E, d)
                }
                return o ? -1 : r || i ? i : E
            }
        },
        q_ = {
            forEach: Y_(0),
            map: Y_(1),
            filter: Y_(2),
            some: Y_(3),
            every: Y_(4),
            find: Y_(5),
            findIndex: Y_(6),
            filterReject: Y_(7)
        },
        X_ = nv,
        z_ = ll,
        Q_ = gl,
        Z_ = Pl,
        $_ = hl,
        eg = lf,
        tg = dl,
        ng = Hf,
        rg = Zl,
        ig = Dd,
        og = Jl,
        ag = pd,
        cg = pv,
        sg = Ol,
        ug = Uv,
        lg = yv,
        fg = ep,
        dg = Fv,
        hg = Ap,
        pg = fl,
        vg = Pd,
        _g = vv,
        gg = yl,
        yg = $h,
        mg = Cf.exports,
        Eg = yh,
        bg = Yf,
        Tg = id,
        Ig = e_,
        Og = function(e) {
            var t = r_.Symbol || (r_.Symbol = {});
            i_(t, e) || a_(t, e, {
                value: o_.f(e)
            })
        },
        Sg = function() {
            var e = s_("Symbol"),
                t = e && e.prototype,
                n = t && t.valueOf,
                r = u_("toPrimitive");
            t && !t[r] && l_(t, r, (function(e) {
                return c_(n, this)
            }), {
                arity: 1
            })
        },
        Ng = p_,
        Rg = xh,
        Ag = q_.forEach,
        Cg = gh("hidden"),
        Pg = "Symbol",
        wg = Rg.set,
        kg = Rg.getterFor(Pg),
        Mg = Object.prototype,
        Lg = z_.Symbol,
        Dg = Lg && Lg.prototype,
        xg = z_.TypeError,
        jg = z_.QObject,
        Ug = pg.f,
        Fg = vg.f,
        Bg = dg.f,
        Gg = gg.f,
        Hg = Z_([].push),
        Vg = mg("symbols"),
        Jg = mg("op-symbols"),
        Kg = mg("wks"),
        Wg = !jg || !jg.prototype || !jg.prototype.findChild,
        Yg = $_ && tg((function() {
            return 7 != ug(Fg({}, "a", {
                get: function() {
                    return Fg(this, "a", {
                        value: 7
                    }).a
                }
            })).a
        })) ? function(e, t, n) {
            var r = Ug(Mg, t);
            r && delete Mg[t], Fg(e, t, n), r && e !== Mg && Fg(Mg, t, r)
        } : Fg,
        qg = function(e, t) {
            var n = Vg[e] = ug(Dg);
            return wg(n, {
                type: Pg,
                tag: e,
                description: t
            }), $_ || (n.description = t), n
        },
        Xg = function(e, t, n) {
            e === Mg && Xg(Jg, t, n), ig(e);
            var r = ag(t);
            return ig(n), ng(Vg, r) ? (n.enumerable ? (ng(e, Cg) && e[Cg][r] && (e[Cg][r] = !1), n = ug(n, {
                enumerable: sg(0, !1)
            })) : (ng(e, Cg) || Fg(e, Cg, sg(1, {})), e[Cg][r] = !0), Yg(e, r, n)) : Fg(e, r, n)
        },
        zg = function(e, t) {
            ig(e);
            var n = og(t),
                r = lg(n).concat(ey(n));
            return Ag(r, (function(t) {
                $_ && !Q_(Qg, n, t) || Xg(e, t, n[t])
            })), e
        },
        Qg = function(e) {
            var t = ag(e),
                n = Q_(Gg, this, t);
            return !(this === Mg && ng(Vg, t) && !ng(Jg, t)) && (!(n || !ng(this, t) || !ng(Vg, t) || ng(this, Cg) && this[Cg][t]) || n)
        },
        Zg = function(e, t) {
            var n = og(e),
                r = ag(t);
            if (n !== Mg || !ng(Vg, r) || ng(Jg, r)) {
                var i = Ug(n, r);
                return !i || !ng(Vg, r) || ng(n, Cg) && n[Cg][r] || (i.enumerable = !0), i
            }
        },
        $g = function(e) {
            var t = Bg(og(e)),
                n = [];
            return Ag(t, (function(e) {
                ng(Vg, e) || ng(Eg, e) || Hg(n, e)
            })), n
        },
        ey = function(e) {
            var t = e === Mg,
                n = Bg(t ? Jg : og(e)),
                r = [];
            return Ag(n, (function(e) {
                !ng(Vg, e) || t && !ng(Mg, e) || Hg(r, Vg[e])
            })), r
        };
    eg || (Lg = function() {
        if (rg(Dg, this)) throw xg("Symbol is not a constructor");
        var e = arguments.length && void 0 !== arguments[0] ? cg(arguments[0]) : void 0,
            t = bg(e),
            n = function(e) {
                this === Mg && Q_(n, Jg, e), ng(this, Cg) && ng(this[Cg], t) && (this[Cg][t] = !1), Yg(this, t, sg(1, e))
            };
        return $_ && Wg && Yg(Mg, t, {
            configurable: !0,
            set: n
        }), qg(t, e)
    }, yg(Dg = Lg.prototype, "toString", (function() {
        return kg(this).tag
    })), yg(Lg, "withoutSetter", (function(e) {
        return qg(bg(e), e)
    })), gg.f = Qg, vg.f = Xg, _g.f = zg, pg.f = Zg, fg.f = dg.f = $g, hg.f = ey, Ig.f = function(e) {
        return qg(Tg(e), e)
    }, $_ && (Fg(Dg, "description", {
        configurable: !0,
        get: function() {
            return kg(this).description
        }
    }), yg(Mg, "propertyIsEnumerable", Qg, {
        unsafe: !0
    }))), X_({
        global: !0,
        constructor: !0,
        wrap: !0,
        forced: !eg,
        sham: !eg
    }, {
        Symbol: Lg
    }), Ag(lg(Kg), (function(e) {
        Og(e)
    })), X_({
        target: Pg,
        stat: !0,
        forced: !eg
    }, {
        useSetter: function() {
            Wg = !0
        },
        useSimple: function() {
            Wg = !1
        }
    }), X_({
        target: "Object",
        stat: !0,
        forced: !eg,
        sham: !$_
    }, {
        create: function(e, t) {
            return void 0 === t ? ug(e) : zg(ug(e), t)
        },
        defineProperty: Xg,
        defineProperties: zg,
        getOwnPropertyDescriptor: Zg
    }), X_({
        target: "Object",
        stat: !0,
        forced: !eg
    }, {
        getOwnPropertyNames: $g
    }), Sg(), Ng(Lg, Pg), Eg[Cg] = !0;
    var ty = lf && !!Symbol.for && !!Symbol.keyFor,
        ny = nv,
        ry = Ql,
        iy = Hf,
        oy = pv,
        ay = Cf.exports,
        cy = ty,
        sy = ay("string-to-symbol-registry"),
        uy = ay("symbol-to-string-registry");
    ny({
        target: "Symbol",
        stat: !0,
        forced: !cy
    }, {
        for: function(e) {
            var t = oy(e);
            if (iy(sy, t)) return sy[t];
            var n = ry("Symbol")(t);
            return sy[t] = n, uy[n] = t, n
        }
    });
    var ly = nv,
        fy = Hf,
        dy = _f,
        hy = yf,
        py = ty,
        vy = (0, Cf.exports)("symbol-to-string-registry");
    ly({
        target: "Symbol",
        stat: !0,
        forced: !py
    }, {
        keyFor: function(e) {
            if (!dy(e)) throw TypeError(hy(e) + " is not a symbol");
            if (fy(vy, e)) return vy[e]
        }
    });
    var _y = pl,
        gy = Function.prototype,
        yy = gy.apply,
        my = gy.call,
        Ey = "object" == typeof Reflect && Reflect.apply || (_y ? my.bind(yy) : function() {
            return my.apply(yy, arguments)
        }),
        by = Pl([].slice),
        Ty = nv,
        Iy = Ql,
        Oy = Ey,
        Sy = gl,
        Ny = Pl,
        Ry = dl,
        Ay = E_,
        Cy = Kl,
        Py = Yl,
        wy = _f,
        ky = by,
        My = lf,
        Ly = Iy("JSON", "stringify"),
        Dy = Ny(/./.exec),
        xy = Ny("".charAt),
        jy = Ny("".charCodeAt),
        Uy = Ny("".replace),
        Fy = Ny(1..toString),
        By = /[\uD800-\uDFFF]/g,
        Gy = /^[\uD800-\uDBFF]$/,
        Hy = /^[\uDC00-\uDFFF]$/,
        Vy = !My || Ry((function() {
            var e = Iy("Symbol")();
            return "[null]" != Ly([e]) || "{}" != Ly({
                a: e
            }) || "{}" != Ly(Object(e))
        })),
        Jy = Ry((function() {
            return '"\\udf06\\ud834"' !== Ly("\udf06\ud834") || '"\\udead"' !== Ly("\udead")
        })),
        Ky = function(e, t) {
            var n = ky(arguments),
                r = t;
            if ((Py(t) || void 0 !== e) && !wy(e)) return Ay(t) || (t = function(e, t) {
                if (Cy(r) && (t = Sy(r, this, e, t)), !wy(t)) return t
            }), n[1] = t, Oy(Ly, null, n)
        },
        Wy = function(e, t, n) {
            var r = xy(n, t - 1),
                i = xy(n, t + 1);
            return Dy(Gy, e) && !Dy(Hy, i) || Dy(Hy, e) && !Dy(Gy, r) ? "\\u" + Fy(jy(e, 0), 16) : e
        };
    Ly && Ty({
        target: "JSON",
        stat: !0,
        arity: 3,
        forced: Vy || Jy
    }, {
        stringify: function(e, t, n) {
            var r = ky(arguments),
                i = Oy(Vy ? Ky : Ly, null, r);
            return Jy && "string" == typeof i ? Uy(i, By, Wy) : i
        }
    });
    var Yy = Ap,
        qy = Ff;
    nv({
        target: "Object",
        stat: !0,
        forced: !lf || dl((function() {
            Yy.f(1)
        }))
    }, {
        getOwnPropertySymbols: function(e) {
            var t = Yy.f;
            return t ? t(qy(e)) : []
        }
    });
    var Xy = hl,
        zy = Pl,
        Qy = gl,
        Zy = dl,
        $y = yv,
        em = Ap,
        tm = yl,
        nm = Ff,
        rm = Fl,
        im = Object.assign,
        om = Object.defineProperty,
        am = zy([].concat),
        cm = !im || Zy((function() {
            if (Xy && 1 !== im({
                    b: 1
                }, im(om({}, "a", {
                    enumerable: !0,
                    get: function() {
                        om(this, "b", {
                            value: 3,
                            enumerable: !1
                        })
                    }
                }), {
                    b: 2
                })).b) return !0;
            var e = {},
                t = {},
                n = Symbol(),
                r = "abcdefghijklmnopqrst";
            return e[n] = 7, r.split("").forEach((function(e) {
                t[e] = e
            })), 7 != im({}, e)[n] || $y(im({}, t)).join("") != r
        })) ? function(e, t) {
            for (var n = nm(e), r = arguments.length, i = 1, o = em.f, a = tm.f; r > i;)
                for (var c, s = rm(arguments[i++]), u = o ? am($y(s), o(s)) : $y(s), l = u.length, f = 0; l > f;) c = u[f++], Xy && !Qy(a, s, c) || (n[c] = s[c]);
            return n
        } : im,
        sm = cm;
    nv({
        target: "Object",
        stat: !0,
        arity: 2,
        forced: Object.assign !== sm
    }, {
        assign: sm
    }), nv({
        target: "Object",
        stat: !0,
        sham: !hl
    }, {
        create: Uv
    });
    var um = nv,
        lm = hl,
        fm = Pd.f;
    um({
        target: "Object",
        stat: !0,
        forced: Object.defineProperty !== fm,
        sham: !lm
    }, {
        defineProperty: fm
    });
    var dm = nv,
        hm = hl,
        pm = vv.f;
    dm({
        target: "Object",
        stat: !0,
        forced: Object.defineProperties !== pm,
        sham: !hm
    }, {
        defineProperties: pm
    });
    var vm = hl,
        _m = Pl,
        gm = yv,
        ym = Jl,
        mm = _m(yl.f),
        Em = _m([].push),
        bm = function(e) {
            return function(t) {
                for (var n, r = ym(t), i = gm(r), o = i.length, a = 0, c = []; o > a;) n = i[a++], vm && !mm(r, n) || Em(c, e ? [n, r[n]] : r[n]);
                return c
            }
        },
        Tm = {
            entries: bm(!0),
            values: bm(!1)
        },
        Im = Tm.entries;
    nv({
        target: "Object",
        stat: !0
    }, {
        entries: function(e) {
            return Im(e)
        }
    });
    var Om = !dl((function() {
            return Object.isExtensible(Object.preventExtensions({}))
        })),
        Sm = {
            exports: {}
        },
        Nm = dl((function() {
            if ("function" == typeof ArrayBuffer) {
                var e = new ArrayBuffer(8);
                Object.isExtensible(e) && Object.defineProperty(e, "a", {
                    value: 8
                })
            }
        })),
        Rm = dl,
        Am = Yl,
        Cm = Ll,
        Pm = Nm,
        wm = Object.isExtensible,
        km = Rm((function() {
            wm(1)
        })) || Pm ? function(e) {
            return !!Am(e) && ((!Pm || "ArrayBuffer" != Cm(e)) && (!wm || wm(e)))
        } : wm,
        Mm = nv,
        Lm = Pl,
        Dm = yh,
        xm = Yl,
        jm = Hf,
        Um = Pd.f,
        Fm = ep,
        Bm = Fv,
        Gm = km,
        Hm = Om,
        Vm = !1,
        Jm = Yf("meta"),
        Km = 0,
        Wm = function(e) {
            Um(e, Jm, {
                value: {
                    objectID: "O" + Km++,
                    weakData: {}
                }
            })
        },
        Ym = Sm.exports = {
            enable: function() {
                Ym.enable = function() {}, Vm = !0;
                var e = Fm.f,
                    t = Lm([].splice),
                    n = {};
                n[Jm] = 1, e(n).length && (Fm.f = function(n) {
                    for (var r = e(n), i = 0, o = r.length; i < o; i++)
                        if (r[i] === Jm) {
                            t(r, i, 1);
                            break
                        }
                    return r
                }, Mm({
                    target: "Object",
                    stat: !0,
                    forced: !0
                }, {
                    getOwnPropertyNames: Bm.f
                }))
            },
            fastKey: function(e, t) {
                if (!xm(e)) return "symbol" == typeof e ? e : ("string" == typeof e ? "S" : "P") + e;
                if (!jm(e, Jm)) {
                    if (!Gm(e)) return "F";
                    if (!t) return "E";
                    Wm(e)
                }
                return e[Jm].objectID
            },
            getWeakData: function(e, t) {
                if (!jm(e, Jm)) {
                    if (!Gm(e)) return !0;
                    if (!t) return !1;
                    Wm(e)
                }
                return e[Jm].weakData
            },
            onFreeze: function(e) {
                return Hm && Vm && Gm(e) && !jm(e, Jm) && Wm(e), e
            }
        };
    Dm[Jm] = !0;
    var qm = nv,
        Xm = Om,
        zm = dl,
        Qm = Yl,
        Zm = Sm.exports.onFreeze,
        $m = Object.freeze;
    qm({
        target: "Object",
        stat: !0,
        forced: zm((function() {
            $m(1)
        })),
        sham: !Xm
    }, {
        freeze: function(e) {
            return $m && Qm(e) ? $m(Zm(e)) : e
        }
    });
    var eE = {},
        tE = eE,
        nE = id("iterator"),
        rE = Array.prototype,
        iE = fv,
        oE = Of,
        aE = eE,
        cE = id("iterator"),
        sE = function(e) {
            if (null != e) return oE(e, cE) || oE(e, "@@iterator") || aE[iE(e)]
        },
        uE = gl,
        lE = Tf,
        fE = Dd,
        dE = yf,
        hE = sE,
        pE = TypeError,
        vE = gl,
        _E = Dd,
        gE = Of,
        yE = y_,
        mE = gl,
        EE = Dd,
        bE = yf,
        TE = function(e) {
            return void 0 !== e && (tE.Array === e || rE[nE] === e)
        },
        IE = hp,
        OE = Zl,
        SE = function(e, t) {
            var n = arguments.length < 2 ? hE(e) : t;
            if (lE(n)) return fE(uE(n, e));
            throw pE(dE(e) + " is not iterable")
        },
        NE = sE,
        RE = function(e, t, n) {
            var r, i;
            _E(e);
            try {
                if (!(r = gE(e, "return"))) {
                    if ("throw" === t) throw n;
                    return n
                }
                r = vE(r, e)
            } catch (e) {
                i = !0, r = e
            }
            if ("throw" === t) throw n;
            if (i) throw r;
            return _E(r), n
        },
        AE = TypeError,
        CE = function(e, t) {
            this.stopped = e, this.result = t
        },
        PE = CE.prototype,
        wE = function(e, t, n) {
            var r, i, o, a, c, s, u, l = n && n.that,
                f = !(!n || !n.AS_ENTRIES),
                d = !(!n || !n.IS_RECORD),
                h = !(!n || !n.IS_ITERATOR),
                p = !(!n || !n.INTERRUPTED),
                v = yE(t, l),
                _ = function(e) {
                    return r && RE(r, "normal", e), new CE(!0, e)
                },
                g = function(e) {
                    return f ? (EE(e), p ? v(e[0], e[1], _) : v(e[0], e[1])) : p ? v(e, _) : v(e)
                };
            if (d) r = e.iterator;
            else if (h) r = e;
            else {
                if (!(i = NE(e))) throw AE(bE(e) + " is not iterable");
                if (TE(i)) {
                    for (o = 0, a = IE(e); a > o; o++)
                        if ((c = g(e[o])) && OE(PE, c)) return c;
                    return new CE(!1)
                }
                r = SE(e, i)
            }
            for (s = d ? e.next : r.next; !(u = mE(s, r)).done;) {
                try {
                    c = g(u.value)
                } catch (e) {
                    RE(r, "throw", e)
                }
                if ("object" == typeof c && c && OE(PE, c)) return c
            }
            return new CE(!1)
        },
        kE = wE,
        ME = Vv;
    nv({
        target: "Object",
        stat: !0
    }, {
        fromEntries: function(e) {
            var t = {};
            return kE(e, (function(e, n) {
                ME(t, e, n)
            }), {
                AS_ENTRIES: !0
            }), t
        }
    });
    var LE = nv,
        DE = dl,
        xE = Jl,
        jE = fl.f,
        UE = hl,
        FE = DE((function() {
            jE(1)
        }));
    LE({
        target: "Object",
        stat: !0,
        forced: !UE || FE,
        sham: !UE
    }, {
        getOwnPropertyDescriptor: function(e, t) {
            return jE(xE(e), t)
        }
    });
    var BE = Lp,
        GE = Jl,
        HE = fl,
        VE = Vv;
    nv({
        target: "Object",
        stat: !0,
        sham: !hl
    }, {
        getOwnPropertyDescriptors: function(e) {
            for (var t, n, r = GE(e), i = HE.f, o = BE(r), a = {}, c = 0; o.length > c;) void 0 !== (n = i(r, t = o[c++])) && VE(a, t, n);
            return a
        }
    });
    var JE = nv,
        KE = dl,
        WE = Fv.f;
    JE({
        target: "Object",
        stat: !0,
        forced: KE((function() {
            return !Object.getOwnPropertyNames(1)
        }))
    }, {
        getOwnPropertyNames: WE
    });
    var YE = !dl((function() {
            function e() {}
            return e.prototype.constructor = null, Object.getPrototypeOf(new e) !== e.prototype
        })),
        qE = Hf,
        XE = Kl,
        zE = Ff,
        QE = YE,
        ZE = gh("IE_PROTO"),
        $E = Object,
        eb = $E.prototype,
        tb = QE ? $E.getPrototypeOf : function(e) {
            var t = zE(e);
            if (qE(t, ZE)) return t[ZE];
            var n = t.constructor;
            return XE(n) && t instanceof n ? n.prototype : t instanceof $E ? eb : null
        },
        nb = Ff,
        rb = tb,
        ib = YE;
    nv({
        target: "Object",
        stat: !0,
        forced: dl((function() {
            rb(1)
        })),
        sham: !ib
    }, {
        getPrototypeOf: function(e) {
            return rb(nb(e))
        }
    }), nv({
        target: "Object",
        stat: !0
    }, {
        hasOwn: Hf
    });
    var ob = Object.is || function(e, t) {
        return e === t ? 0 !== e || 1 / e == 1 / t : e != e && t != t
    };
    nv({
        target: "Object",
        stat: !0
    }, {
        is: ob
    });
    var ab = km;
    nv({
        target: "Object",
        stat: !0,
        forced: Object.isExtensible !== ab
    }, {
        isExtensible: ab
    });
    var cb = nv,
        sb = dl,
        ub = Yl,
        lb = Ll,
        fb = Nm,
        db = Object.isFrozen;
    cb({
        target: "Object",
        stat: !0,
        forced: sb((function() {
            db(1)
        })) || fb
    }, {
        isFrozen: function(e) {
            return !ub(e) || (!(!fb || "ArrayBuffer" != lb(e)) || !!db && db(e))
        }
    });
    var hb = nv,
        pb = dl,
        vb = Yl,
        _b = Ll,
        gb = Nm,
        yb = Object.isSealed;
    hb({
        target: "Object",
        stat: !0,
        forced: pb((function() {
            yb(1)
        })) || gb
    }, {
        isSealed: function(e) {
            return !vb(e) || (!(!gb || "ArrayBuffer" != _b(e)) || !!yb && yb(e))
        }
    });
    var mb = Ff,
        Eb = yv;
    nv({
        target: "Object",
        stat: !0,
        forced: dl((function() {
            Eb(1)
        }))
    }, {
        keys: function(e) {
            return Eb(mb(e))
        }
    });
    var bb = nv,
        Tb = Yl,
        Ib = Sm.exports.onFreeze,
        Ob = Om,
        Sb = dl,
        Nb = Object.preventExtensions;
    bb({
        target: "Object",
        stat: !0,
        forced: Sb((function() {
            Nb(1)
        })),
        sham: !Ob
    }, {
        preventExtensions: function(e) {
            return Nb && Tb(e) ? Nb(Ib(e)) : e
        }
    });
    var Rb = nv,
        Ab = Yl,
        Cb = Sm.exports.onFreeze,
        Pb = Om,
        wb = dl,
        kb = Object.seal;
    Rb({
        target: "Object",
        stat: !0,
        forced: wb((function() {
            kb(1)
        })),
        sham: !Pb
    }, {
        seal: function(e) {
            return kb && Ab(e) ? kb(Cb(e)) : e
        }
    });
    var Mb = Kl,
        Lb = String,
        Db = TypeError,
        xb = Pl,
        jb = Dd,
        Ub = function(e) {
            if ("object" == typeof e || Mb(e)) return e;
            throw Db("Can't set " + Lb(e) + " as a prototype")
        },
        Fb = Object.setPrototypeOf || ("__proto__" in {} ? function() {
            var e, t = !1,
                n = {};
            try {
                (e = xb(Object.getOwnPropertyDescriptor(Object.prototype, "__proto__").set))(n, []), t = n instanceof Array
            } catch (e) {}
            return function(n, r) {
                return jb(n), Ub(r), t ? e(n, r) : n.__proto__ = r, n
            }
        }() : void 0);
    nv({
        target: "Object",
        stat: !0
    }, {
        setPrototypeOf: Fb
    });
    var Bb = Tm.values;
    nv({
        target: "Object",
        stat: !0
    }, {
        values: function(e) {
            return Bb(e)
        }
    });
    var Gb = fv,
        Hb = iv ? {}.toString : function() {
            return "[object " + Gb(this) + "]"
        };
    iv || $h(Object.prototype, "toString", Hb, {
        unsafe: !0
    });
    var Vb = $l.match(/AppleWebKit\/(\d+)\./),
        Jb = !!Vb && +Vb[1],
        Kb = ll,
        Wb = Jb,
        Yb = !dl((function() {
            if (!(Wb && Wb < 535)) {
                var e = Math.random();
                __defineSetter__.call(null, e, (function() {})), delete Kb[e]
            }
        })),
        qb = Tf,
        Xb = Ff,
        zb = Pd;
    hl && nv({
        target: "Object",
        proto: !0,
        forced: Yb
    }, {
        __defineGetter__: function(e, t) {
            zb.f(Xb(this), e, {
                get: qb(t),
                enumerable: !0,
                configurable: !0
            })
        }
    });
    var Qb = Tf,
        Zb = Ff,
        $b = Pd;
    hl && nv({
        target: "Object",
        proto: !0,
        forced: Yb
    }, {
        __defineSetter__: function(e, t) {
            $b.f(Zb(this), e, {
                set: Qb(t),
                enumerable: !0,
                configurable: !0
            })
        }
    });
    var eT = nv,
        tT = hl,
        nT = Yb,
        rT = Ff,
        iT = pd,
        oT = tb,
        aT = fl.f;
    tT && eT({
        target: "Object",
        proto: !0,
        forced: nT
    }, {
        __lookupGetter__: function(e) {
            var t, n = rT(this),
                r = iT(e);
            do {
                if (t = aT(n, r)) return t.get
            } while (n = oT(n))
        }
    });
    var cT = nv,
        sT = hl,
        uT = Yb,
        lT = Ff,
        fT = pd,
        dT = tb,
        hT = fl.f;
    sT && cT({
        target: "Object",
        proto: !0,
        forced: uT
    }, {
        __lookupSetter__: function(e) {
            var t, n = lT(this),
                r = fT(e);
            do {
                if (t = hT(n, r)) return t.set
            } while (n = dT(n))
        }
    }), p_(ll.JSON, "JSON", !0), p_(Math, "Math", !0);
    var pT = ll,
        vT = p_;
    nv({
        global: !0
    }, {
        Reflect: {}
    }), vT(pT.Reflect, "Reflect", !0), n_.Object;
    var _T = Error,
        gT = Pl("".replace),
        yT = String(_T("zxcasd").stack),
        mT = /\n\s*at [^:]*:[^\n]*/,
        ET = mT.test(yT),
        bT = Yl,
        TT = Xd,
        IT = pv,
        OT = Ol,
        ST = !dl((function() {
            var e = Error("a");
            return !("stack" in e) || (Object.defineProperty(e, "stack", OT(1, 7)), 7 !== e.stack)
        })),
        NT = nv,
        RT = Zl,
        AT = tb,
        CT = Fb,
        PT = Fp,
        wT = Uv,
        kT = Xd,
        MT = Ol,
        LT = function(e, t) {
            if (ET && "string" == typeof e && !_T.prepareStackTrace)
                for (; t--;) e = gT(e, mT, "");
            return e
        },
        DT = function(e, t) {
            bT(t) && "cause" in t && TT(e, "cause", t.cause)
        },
        xT = wE,
        jT = function(e, t) {
            return void 0 === e ? arguments.length < 2 ? "" : t : IT(e)
        },
        UT = ST,
        FT = id("toStringTag"),
        BT = Error,
        GT = [].push,
        HT = function(e, t) {
            var n, r = arguments.length > 2 ? arguments[2] : void 0,
                i = RT(VT, this);
            CT ? n = CT(new BT, i ? AT(this) : VT) : (n = i ? this : wT(VT), kT(n, FT, "Error")), void 0 !== t && kT(n, "message", jT(t)), UT && kT(n, "stack", LT(n.stack, 1)), DT(n, r);
            var o = [];
            return xT(e, GT, {
                that: o
            }), kT(n, "errors", o), n
        };
    CT ? CT(HT, BT) : PT(HT, BT, {
        name: !0
    });
    var VT = HT.prototype = wT(BT.prototype, {
        constructor: MT(1, HT),
        message: MT(1, ""),
        name: MT(1, "AggregateError")
    });
    NT({
        global: !0,
        constructor: !0,
        arity: 2
    }, {
        AggregateError: HT
    });
    var JT = id,
        KT = Uv,
        WT = Pd.f,
        YT = JT("unscopables"),
        qT = Array.prototype;
    null == qT[YT] && WT(qT, YT, {
        configurable: !0,
        value: KT(null)
    });
    var XT, zT, QT, ZT = dl,
        $T = Kl,
        eI = tb,
        tI = $h,
        nI = id("iterator"),
        rI = !1;
    [].keys && ("next" in (QT = [].keys()) ? (zT = eI(eI(QT))) !== Object.prototype && (XT = zT) : rI = !0);
    var iI = null == XT || ZT((function() {
        var e = {};
        return XT[nI].call(e) !== e
    }));
    iI && (XT = {}), $T(XT[nI]) || tI(XT, nI, (function() {
        return this
    }));
    var oI = {
            IteratorPrototype: XT,
            BUGGY_SAFARI_ITERATORS: rI
        },
        aI = oI.IteratorPrototype,
        cI = Uv,
        sI = Ol,
        uI = p_,
        lI = eE,
        fI = function() {
            return this
        },
        dI = nv,
        hI = gl,
        pI = Kl,
        vI = function(e, t, n, r) {
            var i = t + " Iterator";
            return e.prototype = cI(aI, {
                next: sI(+!r, n)
            }), uI(e, i, !1), lI[i] = fI, e
        },
        _I = tb,
        gI = Fb,
        yI = p_,
        mI = Xd,
        EI = $h,
        bI = eE,
        TI = nh.PROPER,
        II = nh.CONFIGURABLE,
        OI = oI.IteratorPrototype,
        SI = oI.BUGGY_SAFARI_ITERATORS,
        NI = id("iterator"),
        RI = "keys",
        AI = "values",
        CI = "entries",
        PI = function() {
            return this
        },
        wI = function(e, t, n, r, i, o, a) {
            vI(n, t, r);
            var c, s, u, l = function(e) {
                    if (e === i && v) return v;
                    if (!SI && e in h) return h[e];
                    switch (e) {
                        case RI:
                        case AI:
                        case CI:
                            return function() {
                                return new n(this, e)
                            }
                    }
                    return function() {
                        return new n(this)
                    }
                },
                f = t + " Iterator",
                d = !1,
                h = e.prototype,
                p = h[NI] || h["@@iterator"] || i && h[i],
                v = !SI && p || l(i),
                _ = "Array" == t && h.entries || p;
            if (_ && (c = _I(_.call(new e))) !== Object.prototype && c.next && (_I(c) !== OI && (gI ? gI(c, OI) : pI(c[NI]) || EI(c, NI, PI)), yI(c, f, !0)), TI && i == AI && p && p.name !== AI && (II ? mI(h, "name", AI) : (d = !0, v = function() {
                    return hI(p, this)
                })), i)
                if (s = {
                        values: l(AI),
                        keys: o ? v : l(RI),
                        entries: l(CI)
                    }, a)
                    for (u in s)(SI || d || !(u in h)) && EI(h, u, s[u]);
                else dI({
                    target: t,
                    proto: !0,
                    forced: SI || d
                }, s);
            return h[NI] !== v && EI(h, NI, v, {
                name: i
            }), bI[t] = v, s
        },
        kI = Jl,
        MI = function(e) {
            qT[YT][e] = !0
        },
        LI = eE,
        DI = xh,
        xI = Pd.f,
        jI = wI,
        UI = hl,
        FI = "Array Iterator",
        BI = DI.set,
        GI = DI.getterFor(FI);
    jI(Array, "Array", (function(e, t) {
        BI(this, {
            type: FI,
            target: kI(e),
            index: 0,
            kind: t
        })
    }), (function() {
        var e = GI(this),
            t = e.target,
            n = e.kind,
            r = e.index++;
        return !t || r >= t.length ? (e.target = void 0, {
            value: void 0,
            done: !0
        }) : "keys" == n ? {
            value: r,
            done: !1
        } : "values" == n ? {
            value: t[r],
            done: !1
        } : {
            value: [r, t[r]],
            done: !1
        }
    }), "values");
    var HI = LI.Arguments = LI.Array;
    if (MI("keys"), MI("values"), MI("entries"), UI && "values" !== HI.name) try {
        xI(HI, "name", {
            value: "values"
        })
    } catch (QR) {}
    var VI, JI, KI, WI, YI = "process" == Ll(ll.process),
        qI = Ql,
        XI = Pd,
        zI = hl,
        QI = id("species"),
        ZI = Zl,
        $I = TypeError,
        eO = L_,
        tO = yf,
        nO = TypeError,
        rO = Dd,
        iO = function(e) {
            if (eO(e)) return e;
            throw nO(tO(e) + " is not a constructor")
        },
        oO = id("species"),
        aO = function(e, t) {
            var n, r = rO(e).constructor;
            return void 0 === r || null == (n = rO(r)[oO]) ? t : iO(n)
        },
        cO = TypeError,
        sO = /(?:ipad|iphone|ipod).*applewebkit/i.test($l),
        uO = ll,
        lO = Ey,
        fO = y_,
        dO = Kl,
        hO = Hf,
        pO = dl,
        vO = Nv,
        _O = by,
        gO = yd,
        yO = function(e, t) {
            if (e < t) throw cO("Not enough arguments");
            return e
        },
        mO = sO,
        EO = YI,
        bO = uO.setImmediate,
        TO = uO.clearImmediate,
        IO = uO.process,
        OO = uO.Dispatch,
        SO = uO.Function,
        NO = uO.MessageChannel,
        RO = uO.String,
        AO = 0,
        CO = {},
        PO = "onreadystatechange";
    try {
        VI = uO.location
    } catch (QR) {}
    var wO = function(e) {
            if (hO(CO, e)) {
                var t = CO[e];
                delete CO[e], t()
            }
        },
        kO = function(e) {
            return function() {
                wO(e)
            }
        },
        MO = function(e) {
            wO(e.data)
        },
        LO = function(e) {
            uO.postMessage(RO(e), VI.protocol + "//" + VI.host)
        };
    bO && TO || (bO = function(e) {
        yO(arguments.length, 1);
        var t = dO(e) ? e : SO(e),
            n = _O(arguments, 1);
        return CO[++AO] = function() {
            lO(t, void 0, n)
        }, JI(AO), AO
    }, TO = function(e) {
        delete CO[e]
    }, EO ? JI = function(e) {
        IO.nextTick(kO(e))
    } : OO && OO.now ? JI = function(e) {
        OO.now(kO(e))
    } : NO && !mO ? (WI = (KI = new NO).port2, KI.port1.onmessage = MO, JI = fO(WI.postMessage, WI)) : uO.addEventListener && dO(uO.postMessage) && !uO.importScripts && VI && "file:" !== VI.protocol && !pO(LO) ? (JI = LO, uO.addEventListener("message", MO, !1)) : JI = PO in gO("script") ? function(e) {
        vO.appendChild(gO("script")).onreadystatechange = function() {
            vO.removeChild(this), wO(e)
        }
    } : function(e) {
        setTimeout(kO(e), 0)
    });
    var DO, xO, jO, UO, FO, BO, GO, HO, VO = {
            set: bO,
            clear: TO
        },
        JO = ll,
        KO = /ipad|iphone|ipod/i.test($l) && void 0 !== JO.Pebble,
        WO = /web0s(?!.*chrome)/i.test($l),
        YO = ll,
        qO = y_,
        XO = fl.f,
        zO = VO.set,
        QO = sO,
        ZO = KO,
        $O = WO,
        eS = YI,
        tS = YO.MutationObserver || YO.WebKitMutationObserver,
        nS = YO.document,
        rS = YO.process,
        iS = YO.Promise,
        oS = XO(YO, "queueMicrotask"),
        aS = oS && oS.value;
    aS || (DO = function() {
        var e, t;
        for (eS && (e = rS.domain) && e.exit(); xO;) {
            t = xO.fn, xO = xO.next;
            try {
                t()
            } catch (e) {
                throw xO ? UO() : jO = void 0, e
            }
        }
        jO = void 0, e && e.enter()
    }, QO || eS || $O || !tS || !nS ? !ZO && iS && iS.resolve ? ((GO = iS.resolve(void 0)).constructor = iS, HO = qO(GO.then, GO), UO = function() {
        HO(DO)
    }) : eS ? UO = function() {
        rS.nextTick(DO)
    } : (zO = qO(zO, YO), UO = function() {
        zO(DO)
    }) : (FO = !0, BO = nS.createTextNode(""), new tS(DO).observe(BO, {
        characterData: !0
    }), UO = function() {
        BO.data = FO = !FO
    }));
    var cS = aS || function(e) {
            var t = {
                fn: e,
                next: void 0
            };
            jO && (jO.next = t), xO || (xO = t, UO()), jO = t
        },
        sS = ll,
        uS = function(e) {
            try {
                return {
                    error: !1,
                    value: e()
                }
            } catch (e) {
                return {
                    error: !0,
                    value: e
                }
            }
        },
        lS = function() {
            this.head = null, this.tail = null
        };
    lS.prototype = {
        add: function(e) {
            var t = {
                item: e,
                next: null
            };
            this.head ? this.tail.next = t : this.head = t, this.tail = t
        },
        get: function() {
            var e = this.head;
            if (e) return this.head = e.next, this.tail === e && (this.tail = null), e.item
        }
    };
    var fS = lS,
        dS = ll.Promise,
        hS = "object" == typeof window && "object" != typeof Deno,
        pS = ll,
        vS = dS,
        _S = Kl,
        gS = qp,
        yS = uh,
        mS = id,
        ES = hS,
        bS = cf;
    vS && vS.prototype;
    var TS = mS("species"),
        IS = !1,
        OS = _S(pS.PromiseRejectionEvent),
        SS = gS("Promise", (function() {
            var e = yS(vS),
                t = e !== String(vS);
            if (!t && 66 === bS) return !0;
            if (bS >= 51 && /native code/.test(e)) return !1;
            var n = new vS((function(e) {
                    e(1)
                })),
                r = function(e) {
                    e((function() {}), (function() {}))
                };
            return (n.constructor = {})[TS] = r, !(IS = n.then((function() {})) instanceof r) || !t && ES && !OS
        })),
        NS = {
            CONSTRUCTOR: SS,
            REJECTION_EVENT: OS,
            SUBCLASSING: IS
        },
        RS = {},
        AS = Tf,
        CS = function(e) {
            var t, n;
            this.promise = new e((function(e, r) {
                if (void 0 !== t || void 0 !== n) throw TypeError("Bad Promise constructor");
                t = e, n = r
            })), this.resolve = AS(t), this.reject = AS(n)
        };
    RS.f = function(e) {
        return new CS(e)
    };
    var PS, wS, kS, MS = nv,
        LS = YI,
        DS = ll,
        xS = gl,
        jS = $h,
        US = Fb,
        FS = p_,
        BS = function(e) {
            var t = qI(e),
                n = XI.f;
            zI && t && !t[QI] && n(t, QI, {
                configurable: !0,
                get: function() {
                    return this
                }
            })
        },
        GS = Tf,
        HS = Kl,
        VS = Yl,
        JS = function(e, t) {
            if (ZI(t, e)) return e;
            throw $I("Incorrect invocation")
        },
        KS = aO,
        WS = VO.set,
        YS = cS,
        qS = function(e, t) {
            var n = sS.console;
            n && n.error && (1 == arguments.length ? n.error(e) : n.error(e, t))
        },
        XS = uS,
        zS = fS,
        QS = xh,
        ZS = dS,
        $S = RS,
        eN = "Promise",
        tN = NS.CONSTRUCTOR,
        nN = NS.REJECTION_EVENT,
        rN = NS.SUBCLASSING,
        iN = QS.getterFor(eN),
        oN = QS.set,
        aN = ZS && ZS.prototype,
        cN = ZS,
        sN = aN,
        uN = DS.TypeError,
        lN = DS.document,
        fN = DS.process,
        dN = $S.f,
        hN = dN,
        pN = !!(lN && lN.createEvent && DS.dispatchEvent),
        vN = "unhandledrejection",
        _N = function(e) {
            var t;
            return !(!VS(e) || !HS(t = e.then)) && t
        },
        gN = function(e, t) {
            var n, r, i, o = t.value,
                a = 1 == t.state,
                c = a ? e.ok : e.fail,
                s = e.resolve,
                u = e.reject,
                l = e.domain;
            try {
                c ? (a || (2 === t.rejection && TN(t), t.rejection = 1), !0 === c ? n = o : (l && l.enter(), n = c(o), l && (l.exit(), i = !0)), n === e.promise ? u(uN("Promise-chain cycle")) : (r = _N(n)) ? xS(r, n, s, u) : s(n)) : u(o)
            } catch (e) {
                l && !i && l.exit(), u(e)
            }
        },
        yN = function(e, t) {
            e.notified || (e.notified = !0, YS((function() {
                for (var n, r = e.reactions; n = r.get();) gN(n, e);
                e.notified = !1, t && !e.rejection && EN(e)
            })))
        },
        mN = function(e, t, n) {
            var r, i;
            pN ? ((r = lN.createEvent("Event")).promise = t, r.reason = n, r.initEvent(e, !1, !0), DS.dispatchEvent(r)) : r = {
                promise: t,
                reason: n
            }, !nN && (i = DS["on" + e]) ? i(r) : e === vN && qS("Unhandled promise rejection", n)
        },
        EN = function(e) {
            xS(WS, DS, (function() {
                var t, n = e.facade,
                    r = e.value;
                if (bN(e) && (t = XS((function() {
                        LS ? fN.emit("unhandledRejection", r, n) : mN(vN, n, r)
                    })), e.rejection = LS || bN(e) ? 2 : 1, t.error)) throw t.value
            }))
        },
        bN = function(e) {
            return 1 !== e.rejection && !e.parent
        },
        TN = function(e) {
            xS(WS, DS, (function() {
                var t = e.facade;
                LS ? fN.emit("rejectionHandled", t) : mN("rejectionhandled", t, e.value)
            }))
        },
        IN = function(e, t, n) {
            return function(r) {
                e(t, r, n)
            }
        },
        ON = function(e, t, n) {
            e.done || (e.done = !0, n && (e = n), e.value = t, e.state = 2, yN(e, !0))
        },
        SN = function(e, t, n) {
            if (!e.done) {
                e.done = !0, n && (e = n);
                try {
                    if (e.facade === t) throw uN("Promise can't be resolved itself");
                    var r = _N(t);
                    r ? YS((function() {
                        var n = {
                            done: !1
                        };
                        try {
                            xS(r, t, IN(SN, n, e), IN(ON, n, e))
                        } catch (t) {
                            ON(n, t, e)
                        }
                    })) : (e.value = t, e.state = 1, yN(e, !1))
                } catch (t) {
                    ON({
                        done: !1
                    }, t, e)
                }
            }
        };
    if (tN && (cN = function(e) {
            JS(this, sN), GS(e), xS(PS, this);
            var t = iN(this);
            try {
                e(IN(SN, t), IN(ON, t))
            } catch (e) {
                ON(t, e)
            }
        }, sN = cN.prototype, (PS = function(e) {
            oN(this, {
                type: eN,
                done: !1,
                notified: !1,
                parent: !1,
                reactions: new zS,
                rejection: !1,
                state: 0,
                value: void 0
            })
        }).prototype = jS(sN, "then", (function(e, t) {
            var n = iN(this),
                r = dN(KS(this, cN));
            return n.parent = !0, r.ok = !HS(e) || e, r.fail = HS(t) && t, r.domain = LS ? fN.domain : void 0, 0 == n.state ? n.reactions.add(r) : YS((function() {
                gN(r, n)
            })), r.promise
        })), wS = function() {
            var e = new PS,
                t = iN(e);
            this.promise = e, this.resolve = IN(SN, t), this.reject = IN(ON, t)
        }, $S.f = dN = function(e) {
            return e === cN || undefined === e ? new wS(e) : hN(e)
        }, HS(ZS) && aN !== Object.prototype)) {
        kS = aN.then, rN || jS(aN, "then", (function(e, t) {
            var n = this;
            return new cN((function(e, t) {
                xS(kS, n, e, t)
            })).then(e, t)
        }), {
            unsafe: !0
        });
        try {
            delete aN.constructor
        } catch (QR) {}
        US && US(aN, sN)
    }
    MS({
        global: !0,
        constructor: !0,
        wrap: !0,
        forced: tN
    }, {
        Promise: cN
    }), FS(cN, eN, !1), BS(eN);
    var NN = id("iterator"),
        RN = !1;
    try {
        var AN = 0,
            CN = {
                next: function() {
                    return {
                        done: !!AN++
                    }
                },
                return: function() {
                    RN = !0
                }
            };
        CN[NN] = function() {
            return this
        }, Array.from(CN, (function() {
            throw 2
        }))
    } catch (QR) {}
    var PN = dS,
        wN = function(e, t) {
            if (!t && !RN) return !1;
            var n = !1;
            try {
                var r = {};
                r[NN] = function() {
                    return {
                        next: function() {
                            return {
                                done: n = !0
                            }
                        }
                    }
                }, e(r)
            } catch (e) {}
            return n
        },
        kN = NS.CONSTRUCTOR || !wN((function(e) {
            PN.all(e).then(void 0, (function() {}))
        })),
        MN = gl,
        LN = Tf,
        DN = RS,
        xN = uS,
        jN = wE;
    nv({
        target: "Promise",
        stat: !0,
        forced: kN
    }, {
        all: function(e) {
            var t = this,
                n = DN.f(t),
                r = n.resolve,
                i = n.reject,
                o = xN((function() {
                    var n = LN(t.resolve),
                        o = [],
                        a = 0,
                        c = 1;
                    jN(e, (function(e) {
                        var s = a++,
                            u = !1;
                        c++, MN(n, t, e).then((function(e) {
                            u || (u = !0, o[s] = e, --c || r(o))
                        }), i)
                    })), --c || r(o)
                }));
            return o.error && i(o.value), n.promise
        }
    });
    var UN = nv,
        FN = NS.CONSTRUCTOR,
        BN = dS,
        GN = Ql,
        HN = Kl,
        VN = $h,
        JN = BN && BN.prototype;
    if (UN({
            target: "Promise",
            proto: !0,
            forced: FN,
            real: !0
        }, {
            catch: function(e) {
                return this.then(void 0, e)
            }
        }), HN(BN)) {
        var KN = GN("Promise").prototype.catch;
        JN.catch !== KN && VN(JN, "catch", KN, {
            unsafe: !0
        })
    }
    var WN = gl,
        YN = Tf,
        qN = RS,
        XN = uS,
        zN = wE;
    nv({
        target: "Promise",
        stat: !0,
        forced: kN
    }, {
        race: function(e) {
            var t = this,
                n = qN.f(t),
                r = n.reject,
                i = XN((function() {
                    var i = YN(t.resolve);
                    zN(e, (function(e) {
                        WN(i, t, e).then(n.resolve, r)
                    }))
                }));
            return i.error && r(i.value), n.promise
        }
    });
    var QN = gl,
        ZN = RS;
    nv({
        target: "Promise",
        stat: !0,
        forced: NS.CONSTRUCTOR
    }, {
        reject: function(e) {
            var t = ZN.f(this);
            return QN(t.reject, void 0, e), t.promise
        }
    });
    var $N = Dd,
        eR = Yl,
        tR = RS,
        nR = function(e, t) {
            if ($N(e), eR(t) && t.constructor === e) return t;
            var n = tR.f(e);
            return (0, n.resolve)(t), n.promise
        },
        rR = nv,
        iR = NS.CONSTRUCTOR,
        oR = nR;
    Ql("Promise"), rR({
        target: "Promise",
        stat: !0,
        forced: iR
    }, {
        resolve: function(e) {
            return oR(this, e)
        }
    });
    var aR = gl,
        cR = Tf,
        sR = RS,
        uR = uS,
        lR = wE;
    nv({
        target: "Promise",
        stat: !0
    }, {
        allSettled: function(e) {
            var t = this,
                n = sR.f(t),
                r = n.resolve,
                i = n.reject,
                o = uR((function() {
                    var n = cR(t.resolve),
                        i = [],
                        o = 0,
                        a = 1;
                    lR(e, (function(e) {
                        var c = o++,
                            s = !1;
                        a++, aR(n, t, e).then((function(e) {
                            s || (s = !0, i[c] = {
                                status: "fulfilled",
                                value: e
                            }, --a || r(i))
                        }), (function(e) {
                            s || (s = !0, i[c] = {
                                status: "rejected",
                                reason: e
                            }, --a || r(i))
                        }))
                    })), --a || r(i)
                }));
            return o.error && i(o.value), n.promise
        }
    });
    var fR = gl,
        dR = Tf,
        hR = Ql,
        pR = RS,
        vR = uS,
        _R = wE,
        gR = "No one promise resolved";
    nv({
        target: "Promise",
        stat: !0
    }, {
        any: function(e) {
            var t = this,
                n = hR("AggregateError"),
                r = pR.f(t),
                i = r.resolve,
                o = r.reject,
                a = vR((function() {
                    var r = dR(t.resolve),
                        a = [],
                        c = 0,
                        s = 1,
                        u = !1;
                    _R(e, (function(e) {
                        var l = c++,
                            f = !1;
                        s++, fR(r, t, e).then((function(e) {
                            f || u || (u = !0, i(e))
                        }), (function(e) {
                            f || u || (f = !0, a[l] = e, --s || o(new n(a, gR)))
                        }))
                    })), --s || o(new n(a, gR))
                }));
            return a.error && o(a.value), r.promise
        }
    });
    var yR = nv,
        mR = dS,
        ER = dl,
        bR = Ql,
        TR = Kl,
        IR = aO,
        OR = nR,
        SR = $h,
        NR = mR && mR.prototype;
    if (yR({
            target: "Promise",
            proto: !0,
            real: !0,
            forced: !!mR && ER((function() {
                NR.finally.call({
                    then: function() {}
                }, (function() {}))
            }))
        }, {
            finally: function(e) {
                var t = IR(this, bR("Promise")),
                    n = TR(e);
                return this.then(n ? function(n) {
                    return OR(t, e()).then((function() {
                        return n
                    }))
                } : e, n ? function(n) {
                    return OR(t, e()).then((function() {
                        throw n
                    }))
                } : e)
            }
        }), TR(mR)) {
        var RR = bR("Promise").prototype.finally;
        NR.finally !== RR && SR(NR, "finally", RR, {
            unsafe: !0
        })
    }
    var AR = Pl,
        CR = op,
        PR = pv,
        wR = Gl,
        kR = AR("".charAt),
        MR = AR("".charCodeAt),
        LR = AR("".slice),
        DR = function(e) {
            return function(t, n) {
                var r, i, o = PR(wR(t)),
                    a = CR(n),
                    c = o.length;
                return a < 0 || a >= c ? e ? "" : void 0 : (r = MR(o, a)) < 55296 || r > 56319 || a + 1 === c || (i = MR(o, a + 1)) < 56320 || i > 57343 ? e ? kR(o, a) : r : e ? LR(o, a, a + 2) : i - 56320 + (r - 55296 << 10) + 65536
            }
        },
        xR = {
            codeAt: DR(!1),
            charAt: DR(!0)
        }.charAt,
        jR = pv,
        UR = xh,
        FR = wI,
        BR = "String Iterator",
        GR = UR.set,
        HR = UR.getterFor(BR);
    FR(String, "String", (function(e) {
            GR(this, {
                type: BR,
                string: jR(e),
                index: 0
            })
        }), (function() {
            var e, t = HR(this),
                n = t.string,
                r = t.index;
            return r >= n.length ? {
                value: void 0,
                done: !0
            } : (e = xR(n, r), t.index += e.length, {
                value: e,
                done: !1
            })
        })), n_.Promise,
        function() {
            if ("undefined" != typeof window) try {
                var e = new window.CustomEvent("test", {
                    cancelable: !0
                });
                if (e.preventDefault(), !0 !== e.defaultPrevented) throw new Error("Could not prevent default")
            } catch (e) {
                var t = function(e, t) {
                    var n, r;
                    return (t = t || {}).bubbles = !!t.bubbles, t.cancelable = !!t.cancelable, (n = document.createEvent("CustomEvent")).initCustomEvent(e, t.bubbles, t.cancelable, t.detail), r = n.preventDefault, n.preventDefault = function() {
                        r.call(this);
                        try {
                            Object.defineProperty(this, "defaultPrevented", {
                                get: function() {
                                    return !0
                                }
                            })
                        } catch (e) {
                            this.defaultPrevented = !0
                        }
                    }, n
                };
                t.prototype = window.Event.prototype, window.CustomEvent = t
            }
        }(),
        function() {
            if ("object" == typeof window)
                if ("IntersectionObserver" in window && "IntersectionObserverEntry" in window && "intersectionRatio" in window.IntersectionObserverEntry.prototype) "isIntersecting" in window.IntersectionObserverEntry.prototype || Object.defineProperty(window.IntersectionObserverEntry.prototype, "isIntersecting", {
                    get: function() {
                        return this.intersectionRatio > 0
                    }
                });
                else {
                    var e = window.document;
                    n.prototype.THROTTLE_TIMEOUT = 100, n.prototype.POLL_INTERVAL = null, n.prototype.USE_MUTATION_OBSERVER = !0, n.prototype.observe = function(e) {
                        if (!this._observationTargets.some((function(t) {
                                return t.element == e
                            }))) {
                            if (!e || 1 != e.nodeType) throw new Error("target must be an Element");
                            this._registerInstance(), this._observationTargets.push({
                                element: e,
                                entry: null
                            }), this._monitorIntersections(), this._checkForIntersections()
                        }
                    }, n.prototype.unobserve = function(e) {
                        this._observationTargets = this._observationTargets.filter((function(t) {
                            return t.element != e
                        })), this._observationTargets.length || (this._unmonitorIntersections(), this._unregisterInstance())
                    }, n.prototype.disconnect = function() {
                        this._observationTargets = [], this._unmonitorIntersections(), this._unregisterInstance()
                    }, n.prototype.takeRecords = function() {
                        var e = this._queuedEntries.slice();
                        return this._queuedEntries = [], e
                    }, n.prototype._initThresholds = function(e) {
                        var t = e || [0];
                        return Array.isArray(t) || (t = [t]), t.sort().filter((function(e, t, n) {
                            if ("number" != typeof e || isNaN(e) || e < 0 || e > 1) throw new Error("threshold must be a number between 0 and 1 inclusively");
                            return e !== n[t - 1]
                        }))
                    }, n.prototype._parseRootMargin = function(e) {
                        var t = (e || "0px").split(/\s+/).map((function(e) {
                            var t = /^(-?\d*\.?\d+)(px|%)$/.exec(e);
                            if (!t) throw new Error("rootMargin must be specified in pixels or percent");
                            return {
                                value: parseFloat(t[1]),
                                unit: t[2]
                            }
                        }));
                        return t[1] = t[1] || t[0], t[2] = t[2] || t[0], t[3] = t[3] || t[1], t
                    }, n.prototype._monitorIntersections = function() {
                        this._monitoringIntersections || (this._monitoringIntersections = !0, this.POLL_INTERVAL ? this._monitoringInterval = setInterval(this._checkForIntersections, this.POLL_INTERVAL) : (r(window, "resize", this._checkForIntersections, !0), r(e, "scroll", this._checkForIntersections, !0), this.USE_MUTATION_OBSERVER && "MutationObserver" in window && (this._domObserver = new MutationObserver(this._checkForIntersections), this._domObserver.observe(e, {
                            attributes: !0,
                            childList: !0,
                            characterData: !0,
                            subtree: !0
                        }))))
                    }, n.prototype._unmonitorIntersections = function() {
                        this._monitoringIntersections && (this._monitoringIntersections = !1, clearInterval(this._monitoringInterval), this._monitoringInterval = null, i(window, "resize", this._checkForIntersections, !0), i(e, "scroll", this._checkForIntersections, !0), this._domObserver && (this._domObserver.disconnect(), this._domObserver = null))
                    }, n.prototype._checkForIntersections = function() {
                        var e = this._rootIsInDom(),
                            n = e ? this._getRootRect() : {
                                top: 0,
                                bottom: 0,
                                left: 0,
                                right: 0,
                                width: 0,
                                height: 0
                            };
                        this._observationTargets.forEach((function(r) {
                            var i = r.element,
                                a = o(i),
                                c = this._rootContainsTarget(i),
                                s = r.entry,
                                u = e && c && this._computeTargetAndRootIntersection(i, n),
                                l = r.entry = new t({
                                    time: window.performance && performance.now && performance.now(),
                                    target: i,
                                    boundingClientRect: a,
                                    rootBounds: n,
                                    intersectionRect: u
                                });
                            s ? e && c ? this._hasCrossedThreshold(s, l) && this._queuedEntries.push(l) : s && s.isIntersecting && this._queuedEntries.push(l) : this._queuedEntries.push(l)
                        }), this), this._queuedEntries.length && this._callback(this.takeRecords(), this)
                    }, n.prototype._computeTargetAndRootIntersection = function(t, n) {
                        if ("none" != window.getComputedStyle(t).display) {
                            for (var r, i, a, s, u, l, f, d, h = o(t), p = c(t), v = !1; !v;) {
                                var _ = null,
                                    g = 1 == p.nodeType ? window.getComputedStyle(p) : {};
                                if ("none" == g.display) return;
                                if (p == this.root || p == e ? (v = !0, _ = n) : p != e.body && p != e.documentElement && "visible" != g.overflow && (_ = o(p)), _ && (r = _, i = h, a = void 0, s = void 0, u = void 0, l = void 0, f = void 0, d = void 0, a = Math.max(r.top, i.top), s = Math.min(r.bottom, i.bottom), u = Math.max(r.left, i.left), l = Math.min(r.right, i.right), d = s - a, !(h = (f = l - u) >= 0 && d >= 0 && {
                                        top: a,
                                        bottom: s,
                                        left: u,
                                        right: l,
                                        width: f,
                                        height: d
                                    }))) break;
                                p = c(p)
                            }
                            return h
                        }
                    }, n.prototype._getRootRect = function() {
                        var t;
                        if (this.root) t = o(this.root);
                        else {
                            var n = e.documentElement,
                                r = e.body;
                            t = {
                                top: 0,
                                left: 0,
                                right: n.clientWidth || r.clientWidth,
                                width: n.clientWidth || r.clientWidth,
                                bottom: n.clientHeight || r.clientHeight,
                                height: n.clientHeight || r.clientHeight
                            }
                        }
                        return this._expandRectByRootMargin(t)
                    }, n.prototype._expandRectByRootMargin = function(e) {
                        var t = this._rootMarginValues.map((function(t, n) {
                                return "px" == t.unit ? t.value : t.value * (n % 2 ? e.width : e.height) / 100
                            })),
                            n = {
                                top: e.top - t[0],
                                right: e.right + t[1],
                                bottom: e.bottom + t[2],
                                left: e.left - t[3]
                            };
                        return n.width = n.right - n.left, n.height = n.bottom - n.top, n
                    }, n.prototype._hasCrossedThreshold = function(e, t) {
                        var n = e && e.isIntersecting ? e.intersectionRatio || 0 : -1,
                            r = t.isIntersecting ? t.intersectionRatio || 0 : -1;
                        if (n !== r)
                            for (var i = 0; i < this.thresholds.length; i++) {
                                var o = this.thresholds[i];
                                if (o == n || o == r || o < n != o < r) return !0
                            }
                    }, n.prototype._rootIsInDom = function() {
                        return !this.root || a(e, this.root)
                    }, n.prototype._rootContainsTarget = function(t) {
                        return a(this.root || e, t)
                    }, n.prototype._registerInstance = function() {}, n.prototype._unregisterInstance = function() {}, window.IntersectionObserver = n, window.IntersectionObserverEntry = t
                }
            function t(e) {
                this.time = e.time, this.target = e.target, this.rootBounds = e.rootBounds, this.boundingClientRect = e.boundingClientRect, this.intersectionRect = e.intersectionRect || {
                    top: 0,
                    bottom: 0,
                    left: 0,
                    right: 0,
                    width: 0,
                    height: 0
                }, this.isIntersecting = !!e.intersectionRect;
                var t = this.boundingClientRect,
                    n = t.width * t.height,
                    r = this.intersectionRect,
                    i = r.width * r.height;
                this.intersectionRatio = n ? Number((i / n).toFixed(4)) : this.isIntersecting ? 1 : 0
            }

            function n(e, t) {
                var n, r, i, o = t || {};
                if ("function" != typeof e) throw new Error("callback must be a function");
                if (o.root && 1 != o.root.nodeType) throw new Error("root must be an Element");
                this._checkForIntersections = (n = this._checkForIntersections.bind(this), r = this.THROTTLE_TIMEOUT, i = null, function() {
                    i || (i = setTimeout((function() {
                        n(), i = null
                    }), r))
                }), this._callback = e, this._observationTargets = [], this._queuedEntries = [], this._rootMarginValues = this._parseRootMargin(o.rootMargin), this.thresholds = this._initThresholds(o.threshold), this.root = o.root || null, this.rootMargin = this._rootMarginValues.map((function(e) {
                    return e.value + e.unit
                })).join(" ")
            }

            function r(e, t, n, r) {
                "function" == typeof e.addEventListener ? e.addEventListener(t, n, r || !1) : "function" == typeof e.attachEvent && e.attachEvent("on" + t, n)
            }

            function i(e, t, n, r) {
                "function" == typeof e.removeEventListener ? e.removeEventListener(t, n, r || !1) : "function" == typeof e.detatchEvent && e.detatchEvent("on" + t, n)
            }

            function o(e) {
                var t;
                try {
                    t = e.getBoundingClientRect()
                } catch (e) {}
                return t ? (t.width && t.height || (t = {
                    top: t.top,
                    right: t.right,
                    bottom: t.bottom,
                    left: t.left,
                    width: t.right - t.left,
                    height: t.bottom - t.top
                }), t) : {
                    top: 0,
                    bottom: 0,
                    left: 0,
                    right: 0,
                    width: 0,
                    height: 0
                }
            }

            function a(e, t) {
                for (var n = t; n;) {
                    if (n == e) return !0;
                    n = c(n)
                }
                return !1
            }

            function c(e) {
                var t = e.parentNode;
                return t && 11 == t.nodeType && t.host ? t.host : t && t.assignedSlot ? t.assignedSlot.parentNode : t
            }
        }();
    var VR;
    ! function(e) {
        e.LOAD_START = "load_start", e.LOAD_END = "load_end", e.BEFORE_INIT = "before_init", e.INIT_START = "init_start", e.INIT_END = "init_end", e.JSB_INIT_START = "jsb_init_start", e.JSB_INIT_END = "jsb_init_end", e.BEFORE_AD_INFO_INIT_START = "before_ad_info_init_start", e.AD_INFO_INIT_START = "ad_info_init_start", e.AD_INFO_INIT_END = "ad_info_init_end", e.IDENTIFY_INIT_START = "identify_init_start", e.IDENTIFY_INIT_END = "identify_init_end", e.PLUGIN_INIT_START = "_init_start", e.PLUGIN_INIT_END = "_init_end", e.PIXEL_SEND = "pixel_send", e.PIXEL_SEND_PCM = "pixel_send_PCM", e.JSB_SEND = "jsb_send", e.HTTP_SEND = "http_send", e.HANDLE_CACHE = "handle_cache", e.INIT_ERROR = "init_error", e.PIXEL_EMPTY = "pixel_empty", e.JSB_ERROR = "jsb_error", e.API_ERROR = "api_error", e.PLUGIN_ERROR = "plugin_error", e.CUSTOM_INFO = "custom_info", e.CUSTOM_ERROR = "custom_error", e.CUSTOM_TIMER = "custom_timer"
    }(VR || (VR = {}));
    var JR = function() {
            return "object" === ("undefined" == typeof window ? "undefined" : t(window)) && window["object" === ("undefined" == typeof window ? "undefined" : t(window)) && window.TiktokAnalyticsObject || "ttq"]
        },
        KR = function(e) {
            try {
                var t = JR()._plugins || {};
                return null == t[e] || !!t[e]
            } catch (e) {
                return !0
            }
        },
        WR = ["input[type='button']", "input[type='image']", "input[type='submit']", "button", "[class*=btn]", "[class*=Btn]", "[class*=button]", "[class*=Button]", "[role*=button]", "[id*=btn]", "[id*=Btn]", "[id*=button]", "[id*=Button]", "a"],
        YR = ["[href^='tel:']", "[href^='callto:']", "[href^='sms:']", "[href^='skype:']", "[href^='whatsapp:']", "[href^='mailto:']"],
        qR = function(e) {
            var t = WR.some((function(t) {
                    return e.matches(t)
                })),
                n = YR.some((function(t) {
                    return e.matches(t)
                }));
            return t && !n
        };
    (function(e, n) {
        for (var r, i = [document.body], o = 0; o <= e && i.length;) {
            var a = i.pop();
            if (a === n) return !0;
            if (!("script" === (null == a ? void 0 : a.tagName.toLowerCase()) && (null === (r = a.src) || void 0 === r ? void 0 : r.indexOf("analytics.tiktok.com")) > -1) && (o++, "object" === t(a) && a.children))
                for (var c = a.children.length - 1; c >= 0; c--) i.push(a.children[c])
        }
        return !1
    }).bind(null, 10);
    var XR = {
        info: [],
        error: []
    };

    function zR(e) {
        var t = arguments.length > 1 && void 0 !== arguments[1] ? arguments[1] : {},
            n = arguments.length > 2 && void 0 !== arguments[2] && arguments[2];
        try {
            var r = JR(),
                i = r.getPlugin && r.getPlugin("Monitor") || null;
            i && i.info && "function" == typeof i.info ? i.info.call(i, e, t, n) : KR("Monitor") && XR.info.push({
                event: e,
                detail: t,
                withoutJSB: n
            })
        } catch (e) {}
    }

    function QR(e, t) {
        var n = arguments.length > 2 && void 0 !== arguments[2] ? arguments[2] : {},
            r = arguments.length > 3 && void 0 !== arguments[3] && arguments[3];
        try {
            var i = JR(),
                o = i.getPlugin && i.getPlugin("Monitor") || null;
            o && o.error && "function" == typeof o.error ? o.error.call(o, e, t, n, r) : KR("Monitor") && XR.error.push({
                event: e,
                err: t,
                detail: n,
                withoutJSB: r
            })
        } catch (e) {}
    }
    var ZR, $R = {};

    function eA(e) {
        var t = !(arguments.length > 1 && void 0 !== arguments[1]) || arguments[1];
        t && $R["".concat(e)] || ($R["".concat(e)] = {
            start: performance.now()
        })
    }

    function tA(e) {
        var t = !(arguments.length > 1 && void 0 !== arguments[1]) || arguments[1];
        if (!(t && $R["".concat(e)] && $R["".concat(e)].end)) {
            var n = $R["".concat(e)];
            n && (n.end = performance.now());
            var r = n.end - n.start;
            return zR(VR.CUSTOM_TIMER, {
                custom_name: e,
                latency: Math.ceil(1e3 * r)
            }), r
        }
    }! function(e) {
        e.AUTO_CONFIG_CONTENT = "auto_config_content", e.AUTO_CONFIG_FORM = "auto_config_form", e.AUTO_CONFIG_CLICK = "auto_config_click", e.EB_RULE_COMPUTE_TOKENIZE_TEXT = "eb_rule_compute_tokenize_text", e.EB_RULE_COMPUTE_IMG_SRC = "eb_rule_compute_img_src", e.EB_RULE_COMPUTE_ELEMENT_XPATH = "eb_rule_compute_element_xpath", e.EB_PARAMETER_V2 = "eb_parameter_v2", e.EB_PARAMETER_V1 = "eb_parameter_v1"
    }(ZR || (ZR = {}));
    var nA, rA = ["", "webkit", "Moz", "MS", "ms", "o"],
        iA = window,
        oA = void 0 !== function(e, t) {
            var n, r, i = t[0].toUpperCase() + t.slice(1),
                o = 0;
            for (; o < rA.length;) {
                if ((r = (n = rA[o]) ? n + i : t) in e) return e[r];
                o++
            }
            return
        }(iA, "PointerEvent"),
        aA = "ontouchstart" in iA;
    ! function(e) {
        e[e.Default = 0] = "Default", e[e.Start = 1] = "Start", e[e.Move = 2] = "Move", e[e.End = 4] = "End", e[e.Cancle = 8] = "Cancle"
    }(nA || (nA = {}));
    var cA = {
        pointer: {
            events: ["pointerdown", "pointermove", "pointerup", "pointercancel"],
            handler: function(e) {
                var t = e.type,
                    n = {
                        status: nA.Default,
                        timestamp: Date.now(),
                        position: [e.clientX, e.clientY]
                    };
                return t !== this.events[0] || 0 !== e.button && "touch" !== e.pointerType ? t === this.events[1] ? n.status = nA.Move : t === this.events[2] ? n.status = nA.End : t === this.events[3] && (n.status = nA.Cancle) : n.status = nA.Start, n
            }
        },
        touch: {
            events: ["touchstart", "touchmove", "touchend", "touchcancel"],
            handler: function(e) {
                var t = e.type;
                if (1 !== e.changedTouches.length) return null;
                var n = {
                    status: nA.Default,
                    timestamp: Date.now(),
                    position: [e.changedTouches[0].clientX, e.changedTouches[0].clientY]
                };
                return t === this.events[0] ? n.status = nA.Start : t === this.events[1] ? n.status = nA.Move : t === this.events[2] ? n.status = nA.End : t === this.events[3] && (n.status = nA.Cancle), n.status === nA.Default ? null : n
            }
        },
        mouse: {
            events: ["mousedown", "mousemove", "mouseup"],
            handler: function(e) {
                var t = e.type,
                    n = {
                        status: nA.Default,
                        timestamp: Date.now(),
                        position: [e.clientX, e.clientY]
                    };
                return t === this.events[0] && 0 === e.button ? n.status = nA.Start : t === this.events[1] ? n.status = nA.Move : t === this.events[2] && (n.status = nA.End), n.status & nA.Move && 1 !== e.which && (n.status = nA.End), n.status === nA.Default ? null : n
            }
        }
    };
    "MSPointerEvent" in iA && !("PointerEvent" in iA) && (cA.pointer.events = ["MSPointerDown", "MSPointerMove", "MSPointerUp", "MSPointerCancel"]);
    var sA = 250,
        uA = 9;

    function lA(e, t, n) {
        for (var r = 0; r < e.length; r++) document.addEventListener(e[r], t, n)
    }
    var fA, dA, hA = function(e, t) {
        var n = function(t) {
            var n, r, i;
            return function(o) {
                var a = cA[t].handler(o);
                if (null !== a) {
                    if (a.status & nA.Start) return n = nA.Start, r = a.timestamp, void(i = a.position);
                    if (a.status & nA.End) n & nA.Start && a.timestamp - r < sA && Math.sqrt(Math.pow(a.position[0] - i[0], 2) + Math.pow(a.position[1] - i[1], 2)) < uA && e(o);
                    else if (a.status & nA.Move && n & nA.Start) return
                }
                n = 0, r = 0, i = [0, 0]
            }
        };
        oA ? lA(cA.pointer.events, n("pointer"), t) : aA ? lA(cA.touch.events, n("touch"), t) : lA(cA.mouse.events, n("mouse"), t)
    };
    ! function(e) {
        e.V1 = "v1", e.V2 = "v2"
    }(fA || (fA = {})),
    function(e) {
        e.ELEMENT_V2 = "ELEMENT_V2", e.IMG_SRC = "IMG_SRC", e.TOKENIZE_TEXT = "TOKENIZE_TEXT", e.PAGE_URL_V2 = "PAGE_URL_V2"
    }(dA || (dA = {}));
    var pA = function(e, t, n) {
            var r = document.querySelectorAll(t);
            for (var i in r)
                if (n) {
                    if (Object.is(i, e)) return !0
                } else if (!Object.is(i, e)) return !0;
            return !1
        },
        vA = function(e) {
            var t = document.createRange(),
                n = document.body ? document.body : document.head;
            t.selectNode(n);
            var r = t.createContextualFragment(e);
            n.appendChild(r)
        },
        _A = function(e, t, n) {
            var r = function() {
                    var e = {},
                        t = new Promise((function(t, n) {
                            e.resolve = t, e.reject = n
                        }));
                    return e.promise = t, e
                }(),
                i = new IntersectionObserver((function(e) {
                    e.forEach((function(e) {
                        if (e.isIntersecting) {
                            var i = {
                                result: e.isIntersecting,
                                curValue: t,
                                condition: n
                            };
                            r.resolve(i)
                        }
                    }))
                }), {
                    root: null,
                    rootMargin: "0px",
                    threshold: .5
                });
            return i.observe(e), r.promise
        };

    function gA(e, t) {
        var n = history[e],
            r = "".concat(e, "-").concat(t);
        return function() {
            n.apply(history, arguments);
            var e = new CustomEvent(r, {
                detail: arguments
            });
            window.dispatchEvent(e)
        }
    }
    var yA = function(e) {
            history.pushState = gA("pushState", e), history.replaceState = gA("replaceState", e)
        },
        mA = function(e, t) {
            var n = e.getComputedStyle(t);
            return "none" !== n.display && ("visible" === n.visibility && !(Number(n.opacity) < .1))
        },
        EA = function(e) {
            var t = e;
            if ("string" == typeof e) try {
                t = decodeURI(e)
            } catch (n) {
                t = e
            }
            return t
        },
        bA = function(e, t) {
            try {
                var n = new URL(e);
                return n.searchParams.delete(t), n.toString()
            } catch (t) {
                return e
            }
        },
        TA = '"pixelMethod":"standard"',
        IA = function(e, t) {
            try {
                var n = e.split(TA),
                    r = "";
                return t && (r += ',"is_button":"true"'), r ? n[0] + TA + r + n[1] : e
            } catch (t) {
                return e
            }
        },
        OA = function(e) {
            try {
                var t = e.split(TA);
                return t[0] + TA + ',"is_standard_mode":"1"' + t[1]
            } catch (t) {
                return e
            }
        },
        SA = function(e, t) {
            try {
                var n = e.split(TA),
                    r = ',"eb_version":"' + t + '"';
                return n[0] + TA + r + n[1]
            } catch (t) {
                return e
            }
        },
        NA = /[\-!$><-==&_\/\?\.,0-9:; \]\[%~\"\{\}\)\(\+\@\^\`]/g,
        RA = /((([a-z])(?=[A-Z]))|(([A-Z])(?=[A-Z][a-z])))/g,
        AA = /\s+/g,
        CA = {
            TOKENIZE_TEXT: "rule_compute_tokenize_text_error",
            IMG_SRC: "rule_compute_img_src_error",
            ELEMENT_V2: "rule_compute_element_v2_xpath_error"
        },
        PA = {
            TOKENIZE_TEXT: ZR.EB_RULE_COMPUTE_TOKENIZE_TEXT,
            IMG_SRC: ZR.EB_RULE_COMPUTE_IMG_SRC,
            ELEMENT_V2: ZR.EB_RULE_COMPUTE_ELEMENT_XPATH
        },
        wA = function(e) {
            var t;
            return null === e ? null : (null === (t = e.innerText) || void 0 === t ? void 0 : t.length) > 0 ? function(e) {
                return e.replace(NA, " ").replace(RA, (function(e) {
                    return "".concat(e, " ")
                })).replace(AA, " ").toLowerCase().trim()
            }(e.innerText) : null
        },
        kA = function(e, t) {
            var n;
            return (null === (n = wA(e)) || void 0 === n ? void 0 : n.toLowerCase()) === t
        },
        MA = function(e, t) {
            return function(e) {
                var t, n;
                if ("IMG" === e.tagName) return e.getAttribute("src") || "";
                if (window.getComputedStyle) {
                    var r = window.getComputedStyle(e).getPropertyValue("background-image");
                    if (null !== r && "none" !== r && r.length > 0) return r
                }
                return "INPUT" === e.tagName && e.getAttribute("src") || (null === (n = null === (t = e.getElementsByTagName("img")) || void 0 === t ? void 0 : t[0]) || void 0 === n ? void 0 : n.getAttribute("src")) || null
            }(e) === t
        },
        LA = function(e, t) {
            var n;
            return !!(null === (n = null == e ? void 0 : e.matches) || void 0 === n ? void 0 : n.call(e, t))
        },
        DA = function(e, t, n, r, i) {
            var o = null,
                a = !1,
                c = null;
            r && (o = PA[t]) && eA(o);
            var s = null;
            switch (t) {
                case "TOKENIZE_TEXT":
                    s = kA;
                    break;
                case "IMG_SRC":
                    s = MA;
                    break;
                case "ELEMENT_V2":
                    s = LA
            }
            for (var u = 0; u < 5 && !["HTML", "BODY"].includes(null == e ? void 0 : e.tagName); u++) {
                if ((null == e ? void 0 : e.matches("input[type='button'], input[type='image'], input[type='submit'], button, [class*=btn], [class*=Btn], [class*=button], [class*=Button], [role*=button], [href^='tel: '], [href^='callto: '], [href^='mailto: '], [href^='sms: '], [href^='skype: '], [href^='whatsapp: '], [id*=btn], [id*=Btn], [id*=button], [id*=Button], a")) && (null == s ? void 0 : s(e, n))) {
                    a = !0, c = e;
                    break
                }
                e = e.parentElement
            }
            return r && o && tA(o), i ? c : a
        };
    String.prototype.startsWith || Object.defineProperty(String.prototype, "startsWith", {
        value: function(e, t) {
            return t = !t || t < 0 ? 0 : +t, this.substring(t, t + e.length) === e
        }
    }), String.prototype.endsWith || (String.prototype.endsWith = function(e, t) {
        return (void 0 === t || t > this.length) && (t = this.length), this.substring(t - e.length, t) === e
    });
    var xA = function(e, t, n, r) {
            switch (t) {
                case "EQUALS":
                    if ([dA.TOKENIZE_TEXT, dA.IMG_SRC, dA.ELEMENT_V2].includes(r)) try {
                        return DA(e, r, n, !0, !1)
                    } catch (e) {
                        return QR(VR.CUSTOM_ERROR, e, {
                            custom_name: "eb_jelly_error",
                            custom_enum: CA[r]
                        }), !1
                    } else if ("ELEMENT" == r) try {
                        for (var i = document.querySelectorAll(n), o = Array.prototype.slice.call(i), a = 0; a < o.length; a++)
                            if (o[a].contains(e)) return !0
                    } catch (e) {
                        return QR(VR.CUSTOM_ERROR, e, {
                            custom_name: "eb_jelly_error",
                            custom_enum: "rule_compute_element_xpath_error"
                        }), !1
                    }
                    if (n.split(";").filter((function(t) {
                            return e == t
                        })).length > 0) return !0;
                    break;
                case "LT":
                    if (e < n) return !0;
                    break;
                case "GT":
                    if (e > n) return !0;
                    break;
                case "LT_OR_EQUAL":
                    if (e <= n) return !0;
                    break;
                case "GT_OR_EQUAL":
                    if (e >= n) return !0;
                    break;
                case "CONTAINS":
                    if (n.split(";").filter((function(t) {
                            return (null == t ? void 0 : t.length) > 0 && e.indexOf(t) > -1
                        })).length > 0) return !0;
                    break;
                case "DOES_NOT_EQUAL":
                    if (0 == n.split(";").filter((function(t) {
                            return e == t
                        })).length) return !0;
                    break;
                case "DOES_NOT_CONTAIN":
                    if (-1 == e.indexOf(n)) return !0;
                    break;
                case "STARTS_WITH":
                    if (e.startsWith(n)) return !0;
                    break;
                case "ENDS_WITH":
                    if (e.endsWith(n)) return !0;
                    break;
                case "MATCHES_REGEX":
                    if (n.test(e)) return !0;
                    break;
                case "MATCHES_REGEX_IGNORE_CASE":
                    if (!n.test(e)) return !0;
                    break;
                case "MATCHES_CSS_SELECTOR":
                    if (pA(e, n, !0)) return !0;
                    break;
                case "DOSE_NOT_MATCHES_CSS_SELECTOR":
                    if (pA(e, n, !1)) return !0
            }
            return !1
        },
        jA = {
            click: ["ELEMENT", "TOKENIZE_TEXT", "IMG_SRC", "ELEMENT_V2", "ELEMENT_CLASSES", "ELEMENT_ID", "ELEMENT_TARGET", "ElEMENT_URL", "ELEMENT_TEXT"],
            pageview: ["PAGE_URL", "PAGE_URL_V2", "PAGE_HOSTNAME", "PAGE_PATH", "REFERRER"],
            visibility: ["ELEMENT", "ELEMENT_CLASSES", "ELEMENT_ID"],
            history_change: ["NEW_HISTORY_FRAGMENT", "OLD_HISTORY_FRAGMENT", "NEW_HISTORY_STATE", "OLD_HISTORY_STATE", "HISTORY_SOURCE"]
        },
        UA = "ttclid",
        FA = function() {
            function e() {
                i(this, e)
            }
            return a(e, [{
                key: "dispatcher",
                value: function(e, t, n, r) {
                    var i, o = arguments.length > 4 && void 0 !== arguments[4] ? arguments[4] : document,
                        a = t.variable_type,
                        c = O("visibility" == e ? ["pageview", "history_change", "visibility"] : ["pageview", "history_change", "click"]);
                    try {
                        for (c.s(); !(i = c.n()).done;) {
                            var s = i.value;
                            if (jA[s].indexOf(a) > -1) {
                                var u = void 0;
                                switch (s) {
                                    case "click":
                                        u = this.click(a, n);
                                        break;
                                    case "pageview":
                                        u = this.pageview(a);
                                        break;
                                    case "history_change":
                                        u = this.history_change(a, n, r);
                                        break;
                                    case "visibility":
                                        u = this.visibility(a, t.value, o)
                                }
                                return u
                            }
                        }
                    } catch (e) {
                        c.e(e)
                    } finally {
                        c.f()
                    }
                }
            }, {
                key: "click",
                value: function(e, t) {
                    var n;
                    if (!t) return !1;
                    switch (e) {
                        case "ELEMENT":
                        case "ELEMENT_V2":
                        case "TOKENIZE_TEXT":
                        case "IMG_SRC":
                        case "ELEMENT_TARGET":
                            n = t.target;
                            break;
                        case "ELEMENT_CLASSES":
                            n = t.target.className;
                            break;
                        case "ELEMENT_ID":
                            n = t.target.id;
                            break;
                        case "ElEMENT_URL":
                            n = t.target.href || t.target.src || "";
                            break;
                        case "ELEMENT_TEXT":
                            n = t.target.text || "";
                            break;
                        default:
                            n = null
                    }
                    return n
                }
            }, {
                key: "pageview",
                value: function(e) {
                    var t;
                    switch (e) {
                        case "PAGE_URL":
                        case "PAGE_URL_V2":
                            t = bA(location.href, UA);
                            break;
                        case "PAGE_HOSTNAME":
                            t = location.hostname;
                            break;
                        case "PAGE_PATH":
                            t = location.pathname;
                            break;
                        case "REFERRER":
                            t = bA(document.referrer, UA);
                            break;
                        default:
                            t = null
                    }
                    return t
                }
            }, {
                key: "history_change",
                value: function(e, t, n) {
                    var r;
                    switch (e) {
                        case "NEW_HISTORY_FRAGMENT":
                            r = location.hash;
                            break;
                        case "OLD_HISTORY_FRAGMENT":
                            r = n.old_hash;
                            break;
                        case "NEW_HISTORY_STATE":
                            r = history.state;
                            break;
                        case "OLD_HISTORY_STATE":
                            r = n.old_state;
                            break;
                        case "HISTORY_SOURCE":
                            r = t.type;
                            break;
                        default:
                            r = null
                    }
                    return r
                }
            }, {
                key: "visibility",
                value: function(e, t) {
                    var n, r = arguments.length > 2 && void 0 !== arguments[2] ? arguments[2] : document;
                    switch (e) {
                        case "ELEMENT_ID":
                            n = "#" + t;
                            break;
                        case "ELEMENT_CLASS":
                            n = "." + t;
                            break;
                        case "ELEMENT":
                            n = t;
                            break;
                        default:
                            n = null
                    }
                    return r.querySelector(n)
                }
            }]), e
        }(),
        BA = {
            exports: {}
        };
    ! function(e) {
        function t(e) {
            if (e) return function(e) {
                for (var n in t.prototype) e[n] = t.prototype[n];
                return e
            }(e)
        }
        e.exports = t, t.prototype.on = t.prototype.addEventListener = function(e, t) {
            return this._callbacks = this._callbacks || {}, (this._callbacks["$" + e] = this._callbacks["$" + e] || []).push(t), this
        }, t.prototype.once = function(e, t) {
            function n() {
                this.off(e, n), t.apply(this, arguments)
            }
            return n.fn = t, this.on(e, n), this
        }, t.prototype.off = t.prototype.removeListener = t.prototype.removeAllListeners = t.prototype.removeEventListener = function(e, t) {
            if (this._callbacks = this._callbacks || {}, 0 == arguments.length) return this._callbacks = {}, this;
            var n, r = this._callbacks["$" + e];
            if (!r) return this;
            if (1 == arguments.length) return delete this._callbacks["$" + e], this;
            for (var i = 0; i < r.length; i++)
                if ((n = r[i]) === t || n.fn === t) {
                    r.splice(i, 1);
                    break
                }
            return 0 === r.length && delete this._callbacks["$" + e], this
        }, t.prototype.emit = function(e) {
            this._callbacks = this._callbacks || {};
            for (var t = new Array(arguments.length - 1), n = this._callbacks["$" + e], r = 1; r < arguments.length; r++) t[r - 1] = arguments[r];
            if (n) {
                r = 0;
                for (var i = (n = n.slice(0)).length; r < i; ++r) n[r].apply(this, t)
            }
            return this
        }, t.prototype.listeners = function(e) {
            return this._callbacks = this._callbacks || {}, this._callbacks["$" + e] || []
        }, t.prototype.hasListeners = function(e) {
            return !!this.listeners(e).length
        }
    }(BA);
    var GA, HA, VA = BA.exports,
        JA = function(e) {
            s(n, e);
            var t = h(n);

            function n(e, r) {
                var o;
                return i(this, n), (o = t.call(this)).BaseConf = e, o.SDK_ID = r, o.BaseConf.forEach((function(e) {
                    e.id = e.code_id, e.conditions = e.conditions || [], e.conditions.forEach((function(e) {
                        e.result = !1
                    }))
                })), o
            }
            return a(n, [{
                key: "sendDebugEvent",
                value: function(e, t, n) {
                    var r = this.BaseConf,
                        i = [];
                    r.forEach((function(e) {
                        e.code_id == t && (e.conditions = n), i.push(e)
                    }));
                    var o = {
                        sdk_id: this.SDK_ID,
                        event_name: e,
                        data: i
                    };
                    this.emit("jelly_message", o)
                }
            }]), n
        }(VA);
    ! function(e) {
        e[e.WRONG = -1] = "WRONG", e[e.KEEP = 0] = "KEEP", e[e.ARRAY = -2] = "ARRAY", e[e.TURNINTOINTEGER = 1] = "TURNINTOINTEGER", e[e.TURNINTODECIMAL = 2] = "TURNINTODECIMAL"
    }(GA || (GA = {})),
    function(e) {
        e[e.CLICK_EVENT = 0] = "CLICK_EVENT", e[e.DESTINATION_URL = 1] = "DESTINATION_URL"
    }(HA || (HA = {}));
    var KA, WA = function(e) {
            var t, n = {};
            try {
                if (eA(ZR.EB_PARAMETER_V1), e.currency && (n.currency = e.currency), e.value) {
                    document.querySelectorAll(e.value).length;
                    var r = document.querySelector(e.value);
                    (null == r ? void 0 : r.innerHTML) && (n.ori_value = r.innerHTML, n.value = YA(null === (t = r.innerHTML) || void 0 === t ? void 0 : t.trim(), e.value_index, e.value_parsing_method))
                }
                if (e.contents && void 0 !== e.contents[0].content_type && (1 === e.contents[0].content_type && (n.content_type = "product"), 2 === e.contents[0].content_type && (n.content_type = "product_group")), e.contents && e.contents[0].content_name) {
                    var i = document.querySelector(e.contents[0].content_name);
                    n.content_name = null == i ? void 0 : i.innerHTML
                }
                if (e.contents && e.contents[0].content_id)
                    if (e.contents[0].content_from === HA.CLICK_EVENT) {
                        var o = document.querySelector(e.contents[0].content_id);
                        n.content_id = null == o ? void 0 : o.innerHTML
                    } else if (e.contents[0].content_from === HA.DESTINATION_URL) {
                    var a = new URL(location.href);
                    if (e.contents[0].content_id.startsWith("path")) {
                        var c = a.pathname.split("/"),
                            s = e.contents[0].content_id.split("|")[1];
                        n.content_id = c[s]
                    }
                    if (e.contents[0].content_id.startsWith("search")) {
                        var u = new URLSearchParams(a.search),
                            l = e.contents[0].content_id.split("|")[1];
                        n.content_id = u.get(l)
                    }
                }
                return tA(ZR.EB_PARAMETER_V1), n
            } catch (e) {
                return tA(ZR.EB_PARAMETER_V1), QR(VR.CUSTOM_ERROR, e, {
                    custom_name: "eb_jelly_error",
                    custom_enum: "dynamicParameter_v1_error"
                }), n
            }
        },
        YA = function(e, t, n) {
            var r = "";
            if (-1 === t || void 0 === t) {
                var i = XA(e)[0];
                r = void 0 !== i ? qA(i, n) : ""
            } else {
                var o = XA(e)[t];
                r = void 0 !== o ? qA(o, n) : ""
            }
            return r
        },
        qA = function(e, t) {
            var n = "";
            if (t !== GA.KEEP && t !== GA.WRONG || (n = e), t === GA.TURNINTOINTEGER && (n = e.replace(/[,\.]/g, "")), t === GA.TURNINTODECIMAL) {
                var r = e.split(/[,\.]/g),
                    i = "";
                r.forEach((function(e, t) {
                    t < r.length - 1 ? i += e : i += "." + e
                })), n = i
            }
            return n
        },
        XA = function(e) {
            for (var t, n = /[\d|\.|,]+/gm, r = []; null !== (t = n.exec(e));) t.index === n.lastIndex && n.lastIndex++, t.forEach((function(e) {
                r.push(e)
            }));
            return r
        },
        zA = function(e, t, n) {
            try {
                var r = e.split(TA),
                    i = "";
                return Object.keys(t).forEach((function(e) {
                    null === t[e] && void 0 === t[e] || (i += ',"' + e + '":"' + ("value" !== e ? encodeURIComponent(t[e]) : t[e]) + '"')
                })), n && (i += ',"dynamic_parameter_config":' + JSON.stringify(n)), i ? r[0] + TA + i + r[1] : e
            } catch (t) {
                return QR(VR.CUSTOM_ERROR, t, {
                    custom_name: "eb_jelly_error",
                    custom_enum: "dynamicParameter_v1_transform_code_error"
                }), e
            }
        },
        QA = function(e, t) {
            var n, r;
            if (!e || "" === e) return null;
            var i, o = null === (n = e.match(/closest\$([^$]+)\$/)) || void 0 === n ? void 0 : n[1],
                a = null === (r = e.match(/children\$([^$]+)\$/)) || void 0 === r ? void 0 : r[1];
            if (t && o && a) {
                Element.prototype.closest || (Element.prototype.closest = function(e) {
                    var t = this;
                    if (!document.contains(t)) return null;
                    do {
                        if (t.matches(e)) return t;
                        t = t.parentElement || t.parentNode
                    } while (null !== t && 1 === t.nodeType);
                    return null
                });
                var c = t.closest(o);
                i = null == c ? void 0 : c.querySelector(a)
            } else i = t && a ? t.querySelector(a) : document.querySelector(e);
            return i
        },
        ZA = function(e, t) {
            var n, r = {};
            try {
                if (eA(ZR.EB_PARAMETER_V2), e.currency && (r.currency = e.currency), e.value) {
                    var i = QA(e.value, t);
                    (null == i ? void 0 : i.innerHTML) && (r.ori_value = i.innerHTML, r.value = YA(null === (n = i.innerHTML) || void 0 === n ? void 0 : n.trim(), e.value_index, e.value_parsing_method)), r.value || zR(VR.CUSTOM_INFO, {
                        custom_name: "eb_jelly_info",
                        custom_enum: "dynamic_parameter_v2_value_empty",
                        extJSON: {
                            selector: e.value
                        }
                    })
                }
                return e.contents && e.contents.length > 0 && (r.contents = [], function(e, t, n) {
                    e.map((function(e) {
                        var r = e.content_type,
                            i = e.content_id,
                            o = e.content_from,
                            a = {};
                        if (r && (1 === r ? a.content_type = "product" : 2 === r && (a.content_type = "product_group")), i) {
                            if (o === HA.CLICK_EVENT) {
                                var c = QA(i, n);
                                (null == c ? void 0 : c.innerText) && (a.content_id = null == c ? void 0 : c.innerText)
                            } else if (o === HA.DESTINATION_URL) {
                                var s = new URL(location.href);
                                if (i.startsWith("path")) {
                                    var u = s.pathname.split("/"),
                                        l = i.split("|")[1];
                                    a.content_id = u[l]
                                }
                                if (i.startsWith("search")) {
                                    var f = new URLSearchParams(s.search),
                                        d = i.split("|")[1];
                                    a.content_id = f.get(d) || void 0
                                }
                            }
                            a.content_id || zR(VR.CUSTOM_INFO, {
                                custom_name: "eb_jelly_info",
                                custom_enum: "dynamic_parameter_v2_content_id_empty",
                                extJSON: {
                                    selector: i
                                }
                            })
                        }
                        o && (a.content_from = o), t.push(a)
                    }))
                }(e.contents, r.contents, t)), tA(ZR.EB_PARAMETER_V2), r
            } catch (e) {
                return tA(ZR.EB_PARAMETER_V2), QR(VR.CUSTOM_ERROR, e, {
                    custom_name: "eb_jelly_error",
                    custom_enum: "dynamicParameter_v2_error"
                }), r
            }
        },
        $A = function(e, t, n) {
            try {
                var r = e.split(TA),
                    i = "";
                return Object.keys(t).forEach((function(e) {
                    if (null !== t[e] || void 0 !== t[e])
                        if ("contents" === e) {
                            var n = t[e];
                            i += ',"' + e + '":[', null == n || n.map((function(e, t) {
                                i += "{";
                                var r = Object.keys(e);
                                r.forEach((function(t, n) {
                                    "content_id" === t && e[t] && (e[t] = encodeURIComponent(e[t])), i += '"' + t + '":"' + e[t] + '"' + (n === (null == r ? void 0 : r.length) - 1 ? "" : ",")
                                })), i += "}" + (t === (null == n ? void 0 : n.length) - 1 ? "" : ",")
                            })), i += "]"
                        } else i += ',"' + e + '":"' + ("value" !== e ? encodeURIComponent(t[e]) : t[e]) + '"'
                })), n && (i += ',"dynamic_parameter_config":' + JSON.stringify(n)), i ? r[0] + TA + i + r[1] : e
            } catch (t) {
                return QR(VR.CUSTOM_ERROR, t, {
                    custom_name: "eb_jelly_error",
                    custom_enum: "dynamicParameter_v2_transform_error"
                }), e
            }
        },
        eC = new FA,
        tC = function(e) {
            s(n, e);
            var t = h(n);

            function n(e, r, o, a) {
                var c;
                return i(this, n), (c = t.call(this)).on("jelly_message", a), c.SendEvent = new JA(r, o), c.SendEvent.on("jelly_message", (function(e) {
                    c.emit("jelly_message", e)
                })), c.CLICK = e.CLICK || [], c.PAGEVIEW = e.PAGEVIEW || [], c.VISIBILITY = e.VISIBILITY || [], c.HISTORY_CHANGE = e.HISTORY_CHANGE || [], c.SDK_ID = o || "", c.click(), c.pageview(), c.visibility(), c
            }
            return a(n, [{
                key: "dispatcher",
                value: function(e, t, n, r) {
                    if (t) {
                        var i, o, a = O(t);
                        try {
                            for (a.s(); !(i = a.n()).done;) {
                                var c, s = i.value,
                                    u = [],
                                    l = O(s.conditions);
                                try {
                                    for (l.s(); !(c = l.n()).done;) {
                                        var f = c.value,
                                            d = eC.dispatcher(e, f, n, r),
                                            h = xA(d, f.operator, f.value, f.variable_type);
                                        if ("history_change" !== e && "pageview" !== e || (h = h || xA(EA(d), f.operator, f.value, f.variable_type)), h) {
                                            var p = !1,
                                                v = (o = f.variable_type, Object.values(dA).includes(o) ? fA.V2 : fA.V1);
                                            try {
                                                p = ["ELEMENT", dA.TOKENIZE_TEXT, dA.IMG_SRC, dA.ELEMENT_V2].includes(f.variable_type) && qR(d)
                                            } catch (e) {
                                                p = !1, QR(VR.CUSTOM_ERROR, e, {
                                                    custom_name: "button_check_jelly_error",
                                                    custom_enum: "auto_click",
                                                    extJSON: {
                                                        element: d
                                                    }
                                                })
                                            }
                                            var _ = IA(s.code, p);
                                            if (_ = OA(_), _ = SA(_, v), f.dynamic_parameter) try {
                                                var g = void 0,
                                                    y = void 0;
                                                switch (f.variable_type) {
                                                    case dA.PAGE_URL_V2:
                                                        g = ZA(f.dynamic_parameter, null), y = $A(_, g, f.dynamic_parameter);
                                                        break;
                                                    case dA.ELEMENT_V2:
                                                    case dA.TOKENIZE_TEXT:
                                                    case dA.IMG_SRC:
                                                        var m = DA(d, f.variable_type, f.value, !1, !0);
                                                        g = ZA(f.dynamic_parameter, m), y = $A(_, g, f.dynamic_parameter);
                                                        break;
                                                    default:
                                                        g = WA(f.dynamic_parameter), y = zA(_, g, f.dynamic_parameter)
                                                }
                                                vA(y)
                                            } catch (e) {
                                                e(VR.CUSTOM_ERROR, e, {
                                                    custom_name: "eb_jelly_error",
                                                    custom_enum: "dynamic_parameter_code_concat"
                                                }), vA(_)
                                            } else vA(_);
                                            this.SendEvent.sendDebugEvent("jelly." + e, s.code_id, u)
                                        }
                                        u.push(Object.assign(f, {
                                            cur_value: d,
                                            result: h
                                        }))
                                    }
                                } catch (e) {
                                    l.e(e)
                                } finally {
                                    l.f()
                                }
                            }
                        } catch (e) {
                            a.e(e)
                        } finally {
                            a.f()
                        }
                    }
                }
            }, {
                key: "click",
                value: function() {
                    var e = this;
                    hA((function(t) {
                        e.dispatcher("click", e.CLICK, t)
                    }), !0)
                }
            }, {
                key: "pageview",
                value: function() {
                    this.dispatcher("pageview", this.PAGEVIEW), this.history_change(this.PAGEVIEW)
                }
            }, {
                key: "history_change",
                value: function() {
                    var e = arguments.length > 0 && void 0 !== arguments[0] ? arguments[0] : this.HISTORY_CHANGE,
                        t = this,
                        n = history.state,
                        r = location.hash,
                        i = location.href;
                    yA(this.SDK_ID), window.addEventListener("pushState-".concat(this.SDK_ID), (function(r) {
                        if (location.href != i) {
                            var o = {
                                old_state: n
                            };
                            t.dispatcher("history_change", e, r, o), n = history.state, i = location.href
                        }
                    })), window.addEventListener("replaceState-".concat(this.SDK_ID), (function() {
                        if (location.href != i) {
                            var r = {
                                old_state: n
                            };
                            t.dispatcher("history_change", e, r), n = history.state, i = location.href
                        }
                    })), window.addEventListener("popstate", (function(n) {
                        if (location.href != i) {
                            var o = {
                                old_hash: r
                            };
                            t.dispatcher("history_change", e, n, o), r = location.hash, i = location.href
                        }
                    }))
                }
            }, {
                key: "visibility",
                value: function() {
                    if (!(this.VISIBILITY.length < 1)) {
                        var e = this.VISIBILITY,
                            t = this.SendEvent.sendDebugEvent.bind(this.SendEvent);
                        new MutationObserver(nC(e, t, window)).observe(document, {
                            childList: !0,
                            characterData: !0,
                            subtree: !0,
                            attributes: !0
                        });
                        for (var n = document.getElementsByTagName("iframe"), r = 0; r < n.length; r++) try {
                            var i = n[r].contentWindow;
                            if (null != i) new MutationObserver(nC(e, t, i)).observe(i.document, {
                                childList: !0,
                                characterData: !0,
                                subtree: !0,
                                attributes: !0
                            })
                        } catch (e) {}
                    }
                }
            }]), n
        }(VA),
        nC = function(e, t) {
            var n = arguments.length > 2 && void 0 !== arguments[2] ? arguments[2] : window,
                r = {};
            return function() {
                e.forEach((function(e) {
                    var i = !0,
                        o = [],
                        a = [];
                    e.conditions.forEach((function(e) {
                        if (jA.visibility.indexOf(e.variable_type) > -1) {
                            var t = eC.dispatcher("visibility", e, null, null, n.document),
                                c = "_" + e.value;
                            t && mA(n, t) && !r[c] && (o.push(_A(t, "", e)), r[c] = !0)
                        } else {
                            var s = eC.dispatcher("visibility", e),
                                u = xA(s, e.operator, e.value, e.variable_type);
                            u || (i = !1), a.push(Object.assign(e, {
                                cur_value: s,
                                result: u
                            }))
                        }
                    })), o.length > 0 && Promise.all(o).then((function(n) {
                        var r, o = !0,
                            c = O(n);
                        try {
                            for (c.s(); !(r = c.n()).done;) {
                                var s = r.value;
                                a.push(Object.assign(s.condition, {
                                    cur_value: s.curValue,
                                    result: s.result
                                })), s.result && i || (o = !1)
                            }
                        } catch (e) {
                            c.e(e)
                        } finally {
                            c.f()
                        }
                        o && vA(e.code), t("jelly.visibility", e.code_id, a)
                    }), (function() {}))
                }))
            }
        },
        rC = function(e) {
            s(n, e);
            var t = h(n);

            function n(e, r) {
                var o;
                if (i(this, n), (o = t.call(this)).BaseConf = r, o.SDK_ID = e, window.jelly_tool_events && window.jelly_tool_events.length && window.jelly_tool_events.forEach((function(e) {
                        o.on(e.name, e.callback)
                    })), o.emit("jelly_event", {
                        SDK_ID: e,
                        BaseConf: r || []
                    }), o.BaseConf instanceof Array) {
                    if (self._jelly_sdks = self._jelly_sdks || {}, self._jelly_sdks[e]) return d(o);
                    self._jelly_sdks[e] = !0;
                    var a = o.dispatch();
                    o.trigger = new tC(a, r, e, (function(e) {
                        o.emit("jelly_message", e)
                    }))
                }
                return o
            }
            return a(n, [{
                key: "dispatch",
                value: function() {
                    var e = {
                        CLICK: [],
                        PAGEVIEW: [],
                        VISIBILITY: [],
                        HISTORY_CHANGE: []
                    };
                    return this.BaseConf.forEach((function(t) {
                        var n = {
                            code_id: t.code_id,
                            code: t.code,
                            conditions: t.conditions || []
                        };
                        void 0 !== t.trigger_type && e[t.trigger_type] && e[t.trigger_type].push(n)
                    })), e
                }
            }]), n
        }(VA);
    window.TiktokJelly = rC;
    var iC = Hr();

    function oC() {
        var e = window[iC];
        return e && e._i || {}
    }

    function aC(e) {
        var t = window[iC],
            n = Pi().pixelCode,
            r = void 0 === n ? "" : n;
        ["instance", "instances", "loadPixel", "enableCookie", "disableCookie", "holdConsent", "revokeConsent", "grantConsent"].forEach((function(n) {
                Object.defineProperty(t, n, {
                    get: function() {
                        return function() {
                            try {
                                var t = Array.prototype.slice.call(arguments);
                                return setTimeout((function() {
                                    Ri(Tr.CUSTOM_INFO, {
                                        pixelCode: r,
                                        custom_name: n,
                                        custom_enum: JSON.stringify(t)
                                    })
                                })), e[n].apply(e, t)
                            } catch (e) {
                                return Ai(Tr.API_ERROR, e, {
                                    extJSON: {
                                        api: n
                                    }
                                }), {}
                            }
                        }
                    },
                    set: function() {}
                })
            })), ["page", "track", "identify"].forEach((function(n) {
                Object.defineProperty(t, n, {
                    get: function() {
                        return function() {
                            try {
                                var t = 1 === arguments.length && void 0 === arguments[0] ? [] : Array.prototype.slice.call(arguments);
                                return setTimeout((function() {
                                    var e = JSON.stringify(t.map((function(e) {
                                        return $n(e) ? Object.keys(e) : e
                                    })));
                                    Ri(Tr.CUSTOM_INFO, {
                                        pixelCode: r,
                                        custom_name: n,
                                        custom_enum: e
                                    })
                                })), To(n, t), e[n].apply(e, t)
                            } catch (e) {
                                return Ai(Tr.API_ERROR, e, {
                                    extJSON: {
                                        api: n
                                    }
                                }), {}
                            }
                        }
                    },
                    set: function() {}
                })
            })), window[iC]._mounted = !0, window[iC].initialize = !0,
            function(e) {
                Gr = e
            }(window[iC])
    }

    function cC(e) {
        var t = arguments.length > 1 && void 0 !== arguments[1] ? arguments[1] : sl;
        null == e || e.resetCookieExpires();
        var n = window[iC],
            r = oC();
        if (Object.entries(r).forEach((function(n) {
                var r = _(n, 2),
                    i = r[0],
                    o = r[1];
                if (!o._init && ("Tealium" === qr() || Kr() || o.info) && (e.getReporter(i) ? Ci(Ir.DUPLICATE_PIXEL_CODE) : t({
                        id: i,
                        type: So.PIXEL_CODE,
                        info: o.info,
                        options: o.options,
                        rules: o.rules,
                        plugins: o.plugins
                    }), o._init = !0, o.length > 0))
                    for (; o.length;) {
                        var a = o.shift();
                        if (a) {
                            var c = g(a),
                                s = c[0],
                                u = c.slice(1),
                                l = e.instance(i);
                            if (l) switch (s) {
                                case "identify":
                                    e.identify(u[0], u[1]);
                                    break;
                                case "page":
                                    e.page(u[0]);
                                    break;
                                case "track":
                                    l.track(u[0], u[1], u[2] || {});
                                    break;
                                default:
                                    l[s] ? l[s](u[0], u[1], u[2] || {}) : Ai(Tr.CUSTOM_ERROR, new Error("action not find: ".concat(l[s])))
                            }
                        }
                    }
            })), n.length > 0)
            for (; n.length;) {
                var i = n.shift();
                if (i) {
                    var o = g(i),
                        a = o[0],
                        c = o.slice(1);
                    switch ("Tealium" !== qr() && To(a, c), a) {
                        case "identify":
                            e.identify(c[0], c[1]);
                            break;
                        case "page":
                            e.page(c[0]);
                            break;
                        case "track":
                            e.track(c[0], c[1], c[2] || {});
                            break;
                        case "enableCookie":
                            e.enableCookie();
                            break;
                        case "disableCookie":
                            e.disableCookie();
                            break;
                        case "holdConsent":
                            e.holdConsent();
                            break;
                        case "revokeConsent":
                            e.revokeConsent();
                            break;
                        case "grantConsent":
                            e.grantConsent()
                    }
                }
            }
    }
    try {
        ! function() {
            var e = Pi().pixelCode,
                t = Vr(),
                n = pi(),
                r = vi();
            if (function(e, t, n) {
                    il(e, n), ol(e), al(e), cl()
                }(t, 0, n), Xr("Monitor")) {
                var i = function() {
                    try {
                        return Wu.get(br.MONITOR_PLUGIN) || null
                    } catch (e) {
                        return null
                    }
                }();
                null == i || i.info(Tr.BEFORE_INIT, {
                    pixelCode: e,
                    extJSON: {
                        stack: fi(e)
                    }
                })
            }
            if (t) {
                t._mounted ? (Ri(Tr.HANDLE_CACHE, {
                    pixelCode: e
                }), cC(t)) : (KA = function(e) {
                    var t = arguments.length > 1 && void 0 !== arguments[1] ? arguments[1] : or.OFFSITE;
                    return qu.toConstantValue(e), Xu.toConstantValue(t), Wu.get(br.TTQ)
                }(n, r), window[iC] = function(e, t) {
                    return ["getReporter", "usePlugin", "getPlugin", "resetCookieExpires"].forEach((function(n) {
                        e[n] = function() {
                            for (var e = arguments.length, r = new Array(e), i = 0; i < e; i++) r[i] = arguments[i];
                            return t[n].apply(t, r)
                        }
                    })), e.context = t.context, e.reporters = t.reporters, e
                }(t, KA), cC(KA), aC(KA));
                var o = Wu.get(mo.IsOnsitePage);
                o.value = r === or.ONSITE || t.reporters.every((function(e) {
                        return e.isOnsite()
                    })), Wu.rebind(mo.IsOnsitePage).toConstantValue(o),
                    function(e) {
                        e.reporters.forEach((function(e) {
                            e.rules && new rC(e.getReporterId(), e.rules)
                        }))
                    }(t)
            }
        }()
    } catch (As) {
        Ai(Tr.INIT_ERROR, As)
    }
}();